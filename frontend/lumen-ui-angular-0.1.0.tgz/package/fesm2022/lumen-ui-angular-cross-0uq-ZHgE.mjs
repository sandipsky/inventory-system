var cross_default = "<svg width=\"20\" height=\"20\" viewBox=\"0 0 20 20\" fill=\"none\" xmlns=\"http://www.w3.org/2000/svg\">\n<path d=\"M13.3337 6.66675L10.0003 10.0001L6.66699 13.3334M6.66699 6.66675L10.0003 10.0001L13.3337 13.3334\" stroke=\"#555755\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>\n</svg>";
export { cross_default as default };

//# sourceMappingURL=lumen-ui-angular-cross-0uq-ZHgE.mjs.map