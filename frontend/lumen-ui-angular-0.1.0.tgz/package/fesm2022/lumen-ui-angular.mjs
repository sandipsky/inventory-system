import * as i0 from "@angular/core";
import { ApplicationRef, ChangeDetectionStrategy, ChangeDetectorRef, Component, DOCUMENT, DestroyRef, Directive, ElementRef, EnvironmentInjector, Injectable, InjectionToken, Injector, Renderer2, TemplateRef, ViewContainerRef, ViewEncapsulation, afterNextRender, booleanAttribute, computed, contentChildren, createComponent, effect, forwardRef, inject, input, linkedSignal, model, numberAttribute, output, provideEnvironmentInitializer, signal, viewChild, viewChildren } from "@angular/core";
import { DomSanitizer } from "@angular/platform-browser";
import * as i1 from "@angular/forms";
import { FormsModule, NG_VALIDATORS, NG_VALUE_ACCESSOR, NgControl } from "@angular/forms";
import { Subject, takeUntil } from "rxjs";
import { NgTemplateOutlet } from "@angular/common";
import { RouterLink } from "@angular/router";
const tint = (color) => `color-mix(in srgb, ${color} 9%, var(--bg-lightest))`;
const shade = (color) => `color-mix(in srgb, ${color} 78%, black)`;
const TINTED = [
	"accent",
	"success",
	"error",
	"warn",
	"info",
	"premium",
	"cancel"
];
function themeVars(theme) {
	const vars = {};
	for (const [key, value] of Object.entries(theme)) if (value) vars[`--${key.replace(/[A-Z]/g, (c) => `-${c.toLowerCase()}`)}`] = value;
	for (const key of TINTED) {
		const color = theme[key];
		if (color) vars[`--${key}-bg`] ??= tint(color);
	}
	if (theme.accent) vars["--accent-dark"] ??= shade(theme.accent);
	return vars;
}
var ThemeService = class ThemeService {
	_root = inject(DOCUMENT).documentElement;
	_theme = signal({}, ...ngDevMode ? [{ debugName: "_theme" }] : /* istanbul ignore next */ []);
	_applied = [];
	theme = this._theme.asReadonly();
	set(theme) {
		const vars = themeVars(theme);
		for (const name of this._applied) this._root.style.removeProperty(name);
		for (const [name, value] of Object.entries(vars)) this._root.style.setProperty(name, value);
		this._applied = Object.keys(vars);
		this._theme.set(theme);
	}
	reset() {
		this.set({});
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.1",
		ngImport: i0,
		type: ThemeService,
		deps: [],
		target: i0.ɵɵFactoryTarget.Injectable
	});
	static ɵprov = i0.ɵɵngDeclareInjectable({
		minVersion: "12.0.0",
		version: "22.2.1",
		ngImport: i0,
		type: ThemeService,
		providedIn: "root"
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: ThemeService,
	decorators: [{
		type: Injectable,
		args: [{ providedIn: "root" }]
	}]
});
function provideTheme(theme) {
	return provideEnvironmentInitializer(() => inject(ThemeService).set(theme));
}
var Button = class Button {
	variant = input("primary", ...ngDevMode ? [{ debugName: "variant" }] : /* istanbul ignore next */ []);
	size = input("md", ...ngDevMode ? [{ debugName: "size" }] : /* istanbul ignore next */ []);
	width = input("auto", ...ngDevMode ? [{ debugName: "width" }] : /* istanbul ignore next */ []);
	rounded = input(false, ...ngDevMode ? [{ debugName: "rounded" }] : /* istanbul ignore next */ []);
	disabled = input(false, ...ngDevMode ? [{ debugName: "disabled" }] : /* istanbul ignore next */ []);
	_classes = computed(() => [
		"btn",
		`btn-${this.variant()}`,
		`btn-${this.size()}`,
		this.width() === "full" ? "full" : "",
		this.rounded() ? "rounded" : ""
	].filter(Boolean).join(" "), ...ngDevMode ? [{ debugName: "_classes" }] : /* istanbul ignore next */ []);
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.1",
		ngImport: i0,
		type: Button,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.1",
		type: Button,
		isStandalone: true,
		selector: "l-button",
		inputs: {
			variant: {
				classPropertyName: "variant",
				publicName: "variant",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			size: {
				classPropertyName: "size",
				publicName: "size",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			width: {
				classPropertyName: "width",
				publicName: "width",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			rounded: {
				classPropertyName: "rounded",
				publicName: "rounded",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			disabled: {
				classPropertyName: "disabled",
				publicName: "disabled",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		ngImport: i0,
		template: "<button type=\"button\" [class]=\"_classes()\" [disabled]=\"disabled()\">\n  <ng-content />\n</button>\n",
		styles: [".btn{display:inline-flex;justify-content:center;align-items:center;padding:6px 12px;gap:8px;border-radius:8px;outline:none;border:0px;font-size:14px;font-weight:600;line-height:20px;cursor:pointer;height:fit-content;white-space:nowrap;transition:background-color .15s ease-out,color .15s ease-out,border-color .15s ease-out}.btn.full{width:100%}.btn.btn-sm{padding:4px 8px}.btn.btn-md{padding:6px 12px}.btn.btn-lg{padding:8px 16px}.btn.rounded{border-radius:50%;padding:0;aspect-ratio:1;line-height:20;width:32px;height:32px}.btn.rounded.btn-sm{width:28px;height:28px}.btn.rounded.btn-lg{width:36px;height:36px}.btn:focus-visible{outline:2px solid var(--accent);outline-offset:2px}.btn:disabled{background-color:var(--bg-dark)!important;border:1px solid var(--separator);color:var(--text-tertiary);pointer-events:none;cursor:not-allowed}.btn-primary{background:var(--accent);color:var(--accent-contrast);border-bottom:2px solid var(--accent-dark);box-shadow:0 1px 2px #0d0d120f}.btn-primary:hover{background:var(--accent-dark);border-bottom:2px solid var(--accent-dark)}.btn-secondary{background:var(--bg-dark);color:var(--text-primary);border-bottom:2px solid var(--separator-dark);box-shadow:0 1px 2px #0d0d120f}.btn-secondary:hover{background:var(--separator-dark);border-bottom:2px solid var(--separator-dark)}.btn-outlined-primary{background:var(--bg-lightest);color:var(--accent);border:1px solid var(--accent)}.btn-outlined-primary:hover,.btn-outlined-primary.active{background:var(--accent);color:var(--accent-contrast)}.btn-outlined{background:var(--bg-lightest);color:var(--text-primary);border:1px solid var(--separator-dark)}.btn-outlined:hover{background:var(--bg-dark)}.btn-danger{background:var(--bg-lightest);color:var(--error);border:1px solid var(--error)}.btn-danger:hover{background:var(--error);color:var(--text-white)}.btn-ghost{background:transparent;color:var(--text-primary);border:1px solid transparent}.btn-ghost:hover{background:var(--bg-dark)}@media(prefers-reduced-motion:reduce){.btn{transition:none}}\n"],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: Button,
	decorators: [{
		type: Component,
		args: [{
			selector: "l-button",
			changeDetection: ChangeDetectionStrategy.OnPush,
			imports: [],
			template: "<button type=\"button\" [class]=\"_classes()\" [disabled]=\"disabled()\">\n  <ng-content />\n</button>\n",
			styles: [".btn{display:inline-flex;justify-content:center;align-items:center;padding:6px 12px;gap:8px;border-radius:8px;outline:none;border:0px;font-size:14px;font-weight:600;line-height:20px;cursor:pointer;height:fit-content;white-space:nowrap;transition:background-color .15s ease-out,color .15s ease-out,border-color .15s ease-out}.btn.full{width:100%}.btn.btn-sm{padding:4px 8px}.btn.btn-md{padding:6px 12px}.btn.btn-lg{padding:8px 16px}.btn.rounded{border-radius:50%;padding:0;aspect-ratio:1;line-height:20;width:32px;height:32px}.btn.rounded.btn-sm{width:28px;height:28px}.btn.rounded.btn-lg{width:36px;height:36px}.btn:focus-visible{outline:2px solid var(--accent);outline-offset:2px}.btn:disabled{background-color:var(--bg-dark)!important;border:1px solid var(--separator);color:var(--text-tertiary);pointer-events:none;cursor:not-allowed}.btn-primary{background:var(--accent);color:var(--accent-contrast);border-bottom:2px solid var(--accent-dark);box-shadow:0 1px 2px #0d0d120f}.btn-primary:hover{background:var(--accent-dark);border-bottom:2px solid var(--accent-dark)}.btn-secondary{background:var(--bg-dark);color:var(--text-primary);border-bottom:2px solid var(--separator-dark);box-shadow:0 1px 2px #0d0d120f}.btn-secondary:hover{background:var(--separator-dark);border-bottom:2px solid var(--separator-dark)}.btn-outlined-primary{background:var(--bg-lightest);color:var(--accent);border:1px solid var(--accent)}.btn-outlined-primary:hover,.btn-outlined-primary.active{background:var(--accent);color:var(--accent-contrast)}.btn-outlined{background:var(--bg-lightest);color:var(--text-primary);border:1px solid var(--separator-dark)}.btn-outlined:hover{background:var(--bg-dark)}.btn-danger{background:var(--bg-lightest);color:var(--error);border:1px solid var(--error)}.btn-danger:hover{background:var(--error);color:var(--text-white)}.btn-ghost{background:transparent;color:var(--text-primary);border:1px solid transparent}.btn-ghost:hover{background:var(--bg-dark)}@media(prefers-reduced-motion:reduce){.btn{transition:none}}\n"]
		}]
	}],
	propDecorators: {
		variant: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "variant",
				required: false
			}]
		}],
		size: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "size",
				required: false
			}]
		}],
		width: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "width",
				required: false
			}]
		}],
		rounded: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "rounded",
				required: false
			}]
		}],
		disabled: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "disabled",
				required: false
			}]
		}]
	}
});
const ICON_NAMES = [
	"add",
	"attach_file",
	"backup",
	"bag",
	"bank",
	"bar_chart",
	"bolt",
	"bookmark",
	"box",
	"building",
	"calculator",
	"calendar",
	"calendar_month",
	"call",
	"car",
	"card",
	"caret",
	"caret_down",
	"cart",
	"cart_add",
	"cart_return",
	"category",
	"checklist",
	"checklist_alt",
	"checkroom",
	"clock",
	"configuration",
	"content_copy",
	"controller",
	"cross",
	"dashboard",
	"dashboard_alt",
	"dislike",
	"donut_large",
	"download",
	"drawer",
	"edit",
	"education",
	"error",
	"event_repeat",
	"eye",
	"eye_slash",
	"factory",
	"family",
	"file",
	"file_add",
	"file_alt",
	"files",
	"filter",
	"filter_list",
	"fitness",
	"flight",
	"fuel",
	"hand",
	"hash",
	"heart",
	"help",
	"home",
	"hospital",
	"image",
	"like",
	"list",
	"location",
	"lock",
	"logout",
	"mail",
	"money",
	"moneys",
	"more",
	"music",
	"notebook",
	"notification",
	"notifications_alt",
	"pie_chart",
	"printer",
	"receipt",
	"refresh",
	"savings",
	"savings_alt",
	"search",
	"settings",
	"shield",
	"star",
	"train",
	"trash",
	"truck",
	"undo",
	"upload_file",
	"user",
	"user_add",
	"user_card",
	"user_config",
	"users",
	"verified_user",
	"view",
	"wallet",
	"wallet_alt",
	"warning",
	"wifi",
	"work"
];
const ICON_LOADERS = {
	"add": () => import("./lumen-ui-angular-add-CWm-IazY.mjs"),
	"attach_file": () => import("./lumen-ui-angular-attach_file-Bmi-YaFY.mjs"),
	"backup": () => import("./lumen-ui-angular-backup-BkVw0dm8.mjs"),
	"bag": () => import("./lumen-ui-angular-bag-BV-mCGQB.mjs"),
	"bank": () => import("./lumen-ui-angular-bank-BlgAV-Uy.mjs"),
	"bar_chart": () => import("./lumen-ui-angular-bar_chart-ldicCVnG.mjs"),
	"bolt": () => import("./lumen-ui-angular-bolt-_YhCMk58.mjs"),
	"bookmark": () => import("./lumen-ui-angular-bookmark-D4MmD2jM.mjs"),
	"box": () => import("./lumen-ui-angular-box-BhKOcCR4.mjs"),
	"building": () => import("./lumen-ui-angular-building-BKhPtBpF.mjs"),
	"calculator": () => import("./lumen-ui-angular-calculator-B_O_govT.mjs"),
	"calendar": () => import("./lumen-ui-angular-calendar-DLVotNk2.mjs"),
	"calendar_month": () => import("./lumen-ui-angular-calendar_month-CpFstCf8.mjs"),
	"call": () => import("./lumen-ui-angular-call-CmqCnNY2.mjs"),
	"car": () => import("./lumen-ui-angular-car-HxogyUlY.mjs"),
	"card": () => import("./lumen-ui-angular-card-DvI3OugR.mjs"),
	"caret": () => import("./lumen-ui-angular-caret-9tUQB5Y5.mjs"),
	"caret_down": () => import("./lumen-ui-angular-caret_down-B_s1CgLb.mjs"),
	"cart": () => import("./lumen-ui-angular-cart-BgOA-Ag-.mjs"),
	"cart_add": () => import("./lumen-ui-angular-cart_add-Dy7YAU4_.mjs"),
	"cart_return": () => import("./lumen-ui-angular-cart_return-CpCkISRd.mjs"),
	"category": () => import("./lumen-ui-angular-category-B9wVTNHW.mjs"),
	"checklist": () => import("./lumen-ui-angular-checklist-DbevOYf-.mjs"),
	"checklist_alt": () => import("./lumen-ui-angular-checklist_alt-BDtgrsPk.mjs"),
	"checkroom": () => import("./lumen-ui-angular-checkroom-DLf2nU0S.mjs"),
	"clock": () => import("./lumen-ui-angular-clock-CeT579eB.mjs"),
	"configuration": () => import("./lumen-ui-angular-configuration-Ct8il9xB.mjs"),
	"content_copy": () => import("./lumen-ui-angular-content_copy-BrV6ep7_.mjs"),
	"controller": () => import("./lumen-ui-angular-controller-CQbZNFvU.mjs"),
	"cross": () => import("./lumen-ui-angular-cross-0uq-ZHgE.mjs"),
	"dashboard": () => import("./lumen-ui-angular-dashboard-BxFNFQu7.mjs"),
	"dashboard_alt": () => import("./lumen-ui-angular-dashboard_alt-Hbp2vZz7.mjs"),
	"dislike": () => import("./lumen-ui-angular-dislike-DSh-cZFQ.mjs"),
	"donut_large": () => import("./lumen-ui-angular-donut_large-Dh6WIQQN.mjs"),
	"download": () => import("./lumen-ui-angular-download-CgrDVSG2.mjs"),
	"drawer": () => import("./lumen-ui-angular-drawer-BhtV9Hag.mjs"),
	"edit": () => import("./lumen-ui-angular-edit-DCvTkFDa.mjs"),
	"education": () => import("./lumen-ui-angular-education-EW9c67Yc.mjs"),
	"error": () => import("./lumen-ui-angular-error-CIWxFqF0.mjs"),
	"event_repeat": () => import("./lumen-ui-angular-event_repeat-DwZQJH2D.mjs"),
	"eye": () => import("./lumen-ui-angular-eye-CdG4UsM0.mjs"),
	"eye_slash": () => import("./lumen-ui-angular-eye_slash-DgOSsBHz.mjs"),
	"factory": () => import("./lumen-ui-angular-factory-BxtTU4Lt.mjs"),
	"family": () => import("./lumen-ui-angular-family-BUiyWWZQ.mjs"),
	"file": () => import("./lumen-ui-angular-file-DJQW5i5b.mjs"),
	"file_add": () => import("./lumen-ui-angular-file_add-uHqTrBCK.mjs"),
	"file_alt": () => import("./lumen-ui-angular-file_alt-D_G0TuQT.mjs"),
	"files": () => import("./lumen-ui-angular-files-BnEmTE3L.mjs"),
	"filter": () => import("./lumen-ui-angular-filter-C_XhOl-U.mjs"),
	"filter_list": () => import("./lumen-ui-angular-filter_list-BX5T1ago.mjs"),
	"fitness": () => import("./lumen-ui-angular-fitness-B9c-6Egr.mjs"),
	"flight": () => import("./lumen-ui-angular-flight-CQD7aZVR.mjs"),
	"fuel": () => import("./lumen-ui-angular-fuel-DhtOsoNn.mjs"),
	"hand": () => import("./lumen-ui-angular-hand-tvpH3EZx.mjs"),
	"hash": () => import("./lumen-ui-angular-hash-ByWtTJoT.mjs"),
	"heart": () => import("./lumen-ui-angular-heart-8iTd4Z05.mjs"),
	"help": () => import("./lumen-ui-angular-help-C6q4jSyC.mjs"),
	"home": () => import("./lumen-ui-angular-home-DkweNb8x.mjs"),
	"hospital": () => import("./lumen-ui-angular-hospital-D1F05NV4.mjs"),
	"image": () => import("./lumen-ui-angular-image-Cx-DS4d9.mjs"),
	"like": () => import("./lumen-ui-angular-like-CWI8GPBd.mjs"),
	"list": () => import("./lumen-ui-angular-list-D8HdTe9A.mjs"),
	"location": () => import("./lumen-ui-angular-location-COTEY802.mjs"),
	"lock": () => import("./lumen-ui-angular-lock-DywZY8hj.mjs"),
	"logout": () => import("./lumen-ui-angular-logout-DiWNIUXN.mjs"),
	"mail": () => import("./lumen-ui-angular-mail-jzwlS83Q.mjs"),
	"money": () => import("./lumen-ui-angular-money-Dib5oHXo.mjs"),
	"moneys": () => import("./lumen-ui-angular-moneys-CtN-8Zlp.mjs"),
	"more": () => import("./lumen-ui-angular-more-DfjzW3FC.mjs"),
	"music": () => import("./lumen-ui-angular-music-8-9uzsYE.mjs"),
	"notebook": () => import("./lumen-ui-angular-notebook-SMsdszNy.mjs"),
	"notification": () => import("./lumen-ui-angular-notification-DZULNYFs.mjs"),
	"notifications_alt": () => import("./lumen-ui-angular-notifications_alt-DqHbvhWF.mjs"),
	"pie_chart": () => import("./lumen-ui-angular-pie_chart-gDHXuZVU.mjs"),
	"printer": () => import("./lumen-ui-angular-printer-TdneEK70.mjs"),
	"receipt": () => import("./lumen-ui-angular-receipt-DuwTWLRN.mjs"),
	"refresh": () => import("./lumen-ui-angular-refresh-BZN-m-gY.mjs"),
	"savings": () => import("./lumen-ui-angular-savings-Bs-79_gz.mjs"),
	"savings_alt": () => import("./lumen-ui-angular-savings_alt-DssYSjlZ.mjs"),
	"search": () => import("./lumen-ui-angular-search-DYgQippv.mjs"),
	"settings": () => import("./lumen-ui-angular-settings-D__Lxwk8.mjs"),
	"shield": () => import("./lumen-ui-angular-shield-BOvHmyme.mjs"),
	"star": () => import("./lumen-ui-angular-star-ClFemAY0.mjs"),
	"train": () => import("./lumen-ui-angular-train-DLKD8m68.mjs"),
	"trash": () => import("./lumen-ui-angular-trash-DhDlh96f.mjs"),
	"truck": () => import("./lumen-ui-angular-truck-D2iLJYt4.mjs"),
	"undo": () => import("./lumen-ui-angular-undo-CAcWBeFT.mjs"),
	"upload_file": () => import("./lumen-ui-angular-upload_file-BN4lnlix.mjs"),
	"user": () => import("./lumen-ui-angular-user-Si7Zx8Yh.mjs"),
	"user_add": () => import("./lumen-ui-angular-user_add-CSQuWeUT.mjs"),
	"user_card": () => import("./lumen-ui-angular-user_card-DJRzJVij.mjs"),
	"user_config": () => import("./lumen-ui-angular-user_config-ArYXLl1z.mjs"),
	"users": () => import("./lumen-ui-angular-users-BaAdb0fa.mjs"),
	"verified_user": () => import("./lumen-ui-angular-verified_user-C-7kebyv.mjs"),
	"view": () => import("./lumen-ui-angular-view-BTtpfLhO.mjs"),
	"wallet": () => import("./lumen-ui-angular-wallet-BE5ytj1a.mjs"),
	"wallet_alt": () => import("./lumen-ui-angular-wallet_alt-3h7aEt-Q.mjs"),
	"warning": () => import("./lumen-ui-angular-warning-schX7ppT.mjs"),
	"wifi": () => import("./lumen-ui-angular-wifi-tF2wQQDF.mjs"),
	"work": () => import("./lumen-ui-angular-work-DwNKa7JJ.mjs")
};
const L_ICON_NAMES = ICON_NAMES;
const normalize = (raw) => raw.replace(/<svg([^>]*)>/, (_, attrs) => `<svg${attrs.replace(/\s(?:width|height)="[^"]*"/g, "")}>`).replace(/<mask[\s\S]*?<\/mask>|\b(stroke|fill)="(?!none)[^"]*"/g, (match, attr) => attr ? `${attr}="currentColor"` : match);
var IconRegistry = class IconRegistry {
	_cache = /* @__PURE__ */ new Map();
	load(name) {
		let svg = this._cache.get(name);
		if (!svg) {
			const loader = Object.hasOwn(ICON_LOADERS, name) ? ICON_LOADERS[name] : void 0;
			svg = (loader ? loader() : Promise.reject()).then((module) => normalize(module.default)).catch(() => {
				console.warn(`[l-icon] Unknown icon name "${name}".`);
				return "";
			});
			this._cache.set(name, svg);
		}
		return svg;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.1",
		ngImport: i0,
		type: IconRegistry,
		deps: [],
		target: i0.ɵɵFactoryTarget.Injectable
	});
	static ɵprov = i0.ɵɵngDeclareInjectable({
		minVersion: "12.0.0",
		version: "22.2.1",
		ngImport: i0,
		type: IconRegistry,
		providedIn: "root"
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: IconRegistry,
	decorators: [{
		type: Injectable,
		args: [{ providedIn: "root" }]
	}]
});
var Icon = class Icon {
	name = input.required(...ngDevMode ? [{ debugName: "name" }] : /* istanbul ignore next */ []);
	size = input(20, ...ngDevMode ? [{ debugName: "size" }] : /* istanbul ignore next */ []);
	color = input("", ...ngDevMode ? [{ debugName: "color" }] : /* istanbul ignore next */ []);
	_registry = inject(IconRegistry);
	_sanitizer = inject(DomSanitizer);
	_dimension = computed(() => {
		const size = this.size();
		return typeof size === "number" ? `${size}px` : size;
	}, ...ngDevMode ? [{ debugName: "_dimension" }] : /* istanbul ignore next */ []);
	_svg = signal(null, ...ngDevMode ? [{ debugName: "_svg" }] : /* istanbul ignore next */ []);
	constructor() {
		effect(() => {
			const name = this.name();
			this._registry.load(name).then((svg) => {
				if (this.name() !== name) return;
				this._svg.set(svg ? this._sanitizer.bypassSecurityTrustHtml(svg) : null);
			});
		});
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.1",
		ngImport: i0,
		type: Icon,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.1",
		type: Icon,
		isStandalone: true,
		selector: "l-icon",
		inputs: {
			name: {
				classPropertyName: "name",
				publicName: "name",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			size: {
				classPropertyName: "size",
				publicName: "size",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			color: {
				classPropertyName: "color",
				publicName: "color",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		host: {
			attributes: { "aria-hidden": "true" },
			properties: {
				"style.width": "_dimension()",
				"style.height": "_dimension()",
				"style.color": "color() || null",
				"innerHTML": "_svg()"
			},
			classAttribute: "lui-icon"
		},
		ngImport: i0,
		template: "",
		isInline: true,
		styles: [".lui-icon{display:inline-flex;flex-shrink:0;vertical-align:middle;color:var(--text-tertiary)}.lui-icon svg{display:block;width:100%;height:100%}\n"],
		changeDetection: i0.ChangeDetectionStrategy.OnPush,
		encapsulation: i0.ViewEncapsulation.None
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: Icon,
	decorators: [{
		type: Component,
		args: [{
			selector: "l-icon",
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: "",
			encapsulation: ViewEncapsulation.None,
			host: {
				class: "lui-icon",
				"aria-hidden": "true",
				"[style.width]": "_dimension()",
				"[style.height]": "_dimension()",
				"[style.color]": "color() || null",
				"[innerHTML]": "_svg()"
			},
			styles: [".lui-icon{display:inline-flex;flex-shrink:0;vertical-align:middle;color:var(--text-tertiary)}.lui-icon svg{display:block;width:100%;height:100%}\n"]
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		name: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "name",
				required: true
			}]
		}],
		size: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "size",
				required: false
			}]
		}],
		color: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "color",
				required: false
			}]
		}]
	}
});
function fixedContainingBlock(parent) {
	const probe = document.createElement("div");
	probe.style.cssText = "position:fixed;inset:0;visibility:hidden;pointer-events:none";
	parent.appendChild(probe);
	const { top, right, bottom, left } = probe.getBoundingClientRect();
	probe.remove();
	return {
		top,
		right,
		bottom,
		left
	};
}
const MIN_SPACE_BELOW = 180;
var Menu = class Menu {
	mode = input("left", ...ngDevMode ? [{ debugName: "mode" }] : /* istanbul ignore next */ []);
	closeOnItemClick = input(true, ...ngDevMode ? [{ debugName: "closeOnItemClick" }] : /* istanbul ignore next */ []);
	contentMode = input(false, ...ngDevMode ? [{ debugName: "contentMode" }] : /* istanbul ignore next */ []);
	showActiveState = input(true, ...ngDevMode ? [{ debugName: "showActiveState" }] : /* istanbul ignore next */ []);
	appendBody = input(false, ...ngDevMode ? [{ debugName: "appendBody" }] : /* istanbul ignore next */ []);
	_open = signal(false, ...ngDevMode ? [{ debugName: "_open" }] : /* istanbul ignore next */ []);
	isOpen = this._open.asReadonly();
	_isReady = signal(false, ...ngDevMode ? [{ debugName: "_isReady" }] : /* istanbul ignore next */ []);
	_dropUp = signal(false, ...ngDevMode ? [{ debugName: "_dropUp" }] : /* istanbul ignore next */ []);
	_top = signal(null, ...ngDevMode ? [{ debugName: "_top" }] : /* istanbul ignore next */ []);
	_bottom = signal(null, ...ngDevMode ? [{ debugName: "_bottom" }] : /* istanbul ignore next */ []);
	_left = signal(null, ...ngDevMode ? [{ debugName: "_left" }] : /* istanbul ignore next */ []);
	_right = signal(null, ...ngDevMode ? [{ debugName: "_right" }] : /* istanbul ignore next */ []);
	_maxHeight = signal(null, ...ngDevMode ? [{ debugName: "_maxHeight" }] : /* istanbul ignore next */ []);
	_host = inject(ElementRef);
	_panel = viewChild("panel", ...ngDevMode ? [{ debugName: "_panel" }] : /* istanbul ignore next */ []);
	_onViewportChange = () => {
		if (this._open()) this._reposition();
	};
	constructor() {
		inject(DestroyRef).onDestroy(() => this._unbindViewport());
		effect(() => {
			const panel = this._panel()?.nativeElement;
			if (this.appendBody() && panel && panel.parentElement !== document.body) document.body.appendChild(panel);
		});
	}
	toggle() {
		this._open() ? this.close() : this._openMenu();
	}
	close() {
		if (!this._open()) return;
		this._open.set(false);
		this._isReady.set(false);
		this._unbindViewport();
	}
	_onDocumentClick(event) {
		if (this._open() && !this._isInside(event.target)) this.close();
	}
	_onTriggerClick(event) {
		if (this._panel()?.nativeElement.contains(event.target)) return;
		this.toggle();
	}
	_onPanelClick() {
		if (this.closeOnItemClick()) this.close();
	}
	_isInside(node) {
		if (!node) return false;
		return this._host.nativeElement.contains(node) || !!this._panel()?.nativeElement.contains(node);
	}
	_openMenu() {
		this._open.set(true);
		this._reposition();
		window.addEventListener("scroll", this._onViewportChange, true);
		window.addEventListener("resize", this._onViewportChange);
		requestAnimationFrame(() => this._isReady.set(true));
	}
	_reposition() {
		const host = this._host.nativeElement;
		const rect = host.getBoundingClientRect();
		const gap = 6;
		const spaceBelow = window.innerHeight - rect.bottom - gap;
		const spaceAbove = rect.top - gap;
		const dropUp = spaceBelow < MIN_SPACE_BELOW && spaceAbove > spaceBelow;
		const box = fixedContainingBlock(this.appendBody() ? document.body : host);
		this._dropUp.set(dropUp);
		this._maxHeight.set(Math.max(120, (dropUp ? spaceAbove : spaceBelow) - 8));
		if (this.mode() === "right") {
			this._right.set(box.right - rect.right);
			this._left.set(null);
		} else {
			this._left.set(rect.left - box.left);
			this._right.set(null);
		}
		if (dropUp) {
			this._bottom.set(box.bottom - rect.top + gap);
			this._top.set(null);
		} else {
			this._top.set(rect.bottom + gap - box.top);
			this._bottom.set(null);
		}
	}
	_unbindViewport() {
		window.removeEventListener("scroll", this._onViewportChange, true);
		window.removeEventListener("resize", this._onViewportChange);
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.1",
		ngImport: i0,
		type: Menu,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.1",
		type: Menu,
		isStandalone: true,
		selector: "l-menu",
		inputs: {
			mode: {
				classPropertyName: "mode",
				publicName: "mode",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			closeOnItemClick: {
				classPropertyName: "closeOnItemClick",
				publicName: "closeOnItemClick",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			contentMode: {
				classPropertyName: "contentMode",
				publicName: "contentMode",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			showActiveState: {
				classPropertyName: "showActiveState",
				publicName: "showActiveState",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			appendBody: {
				classPropertyName: "appendBody",
				publicName: "appendBody",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		host: { listeners: { "document:click": "_onDocumentClick($event)" } },
		viewQueries: [{
			propertyName: "_panel",
			first: true,
			predicate: ["panel"],
			descendants: true,
			isSignal: true
		}],
		ngImport: i0,
		template: "<div\n  class=\"dropdown-menu\"\n  [class.active]=\"isOpen() && showActiveState()\"\n  (click)=\"_onTriggerClick($event)\"\n>\n  <ng-content select=\"[dropdown-display]\" />\n\n  @if (isOpen()) {\n    <div\n      #panel\n      class=\"dropdown-content\"\n      [class.visible]=\"_isReady()\"\n      [class.is-up]=\"_dropUp()\"\n      [class.nopadding]=\"contentMode()\"\n      [style.top.px]=\"_top()\"\n      [style.bottom.px]=\"_bottom()\"\n      [style.left.px]=\"_left()\"\n      [style.right.px]=\"_right()\"\n      [style.max-height.px]=\"_maxHeight()\"\n      (click)=\"_onPanelClick()\"\n    >\n      <ng-content select=\"[dropdown-item]\" />\n      <ng-content select=\"[dropdown-content]\" />\n    </div>\n  }\n</div>\n",
		styles: [":host{display:inline-block}.dropdown-menu{position:relative}.dropdown-menu.active ::ng-deep [dropdown-display]{background-color:var(--separator);border-radius:8px}.dropdown-content{position:fixed;z-index:1000;display:flex;flex-direction:column;min-width:160px;padding:8px;border:1px solid var(--separator);border-radius:8px;background:var(--bg-lightest);box-shadow:0 6px 16px #0d0d121f;overflow-y:auto;opacity:0;transition:opacity .15s ease-out}.dropdown-content.visible{opacity:1}.dropdown-content.nopadding{padding:0}.dropdown-content ::ng-deep [dropdown-item]{display:flex;align-items:center;gap:8px;padding:8px;border-radius:8px;white-space:nowrap;cursor:pointer;font-size:14px;font-weight:400;line-height:20px;color:var(--text-primary);transition:background-color .12s ease-out,color .12s ease-out}.dropdown-content ::ng-deep [dropdown-item]:hover{background-color:var(--separator)}.dropdown-content ::ng-deep [dropdown-item].active{background-color:var(--accent-bg);color:var(--accent-dark)}:host ::ng-deep [dropdown-display]{cursor:pointer}@media(prefers-reduced-motion:reduce){.dropdown-content{transition:none}}\n"],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: Menu,
	decorators: [{
		type: Component,
		args: [{
			selector: "l-menu",
			changeDetection: ChangeDetectionStrategy.OnPush,
			host: { "(document:click)": "_onDocumentClick($event)" },
			template: "<div\n  class=\"dropdown-menu\"\n  [class.active]=\"isOpen() && showActiveState()\"\n  (click)=\"_onTriggerClick($event)\"\n>\n  <ng-content select=\"[dropdown-display]\" />\n\n  @if (isOpen()) {\n    <div\n      #panel\n      class=\"dropdown-content\"\n      [class.visible]=\"_isReady()\"\n      [class.is-up]=\"_dropUp()\"\n      [class.nopadding]=\"contentMode()\"\n      [style.top.px]=\"_top()\"\n      [style.bottom.px]=\"_bottom()\"\n      [style.left.px]=\"_left()\"\n      [style.right.px]=\"_right()\"\n      [style.max-height.px]=\"_maxHeight()\"\n      (click)=\"_onPanelClick()\"\n    >\n      <ng-content select=\"[dropdown-item]\" />\n      <ng-content select=\"[dropdown-content]\" />\n    </div>\n  }\n</div>\n",
			styles: [":host{display:inline-block}.dropdown-menu{position:relative}.dropdown-menu.active ::ng-deep [dropdown-display]{background-color:var(--separator);border-radius:8px}.dropdown-content{position:fixed;z-index:1000;display:flex;flex-direction:column;min-width:160px;padding:8px;border:1px solid var(--separator);border-radius:8px;background:var(--bg-lightest);box-shadow:0 6px 16px #0d0d121f;overflow-y:auto;opacity:0;transition:opacity .15s ease-out}.dropdown-content.visible{opacity:1}.dropdown-content.nopadding{padding:0}.dropdown-content ::ng-deep [dropdown-item]{display:flex;align-items:center;gap:8px;padding:8px;border-radius:8px;white-space:nowrap;cursor:pointer;font-size:14px;font-weight:400;line-height:20px;color:var(--text-primary);transition:background-color .12s ease-out,color .12s ease-out}.dropdown-content ::ng-deep [dropdown-item]:hover{background-color:var(--separator)}.dropdown-content ::ng-deep [dropdown-item].active{background-color:var(--accent-bg);color:var(--accent-dark)}:host ::ng-deep [dropdown-display]{cursor:pointer}@media(prefers-reduced-motion:reduce){.dropdown-content{transition:none}}\n"]
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		mode: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "mode",
				required: false
			}]
		}],
		closeOnItemClick: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "closeOnItemClick",
				required: false
			}]
		}],
		contentMode: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "contentMode",
				required: false
			}]
		}],
		showActiveState: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "showActiveState",
				required: false
			}]
		}],
		appendBody: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "appendBody",
				required: false
			}]
		}],
		_panel: [{
			type: i0.ViewChild,
			args: ["panel", { isSignal: true }]
		}]
	}
});
let _uid$9 = 0;
function provideInputValueAccessor(component) {
	return {
		provide: NG_VALUE_ACCESSOR,
		useExisting: forwardRef(component),
		multi: true
	};
}
function provideInputValidator(component) {
	return {
		provide: NG_VALIDATORS,
		useExisting: forwardRef(component),
		multi: true
	};
}
var BaseInput = class BaseInput {
	label = input("", ...ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []);
	placeholder = input("", ...ngDevMode ? [{ debugName: "placeholder" }] : /* istanbul ignore next */ []);
	disabled = input(false, ...ngDevMode ? [{ debugName: "disabled" }] : /* istanbul ignore next */ []);
	id = input(`l-input-${_uid$9++}`, ...ngDevMode ? [{ debugName: "id" }] : /* istanbul ignore next */ []);
	viewMode = input(false, ...ngDevMode ? [{ debugName: "viewMode" }] : /* istanbul ignore next */ []);
	viewValue = input(...ngDevMode ? [void 0, { debugName: "viewValue" }] : /* istanbul ignore next */ []);
	input = output();
	change = output();
	keyup = output();
	keydown = output();
	keypress = output();
	enter = output();
	_value = signal("", ...ngDevMode ? [{ debugName: "_value" }] : /* istanbul ignore next */ []);
	_disabledByForm = signal(false, ...ngDevMode ? [{ debugName: "_disabledByForm" }] : /* istanbul ignore next */ []);
	_touched = signal(false, ...ngDevMode ? [{ debugName: "_touched" }] : /* istanbul ignore next */ []);
	_isDisabled = computed(() => this.disabled() || this._disabledByForm(), ...ngDevMode ? [{ debugName: "_isDisabled" }] : /* istanbul ignore next */ []);
	_onChange = () => {};
	_onTouched = () => {};
	_handleInput(event) {
		const value = event.target.value;
		this._value.set(value);
		this._onChange(value);
		this.input.emit(event);
	}
	_handleEnter(event) {
		this.enter.emit(event);
	}
	_handleBlur() {
		this._touched.set(true);
		this._onTouched();
	}
	writeValue(value) {
		this._value.set(value ?? "");
	}
	registerOnChange(fn) {
		this._onChange = fn;
	}
	registerOnTouched(fn) {
		this._onTouched = fn;
	}
	setDisabledState(isDisabled) {
		this._disabledByForm.set(isDisabled);
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.1",
		ngImport: i0,
		type: BaseInput,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "17.1.0",
		version: "22.2.1",
		type: BaseInput,
		isStandalone: true,
		inputs: {
			label: {
				classPropertyName: "label",
				publicName: "label",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			placeholder: {
				classPropertyName: "placeholder",
				publicName: "placeholder",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			disabled: {
				classPropertyName: "disabled",
				publicName: "disabled",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			id: {
				classPropertyName: "id",
				publicName: "id",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			viewMode: {
				classPropertyName: "viewMode",
				publicName: "viewMode",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			viewValue: {
				classPropertyName: "viewValue",
				publicName: "viewValue",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: {
			input: "input",
			change: "change",
			keyup: "keyup",
			keydown: "keydown",
			keypress: "keypress",
			enter: "enter"
		},
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: BaseInput,
	decorators: [{ type: Directive }],
	propDecorators: {
		label: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "label",
				required: false
			}]
		}],
		placeholder: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "placeholder",
				required: false
			}]
		}],
		disabled: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "disabled",
				required: false
			}]
		}],
		id: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "id",
				required: false
			}]
		}],
		viewMode: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "viewMode",
				required: false
			}]
		}],
		viewValue: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "viewValue",
				required: false
			}]
		}],
		input: [{
			type: i0.Output,
			args: ["input"]
		}],
		change: [{
			type: i0.Output,
			args: ["change"]
		}],
		keyup: [{
			type: i0.Output,
			args: ["keyup"]
		}],
		keydown: [{
			type: i0.Output,
			args: ["keydown"]
		}],
		keypress: [{
			type: i0.Output,
			args: ["keypress"]
		}],
		enter: [{
			type: i0.Output,
			args: ["enter"]
		}]
	}
});
var BaseBooleanInput = class BaseBooleanInput {
	label = input("", ...ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []);
	disabled = input(false, ...ngDevMode ? [{ debugName: "disabled" }] : /* istanbul ignore next */ []);
	id = input(`l-input-${_uid$9++}`, ...ngDevMode ? [{ debugName: "id" }] : /* istanbul ignore next */ []);
	labelPosition = input("right", ...ngDevMode ? [{ debugName: "labelPosition" }] : /* istanbul ignore next */ []);
	viewMode = input(false, ...ngDevMode ? [{ debugName: "viewMode" }] : /* istanbul ignore next */ []);
	viewValue = input(...ngDevMode ? [void 0, { debugName: "viewValue" }] : /* istanbul ignore next */ []);
	change = output();
	_checked = signal(false, ...ngDevMode ? [{ debugName: "_checked" }] : /* istanbul ignore next */ []);
	_disabledByForm = signal(false, ...ngDevMode ? [{ debugName: "_disabledByForm" }] : /* istanbul ignore next */ []);
	_touched = signal(false, ...ngDevMode ? [{ debugName: "_touched" }] : /* istanbul ignore next */ []);
	_isDisabled = computed(() => this.disabled() || this._disabledByForm(), ...ngDevMode ? [{ debugName: "_isDisabled" }] : /* istanbul ignore next */ []);
	_onChange = () => {};
	_onTouched = () => {};
	_handleChange(event) {
		const checked = event.target.checked;
		this._checked.set(checked);
		this._onChange(checked);
		this.change.emit(checked);
	}
	_handleBlur() {
		this._touched.set(true);
		this._onTouched();
	}
	writeValue(value) {
		this._checked.set(!!value);
	}
	registerOnChange(fn) {
		this._onChange = fn;
	}
	registerOnTouched(fn) {
		this._onTouched = fn;
	}
	setDisabledState(isDisabled) {
		this._disabledByForm.set(isDisabled);
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.1",
		ngImport: i0,
		type: BaseBooleanInput,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "17.1.0",
		version: "22.2.1",
		type: BaseBooleanInput,
		isStandalone: true,
		inputs: {
			label: {
				classPropertyName: "label",
				publicName: "label",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			disabled: {
				classPropertyName: "disabled",
				publicName: "disabled",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			id: {
				classPropertyName: "id",
				publicName: "id",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			labelPosition: {
				classPropertyName: "labelPosition",
				publicName: "labelPosition",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			viewMode: {
				classPropertyName: "viewMode",
				publicName: "viewMode",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			viewValue: {
				classPropertyName: "viewValue",
				publicName: "viewValue",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: { change: "change" },
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: BaseBooleanInput,
	decorators: [{ type: Directive }],
	propDecorators: {
		label: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "label",
				required: false
			}]
		}],
		disabled: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "disabled",
				required: false
			}]
		}],
		id: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "id",
				required: false
			}]
		}],
		labelPosition: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "labelPosition",
				required: false
			}]
		}],
		viewMode: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "viewMode",
				required: false
			}]
		}],
		viewValue: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "viewValue",
				required: false
			}]
		}],
		change: [{
			type: i0.Output,
			args: ["change"]
		}]
	}
});
var BaseRadioInput = class BaseRadioInput {
	label = input("", ...ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []);
	options = input([], ...ngDevMode ? [{ debugName: "options" }] : /* istanbul ignore next */ []);
	name = input(`l-radio-${_uid$9++}`, ...ngDevMode ? [{ debugName: "name" }] : /* istanbul ignore next */ []);
	disabled = input(false, ...ngDevMode ? [{ debugName: "disabled" }] : /* istanbul ignore next */ []);
	labelPosition = input("right", ...ngDevMode ? [{ debugName: "labelPosition" }] : /* istanbul ignore next */ []);
	orientation = input("inline", ...ngDevMode ? [{ debugName: "orientation" }] : /* istanbul ignore next */ []);
	viewMode = input(false, ...ngDevMode ? [{ debugName: "viewMode" }] : /* istanbul ignore next */ []);
	viewValue = input(...ngDevMode ? [void 0, { debugName: "viewValue" }] : /* istanbul ignore next */ []);
	change = output();
	_value = signal(null, ...ngDevMode ? [{ debugName: "_value" }] : /* istanbul ignore next */ []);
	_disabledByForm = signal(false, ...ngDevMode ? [{ debugName: "_disabledByForm" }] : /* istanbul ignore next */ []);
	_touched = signal(false, ...ngDevMode ? [{ debugName: "_touched" }] : /* istanbul ignore next */ []);
	_isDisabled = computed(() => this.disabled() || this._disabledByForm(), ...ngDevMode ? [{ debugName: "_isDisabled" }] : /* istanbul ignore next */ []);
	_selectedLabel = computed(() => this.options().find((option) => option.value === this._value())?.label, ...ngDevMode ? [{ debugName: "_selectedLabel" }] : /* istanbul ignore next */ []);
	_isChecked(value) {
		return this._value() === value;
	}
	_select(value) {
		this._value.set(value);
		this._onChange(value);
		this.change.emit(value);
	}
	_onChange = () => {};
	_onTouched = () => {};
	_handleBlur() {
		this._touched.set(true);
		this._onTouched();
	}
	writeValue(value) {
		this._value.set(value);
	}
	registerOnChange(fn) {
		this._onChange = fn;
	}
	registerOnTouched(fn) {
		this._onTouched = fn;
	}
	setDisabledState(isDisabled) {
		this._disabledByForm.set(isDisabled);
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.1",
		ngImport: i0,
		type: BaseRadioInput,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "17.1.0",
		version: "22.2.1",
		type: BaseRadioInput,
		isStandalone: true,
		inputs: {
			label: {
				classPropertyName: "label",
				publicName: "label",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			options: {
				classPropertyName: "options",
				publicName: "options",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			name: {
				classPropertyName: "name",
				publicName: "name",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			disabled: {
				classPropertyName: "disabled",
				publicName: "disabled",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			labelPosition: {
				classPropertyName: "labelPosition",
				publicName: "labelPosition",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			orientation: {
				classPropertyName: "orientation",
				publicName: "orientation",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			viewMode: {
				classPropertyName: "viewMode",
				publicName: "viewMode",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			viewValue: {
				classPropertyName: "viewValue",
				publicName: "viewValue",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: { change: "change" },
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: BaseRadioInput,
	decorators: [{ type: Directive }],
	propDecorators: {
		label: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "label",
				required: false
			}]
		}],
		options: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "options",
				required: false
			}]
		}],
		name: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "name",
				required: false
			}]
		}],
		disabled: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "disabled",
				required: false
			}]
		}],
		labelPosition: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "labelPosition",
				required: false
			}]
		}],
		orientation: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "orientation",
				required: false
			}]
		}],
		viewMode: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "viewMode",
				required: false
			}]
		}],
		viewValue: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "viewValue",
				required: false
			}]
		}],
		change: [{
			type: i0.Output,
			args: ["change"]
		}]
	}
});
let _uid$8 = 0;
var SegmentedControl = class SegmentedControl {
	options = input([], ...ngDevMode ? [{ debugName: "options" }] : /* istanbul ignore next */ []);
	orientation = input("horizontal", ...ngDevMode ? [{ debugName: "orientation" }] : /* istanbul ignore next */ []);
	size = input("md", ...ngDevMode ? [{ debugName: "size" }] : /* istanbul ignore next */ []);
	disabled = input(false, ...ngDevMode ? [{ debugName: "disabled" }] : /* istanbul ignore next */ []);
	fullWidth = input(false, ...ngDevMode ? [{ debugName: "fullWidth" }] : /* istanbul ignore next */ []);
	name = input(`l-segmented-${_uid$8++}`, ...ngDevMode ? [{ debugName: "name" }] : /* istanbul ignore next */ []);
	change = output();
	_value = signal(null, ...ngDevMode ? [{ debugName: "_value" }] : /* istanbul ignore next */ []);
	_disabledByForm = signal(false, ...ngDevMode ? [{ debugName: "_disabledByForm" }] : /* istanbul ignore next */ []);
	_isDisabled = computed(() => this.disabled() || this._disabledByForm(), ...ngDevMode ? [{ debugName: "_isDisabled" }] : /* istanbul ignore next */ []);
	_segments = viewChildren("segment", ...ngDevMode ? [{ debugName: "_segments" }] : /* istanbul ignore next */ []);
	_host = inject(ElementRef);
	_thumb = signal({
		x: 0,
		y: 0,
		width: 0,
		height: 0,
		visible: false
	}, ...ngDevMode ? [{ debugName: "_thumb" }] : /* istanbul ignore next */ []);
	_ready = signal(false, ...ngDevMode ? [{ debugName: "_ready" }] : /* istanbul ignore next */ []);
	constructor() {
		const destroyRef = inject(DestroyRef);
		effect(() => {
			this._value();
			this._options();
			this.orientation();
			this.size();
			this.fullWidth();
			queueMicrotask(() => this._positionThumb());
		});
		afterNextRender(() => {
			this._positionThumb();
			requestAnimationFrame(() => this._ready.set(true));
			const observer = new ResizeObserver(() => this._positionThumb());
			observer.observe(this._host.nativeElement);
			destroyRef.onDestroy(() => observer.disconnect());
		});
	}
	_positionThumb() {
		const index = this._options().findIndex((o) => o.value === this._value() && !o.disabled);
		const segment = this._segments()[index]?.nativeElement;
		if (index < 0 || !segment) {
			this._thumb.update((t) => ({
				...t,
				visible: false
			}));
			return;
		}
		this._thumb.set({
			x: segment.offsetLeft,
			y: segment.offsetTop,
			width: segment.offsetWidth,
			height: segment.offsetHeight,
			visible: true
		});
	}
	_options = computed(() => this.options().map((option) => option !== null && typeof option === "object" ? {
		label: option.label,
		value: option.value,
		disabled: !!option.disabled
	} : {
		label: String(option),
		value: option,
		disabled: false
	}), ...ngDevMode ? [{ debugName: "_options" }] : /* istanbul ignore next */ []);
	_tabbableValue = computed(() => {
		const options = this._options();
		return (options.find((o) => o.value === this._value() && !o.disabled) ?? options.find((o) => !o.disabled))?.value;
	}, ...ngDevMode ? [{ debugName: "_tabbableValue" }] : /* istanbul ignore next */ []);
	_hostClasses = computed(() => {
		const classes = [
			"l-segmented",
			`l-segmented--${this.orientation()}`,
			`l-segmented--${this.size()}`
		];
		if (this.fullWidth()) classes.push("l-segmented--full");
		if (this._isDisabled()) classes.push("is-disabled");
		return classes.join(" ");
	}, ...ngDevMode ? [{ debugName: "_hostClasses" }] : /* istanbul ignore next */ []);
	_onChange = () => {};
	_onTouched = () => {};
	_isSelected(value) {
		return this._value() === value;
	}
	_select(option) {
		if (this._isDisabled() || option.disabled || this._value() === option.value) return;
		this._value.set(option.value);
		this._onChange(option.value);
		this._onTouched();
		this.change.emit(option.value);
	}
	_onKeydown(event, index) {
		const horizontal = this.orientation() === "horizontal";
		let target = -1;
		switch (event.key) {
			case horizontal ? "ArrowRight" : "ArrowDown":
				target = this._nextEnabled(index, 1);
				break;
			case horizontal ? "ArrowLeft" : "ArrowUp":
				target = this._nextEnabled(index, -1);
				break;
			case "Home":
				target = this._nextEnabled(-1, 1);
				break;
			case "End":
				target = this._nextEnabled(this._options().length, -1);
				break;
			default: return;
		}
		if (target < 0) return;
		event.preventDefault();
		this._select(this._options()[target]);
		this._segments()[target]?.nativeElement.focus();
	}
	_nextEnabled(from, direction) {
		const options = this._options();
		const count = options.length;
		for (let step = 1; step <= count; step++) {
			const index = (from + direction * step + count * 2) % count;
			if (!options[index].disabled) return index;
		}
		return -1;
	}
	writeValue(value) {
		this._value.set(value ?? null);
	}
	registerOnChange(fn) {
		this._onChange = fn;
	}
	registerOnTouched(fn) {
		this._onTouched = fn;
	}
	setDisabledState(isDisabled) {
		this._disabledByForm.set(isDisabled);
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.1",
		ngImport: i0,
		type: SegmentedControl,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.1",
		type: SegmentedControl,
		isStandalone: true,
		selector: "l-segmented-control",
		inputs: {
			options: {
				classPropertyName: "options",
				publicName: "options",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			orientation: {
				classPropertyName: "orientation",
				publicName: "orientation",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			size: {
				classPropertyName: "size",
				publicName: "size",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			disabled: {
				classPropertyName: "disabled",
				publicName: "disabled",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			fullWidth: {
				classPropertyName: "fullWidth",
				publicName: "fullWidth",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			name: {
				classPropertyName: "name",
				publicName: "name",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: { change: "change" },
		host: {
			attributes: { "role": "radiogroup" },
			properties: {
				"class": "_hostClasses()",
				"attr.aria-orientation": "orientation()",
				"attr.aria-disabled": "_isDisabled() || null"
			}
		},
		providers: [provideInputValueAccessor(() => SegmentedControl)],
		viewQueries: [{
			propertyName: "_segments",
			predicate: ["segment"],
			descendants: true,
			isSignal: true
		}],
		ngImport: i0,
		template: "@if (_thumb().visible) {\n  <span\n    class=\"l-segmented__thumb\"\n    [class.is-ready]=\"_ready()\"\n    [style.width.px]=\"_thumb().width\"\n    [style.height.px]=\"_thumb().height\"\n    [style.transform]=\"'translate(' + _thumb().x + 'px, ' + _thumb().y + 'px)'\"\n  ></span>\n}\n\n@for (option of _options(); track option.value; let i = $index) {\n  <button\n    #segment\n    type=\"button\"\n    role=\"radio\"\n    class=\"l-segmented__item\"\n    [class.is-selected]=\"_isSelected(option.value)\"\n    [attr.aria-checked]=\"_isSelected(option.value)\"\n    [attr.aria-label]=\"option.label\"\n    [attr.tabindex]=\"option.value === _tabbableValue() ? 0 : -1\"\n    [disabled]=\"_isDisabled() || option.disabled\"\n    (click)=\"_select(option)\"\n    (keydown)=\"_onKeydown($event, i)\"\n  >\n    <span class=\"l-segmented__label\">{{ option.label }}</span>\n  </button>\n}\n",
		styles: [":host{--l-seg-track-bg: rgba(0, 0, 0, .04);--l-seg-item-color: rgba(0, 0, 0, .65);--l-seg-item-hover-color: rgba(0, 0, 0, .88);--l-seg-item-hover-bg: rgba(0, 0, 0, .06);--l-seg-selected-color: rgba(0, 0, 0, .88);--l-seg-thumb-bg: var(--bg-lightest);--l-seg-disabled-color: rgba(0, 0, 0, .25);position:relative;display:inline-flex;flex-direction:row;padding:2px;background:var(--l-seg-track-bg);border-radius:8px;box-sizing:border-box;vertical-align:middle;font-family:-apple-system,BlinkMacSystemFont,Segoe UI,Roboto,Helvetica Neue,Arial,Noto Sans,sans-serif,\"Apple Color Emoji\",\"Segoe UI Emoji\",Segoe UI Symbol,\"Noto Color Emoji\";font-size:14px}:host(.l-segmented--vertical){flex-direction:column}:host(.l-segmented--full){display:flex;width:100%}:host(.l-segmented--full) .l-segmented__item{flex:1}:host(.is-disabled){opacity:.65}.l-segmented__thumb{position:absolute;top:0;left:0;z-index:0;border-radius:6px;background:var(--l-seg-thumb-bg);box-shadow:0 1px 2px #00000008,0 1px 6px -1px #00000005,0 2px 4px #00000005;pointer-events:none}.l-segmented__thumb.is-ready{transition:transform .3s cubic-bezier(.645,.045,.355,1),width .3s cubic-bezier(.645,.045,.355,1),height .3s cubic-bezier(.645,.045,.355,1)}.l-segmented__item{position:relative;z-index:1;appearance:none;-webkit-appearance:none;margin:0;border:none;background:transparent;display:inline-flex;align-items:center;justify-content:center;min-height:28px;padding:0 11px;border-radius:6px;font:inherit;color:var(--l-seg-item-color);white-space:nowrap;cursor:pointer;transition:color .2s cubic-bezier(.645,.045,.355,1)}.l-segmented__item:hover:not(.is-selected):not(:disabled){color:var(--l-seg-item-hover-color);background:var(--l-seg-item-hover-bg)}.l-segmented__item.is-selected{color:var(--l-seg-selected-color)}.l-segmented__item:focus-visible{outline:2px solid var(--accent);outline-offset:1px}.l-segmented__item:disabled{color:var(--l-seg-disabled-color);cursor:not-allowed}:host(.l-segmented--sm) .l-segmented__item{min-height:20px;padding:0 7px}:host(.l-segmented--lg) .l-segmented__item{min-height:36px;padding:0 11px;font-size:16px}@media(prefers-reduced-motion:reduce){.l-segmented__thumb.is-ready,.l-segmented__item{transition:none}}\n"],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: SegmentedControl,
	decorators: [{
		type: Component,
		args: [{
			selector: "l-segmented-control",
			changeDetection: ChangeDetectionStrategy.OnPush,
			providers: [provideInputValueAccessor(() => SegmentedControl)],
			host: {
				"[class]": "_hostClasses()",
				role: "radiogroup",
				"[attr.aria-orientation]": "orientation()",
				"[attr.aria-disabled]": "_isDisabled() || null"
			},
			template: "@if (_thumb().visible) {\n  <span\n    class=\"l-segmented__thumb\"\n    [class.is-ready]=\"_ready()\"\n    [style.width.px]=\"_thumb().width\"\n    [style.height.px]=\"_thumb().height\"\n    [style.transform]=\"'translate(' + _thumb().x + 'px, ' + _thumb().y + 'px)'\"\n  ></span>\n}\n\n@for (option of _options(); track option.value; let i = $index) {\n  <button\n    #segment\n    type=\"button\"\n    role=\"radio\"\n    class=\"l-segmented__item\"\n    [class.is-selected]=\"_isSelected(option.value)\"\n    [attr.aria-checked]=\"_isSelected(option.value)\"\n    [attr.aria-label]=\"option.label\"\n    [attr.tabindex]=\"option.value === _tabbableValue() ? 0 : -1\"\n    [disabled]=\"_isDisabled() || option.disabled\"\n    (click)=\"_select(option)\"\n    (keydown)=\"_onKeydown($event, i)\"\n  >\n    <span class=\"l-segmented__label\">{{ option.label }}</span>\n  </button>\n}\n",
			styles: [":host{--l-seg-track-bg: rgba(0, 0, 0, .04);--l-seg-item-color: rgba(0, 0, 0, .65);--l-seg-item-hover-color: rgba(0, 0, 0, .88);--l-seg-item-hover-bg: rgba(0, 0, 0, .06);--l-seg-selected-color: rgba(0, 0, 0, .88);--l-seg-thumb-bg: var(--bg-lightest);--l-seg-disabled-color: rgba(0, 0, 0, .25);position:relative;display:inline-flex;flex-direction:row;padding:2px;background:var(--l-seg-track-bg);border-radius:8px;box-sizing:border-box;vertical-align:middle;font-family:-apple-system,BlinkMacSystemFont,Segoe UI,Roboto,Helvetica Neue,Arial,Noto Sans,sans-serif,\"Apple Color Emoji\",\"Segoe UI Emoji\",Segoe UI Symbol,\"Noto Color Emoji\";font-size:14px}:host(.l-segmented--vertical){flex-direction:column}:host(.l-segmented--full){display:flex;width:100%}:host(.l-segmented--full) .l-segmented__item{flex:1}:host(.is-disabled){opacity:.65}.l-segmented__thumb{position:absolute;top:0;left:0;z-index:0;border-radius:6px;background:var(--l-seg-thumb-bg);box-shadow:0 1px 2px #00000008,0 1px 6px -1px #00000005,0 2px 4px #00000005;pointer-events:none}.l-segmented__thumb.is-ready{transition:transform .3s cubic-bezier(.645,.045,.355,1),width .3s cubic-bezier(.645,.045,.355,1),height .3s cubic-bezier(.645,.045,.355,1)}.l-segmented__item{position:relative;z-index:1;appearance:none;-webkit-appearance:none;margin:0;border:none;background:transparent;display:inline-flex;align-items:center;justify-content:center;min-height:28px;padding:0 11px;border-radius:6px;font:inherit;color:var(--l-seg-item-color);white-space:nowrap;cursor:pointer;transition:color .2s cubic-bezier(.645,.045,.355,1)}.l-segmented__item:hover:not(.is-selected):not(:disabled){color:var(--l-seg-item-hover-color);background:var(--l-seg-item-hover-bg)}.l-segmented__item.is-selected{color:var(--l-seg-selected-color)}.l-segmented__item:focus-visible{outline:2px solid var(--accent);outline-offset:1px}.l-segmented__item:disabled{color:var(--l-seg-disabled-color);cursor:not-allowed}:host(.l-segmented--sm) .l-segmented__item{min-height:20px;padding:0 7px}:host(.l-segmented--lg) .l-segmented__item{min-height:36px;padding:0 11px;font-size:16px}@media(prefers-reduced-motion:reduce){.l-segmented__thumb.is-ready,.l-segmented__item{transition:none}}\n"]
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		options: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "options",
				required: false
			}]
		}],
		orientation: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "orientation",
				required: false
			}]
		}],
		size: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "size",
				required: false
			}]
		}],
		disabled: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "disabled",
				required: false
			}]
		}],
		fullWidth: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "fullWidth",
				required: false
			}]
		}],
		name: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "name",
				required: false
			}]
		}],
		change: [{
			type: i0.Output,
			args: ["change"]
		}],
		_segments: [{
			type: i0.ViewChildren,
			args: ["segment", { isSignal: true }]
		}]
	}
});
var FormValidation = class FormValidation {
	useValidation = input(true, {
		...ngDevMode ? { debugName: "useValidation" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	_host = inject(ElementRef);
	_renderer = inject(Renderer2);
	_ngControl = inject(NgControl, { optional: true });
	_errorEl = null;
	_asteriskEl = null;
	_destroy$ = new Subject();
	constructor() {
		afterNextRender(() => this._init());
	}
	ngOnDestroy() {
		this._destroy$.next();
		this._destroy$.complete();
		this._removeError();
		this._removeAsterisk();
	}
	_init() {
		const control = this._ngControl?.control;
		if (!this.useValidation() || !control) return;
		control.events.pipe(takeUntil(this._destroy$)).subscribe(() => this._refresh());
		this._refresh();
	}
	_refresh() {
		const control = this._ngControl?.control;
		if (!control) return;
		if (this._isRequired()) this._addAsterisk();
		else this._removeAsterisk();
		const message = control.errors ? this._messageFor(control.errors) : null;
		if (!!message && (control.touched || control.dirty)) {
			this._renderer.addClass(this._controlEl, "error");
			this._showError(message);
		} else {
			this._renderer.removeClass(this._controlEl, "error");
			this._removeError();
		}
	}
	_messageFor(errors) {
		if (errors["required"] || errors["requiredTrue"]) return "This field is required.";
		if (errors["minlength"]) return `Must be at least ${errors["minlength"].requiredLength} characters.`;
		if (errors["maxlength"]) return `Must be no more than ${errors["maxlength"].requiredLength} characters.`;
		if (errors["min"]) return `Must be at least ${errors["min"].min}.`;
		if (errors["max"]) return `Must be no more than ${errors["max"].max}.`;
		if (errors["pattern"]) return "Please match the required format.";
		return null;
	}
	_isRequired() {
		const control = this._ngControl?.control;
		if (!control?.validator) return false;
		const result = control.validator({ value: null });
		return !!(result?.["required"] || result?.["requiredTrue"]);
	}
	_query(selector) {
		const host = this._host.nativeElement;
		return host.closest(selector) ?? host.querySelector(selector);
	}
	get _formGroup() {
		return this._query(".form-group");
	}
	get _controlEl() {
		const host = this._host.nativeElement;
		if (host.matches(".form-control")) return host;
		return host.querySelector(".form-control") ?? host;
	}
	_showError(message) {
		if (this._errorEl) {
			this._renderer.setProperty(this._errorEl, "textContent", message);
			return;
		}
		const div = this._renderer.createElement("div");
		this._renderer.addClass(div, "alert");
		this._renderer.addClass(div, "error");
		this._renderer.appendChild(div, this._renderer.createText(message));
		const group = this._formGroup;
		if (group) this._renderer.appendChild(group, div);
		else {
			const anchor = this._controlEl;
			this._renderer.insertBefore(anchor.parentNode, div, anchor.nextSibling);
		}
		this._errorEl = div;
	}
	_removeError() {
		if (!this._errorEl) return;
		this._renderer.removeChild(this._errorEl.parentNode, this._errorEl);
		this._errorEl = null;
	}
	_addAsterisk() {
		if (this._asteriskEl) return;
		const label = this._formGroup?.querySelector(":scope > label");
		if (!label) return;
		const existing = label.querySelector(".required-asterisk");
		if (existing) {
			this._asteriskEl = existing;
			return;
		}
		const span = this._renderer.createElement("span");
		this._renderer.addClass(span, "required-asterisk");
		this._renderer.appendChild(span, this._renderer.createText(" *"));
		this._renderer.appendChild(label, span);
		this._asteriskEl = span;
	}
	_removeAsterisk() {
		if (!this._asteriskEl) return;
		this._renderer.removeChild(this._asteriskEl.parentNode, this._asteriskEl);
		this._asteriskEl = null;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.1",
		ngImport: i0,
		type: FormValidation,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "17.1.0",
		version: "22.2.1",
		type: FormValidation,
		isStandalone: true,
		selector: "\n    input[formControlName], input[formControl], input[ngModel],\n    textarea[formControlName], textarea[formControl], textarea[ngModel]\n  ",
		inputs: { useValidation: {
			classPropertyName: "useValidation",
			publicName: "useValidation",
			isSignal: true,
			isRequired: false,
			transformFunction: null
		} },
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: FormValidation,
	decorators: [{
		type: Directive,
		args: [{ selector: `
    input[formControlName], input[formControl], input[ngModel],
    textarea[formControlName], textarea[formControl], textarea[ngModel]
  ` }]
	}],
	ctorParameters: () => [],
	propDecorators: { useValidation: [{
		type: i0.Input,
		args: [{
			isSignal: true,
			alias: "useValidation",
			required: false
		}]
	}] }
});
var TextInput = class TextInput extends BaseInput {
	type = "text";
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.1",
		ngImport: i0,
		type: TextInput,
		deps: null,
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.1",
		type: TextInput,
		isStandalone: true,
		selector: "l-text-input",
		providers: [provideInputValueAccessor(() => TextInput)],
		usesInheritance: true,
		hostDirectives: [{
			directive: FormValidation,
			inputs: ["useValidation", "useValidation"]
		}],
		ngImport: i0,
		template: "@if (viewMode()) {\n  <div class=\"form-group view-mode\">\n    @if (label()) {\n      <label>{{ label() }}</label>\n    }\n    <div class=\"view-value\">{{ viewValue() ?? (_value() || '-') }}</div>\n  </div>\n} @else {\n  <div class=\"form-group\">\n    @if (label()) {\n      <label [attr.for]=\"id()\">{{ label() }}</label>\n    }\n\n    <input\n      class=\"form-control\"\n      [id]=\"id()\"\n      [type]=\"type\"\n      [value]=\"_value()\"\n      [placeholder]=\"placeholder()\"\n      [disabled]=\"_isDisabled()\"\n      (input)=\"_handleInput($event)\"\n      (change)=\"change.emit($event)\"\n      (keyup)=\"keyup.emit($event)\"\n      (keydown)=\"keydown.emit($event)\"\n      (keypress)=\"keypress.emit($event)\"\n      (keydown.enter)=\"_handleEnter($event)\"\n      (blur)=\"_handleBlur()\"\n    />\n  </div>\n}\n",
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: TextInput,
	decorators: [{
		type: Component,
		args: [{
			selector: "l-text-input",
			changeDetection: ChangeDetectionStrategy.OnPush,
			imports: [],
			providers: [provideInputValueAccessor(() => TextInput)],
			hostDirectives: [{
				directive: FormValidation,
				inputs: ["useValidation"]
			}],
			template: "@if (viewMode()) {\n  <div class=\"form-group view-mode\">\n    @if (label()) {\n      <label>{{ label() }}</label>\n    }\n    <div class=\"view-value\">{{ viewValue() ?? (_value() || '-') }}</div>\n  </div>\n} @else {\n  <div class=\"form-group\">\n    @if (label()) {\n      <label [attr.for]=\"id()\">{{ label() }}</label>\n    }\n\n    <input\n      class=\"form-control\"\n      [id]=\"id()\"\n      [type]=\"type\"\n      [value]=\"_value()\"\n      [placeholder]=\"placeholder()\"\n      [disabled]=\"_isDisabled()\"\n      (input)=\"_handleInput($event)\"\n      (change)=\"change.emit($event)\"\n      (keyup)=\"keyup.emit($event)\"\n      (keydown)=\"keydown.emit($event)\"\n      (keypress)=\"keypress.emit($event)\"\n      (keydown.enter)=\"_handleEnter($event)\"\n      (blur)=\"_handleBlur()\"\n    />\n  </div>\n}\n"
		}]
	}]
});
var PasswordInput = class PasswordInput extends BaseInput {
	showRules = input(false, ...ngDevMode ? [{ debugName: "showRules" }] : /* istanbul ignore next */ []);
	_visible = signal(false, ...ngDevMode ? [{ debugName: "_visible" }] : /* istanbul ignore next */ []);
	get type() {
		return this._visible() ? "text" : "password";
	}
	hasMinLength = computed(() => this._value().length >= 8, ...ngDevMode ? [{ debugName: "hasMinLength" }] : /* istanbul ignore next */ []);
	hasUpperLower = computed(() => /[a-z]/.test(this._value()) && /[A-Z]/.test(this._value()), ...ngDevMode ? [{ debugName: "hasUpperLower" }] : /* istanbul ignore next */ []);
	hasSpecialChar = computed(() => /[^A-Za-z0-9]/.test(this._value()), ...ngDevMode ? [{ debugName: "hasSpecialChar" }] : /* istanbul ignore next */ []);
	hasNumber = computed(() => /\d/.test(this._value()), ...ngDevMode ? [{ debugName: "hasNumber" }] : /* istanbul ignore next */ []);
	_toggleVisible() {
		this._visible.update((visible) => !visible);
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.1",
		ngImport: i0,
		type: PasswordInput,
		deps: null,
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.1",
		type: PasswordInput,
		isStandalone: true,
		selector: "l-password-input",
		inputs: { showRules: {
			classPropertyName: "showRules",
			publicName: "showRules",
			isSignal: true,
			isRequired: false,
			transformFunction: null
		} },
		providers: [provideInputValueAccessor(() => PasswordInput)],
		usesInheritance: true,
		hostDirectives: [{
			directive: FormValidation,
			inputs: ["useValidation", "useValidation"]
		}],
		ngImport: i0,
		template: "@if (viewMode()) {\n  <div class=\"form-group view-mode\">\n    @if (label()) {\n      <label>{{ label() }}</label>\n    }\n    <div class=\"view-value\">{{ viewValue() ?? (_value() || '-') }}</div>\n  </div>\n} @else {\n  <div class=\"form-group\">\n    @if (label()) {\n      <label [attr.for]=\"id()\">{{ label() }}</label>\n    }\n\n    <div class=\"input-wrapper\">\n      <span class=\"left-icon\" aria-hidden=\"true\">\n        <svg\n          width=\"18\"\n          height=\"18\"\n          viewBox=\"0 0 20 20\"\n          fill=\"none\"\n          xmlns=\"http://www.w3.org/2000/svg\"\n        >\n          <path\n            d=\"M10 2.33301C12.3929 2.33318 14.3336 4.27319 14.334 6.66602V9.00781C15.7285 9.09423 16.8336 10.2498 16.834 11.666V15C16.8338 16.4725 15.6395 17.6658 14.167 17.666H5.83398C4.36133 17.666 3.16717 16.4726 3.16699 15V11.666C3.16733 10.2496 4.27217 9.09392 5.66699 9.00781V6.66602C5.66734 4.27319 7.60713 2.33318 10 2.33301ZM5.83398 11C5.46601 11 5.16734 11.2981 5.16699 11.666V15C5.16717 15.368 5.4659 15.666 5.83398 15.666H14.167C14.5349 15.6658 14.8338 15.3679 14.834 15V11.666C14.8336 11.2982 14.5348 11.0002 14.167 11H5.83398ZM10 12.292C10.5752 12.292 11.0418 12.7579 11.042 13.333C11.042 13.9083 10.5753 14.375 10 14.375C9.4247 14.375 8.95801 13.9083 8.95801 13.333C8.95818 12.7579 9.42481 12.292 10 12.292ZM10 4.33301C8.7117 4.33318 7.66734 5.37776 7.66699 6.66602V9H12.334V6.66602C12.3336 5.37776 11.2883 4.33318 10 4.33301Z\"\n            fill=\"#646663\"\n          />\n        </svg>\n      </span>\n\n      <input\n        class=\"form-control\"\n        [id]=\"id()\"\n        [type]=\"type\"\n        [value]=\"_value()\"\n        [placeholder]=\"placeholder()\"\n        [disabled]=\"_isDisabled()\"\n        (input)=\"_handleInput($event)\"\n        (change)=\"change.emit($event)\"\n        (keyup)=\"keyup.emit($event)\"\n        (keydown)=\"keydown.emit($event)\"\n        (keypress)=\"keypress.emit($event)\"\n        (keydown.enter)=\"_handleEnter($event)\"\n        (blur)=\"_handleBlur()\"\n      />\n\n      <button\n        type=\"button\"\n        class=\"right-icon clickable\"\n        [attr.aria-label]=\"_visible() ? 'Hide password' : 'Show password'\"\n        [attr.aria-pressed]=\"_visible()\"\n        [disabled]=\"_isDisabled()\"\n        (click)=\"_toggleVisible()\"\n      >\n        @if (_visible()) {\n          <svg\n            width=\"18\"\n            height=\"18\"\n            viewBox=\"0 0 20 20\"\n            fill=\"none\"\n            xmlns=\"http://www.w3.org/2000/svg\"\n          >\n            <path\n              d=\"M12.9833 9.99993C12.9833 11.6499 11.6499 12.9833 9.99993 12.9833C8.34993 12.9833 7.0166 11.6499 7.0166 9.99993C7.0166 8.34993 8.34993 7.0166 9.99993 7.0166C11.6499 7.0166 12.9833 8.34993 12.9833 9.99993Z\"\n              stroke=\"#4B5563\"\n              stroke-width=\"1.5\"\n              stroke-linecap=\"round\"\n              stroke-linejoin=\"round\"\n            />\n            <path\n              d=\"M9.99987 16.8918C12.9415 16.8918 15.6832 15.1584 17.5915 12.1584C18.3415 10.9834 18.3415 9.00843 17.5915 7.83343C15.6832 4.83343 12.9415 3.1001 9.99987 3.1001C7.0582 3.1001 4.31654 4.83343 2.4082 7.83343C1.6582 9.00843 1.6582 10.9834 2.4082 12.1584C4.31654 15.1584 7.0582 16.8918 9.99987 16.8918Z\"\n              stroke=\"#4B5563\"\n              stroke-width=\"1.5\"\n              stroke-linecap=\"round\"\n              stroke-linejoin=\"round\"\n            />\n          </svg>\n        } @else {\n          <svg\n            width=\"18\"\n            height=\"18\"\n            viewBox=\"0 0 24 24\"\n            fill=\"none\"\n            xmlns=\"http://www.w3.org/2000/svg\"\n          >\n            <path\n              d=\"M14.53 9.46992L9.47001 14.5299C8.82001 13.8799 8.42001 12.9899 8.42001 11.9999C8.42001 10.0199 10.02 8.41992 12 8.41992C12.99 8.41992 13.88 8.81992 14.53 9.46992Z\"\n              stroke=\"#4B5563\"\n              stroke-width=\"1.5\"\n              stroke-linecap=\"round\"\n              stroke-linejoin=\"round\"\n            />\n            <path\n              d=\"M17.82 5.76998C16.07 4.44998 14.07 3.72998 12 3.72998C8.47 3.72998 5.18 5.80998 2.89 9.40998C1.99 10.82 1.99 13.19 2.89 14.6C3.68 15.84 4.6 16.91 5.6 17.77\"\n              stroke=\"#4B5563\"\n              stroke-width=\"1.5\"\n              stroke-linecap=\"round\"\n              stroke-linejoin=\"round\"\n            />\n            <path\n              d=\"M8.42001 19.5302C9.56001 20.0102 10.77 20.2702 12 20.2702C15.53 20.2702 18.82 18.1902 21.11 14.5902C22.01 13.1802 22.01 10.8102 21.11 9.40018C20.78 8.88018 20.42 8.39018 20.05 7.93018\"\n              stroke=\"#4B5563\"\n              stroke-width=\"1.5\"\n              stroke-linecap=\"round\"\n              stroke-linejoin=\"round\"\n            />\n            <path\n              d=\"M15.51 12.7002C15.25 14.1102 14.1 15.2602 12.69 15.5202\"\n              stroke=\"#4B5563\"\n              stroke-width=\"1.5\"\n              stroke-linecap=\"round\"\n              stroke-linejoin=\"round\"\n            />\n            <path\n              d=\"M9.47 14.5298L2 21.9998\"\n              stroke=\"#4B5563\"\n              stroke-width=\"1.5\"\n              stroke-linecap=\"round\"\n              stroke-linejoin=\"round\"\n            />\n            <path\n              d=\"M22 2L14.53 9.47\"\n              stroke=\"#4B5563\"\n              stroke-width=\"1.5\"\n              stroke-linecap=\"round\"\n              stroke-linejoin=\"round\"\n            />\n          </svg>\n        }\n      </button>\n    </div>\n\n    @if (showRules()) {\n      <div class=\"password-rules\">\n        <p>Password must have :</p>\n\n        <div class=\"rule\" [class.valid]=\"hasMinLength()\"><span></span> At least 8 characters</div>\n        <div class=\"rule\" [class.valid]=\"hasUpperLower()\">\n          <span></span> Uppercase and lowercase character (A–a)\n        </div>\n        <div class=\"rule\" [class.valid]=\"hasSpecialChar()\">\n          <span></span> One Special character (!, &#64;, #, $, % ...)\n        </div>\n        <div class=\"rule\" [class.valid]=\"hasNumber()\"><span></span> One number (1–9)</div>\n      </div>\n    }\n  </div>\n}\n",
		styles: [".right-icon.clickable{display:inline-flex;align-items:center;justify-content:center;padding:0;border:0;background:transparent;color:inherit}.right-icon.clickable:focus-visible{outline:2px solid var(--accent);outline-offset:2px;border-radius:4px}.right-icon.clickable:disabled{cursor:not-allowed}.password-rules{font-size:14px;color:var(--text-quaternary)}.password-rules p{margin-bottom:8px;font-weight:500}.password-rules .rule{display:flex;align-items:center;gap:8px;margin-bottom:6px}.password-rules .rule span{width:12px;height:12px;border-radius:50%;border:1px solid var(--separator-dark);display:inline-block}.password-rules .rule.valid{color:var(--success)}.password-rules .rule.valid span{background:var(--success);border:var(--success)}\n"],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: PasswordInput,
	decorators: [{
		type: Component,
		args: [{
			selector: "l-password-input",
			changeDetection: ChangeDetectionStrategy.OnPush,
			imports: [],
			providers: [provideInputValueAccessor(() => PasswordInput)],
			hostDirectives: [{
				directive: FormValidation,
				inputs: ["useValidation"]
			}],
			template: "@if (viewMode()) {\n  <div class=\"form-group view-mode\">\n    @if (label()) {\n      <label>{{ label() }}</label>\n    }\n    <div class=\"view-value\">{{ viewValue() ?? (_value() || '-') }}</div>\n  </div>\n} @else {\n  <div class=\"form-group\">\n    @if (label()) {\n      <label [attr.for]=\"id()\">{{ label() }}</label>\n    }\n\n    <div class=\"input-wrapper\">\n      <span class=\"left-icon\" aria-hidden=\"true\">\n        <svg\n          width=\"18\"\n          height=\"18\"\n          viewBox=\"0 0 20 20\"\n          fill=\"none\"\n          xmlns=\"http://www.w3.org/2000/svg\"\n        >\n          <path\n            d=\"M10 2.33301C12.3929 2.33318 14.3336 4.27319 14.334 6.66602V9.00781C15.7285 9.09423 16.8336 10.2498 16.834 11.666V15C16.8338 16.4725 15.6395 17.6658 14.167 17.666H5.83398C4.36133 17.666 3.16717 16.4726 3.16699 15V11.666C3.16733 10.2496 4.27217 9.09392 5.66699 9.00781V6.66602C5.66734 4.27319 7.60713 2.33318 10 2.33301ZM5.83398 11C5.46601 11 5.16734 11.2981 5.16699 11.666V15C5.16717 15.368 5.4659 15.666 5.83398 15.666H14.167C14.5349 15.6658 14.8338 15.3679 14.834 15V11.666C14.8336 11.2982 14.5348 11.0002 14.167 11H5.83398ZM10 12.292C10.5752 12.292 11.0418 12.7579 11.042 13.333C11.042 13.9083 10.5753 14.375 10 14.375C9.4247 14.375 8.95801 13.9083 8.95801 13.333C8.95818 12.7579 9.42481 12.292 10 12.292ZM10 4.33301C8.7117 4.33318 7.66734 5.37776 7.66699 6.66602V9H12.334V6.66602C12.3336 5.37776 11.2883 4.33318 10 4.33301Z\"\n            fill=\"#646663\"\n          />\n        </svg>\n      </span>\n\n      <input\n        class=\"form-control\"\n        [id]=\"id()\"\n        [type]=\"type\"\n        [value]=\"_value()\"\n        [placeholder]=\"placeholder()\"\n        [disabled]=\"_isDisabled()\"\n        (input)=\"_handleInput($event)\"\n        (change)=\"change.emit($event)\"\n        (keyup)=\"keyup.emit($event)\"\n        (keydown)=\"keydown.emit($event)\"\n        (keypress)=\"keypress.emit($event)\"\n        (keydown.enter)=\"_handleEnter($event)\"\n        (blur)=\"_handleBlur()\"\n      />\n\n      <button\n        type=\"button\"\n        class=\"right-icon clickable\"\n        [attr.aria-label]=\"_visible() ? 'Hide password' : 'Show password'\"\n        [attr.aria-pressed]=\"_visible()\"\n        [disabled]=\"_isDisabled()\"\n        (click)=\"_toggleVisible()\"\n      >\n        @if (_visible()) {\n          <svg\n            width=\"18\"\n            height=\"18\"\n            viewBox=\"0 0 20 20\"\n            fill=\"none\"\n            xmlns=\"http://www.w3.org/2000/svg\"\n          >\n            <path\n              d=\"M12.9833 9.99993C12.9833 11.6499 11.6499 12.9833 9.99993 12.9833C8.34993 12.9833 7.0166 11.6499 7.0166 9.99993C7.0166 8.34993 8.34993 7.0166 9.99993 7.0166C11.6499 7.0166 12.9833 8.34993 12.9833 9.99993Z\"\n              stroke=\"#4B5563\"\n              stroke-width=\"1.5\"\n              stroke-linecap=\"round\"\n              stroke-linejoin=\"round\"\n            />\n            <path\n              d=\"M9.99987 16.8918C12.9415 16.8918 15.6832 15.1584 17.5915 12.1584C18.3415 10.9834 18.3415 9.00843 17.5915 7.83343C15.6832 4.83343 12.9415 3.1001 9.99987 3.1001C7.0582 3.1001 4.31654 4.83343 2.4082 7.83343C1.6582 9.00843 1.6582 10.9834 2.4082 12.1584C4.31654 15.1584 7.0582 16.8918 9.99987 16.8918Z\"\n              stroke=\"#4B5563\"\n              stroke-width=\"1.5\"\n              stroke-linecap=\"round\"\n              stroke-linejoin=\"round\"\n            />\n          </svg>\n        } @else {\n          <svg\n            width=\"18\"\n            height=\"18\"\n            viewBox=\"0 0 24 24\"\n            fill=\"none\"\n            xmlns=\"http://www.w3.org/2000/svg\"\n          >\n            <path\n              d=\"M14.53 9.46992L9.47001 14.5299C8.82001 13.8799 8.42001 12.9899 8.42001 11.9999C8.42001 10.0199 10.02 8.41992 12 8.41992C12.99 8.41992 13.88 8.81992 14.53 9.46992Z\"\n              stroke=\"#4B5563\"\n              stroke-width=\"1.5\"\n              stroke-linecap=\"round\"\n              stroke-linejoin=\"round\"\n            />\n            <path\n              d=\"M17.82 5.76998C16.07 4.44998 14.07 3.72998 12 3.72998C8.47 3.72998 5.18 5.80998 2.89 9.40998C1.99 10.82 1.99 13.19 2.89 14.6C3.68 15.84 4.6 16.91 5.6 17.77\"\n              stroke=\"#4B5563\"\n              stroke-width=\"1.5\"\n              stroke-linecap=\"round\"\n              stroke-linejoin=\"round\"\n            />\n            <path\n              d=\"M8.42001 19.5302C9.56001 20.0102 10.77 20.2702 12 20.2702C15.53 20.2702 18.82 18.1902 21.11 14.5902C22.01 13.1802 22.01 10.8102 21.11 9.40018C20.78 8.88018 20.42 8.39018 20.05 7.93018\"\n              stroke=\"#4B5563\"\n              stroke-width=\"1.5\"\n              stroke-linecap=\"round\"\n              stroke-linejoin=\"round\"\n            />\n            <path\n              d=\"M15.51 12.7002C15.25 14.1102 14.1 15.2602 12.69 15.5202\"\n              stroke=\"#4B5563\"\n              stroke-width=\"1.5\"\n              stroke-linecap=\"round\"\n              stroke-linejoin=\"round\"\n            />\n            <path\n              d=\"M9.47 14.5298L2 21.9998\"\n              stroke=\"#4B5563\"\n              stroke-width=\"1.5\"\n              stroke-linecap=\"round\"\n              stroke-linejoin=\"round\"\n            />\n            <path\n              d=\"M22 2L14.53 9.47\"\n              stroke=\"#4B5563\"\n              stroke-width=\"1.5\"\n              stroke-linecap=\"round\"\n              stroke-linejoin=\"round\"\n            />\n          </svg>\n        }\n      </button>\n    </div>\n\n    @if (showRules()) {\n      <div class=\"password-rules\">\n        <p>Password must have :</p>\n\n        <div class=\"rule\" [class.valid]=\"hasMinLength()\"><span></span> At least 8 characters</div>\n        <div class=\"rule\" [class.valid]=\"hasUpperLower()\">\n          <span></span> Uppercase and lowercase character (A–a)\n        </div>\n        <div class=\"rule\" [class.valid]=\"hasSpecialChar()\">\n          <span></span> One Special character (!, &#64;, #, $, % ...)\n        </div>\n        <div class=\"rule\" [class.valid]=\"hasNumber()\"><span></span> One number (1–9)</div>\n      </div>\n    }\n  </div>\n}\n",
			styles: [".right-icon.clickable{display:inline-flex;align-items:center;justify-content:center;padding:0;border:0;background:transparent;color:inherit}.right-icon.clickable:focus-visible{outline:2px solid var(--accent);outline-offset:2px;border-radius:4px}.right-icon.clickable:disabled{cursor:not-allowed}.password-rules{font-size:14px;color:var(--text-quaternary)}.password-rules p{margin-bottom:8px;font-weight:500}.password-rules .rule{display:flex;align-items:center;gap:8px;margin-bottom:6px}.password-rules .rule span{width:12px;height:12px;border-radius:50%;border:1px solid var(--separator-dark);display:inline-block}.password-rules .rule.valid{color:var(--success)}.password-rules .rule.valid span{background:var(--success);border:var(--success)}\n"]
		}]
	}],
	propDecorators: { showRules: [{
		type: i0.Input,
		args: [{
			isSignal: true,
			alias: "showRules",
			required: false
		}]
	}] }
});
const EMAIL_PATTERN = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
var EmailInput = class EmailInput extends BaseInput {
	type = "email";
	_invalid = computed(() => this._touched() && this._value().length > 0 && !EMAIL_PATTERN.test(this._value()), ...ngDevMode ? [{ debugName: "_invalid" }] : /* istanbul ignore next */ []);
	validate(control) {
		const value = control.value;
		if (!value) return null;
		return EMAIL_PATTERN.test(value) ? null : { email: true };
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.1",
		ngImport: i0,
		type: EmailInput,
		deps: null,
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.1",
		type: EmailInput,
		isStandalone: true,
		selector: "l-email-input",
		providers: [provideInputValueAccessor(() => EmailInput), provideInputValidator(() => EmailInput)],
		usesInheritance: true,
		hostDirectives: [{
			directive: FormValidation,
			inputs: ["useValidation", "useValidation"]
		}],
		ngImport: i0,
		template: "@if (viewMode()) {\n  <div class=\"form-group view-mode\">\n    @if (label()) {\n      <label>{{ label() }}</label>\n    }\n    <div class=\"view-value\">{{ viewValue() ?? (_value() || '-') }}</div>\n  </div>\n} @else {\n  <div class=\"form-group\">\n    @if (label()) {\n      <label [attr.for]=\"id()\">{{ label() }}</label>\n    }\n\n    <div class=\"input-wrapper\">\n      <span class=\"left-icon\" aria-hidden=\"true\">\n        <svg\n          width=\"18\"\n          height=\"18\"\n          viewBox=\"0 0 20 20\"\n          fill=\"none\"\n          xmlns=\"http://www.w3.org/2000/svg\"\n        >\n          <path\n            d=\"M5 6.66675L8.50929 8.42139C9.44771 8.8906 10.5523 8.8906 11.4907 8.42139L15 6.66675M5 15.8334H15C16.3807 15.8334 17.5 14.7141 17.5 13.3334V6.66675C17.5 5.28604 16.3807 4.16675 15 4.16675H5C3.61929 4.16675 2.5 5.28604 2.5 6.66675V13.3334C2.5 14.7141 3.61929 15.8334 5 15.8334Z\"\n            stroke=\"#646663\"\n            stroke-width=\"1.5\"\n            stroke-linecap=\"round\"\n            stroke-linejoin=\"round\"\n          />\n        </svg>\n      </span>\n\n      <input\n        class=\"form-control\"\n        [class.error]=\"_invalid()\"\n        [id]=\"id()\"\n        [type]=\"type\"\n        [value]=\"_value()\"\n        [placeholder]=\"placeholder()\"\n        [disabled]=\"_isDisabled()\"\n        [attr.aria-invalid]=\"_invalid()\"\n        [attr.aria-describedby]=\"_invalid() ? id() + '-error' : null\"\n        (input)=\"_handleInput($event)\"\n        (change)=\"change.emit($event)\"\n        (keyup)=\"keyup.emit($event)\"\n        (keydown)=\"keydown.emit($event)\"\n        (keypress)=\"keypress.emit($event)\"\n        (keydown.enter)=\"_handleEnter($event)\"\n        (blur)=\"_handleBlur()\"\n      />\n    </div>\n\n    @if (_invalid()) {\n      <span class=\"alert error\" [id]=\"id() + '-error'\">Please enter a valid email address.</span>\n    }\n  </div>\n}\n",
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: EmailInput,
	decorators: [{
		type: Component,
		args: [{
			selector: "l-email-input",
			changeDetection: ChangeDetectionStrategy.OnPush,
			imports: [],
			providers: [provideInputValueAccessor(() => EmailInput), provideInputValidator(() => EmailInput)],
			hostDirectives: [{
				directive: FormValidation,
				inputs: ["useValidation"]
			}],
			template: "@if (viewMode()) {\n  <div class=\"form-group view-mode\">\n    @if (label()) {\n      <label>{{ label() }}</label>\n    }\n    <div class=\"view-value\">{{ viewValue() ?? (_value() || '-') }}</div>\n  </div>\n} @else {\n  <div class=\"form-group\">\n    @if (label()) {\n      <label [attr.for]=\"id()\">{{ label() }}</label>\n    }\n\n    <div class=\"input-wrapper\">\n      <span class=\"left-icon\" aria-hidden=\"true\">\n        <svg\n          width=\"18\"\n          height=\"18\"\n          viewBox=\"0 0 20 20\"\n          fill=\"none\"\n          xmlns=\"http://www.w3.org/2000/svg\"\n        >\n          <path\n            d=\"M5 6.66675L8.50929 8.42139C9.44771 8.8906 10.5523 8.8906 11.4907 8.42139L15 6.66675M5 15.8334H15C16.3807 15.8334 17.5 14.7141 17.5 13.3334V6.66675C17.5 5.28604 16.3807 4.16675 15 4.16675H5C3.61929 4.16675 2.5 5.28604 2.5 6.66675V13.3334C2.5 14.7141 3.61929 15.8334 5 15.8334Z\"\n            stroke=\"#646663\"\n            stroke-width=\"1.5\"\n            stroke-linecap=\"round\"\n            stroke-linejoin=\"round\"\n          />\n        </svg>\n      </span>\n\n      <input\n        class=\"form-control\"\n        [class.error]=\"_invalid()\"\n        [id]=\"id()\"\n        [type]=\"type\"\n        [value]=\"_value()\"\n        [placeholder]=\"placeholder()\"\n        [disabled]=\"_isDisabled()\"\n        [attr.aria-invalid]=\"_invalid()\"\n        [attr.aria-describedby]=\"_invalid() ? id() + '-error' : null\"\n        (input)=\"_handleInput($event)\"\n        (change)=\"change.emit($event)\"\n        (keyup)=\"keyup.emit($event)\"\n        (keydown)=\"keydown.emit($event)\"\n        (keypress)=\"keypress.emit($event)\"\n        (keydown.enter)=\"_handleEnter($event)\"\n        (blur)=\"_handleBlur()\"\n      />\n    </div>\n\n    @if (_invalid()) {\n      <span class=\"alert error\" [id]=\"id() + '-error'\">Please enter a valid email address.</span>\n    }\n  </div>\n}\n"
		}]
	}]
});
var UsernameInput = class UsernameInput extends BaseInput {
	type = "text";
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.1",
		ngImport: i0,
		type: UsernameInput,
		deps: null,
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.1",
		type: UsernameInput,
		isStandalone: true,
		selector: "l-username-input",
		providers: [provideInputValueAccessor(() => UsernameInput)],
		usesInheritance: true,
		hostDirectives: [{
			directive: FormValidation,
			inputs: ["useValidation", "useValidation"]
		}],
		ngImport: i0,
		template: "@if (viewMode()) {\n  <div class=\"form-group view-mode\">\n    @if (label()) {\n      <label>{{ label() }}</label>\n    }\n    <div class=\"view-value\">{{ viewValue() ?? (_value() || '-') }}</div>\n  </div>\n} @else {\n  <div class=\"form-group\">\n    @if (label()) {\n      <label [attr.for]=\"id()\">{{ label() }}</label>\n    }\n\n    <div class=\"input-wrapper\">\n      <span class=\"left-icon\" aria-hidden=\"true\">\n        <svg\n          width=\"18\"\n          height=\"18\"\n          viewBox=\"0 0 20 20\"\n          fill=\"none\"\n          xmlns=\"http://www.w3.org/2000/svg\"\n        >\n          <path\n            d=\"M11.666 11.6667H8.33268C6.0315 11.6667 4.16602 13.5321 4.16602 15.8333V16.6667C4.16602 17.1269 4.53911 17.5 4.99935 17.5H14.9993C15.4596 17.5 15.8327 17.1269 15.8327 16.6667V15.8333C15.8327 13.5321 13.9672 11.6667 11.666 11.6667Z\"\n            stroke=\"#646663\"\n            stroke-width=\"2\"\n          />\n          <path\n            d=\"M9.99935 9.16667C11.8403 9.16667 13.3327 7.67428 13.3327 5.83333C13.3327 3.99238 11.8403 2.5 9.99935 2.5C8.1584 2.5 6.66602 3.99238 6.66602 5.83333C6.66602 7.67428 8.1584 9.16667 9.99935 9.16667Z\"\n            stroke=\"#646663\"\n            stroke-width=\"2\"\n          />\n        </svg>\n      </span>\n\n      <input\n        class=\"form-control\"\n        [id]=\"id()\"\n        [type]=\"type\"\n        [value]=\"_value()\"\n        [placeholder]=\"placeholder()\"\n        [disabled]=\"_isDisabled()\"\n        (input)=\"_handleInput($event)\"\n        (change)=\"change.emit($event)\"\n        (keyup)=\"keyup.emit($event)\"\n        (keydown)=\"keydown.emit($event)\"\n        (keypress)=\"keypress.emit($event)\"\n        (keydown.enter)=\"_handleEnter($event)\"\n        (blur)=\"_handleBlur()\"\n      />\n    </div>\n  </div>\n}\n",
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: UsernameInput,
	decorators: [{
		type: Component,
		args: [{
			selector: "l-username-input",
			changeDetection: ChangeDetectionStrategy.OnPush,
			imports: [],
			providers: [provideInputValueAccessor(() => UsernameInput)],
			hostDirectives: [{
				directive: FormValidation,
				inputs: ["useValidation"]
			}],
			template: "@if (viewMode()) {\n  <div class=\"form-group view-mode\">\n    @if (label()) {\n      <label>{{ label() }}</label>\n    }\n    <div class=\"view-value\">{{ viewValue() ?? (_value() || '-') }}</div>\n  </div>\n} @else {\n  <div class=\"form-group\">\n    @if (label()) {\n      <label [attr.for]=\"id()\">{{ label() }}</label>\n    }\n\n    <div class=\"input-wrapper\">\n      <span class=\"left-icon\" aria-hidden=\"true\">\n        <svg\n          width=\"18\"\n          height=\"18\"\n          viewBox=\"0 0 20 20\"\n          fill=\"none\"\n          xmlns=\"http://www.w3.org/2000/svg\"\n        >\n          <path\n            d=\"M11.666 11.6667H8.33268C6.0315 11.6667 4.16602 13.5321 4.16602 15.8333V16.6667C4.16602 17.1269 4.53911 17.5 4.99935 17.5H14.9993C15.4596 17.5 15.8327 17.1269 15.8327 16.6667V15.8333C15.8327 13.5321 13.9672 11.6667 11.666 11.6667Z\"\n            stroke=\"#646663\"\n            stroke-width=\"2\"\n          />\n          <path\n            d=\"M9.99935 9.16667C11.8403 9.16667 13.3327 7.67428 13.3327 5.83333C13.3327 3.99238 11.8403 2.5 9.99935 2.5C8.1584 2.5 6.66602 3.99238 6.66602 5.83333C6.66602 7.67428 8.1584 9.16667 9.99935 9.16667Z\"\n            stroke=\"#646663\"\n            stroke-width=\"2\"\n          />\n        </svg>\n      </span>\n\n      <input\n        class=\"form-control\"\n        [id]=\"id()\"\n        [type]=\"type\"\n        [value]=\"_value()\"\n        [placeholder]=\"placeholder()\"\n        [disabled]=\"_isDisabled()\"\n        (input)=\"_handleInput($event)\"\n        (change)=\"change.emit($event)\"\n        (keyup)=\"keyup.emit($event)\"\n        (keydown)=\"keydown.emit($event)\"\n        (keypress)=\"keypress.emit($event)\"\n        (keydown.enter)=\"_handleEnter($event)\"\n        (blur)=\"_handleBlur()\"\n      />\n    </div>\n  </div>\n}\n"
		}]
	}]
});
let _uid$7 = 0;
const NAV_KEYS = /* @__PURE__ */ new Set([
	"Backspace",
	"Delete",
	"Tab",
	"Enter",
	"Escape",
	"ArrowLeft",
	"ArrowRight",
	"ArrowUp",
	"ArrowDown",
	"Home",
	"End"
]);
var NumberInput = class NumberInput {
	label = input("", ...ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []);
	placeholder = input("", ...ngDevMode ? [{ debugName: "placeholder" }] : /* istanbul ignore next */ []);
	disabled = input(false, ...ngDevMode ? [{ debugName: "disabled" }] : /* istanbul ignore next */ []);
	id = input(`l-number-${_uid$7++}`, ...ngDevMode ? [{ debugName: "id" }] : /* istanbul ignore next */ []);
	decimalPlaces = input(...ngDevMode ? [void 0, { debugName: "decimalPlaces" }] : /* istanbul ignore next */ []);
	prefix = input("", ...ngDevMode ? [{ debugName: "prefix" }] : /* istanbul ignore next */ []);
	suffix = input("", ...ngDevMode ? [{ debugName: "suffix" }] : /* istanbul ignore next */ []);
	allowNegative = input(false, ...ngDevMode ? [{ debugName: "allowNegative" }] : /* istanbul ignore next */ []);
	allowZero = input(true, ...ngDevMode ? [{ debugName: "allowZero" }] : /* istanbul ignore next */ []);
	viewMode = input(false, ...ngDevMode ? [{ debugName: "viewMode" }] : /* istanbul ignore next */ []);
	viewValue = input(...ngDevMode ? [void 0, { debugName: "viewValue" }] : /* istanbul ignore next */ []);
	valueChange = output();
	_value = signal(null, ...ngDevMode ? [{ debugName: "_value" }] : /* istanbul ignore next */ []);
	_buffer = signal("", ...ngDevMode ? [{ debugName: "_buffer" }] : /* istanbul ignore next */ []);
	_focused = signal(false, ...ngDevMode ? [{ debugName: "_focused" }] : /* istanbul ignore next */ []);
	_disabledByForm = signal(false, ...ngDevMode ? [{ debugName: "_disabledByForm" }] : /* istanbul ignore next */ []);
	_touched = signal(false, ...ngDevMode ? [{ debugName: "_touched" }] : /* istanbul ignore next */ []);
	_isDisabled = computed(() => this.disabled() || this._disabledByForm(), ...ngDevMode ? [{ debugName: "_isDisabled" }] : /* istanbul ignore next */ []);
	_inputMode = computed(() => this.decimalPlaces() === 0 ? "numeric" : "decimal", ...ngDevMode ? [{ debugName: "_inputMode" }] : /* istanbul ignore next */ []);
	_display = computed(() => this._focused() ? this._buffer() : this._format(this._value()), ...ngDevMode ? [{ debugName: "_display" }] : /* istanbul ignore next */ []);
	_viewText = computed(() => {
		const text = this._format(this._value());
		return text ? `${this.prefix()}${text}${this.suffix()}` : "";
	}, ...ngDevMode ? [{ debugName: "_viewText" }] : /* istanbul ignore next */ []);
	_onChange = () => {};
	_onTouched = () => {};
	_handleKeydown(event) {
		if (event.ctrlKey || event.metaKey || event.altKey) return;
		if (NAV_KEYS.has(event.key)) return;
		if (event.key.length !== 1) return;
		if (!this._isKeyAllowed(event.key, event.target)) event.preventDefault();
	}
	_handleFocus() {
		this._buffer.set(this._rawString(this._value()));
		this._focused.set(true);
	}
	_handleInput(event) {
		const cleaned = this._sanitize(event.target.value);
		this._buffer.set(cleaned);
		this._commit(this._parse(cleaned));
	}
	_handleBlur() {
		let value = this._value();
		const places = this.decimalPlaces();
		if (value !== null && places !== void 0) value = this._round(value, places);
		if (value === 0 && !this.allowZero()) value = null;
		this._commit(value);
		this._focused.set(false);
		this._touched.set(true);
		this._onTouched();
	}
	writeValue(value) {
		this._value.set(typeof value === "number" && !Number.isNaN(value) ? value : null);
		if (this._focused()) this._buffer.set(this._rawString(this._value()));
	}
	registerOnChange(fn) {
		this._onChange = fn;
	}
	registerOnTouched(fn) {
		this._onTouched = fn;
	}
	setDisabledState(isDisabled) {
		this._disabledByForm.set(isDisabled);
	}
	_isKeyAllowed(key, input) {
		const start = input.selectionStart ?? input.value.length;
		const end = input.selectionEnd ?? input.value.length;
		const prospective = input.value.slice(0, start) + key + input.value.slice(end);
		if (key === "-") return this.allowNegative() && start === 0 && !input.value.includes("-");
		if (key === ".") return this.decimalPlaces() !== 0 && !input.value.includes(".");
		if (key >= "0" && key <= "9") {
			if (!this.allowZero() && this._parse(this._sanitize(prospective)) === 0) return false;
			return true;
		}
		return false;
	}
	_commit(value) {
		this._value.set(value);
		this._onChange(value);
		this.valueChange.emit(value);
	}
	_rawString(value) {
		return value === null ? "" : String(value);
	}
	_sanitize(raw) {
		const negative = this.allowNegative() && raw.trimStart().startsWith("-");
		let s = raw.replace(/[^0-9.]/g, "");
		if (this.decimalPlaces() === 0) s = s.replace(/\./g, "");
		else {
			const dot = s.indexOf(".");
			if (dot !== -1) s = s.slice(0, dot + 1) + s.slice(dot + 1).replace(/\./g, "");
		}
		s = s.replace(/^0+(?=\d)/, "");
		return (negative ? "-" : "") + s;
	}
	_parse(s) {
		if (s === "" || s === "-" || s === "." || s === "-.") return null;
		const n = Number(s);
		return Number.isNaN(n) ? null : n;
	}
	_round(value, places) {
		const factor = 10 ** places;
		return Math.round((value + Number.EPSILON) * factor) / factor;
	}
	_format(value) {
		if (value === null) return "";
		const places = this.decimalPlaces();
		return places !== void 0 ? value.toFixed(places) : String(value);
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.1",
		ngImport: i0,
		type: NumberInput,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.1",
		type: NumberInput,
		isStandalone: true,
		selector: "l-number-input",
		inputs: {
			label: {
				classPropertyName: "label",
				publicName: "label",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			placeholder: {
				classPropertyName: "placeholder",
				publicName: "placeholder",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			disabled: {
				classPropertyName: "disabled",
				publicName: "disabled",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			id: {
				classPropertyName: "id",
				publicName: "id",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			decimalPlaces: {
				classPropertyName: "decimalPlaces",
				publicName: "decimalPlaces",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			prefix: {
				classPropertyName: "prefix",
				publicName: "prefix",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			suffix: {
				classPropertyName: "suffix",
				publicName: "suffix",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			allowNegative: {
				classPropertyName: "allowNegative",
				publicName: "allowNegative",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			allowZero: {
				classPropertyName: "allowZero",
				publicName: "allowZero",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			viewMode: {
				classPropertyName: "viewMode",
				publicName: "viewMode",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			viewValue: {
				classPropertyName: "viewValue",
				publicName: "viewValue",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: { valueChange: "valueChange" },
		providers: [provideInputValueAccessor(() => NumberInput)],
		hostDirectives: [{
			directive: FormValidation,
			inputs: ["useValidation", "useValidation"]
		}],
		ngImport: i0,
		template: "@if (viewMode()) {\n  <div class=\"form-group view-mode\">\n    @if (label()) {\n      <label>{{ label() }}</label>\n    }\n    <div class=\"view-value\">{{ viewValue() ?? (_viewText() || '-') }}</div>\n  </div>\n} @else {\n  <div class=\"form-group\">\n    @if (label()) {\n      <label [attr.for]=\"id()\">{{ label() }}</label>\n    }\n\n    <div class=\"input-affix\" [class.has-prefix]=\"prefix()\" [class.has-suffix]=\"suffix()\">\n      @if (prefix()) {\n        <span class=\"affix prefix\">{{ prefix() }}</span>\n      }\n\n      <input\n        class=\"form-control\"\n        type=\"text\"\n        [id]=\"id()\"\n        [attr.inputmode]=\"_inputMode()\"\n        [value]=\"_display()\"\n        [placeholder]=\"placeholder()\"\n        [disabled]=\"_isDisabled()\"\n        (keydown)=\"_handleKeydown($event)\"\n        (input)=\"_handleInput($event)\"\n        (focus)=\"_handleFocus()\"\n        (blur)=\"_handleBlur()\"\n      />\n\n      @if (suffix()) {\n        <span class=\"affix suffix\">{{ suffix() }}</span>\n      }\n    </div>\n  </div>\n}\n",
		styles: [".input-affix{position:relative;width:100%}.input-affix .form-control{width:100%}.input-affix.has-prefix .form-control{padding-left:32px}.input-affix.has-suffix .form-control{padding-right:32px}.input-affix .affix{position:absolute;top:50%;transform:translateY(-50%);color:var(--text-tertiary);font-size:14px;line-height:20px;pointer-events:none;-webkit-user-select:none;user-select:none}.input-affix .affix.prefix{left:8px}.input-affix .affix.suffix{right:8px}\n"],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: NumberInput,
	decorators: [{
		type: Component,
		args: [{
			selector: "l-number-input",
			changeDetection: ChangeDetectionStrategy.OnPush,
			imports: [],
			providers: [provideInputValueAccessor(() => NumberInput)],
			hostDirectives: [{
				directive: FormValidation,
				inputs: ["useValidation"]
			}],
			template: "@if (viewMode()) {\n  <div class=\"form-group view-mode\">\n    @if (label()) {\n      <label>{{ label() }}</label>\n    }\n    <div class=\"view-value\">{{ viewValue() ?? (_viewText() || '-') }}</div>\n  </div>\n} @else {\n  <div class=\"form-group\">\n    @if (label()) {\n      <label [attr.for]=\"id()\">{{ label() }}</label>\n    }\n\n    <div class=\"input-affix\" [class.has-prefix]=\"prefix()\" [class.has-suffix]=\"suffix()\">\n      @if (prefix()) {\n        <span class=\"affix prefix\">{{ prefix() }}</span>\n      }\n\n      <input\n        class=\"form-control\"\n        type=\"text\"\n        [id]=\"id()\"\n        [attr.inputmode]=\"_inputMode()\"\n        [value]=\"_display()\"\n        [placeholder]=\"placeholder()\"\n        [disabled]=\"_isDisabled()\"\n        (keydown)=\"_handleKeydown($event)\"\n        (input)=\"_handleInput($event)\"\n        (focus)=\"_handleFocus()\"\n        (blur)=\"_handleBlur()\"\n      />\n\n      @if (suffix()) {\n        <span class=\"affix suffix\">{{ suffix() }}</span>\n      }\n    </div>\n  </div>\n}\n",
			styles: [".input-affix{position:relative;width:100%}.input-affix .form-control{width:100%}.input-affix.has-prefix .form-control{padding-left:32px}.input-affix.has-suffix .form-control{padding-right:32px}.input-affix .affix{position:absolute;top:50%;transform:translateY(-50%);color:var(--text-tertiary);font-size:14px;line-height:20px;pointer-events:none;-webkit-user-select:none;user-select:none}.input-affix .affix.prefix{left:8px}.input-affix .affix.suffix{right:8px}\n"]
		}]
	}],
	propDecorators: {
		label: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "label",
				required: false
			}]
		}],
		placeholder: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "placeholder",
				required: false
			}]
		}],
		disabled: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "disabled",
				required: false
			}]
		}],
		id: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "id",
				required: false
			}]
		}],
		decimalPlaces: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "decimalPlaces",
				required: false
			}]
		}],
		prefix: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "prefix",
				required: false
			}]
		}],
		suffix: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "suffix",
				required: false
			}]
		}],
		allowNegative: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "allowNegative",
				required: false
			}]
		}],
		allowZero: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "allowZero",
				required: false
			}]
		}],
		viewMode: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "viewMode",
				required: false
			}]
		}],
		viewValue: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "viewValue",
				required: false
			}]
		}],
		valueChange: [{
			type: i0.Output,
			args: ["valueChange"]
		}]
	}
});
let _uid$6 = 0;
const TAG_GAP = 4;
const ROW_HEIGHT = 36;
const VIEWPORT_HEIGHT = 252;
const OVERSCAN = 4;
var Select = class Select {
	label = input("", ...ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []);
	placeholder = input("Select…", ...ngDevMode ? [{ debugName: "placeholder" }] : /* istanbul ignore next */ []);
	disabled = input(false, ...ngDevMode ? [{ debugName: "disabled" }] : /* istanbul ignore next */ []);
	id = input(`l-select-${_uid$6++}`, ...ngDevMode ? [{ debugName: "id" }] : /* istanbul ignore next */ []);
	multiple = input(false, ...ngDevMode ? [{ debugName: "multiple" }] : /* istanbul ignore next */ []);
	maxCount = input(...ngDevMode ? [void 0, { debugName: "maxCount" }] : /* istanbul ignore next */ []);
	maxTagCount = input("responsive", ...ngDevMode ? [{ debugName: "maxTagCount" }] : /* istanbul ignore next */ []);
	clearable = input(false, ...ngDevMode ? [{ debugName: "clearable" }] : /* istanbul ignore next */ []);
	items = input([], ...ngDevMode ? [{ debugName: "items" }] : /* istanbul ignore next */ []);
	bindValue = input(...ngDevMode ? [void 0, { debugName: "bindValue" }] : /* istanbul ignore next */ []);
	bindLabel = input(...ngDevMode ? [void 0, { debugName: "bindLabel" }] : /* istanbul ignore next */ []);
	bindDisabled = input(...ngDevMode ? [void 0, { debugName: "bindDisabled" }] : /* istanbul ignore next */ []);
	groupBy = input(...ngDevMode ? [void 0, { debugName: "groupBy" }] : /* istanbul ignore next */ []);
	searchable = input(false, ...ngDevMode ? [{ debugName: "searchable" }] : /* istanbul ignore next */ []);
	showArrow = input(true, ...ngDevMode ? [{ debugName: "showArrow" }] : /* istanbul ignore next */ []);
	showLoading = input(false, ...ngDevMode ? [{ debugName: "showLoading" }] : /* istanbul ignore next */ []);
	virtualScroll = input(false, ...ngDevMode ? [{ debugName: "virtualScroll" }] : /* istanbul ignore next */ []);
	viewMode = input(false, ...ngDevMode ? [{ debugName: "viewMode" }] : /* istanbul ignore next */ []);
	viewValue = input(...ngDevMode ? [void 0, { debugName: "viewValue" }] : /* istanbul ignore next */ []);
	change = output();
	search = output();
	scrollToEnd = output();
	_open = signal(false, ...ngDevMode ? [{ debugName: "_open" }] : /* istanbul ignore next */ []);
	_searchText = signal("", ...ngDevMode ? [{ debugName: "_searchText" }] : /* istanbul ignore next */ []);
	_activeIndex = signal(-1, ...ngDevMode ? [{ debugName: "_activeIndex" }] : /* istanbul ignore next */ []);
	_scrollTop = signal(0, ...ngDevMode ? [{ debugName: "_scrollTop" }] : /* istanbul ignore next */ []);
	_endReached = false;
	_value = signal(null, ...ngDevMode ? [{ debugName: "_value" }] : /* istanbul ignore next */ []);
	_disabledByForm = signal(false, ...ngDevMode ? [{ debugName: "_disabledByForm" }] : /* istanbul ignore next */ []);
	_touched = signal(false, ...ngDevMode ? [{ debugName: "_touched" }] : /* istanbul ignore next */ []);
	_isDisabled = computed(() => this.disabled() || this._disabledByForm(), ...ngDevMode ? [{ debugName: "_isDisabled" }] : /* istanbul ignore next */ []);
	_rowHeight = ROW_HEIGHT;
	_host = inject(ElementRef);
	_dropdown = viewChild("dropdown", ...ngDevMode ? [{ debugName: "_dropdown" }] : /* istanbul ignore next */ []);
	_trigger = viewChild("trigger", ...ngDevMode ? [{ debugName: "_trigger" }] : /* istanbul ignore next */ []);
	_searchInput = viewChild("searchInput", ...ngDevMode ? [{ debugName: "_searchInput" }] : /* istanbul ignore next */ []);
	_viewport = viewChild("viewport", ...ngDevMode ? [{ debugName: "_viewport" }] : /* istanbul ignore next */ []);
	_tagsArea = viewChild("tagsArea", ...ngDevMode ? [{ debugName: "_tagsArea" }] : /* istanbul ignore next */ []);
	_tagsMeasure = viewChild("tagsMeasure", ...ngDevMode ? [{ debugName: "_tagsMeasure" }] : /* istanbul ignore next */ []);
	_responsiveCount = signal(999, ...ngDevMode ? [{ debugName: "_responsiveCount" }] : /* istanbul ignore next */ []);
	_dropUp = signal(false, ...ngDevMode ? [{ debugName: "_dropUp" }] : /* istanbul ignore next */ []);
	_menuLeft = signal(0, ...ngDevMode ? [{ debugName: "_menuLeft" }] : /* istanbul ignore next */ []);
	_menuWidth = signal(0, ...ngDevMode ? [{ debugName: "_menuWidth" }] : /* istanbul ignore next */ []);
	_menuTop = signal(null, ...ngDevMode ? [{ debugName: "_menuTop" }] : /* istanbul ignore next */ []);
	_menuBottom = signal(null, ...ngDevMode ? [{ debugName: "_menuBottom" }] : /* istanbul ignore next */ []);
	_maxListHeight = signal(VIEWPORT_HEIGHT, ...ngDevMode ? [{ debugName: "_maxListHeight" }] : /* istanbul ignore next */ []);
	_onViewportChange = () => {
		if (this._open()) this._reposition();
	};
	_onChange = () => {};
	_onTouched = () => {};
	constructor() {
		const destroyRef = inject(DestroyRef);
		afterNextRender(() => {
			const observer = new ResizeObserver(() => this._measureTags());
			observer.observe(this._host.nativeElement);
			destroyRef.onDestroy(() => observer.disconnect());
			this._measureTags();
		});
		effect(() => {
			this._selectedOptions();
			this.maxTagCount();
			if (this._isResponsive()) queueMicrotask(() => this._measureTags());
		});
		effect(() => {
			const dropdown = this._dropdown()?.nativeElement;
			if (dropdown && dropdown.parentElement !== document.body) document.body.appendChild(dropdown);
		});
		destroyRef.onDestroy(() => {
			window.removeEventListener("scroll", this._onViewportChange, true);
			window.removeEventListener("resize", this._onViewportChange);
		});
	}
	_selectedArray = computed(() => {
		const value = this._value();
		return Array.isArray(value) ? value : [];
	}, ...ngDevMode ? [{ debugName: "_selectedArray" }] : /* istanbul ignore next */ []);
	_selectedOptions = computed(() => {
		if (!this.multiple()) return [];
		const all = this._all();
		return this._selectedArray().map((value) => all.find((o) => o.value === value)).filter((o) => !!o);
	}, ...ngDevMode ? [{ debugName: "_selectedOptions" }] : /* istanbul ignore next */ []);
	_isResponsive = computed(() => this.multiple() && this.maxTagCount() === "responsive", ...ngDevMode ? [{ debugName: "_isResponsive" }] : /* istanbul ignore next */ []);
	_visibleTagCount = computed(() => {
		const max = this.maxTagCount();
		return typeof max === "number" ? max : this._responsiveCount();
	}, ...ngDevMode ? [{ debugName: "_visibleTagCount" }] : /* istanbul ignore next */ []);
	_shownTags = computed(() => this._selectedOptions().slice(0, this._visibleTagCount()), ...ngDevMode ? [{ debugName: "_shownTags" }] : /* istanbul ignore next */ []);
	_overflowCount = computed(() => this._selectedOptions().length - this._shownTags().length, ...ngDevMode ? [{ debugName: "_overflowCount" }] : /* istanbul ignore next */ []);
	_limitReached = computed(() => {
		const max = this.maxCount();
		return this.multiple() && max != null && this._selectedArray().length >= max;
	}, ...ngDevMode ? [{ debugName: "_limitReached" }] : /* istanbul ignore next */ []);
	_hasValue = computed(() => {
		if (this.multiple()) return this._selectedArray().length > 0;
		const value = this._value();
		return value !== null && value !== void 0 && value !== "";
	}, ...ngDevMode ? [{ debugName: "_hasValue" }] : /* istanbul ignore next */ []);
	_showClear = computed(() => this.clearable() && this._hasValue() && !this._isDisabled(), ...ngDevMode ? [{ debugName: "_showClear" }] : /* istanbul ignore next */ []);
	_all = computed(() => this.items().map((item, index) => this._normalize(item, index)), ...ngDevMode ? [{ debugName: "_all" }] : /* istanbul ignore next */ []);
	_visible = computed(() => {
		const term = this.searchable() ? this._searchText().trim().toLowerCase() : "";
		return (term ? this._all().filter((o) => o.label.toLowerCase().includes(term)) : this._all()).map((o, index) => ({
			...o,
			index
		}));
	}, ...ngDevMode ? [{ debugName: "_visible" }] : /* istanbul ignore next */ []);
	_groups = computed(() => {
		if (!this.groupBy()) return [];
		const groups = /* @__PURE__ */ new Map();
		for (const option of this._visible()) {
			let group = groups.get(option.group);
			if (!group) {
				group = {
					label: option.group == null ? "" : String(option.group),
					options: []
				};
				groups.set(option.group, group);
			}
			group.options.push(option);
		}
		return [...groups.values()];
	}, ...ngDevMode ? [{ debugName: "_groups" }] : /* istanbul ignore next */ []);
	_selectedLabel = computed(() => {
		const value = this._value();
		if (value === null || value === void 0) return "";
		return this._all().find((o) => o.value === value)?.label ?? "";
	}, ...ngDevMode ? [{ debugName: "_selectedLabel" }] : /* istanbul ignore next */ []);
	_viewText = computed(() => this.multiple() ? this._selectedOptions().map((option) => option.label).join(", ") : this._selectedLabel(), ...ngDevMode ? [{ debugName: "_viewText" }] : /* istanbul ignore next */ []);
	_useVirtual = computed(() => this.virtualScroll() && !this.groupBy(), ...ngDevMode ? [{ debugName: "_useVirtual" }] : /* istanbul ignore next */ []);
	_totalHeight = computed(() => this._visible().length * ROW_HEIGHT, ...ngDevMode ? [{ debugName: "_totalHeight" }] : /* istanbul ignore next */ []);
	_viewportHeight = computed(() => Math.min(this._totalHeight(), this._maxListHeight()), ...ngDevMode ? [{ debugName: "_viewportHeight" }] : /* istanbul ignore next */ []);
	_startIndex = computed(() => Math.max(0, Math.floor(this._scrollTop() / ROW_HEIGHT) - OVERSCAN), ...ngDevMode ? [{ debugName: "_startIndex" }] : /* istanbul ignore next */ []);
	_window = computed(() => {
		const end = Math.min(this._visible().length, Math.ceil((this._scrollTop() + this._maxListHeight()) / ROW_HEIGHT) + OVERSCAN);
		return this._visible().slice(this._startIndex(), end);
	}, ...ngDevMode ? [{ debugName: "_window" }] : /* istanbul ignore next */ []);
	_offsetTop = computed(() => this._startIndex() * ROW_HEIGHT, ...ngDevMode ? [{ debugName: "_offsetTop" }] : /* istanbul ignore next */ []);
	_toggle() {
		if (this._isDisabled()) return;
		this._open() ? this._close() : this._openDropdown();
	}
	_onOptionClick(option) {
		if (this._optionDisabled(option)) return;
		this._select(option.value);
	}
	_setActive(option) {
		if (!this._optionDisabled(option)) this._activeIndex.set(option.index);
	}
	_optionDisabled(option) {
		if (option.disabled) return true;
		return this._limitReached() && !this._isSelected(option.value);
	}
	_onSearch(event) {
		const text = event.target.value;
		this._searchText.set(text);
		this.search.emit(text);
		this._scrollTop.set(0);
		this._endReached = false;
		this._activeIndex.set(this._firstSelectable());
	}
	_onScroll(event) {
		const list = event.target;
		if (this._useVirtual()) this._scrollTop.set(list.scrollTop);
		if (!(list.scrollTop + list.clientHeight >= list.scrollHeight - ROW_HEIGHT)) this._endReached = false;
		else if (!this._endReached) {
			this._endReached = true;
			this.scrollToEnd.emit();
		}
	}
	_isInside(node) {
		if (!node) return false;
		return this._host.nativeElement.contains(node) || !!this._dropdown()?.nativeElement.contains(node);
	}
	_onDocumentPointerDown(event) {
		if (this._open() && !this._isInside(event.target)) this._close();
	}
	_onKeydown(event, fromSearch) {
		switch (event.key) {
			case "ArrowDown":
				event.preventDefault();
				this._open() ? this._move(1) : this._openDropdown();
				break;
			case "ArrowUp":
				event.preventDefault();
				this._open() ? this._move(-1) : this._openDropdown();
				break;
			case "Enter":
				event.preventDefault();
				this._open() ? this._selectActive() : this._openDropdown();
				break;
			case " ":
				if (fromSearch && this._open()) break;
				event.preventDefault();
				this._open() ? this._selectActive() : this._openDropdown();
				break;
			case "Escape":
				if (this._open()) {
					event.preventDefault();
					this._close();
				}
				break;
			case "Tab": this._close();
		}
	}
	_onBlur(event) {
		if (!this._isInside(event.relatedTarget)) {
			this._touched.set(true);
			this._onTouched();
		}
	}
	_openDropdown() {
		if (this._isDisabled()) return;
		this._open.set(true);
		this._reposition();
		const selected = this._visible().findIndex((o) => o.value === this._value() && !o.disabled);
		this._activeIndex.set(selected >= 0 ? selected : this._firstSelectable());
		window.addEventListener("scroll", this._onViewportChange, true);
		window.addEventListener("resize", this._onViewportChange);
		queueMicrotask(() => {
			this._reposition();
			this._searchInput()?.nativeElement.focus();
			this._scrollActiveIntoView();
		});
	}
	_close() {
		if (!this._open()) return;
		this._open.set(false);
		this._searchText.set("");
		this._scrollTop.set(0);
		this._endReached = false;
		this._activeIndex.set(-1);
		window.removeEventListener("scroll", this._onViewportChange, true);
		window.removeEventListener("resize", this._onViewportChange);
	}
	_reposition() {
		const triggerEl = this._trigger()?.nativeElement;
		if (!triggerEl) return;
		const rect = triggerEl.getBoundingClientRect();
		const gap = 4;
		const viewportHeight = window.innerHeight;
		const spaceBelow = viewportHeight - rect.bottom - gap;
		const spaceAbove = rect.top - gap;
		const reserve = (this.searchable() ? 48 : 0) + 8;
		const dropUp = spaceBelow < 180 && spaceAbove > spaceBelow;
		const available = dropUp ? spaceAbove : spaceBelow;
		this._dropUp.set(dropUp);
		this._menuLeft.set(rect.left);
		this._menuWidth.set(rect.width);
		this._maxListHeight.set(Math.max(120, Math.min(VIEWPORT_HEIGHT, available - reserve)));
		if (dropUp) {
			this._menuTop.set(null);
			this._menuBottom.set(viewportHeight - rect.top + gap);
		} else {
			this._menuTop.set(rect.bottom + gap);
			this._menuBottom.set(null);
		}
	}
	_select(value) {
		if (this.multiple()) {
			const current = [...this._selectedArray()];
			const at = current.indexOf(value);
			if (at >= 0) current.splice(at, 1);
			else {
				const max = this.maxCount();
				if (max != null && current.length >= max) return;
				current.push(value);
			}
			this._value.set(current);
			this._onChange(current);
			this.change.emit(current);
			return;
		}
		this._value.set(value);
		this._onChange(value);
		this.change.emit(value);
		this._close();
		this._trigger()?.nativeElement.focus();
	}
	_removeTag(option, event) {
		event.stopPropagation();
		if (this._isDisabled()) return;
		this._select(option.value);
	}
	_clear(event) {
		event.stopPropagation();
		if (this._isDisabled()) return;
		const empty = this.multiple() ? [] : null;
		this._value.set(empty);
		this._onChange(empty);
		this.change.emit(empty);
		this._trigger()?.nativeElement.focus();
	}
	_selectActive() {
		const option = this._visible()[this._activeIndex()];
		if (option && !this._optionDisabled(option)) this._select(option.value);
	}
	_move(delta) {
		const options = this._visible();
		if (!options.length) return;
		let next = this._activeIndex();
		for (let i = 0; i < options.length; i++) {
			next = (next + delta + options.length) % options.length;
			if (!this._optionDisabled(options[next])) {
				this._activeIndex.set(next);
				break;
			}
		}
		queueMicrotask(() => this._scrollActiveIntoView());
	}
	_firstSelectable() {
		return this._visible().findIndex((o) => !this._optionDisabled(o));
	}
	_measureTags() {
		if (!this._isResponsive()) return;
		const area = this._tagsArea()?.nativeElement;
		const measure = this._tagsMeasure()?.nativeElement;
		if (!area || !measure) return;
		const available = area.clientWidth;
		if (available <= 0) return;
		const tags = Array.from(measure.children);
		let used = 0;
		let count = 0;
		for (let i = 0; i < tags.length; i++) {
			const width = tags[i].offsetWidth + (count > 0 ? TAG_GAP : 0);
			const reserve = i < tags.length - 1 ? 50 : 0;
			if (count > 0 && used + width + reserve > available) break;
			used += width;
			count++;
		}
		this._responsiveCount.set(Math.max(1, count));
	}
	_scrollActiveIntoView() {
		const viewport = this._viewport()?.nativeElement;
		const index = this._activeIndex();
		if (!viewport || index < 0) return;
		if (this._useVirtual()) {
			const top = index * ROW_HEIGHT;
			const bottom = top + ROW_HEIGHT;
			if (top < viewport.scrollTop) viewport.scrollTop = top;
			else if (bottom > viewport.scrollTop + viewport.clientHeight) viewport.scrollTop = bottom - viewport.clientHeight;
		} else viewport.querySelector(`[data-index="${index}"]`)?.scrollIntoView({ block: "nearest" });
	}
	_isSelected(value) {
		if (this.multiple()) return this._selectedArray().includes(value);
		const current = this._value();
		return current !== null && current !== void 0 && value === current;
	}
	_normalize(item, index) {
		if (item !== null && typeof item === "object") {
			const record = item;
			const valueKey = this.bindValue();
			const labelKey = this.bindLabel();
			const value = valueKey ? record[valueKey] : item;
			const label = labelKey ? String(record[labelKey] ?? "") : String((valueKey ? value : void 0) ?? item);
			const disabledKey = this.bindDisabled();
			const groupKey = this.groupBy();
			return {
				value,
				label,
				disabled: disabledKey ? !!record[disabledKey] : false,
				group: groupKey ? record[groupKey] : void 0,
				index
			};
		}
		return {
			value: item,
			label: String(item),
			disabled: false,
			group: void 0,
			index
		};
	}
	writeValue(value) {
		if (this.multiple()) this._value.set(Array.isArray(value) ? value : value == null ? [] : [value]);
		else this._value.set(value ?? null);
	}
	registerOnChange(fn) {
		this._onChange = fn;
	}
	registerOnTouched(fn) {
		this._onTouched = fn;
	}
	setDisabledState(isDisabled) {
		this._disabledByForm.set(isDisabled);
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.1",
		ngImport: i0,
		type: Select,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.1",
		type: Select,
		isStandalone: true,
		selector: "l-select",
		inputs: {
			label: {
				classPropertyName: "label",
				publicName: "label",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			placeholder: {
				classPropertyName: "placeholder",
				publicName: "placeholder",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			disabled: {
				classPropertyName: "disabled",
				publicName: "disabled",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			id: {
				classPropertyName: "id",
				publicName: "id",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			multiple: {
				classPropertyName: "multiple",
				publicName: "multiple",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			maxCount: {
				classPropertyName: "maxCount",
				publicName: "maxCount",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			maxTagCount: {
				classPropertyName: "maxTagCount",
				publicName: "maxTagCount",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			clearable: {
				classPropertyName: "clearable",
				publicName: "clearable",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			items: {
				classPropertyName: "items",
				publicName: "items",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			bindValue: {
				classPropertyName: "bindValue",
				publicName: "bindValue",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			bindLabel: {
				classPropertyName: "bindLabel",
				publicName: "bindLabel",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			bindDisabled: {
				classPropertyName: "bindDisabled",
				publicName: "bindDisabled",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			groupBy: {
				classPropertyName: "groupBy",
				publicName: "groupBy",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			searchable: {
				classPropertyName: "searchable",
				publicName: "searchable",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			showArrow: {
				classPropertyName: "showArrow",
				publicName: "showArrow",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			showLoading: {
				classPropertyName: "showLoading",
				publicName: "showLoading",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			virtualScroll: {
				classPropertyName: "virtualScroll",
				publicName: "virtualScroll",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			viewMode: {
				classPropertyName: "viewMode",
				publicName: "viewMode",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			viewValue: {
				classPropertyName: "viewValue",
				publicName: "viewValue",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: {
			change: "change",
			search: "search",
			scrollToEnd: "scrollToEnd"
		},
		host: { listeners: { "document:pointerdown": "_onDocumentPointerDown($event)" } },
		providers: [provideInputValueAccessor(() => Select)],
		viewQueries: [
			{
				propertyName: "_dropdown",
				first: true,
				predicate: ["dropdown"],
				descendants: true,
				isSignal: true
			},
			{
				propertyName: "_trigger",
				first: true,
				predicate: ["trigger"],
				descendants: true,
				isSignal: true
			},
			{
				propertyName: "_searchInput",
				first: true,
				predicate: ["searchInput"],
				descendants: true,
				isSignal: true
			},
			{
				propertyName: "_viewport",
				first: true,
				predicate: ["viewport"],
				descendants: true,
				isSignal: true
			},
			{
				propertyName: "_tagsArea",
				first: true,
				predicate: ["tagsArea"],
				descendants: true,
				isSignal: true
			},
			{
				propertyName: "_tagsMeasure",
				first: true,
				predicate: ["tagsMeasure"],
				descendants: true,
				isSignal: true
			}
		],
		hostDirectives: [{
			directive: FormValidation,
			inputs: ["useValidation", "useValidation"]
		}],
		ngImport: i0,
		template: "@if (viewMode()) {\n  <div class=\"form-group view-mode\">\n    @if (label()) {\n      <label>{{ label() }}</label>\n    }\n    <div class=\"view-value\">{{ viewValue() ?? (_viewText() || '-') }}</div>\n  </div>\n} @else {\n  <div class=\"form-group\">\n    @if (label()) {\n      <label [attr.for]=\"id()\">{{ label() }}</label>\n    }\n\n    <div class=\"l-select\" [class.is-open]=\"_open()\" (focusout)=\"_onBlur($event)\">\n      <div\n        #trigger\n        class=\"form-control l-select__trigger\"\n        [class.is-placeholder]=\"!_hasValue()\"\n        [class.is-multiple]=\"multiple()\"\n        [attr.id]=\"id()\"\n        role=\"combobox\"\n        [attr.tabindex]=\"_isDisabled() ? -1 : 0\"\n        [attr.aria-haspopup]=\"'listbox'\"\n        [attr.aria-expanded]=\"_open()\"\n        [attr.aria-disabled]=\"_isDisabled()\"\n        [attr.aria-controls]=\"id() + '-listbox'\"\n        (click)=\"_toggle()\"\n        (keydown)=\"_onKeydown($event, false)\"\n      >\n        @if (multiple()) {\n          @if (_hasValue()) {\n            <div #tagsArea class=\"l-select__tags\">\n              @for (option of _shownTags(); track option.value) {\n                <span class=\"l-select__tag\">\n                  <span class=\"l-select__tag-label\">{{ option.label }}</span>\n                  @if (!_isDisabled()) {\n                    <button\n                      type=\"button\"\n                      class=\"l-select__tag-remove\"\n                      tabindex=\"-1\"\n                      [attr.aria-label]=\"'Remove ' + option.label\"\n                      (click)=\"_removeTag(option, $event)\"\n                    >\n                      <ng-container [ngTemplateOutlet]=\"closeIcon\" />\n                    </button>\n                  }\n                </span>\n              }\n              @if (_overflowCount() > 0) {\n                <span class=\"l-select__tag l-select__tag--count\">+ {{ _overflowCount() }} …</span>\n              }\n            </div>\n          } @else {\n            <span class=\"l-select__label\">{{ placeholder() }}</span>\n          }\n        } @else {\n          <span class=\"l-select__label\">{{ _selectedLabel() || placeholder() }}</span>\n        }\n\n        <div class=\"l-select__affixes\">\n          @if (_showClear()) {\n            <button\n              type=\"button\"\n              class=\"l-select__clear\"\n              tabindex=\"-1\"\n              aria-label=\"Clear selection\"\n              (click)=\"_clear($event)\"\n            >\n              <ng-container [ngTemplateOutlet]=\"closeIcon\" />\n            </button>\n          }\n\n          @if (showArrow()) {\n            <svg\n              class=\"l-select__arrow\"\n              width=\"14\"\n              height=\"14\"\n              viewBox=\"0 0 20 20\"\n              fill=\"none\"\n              aria-hidden=\"true\"\n              xmlns=\"http://www.w3.org/2000/svg\"\n            >\n              <path\n                d=\"M5 7.5L10 12.5L15 7.5\"\n                stroke=\"currentColor\"\n                stroke-width=\"1.5\"\n                stroke-linecap=\"round\"\n                stroke-linejoin=\"round\"\n              />\n            </svg>\n          }\n        </div>\n      </div>\n\n      @if (_isResponsive() && _hasValue()) {\n        <!-- Off-screen mirror used only to measure how many tags fit on one line. -->\n        <div #tagsMeasure class=\"l-select__tags-measure\" aria-hidden=\"true\">\n          @for (option of _selectedOptions(); track option.value) {\n            <span class=\"l-select__tag\">\n              <span class=\"l-select__tag-label\">{{ option.label }}</span>\n              @if (!_isDisabled()) {\n                <span class=\"l-select__tag-remove\">\n                  <ng-container [ngTemplateOutlet]=\"closeIcon\" />\n                </span>\n              }\n            </span>\n          }\n        </div>\n      }\n\n      @if (_open()) {\n        <!-- Moved to <body> after render (see the portal effect in select.ts) — the\n           focusout handler must sit here too, since events no longer bubble to .l-select. -->\n        <div\n          #dropdown\n          class=\"l-select__dropdown\"\n          [class.is-up]=\"_dropUp()\"\n          [style.left.px]=\"_menuLeft()\"\n          [style.width.px]=\"_menuWidth()\"\n          [style.top.px]=\"_menuTop()\"\n          [style.bottom.px]=\"_menuBottom()\"\n          (focusout)=\"_onBlur($event)\"\n        >\n          @if (searchable()) {\n            <div class=\"l-select__search\">\n              <input\n                #searchInput\n                type=\"text\"\n                class=\"l-select__search-input\"\n                [value]=\"_searchText()\"\n                placeholder=\"Search…\"\n                autocomplete=\"off\"\n                (input)=\"_onSearch($event)\"\n                (keydown)=\"_onKeydown($event, true)\"\n              />\n            </div>\n          }\n\n          @if (showLoading()) {\n            <div class=\"l-select__status\">\n              <span class=\"l-select__spinner\" aria-hidden=\"true\"></span>\n              <span>Loading…</span>\n            </div>\n          } @else if (_visible().length === 0) {\n            <div class=\"l-select__status l-select__status--empty\">No results</div>\n          } @else if (groupBy()) {\n            <div\n              #viewport\n              class=\"l-select__options\"\n              role=\"listbox\"\n              [attr.id]=\"id() + '-listbox'\"\n              [style.maxHeight.px]=\"_maxListHeight()\"\n              (scroll)=\"_onScroll($event)\"\n            >\n              @for (group of _groups(); track group.label) {\n                <div class=\"l-select__group-label\">{{ group.label }}</div>\n                @for (option of group.options; track option.index) {\n                  <ng-container\n                    [ngTemplateOutlet]=\"optionRow\"\n                    [ngTemplateOutletContext]=\"{ $implicit: option }\"\n                  />\n                }\n              }\n            </div>\n          } @else if (_useVirtual()) {\n            <div\n              #viewport\n              class=\"l-select__options\"\n              role=\"listbox\"\n              [attr.id]=\"id() + '-listbox'\"\n              [style.height.px]=\"_viewportHeight()\"\n              (scroll)=\"_onScroll($event)\"\n            >\n              <div class=\"l-select__spacer\" [style.height.px]=\"_totalHeight()\">\n                <div [style.transform]=\"'translateY(' + _offsetTop() + 'px)'\">\n                  @for (option of _window(); track option.index) {\n                    <ng-container\n                      [ngTemplateOutlet]=\"optionRow\"\n                      [ngTemplateOutletContext]=\"{ $implicit: option }\"\n                    />\n                  }\n                </div>\n              </div>\n            </div>\n          } @else {\n            <div\n              #viewport\n              class=\"l-select__options\"\n              role=\"listbox\"\n              [attr.id]=\"id() + '-listbox'\"\n              [style.maxHeight.px]=\"_maxListHeight()\"\n              (scroll)=\"_onScroll($event)\"\n            >\n              @for (option of _visible(); track option.index) {\n                <ng-container\n                  [ngTemplateOutlet]=\"optionRow\"\n                  [ngTemplateOutletContext]=\"{ $implicit: option }\"\n                />\n              }\n            </div>\n          }\n        </div>\n      }\n    </div>\n  </div>\n}\n\n<ng-template #optionRow let-option>\n  <div\n    class=\"l-select__option\"\n    role=\"option\"\n    [class.is-selected]=\"_isSelected(option.value)\"\n    [class.is-active]=\"_activeIndex() === option.index\"\n    [class.is-disabled]=\"_optionDisabled(option)\"\n    [style.height.px]=\"_rowHeight\"\n    [attr.data-index]=\"option.index\"\n    [attr.aria-selected]=\"_isSelected(option.value)\"\n    [attr.aria-disabled]=\"_optionDisabled(option)\"\n    (click)=\"_onOptionClick(option)\"\n    (mouseenter)=\"_setActive(option)\"\n  >\n    <span class=\"l-select__option-label\">{{ option.label }}</span>\n\n    @if (_isSelected(option.value)) {\n      <svg\n        class=\"l-select__check\"\n        width=\"16\"\n        height=\"16\"\n        viewBox=\"0 0 20 20\"\n        fill=\"none\"\n        aria-hidden=\"true\"\n        xmlns=\"http://www.w3.org/2000/svg\"\n      >\n        <path\n          d=\"M16.6667 5L7.5 14.1667L3.33333 10\"\n          stroke=\"currentColor\"\n          stroke-width=\"1.75\"\n          stroke-linecap=\"round\"\n          stroke-linejoin=\"round\"\n        />\n      </svg>\n    }\n  </div>\n</ng-template>\n\n<ng-template #closeIcon>\n  <svg\n    width=\"12\"\n    height=\"12\"\n    viewBox=\"0 0 20 20\"\n    fill=\"none\"\n    aria-hidden=\"true\"\n    xmlns=\"http://www.w3.org/2000/svg\"\n  >\n    <path\n      d=\"M15 5L5 15M5 5L15 15\"\n      stroke=\"currentColor\"\n      stroke-width=\"1.75\"\n      stroke-linecap=\"round\"\n      stroke-linejoin=\"round\"\n    />\n  </svg>\n</ng-template>\n",
		styles: [":host{display:block;width:100%}.l-select{position:relative;width:100%}.l-select__trigger{width:100%;align-items:center;justify-content:space-between;gap:8px;cursor:pointer;-webkit-user-select:none;user-select:none;transition:border-color .15s ease-out,box-shadow .15s ease-out}.l-select__trigger.is-placeholder .l-select__label{color:var(--text-quaternary)}.l-select__trigger:focus-visible{outline:none;border-color:var(--accent);box-shadow:0 0 0 3px var(--accent-bg)}.l-select__trigger[aria-disabled=true]{opacity:.5;cursor:not-allowed;background:var(--bg-light)}.is-open .l-select__trigger{border-color:var(--accent);box-shadow:0 0 0 3px var(--accent-bg)}.l-select__label{flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.l-select__arrow{flex-shrink:0;color:var(--text-tertiary);transition:transform .15s ease-out}.is-open .l-select__arrow{transform:rotate(180deg)}.l-select__trigger.is-multiple{padding-top:3px;padding-bottom:3px;min-height:34px;gap:6px}.l-select__affixes{display:flex;align-items:center;gap:2px;flex-shrink:0}.l-select__clear,.l-select__tag-remove{display:inline-flex;align-items:center;justify-content:center;flex-shrink:0;padding:2px;border:none;background:transparent;border-radius:4px;color:var(--text-tertiary);cursor:pointer;transition:color .12s ease-out,background .12s ease-out}.l-select__clear:hover,.l-select__tag-remove:hover{color:var(--text-primary);background:var(--separator)}.l-select__clear:focus-visible,.l-select__tag-remove:focus-visible{outline:2px solid var(--accent);outline-offset:1px}.l-select__tags{display:flex;flex:1;min-width:0;flex-wrap:nowrap;align-items:center;gap:4px;overflow:hidden}.l-select__tag{display:inline-flex;align-items:center;flex:0 0 auto;max-width:100%;height:22px;padding:0 2px 0 8px;gap:2px;background:var(--bg-dark);border-radius:4px;font-size:13px;line-height:1;white-space:nowrap}.l-select__tag--count{padding:0 8px;color:var(--text-secondary)}.l-select__tag-label{overflow:hidden;text-overflow:ellipsis}.l-select__tags-measure{position:absolute;visibility:hidden;pointer-events:none;top:0;left:0;display:flex;gap:4px}.l-select__dropdown{position:fixed;z-index:1000;display:flex;flex-direction:column;padding:4px;background:var(--bg-lightest);border:1px solid var(--separator);border-radius:8px;box-shadow:0 6px 16px #0d0d121f;animation:l-select-in .12s ease-out;transform-origin:top center}.l-select__dropdown.is-up{transform-origin:bottom center;animation-name:l-select-in-up}@keyframes l-select-in{0%{opacity:0;transform:translateY(-4px)}}@keyframes l-select-in-up{0%{opacity:0;transform:translateY(4px)}}.l-select__search{padding:4px 4px 8px}.l-select__search-input{width:100%;padding:6px 8px;border:1px solid var(--separator);border-radius:6px;outline:none;font-size:14px;line-height:20px;color:var(--text-primary)}.l-select__search-input::placeholder{color:var(--text-quaternary)}.l-select__search-input:focus{border-color:var(--accent);box-shadow:0 0 0 3px var(--accent-bg)}.l-select__options{max-height:252px;overflow-y:auto}.l-select__spacer{position:relative}.l-select__group-label{padding:6px 8px 4px;font-size:12px;font-weight:600;text-transform:uppercase;letter-spacing:.04em;color:var(--text-quaternary)}.l-select__option{display:flex;align-items:center;justify-content:space-between;gap:8px;padding:0 8px;border-radius:6px;font-size:14px;line-height:20px;color:var(--text-primary);cursor:pointer}.l-select__option.is-active{background:var(--bg-light)}.l-select__option.is-selected{background:var(--accent-bg);color:var(--accent-dark);font-weight:600}.l-select__option.is-disabled{color:var(--text-quaternary);cursor:not-allowed;background:transparent}.l-select__option-label{overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.l-select__check{flex-shrink:0;color:var(--accent)}.l-select__status{display:flex;align-items:center;justify-content:center;gap:8px;padding:16px;font-size:13px;color:var(--text-tertiary)}.l-select__status--empty{color:var(--text-quaternary)}.l-select__spinner{width:16px;height:16px;border:2px solid var(--separator-dark);border-top-color:var(--accent);border-radius:50%;animation:l-select-spin .6s linear infinite}@keyframes l-select-spin{to{transform:rotate(360deg)}}@media(prefers-reduced-motion:reduce){.l-select__trigger,.l-select__arrow,.l-select__dropdown{transition:none;animation:none}.l-select__spinner{animation-duration:1.6s}}\n"],
		dependencies: [{
			kind: "directive",
			type: NgTemplateOutlet,
			selector: "[ngTemplateOutlet]",
			inputs: [
				"ngTemplateOutletContext",
				"ngTemplateOutlet",
				"ngTemplateOutletInjector"
			]
		}],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: Select,
	decorators: [{
		type: Component,
		args: [{
			selector: "l-select",
			changeDetection: ChangeDetectionStrategy.OnPush,
			imports: [NgTemplateOutlet],
			providers: [provideInputValueAccessor(() => Select)],
			hostDirectives: [{
				directive: FormValidation,
				inputs: ["useValidation"]
			}],
			host: { "(document:pointerdown)": "_onDocumentPointerDown($event)" },
			template: "@if (viewMode()) {\n  <div class=\"form-group view-mode\">\n    @if (label()) {\n      <label>{{ label() }}</label>\n    }\n    <div class=\"view-value\">{{ viewValue() ?? (_viewText() || '-') }}</div>\n  </div>\n} @else {\n  <div class=\"form-group\">\n    @if (label()) {\n      <label [attr.for]=\"id()\">{{ label() }}</label>\n    }\n\n    <div class=\"l-select\" [class.is-open]=\"_open()\" (focusout)=\"_onBlur($event)\">\n      <div\n        #trigger\n        class=\"form-control l-select__trigger\"\n        [class.is-placeholder]=\"!_hasValue()\"\n        [class.is-multiple]=\"multiple()\"\n        [attr.id]=\"id()\"\n        role=\"combobox\"\n        [attr.tabindex]=\"_isDisabled() ? -1 : 0\"\n        [attr.aria-haspopup]=\"'listbox'\"\n        [attr.aria-expanded]=\"_open()\"\n        [attr.aria-disabled]=\"_isDisabled()\"\n        [attr.aria-controls]=\"id() + '-listbox'\"\n        (click)=\"_toggle()\"\n        (keydown)=\"_onKeydown($event, false)\"\n      >\n        @if (multiple()) {\n          @if (_hasValue()) {\n            <div #tagsArea class=\"l-select__tags\">\n              @for (option of _shownTags(); track option.value) {\n                <span class=\"l-select__tag\">\n                  <span class=\"l-select__tag-label\">{{ option.label }}</span>\n                  @if (!_isDisabled()) {\n                    <button\n                      type=\"button\"\n                      class=\"l-select__tag-remove\"\n                      tabindex=\"-1\"\n                      [attr.aria-label]=\"'Remove ' + option.label\"\n                      (click)=\"_removeTag(option, $event)\"\n                    >\n                      <ng-container [ngTemplateOutlet]=\"closeIcon\" />\n                    </button>\n                  }\n                </span>\n              }\n              @if (_overflowCount() > 0) {\n                <span class=\"l-select__tag l-select__tag--count\">+ {{ _overflowCount() }} …</span>\n              }\n            </div>\n          } @else {\n            <span class=\"l-select__label\">{{ placeholder() }}</span>\n          }\n        } @else {\n          <span class=\"l-select__label\">{{ _selectedLabel() || placeholder() }}</span>\n        }\n\n        <div class=\"l-select__affixes\">\n          @if (_showClear()) {\n            <button\n              type=\"button\"\n              class=\"l-select__clear\"\n              tabindex=\"-1\"\n              aria-label=\"Clear selection\"\n              (click)=\"_clear($event)\"\n            >\n              <ng-container [ngTemplateOutlet]=\"closeIcon\" />\n            </button>\n          }\n\n          @if (showArrow()) {\n            <svg\n              class=\"l-select__arrow\"\n              width=\"14\"\n              height=\"14\"\n              viewBox=\"0 0 20 20\"\n              fill=\"none\"\n              aria-hidden=\"true\"\n              xmlns=\"http://www.w3.org/2000/svg\"\n            >\n              <path\n                d=\"M5 7.5L10 12.5L15 7.5\"\n                stroke=\"currentColor\"\n                stroke-width=\"1.5\"\n                stroke-linecap=\"round\"\n                stroke-linejoin=\"round\"\n              />\n            </svg>\n          }\n        </div>\n      </div>\n\n      @if (_isResponsive() && _hasValue()) {\n        <!-- Off-screen mirror used only to measure how many tags fit on one line. -->\n        <div #tagsMeasure class=\"l-select__tags-measure\" aria-hidden=\"true\">\n          @for (option of _selectedOptions(); track option.value) {\n            <span class=\"l-select__tag\">\n              <span class=\"l-select__tag-label\">{{ option.label }}</span>\n              @if (!_isDisabled()) {\n                <span class=\"l-select__tag-remove\">\n                  <ng-container [ngTemplateOutlet]=\"closeIcon\" />\n                </span>\n              }\n            </span>\n          }\n        </div>\n      }\n\n      @if (_open()) {\n        <!-- Moved to <body> after render (see the portal effect in select.ts) — the\n           focusout handler must sit here too, since events no longer bubble to .l-select. -->\n        <div\n          #dropdown\n          class=\"l-select__dropdown\"\n          [class.is-up]=\"_dropUp()\"\n          [style.left.px]=\"_menuLeft()\"\n          [style.width.px]=\"_menuWidth()\"\n          [style.top.px]=\"_menuTop()\"\n          [style.bottom.px]=\"_menuBottom()\"\n          (focusout)=\"_onBlur($event)\"\n        >\n          @if (searchable()) {\n            <div class=\"l-select__search\">\n              <input\n                #searchInput\n                type=\"text\"\n                class=\"l-select__search-input\"\n                [value]=\"_searchText()\"\n                placeholder=\"Search…\"\n                autocomplete=\"off\"\n                (input)=\"_onSearch($event)\"\n                (keydown)=\"_onKeydown($event, true)\"\n              />\n            </div>\n          }\n\n          @if (showLoading()) {\n            <div class=\"l-select__status\">\n              <span class=\"l-select__spinner\" aria-hidden=\"true\"></span>\n              <span>Loading…</span>\n            </div>\n          } @else if (_visible().length === 0) {\n            <div class=\"l-select__status l-select__status--empty\">No results</div>\n          } @else if (groupBy()) {\n            <div\n              #viewport\n              class=\"l-select__options\"\n              role=\"listbox\"\n              [attr.id]=\"id() + '-listbox'\"\n              [style.maxHeight.px]=\"_maxListHeight()\"\n              (scroll)=\"_onScroll($event)\"\n            >\n              @for (group of _groups(); track group.label) {\n                <div class=\"l-select__group-label\">{{ group.label }}</div>\n                @for (option of group.options; track option.index) {\n                  <ng-container\n                    [ngTemplateOutlet]=\"optionRow\"\n                    [ngTemplateOutletContext]=\"{ $implicit: option }\"\n                  />\n                }\n              }\n            </div>\n          } @else if (_useVirtual()) {\n            <div\n              #viewport\n              class=\"l-select__options\"\n              role=\"listbox\"\n              [attr.id]=\"id() + '-listbox'\"\n              [style.height.px]=\"_viewportHeight()\"\n              (scroll)=\"_onScroll($event)\"\n            >\n              <div class=\"l-select__spacer\" [style.height.px]=\"_totalHeight()\">\n                <div [style.transform]=\"'translateY(' + _offsetTop() + 'px)'\">\n                  @for (option of _window(); track option.index) {\n                    <ng-container\n                      [ngTemplateOutlet]=\"optionRow\"\n                      [ngTemplateOutletContext]=\"{ $implicit: option }\"\n                    />\n                  }\n                </div>\n              </div>\n            </div>\n          } @else {\n            <div\n              #viewport\n              class=\"l-select__options\"\n              role=\"listbox\"\n              [attr.id]=\"id() + '-listbox'\"\n              [style.maxHeight.px]=\"_maxListHeight()\"\n              (scroll)=\"_onScroll($event)\"\n            >\n              @for (option of _visible(); track option.index) {\n                <ng-container\n                  [ngTemplateOutlet]=\"optionRow\"\n                  [ngTemplateOutletContext]=\"{ $implicit: option }\"\n                />\n              }\n            </div>\n          }\n        </div>\n      }\n    </div>\n  </div>\n}\n\n<ng-template #optionRow let-option>\n  <div\n    class=\"l-select__option\"\n    role=\"option\"\n    [class.is-selected]=\"_isSelected(option.value)\"\n    [class.is-active]=\"_activeIndex() === option.index\"\n    [class.is-disabled]=\"_optionDisabled(option)\"\n    [style.height.px]=\"_rowHeight\"\n    [attr.data-index]=\"option.index\"\n    [attr.aria-selected]=\"_isSelected(option.value)\"\n    [attr.aria-disabled]=\"_optionDisabled(option)\"\n    (click)=\"_onOptionClick(option)\"\n    (mouseenter)=\"_setActive(option)\"\n  >\n    <span class=\"l-select__option-label\">{{ option.label }}</span>\n\n    @if (_isSelected(option.value)) {\n      <svg\n        class=\"l-select__check\"\n        width=\"16\"\n        height=\"16\"\n        viewBox=\"0 0 20 20\"\n        fill=\"none\"\n        aria-hidden=\"true\"\n        xmlns=\"http://www.w3.org/2000/svg\"\n      >\n        <path\n          d=\"M16.6667 5L7.5 14.1667L3.33333 10\"\n          stroke=\"currentColor\"\n          stroke-width=\"1.75\"\n          stroke-linecap=\"round\"\n          stroke-linejoin=\"round\"\n        />\n      </svg>\n    }\n  </div>\n</ng-template>\n\n<ng-template #closeIcon>\n  <svg\n    width=\"12\"\n    height=\"12\"\n    viewBox=\"0 0 20 20\"\n    fill=\"none\"\n    aria-hidden=\"true\"\n    xmlns=\"http://www.w3.org/2000/svg\"\n  >\n    <path\n      d=\"M15 5L5 15M5 5L15 15\"\n      stroke=\"currentColor\"\n      stroke-width=\"1.75\"\n      stroke-linecap=\"round\"\n      stroke-linejoin=\"round\"\n    />\n  </svg>\n</ng-template>\n",
			styles: [":host{display:block;width:100%}.l-select{position:relative;width:100%}.l-select__trigger{width:100%;align-items:center;justify-content:space-between;gap:8px;cursor:pointer;-webkit-user-select:none;user-select:none;transition:border-color .15s ease-out,box-shadow .15s ease-out}.l-select__trigger.is-placeholder .l-select__label{color:var(--text-quaternary)}.l-select__trigger:focus-visible{outline:none;border-color:var(--accent);box-shadow:0 0 0 3px var(--accent-bg)}.l-select__trigger[aria-disabled=true]{opacity:.5;cursor:not-allowed;background:var(--bg-light)}.is-open .l-select__trigger{border-color:var(--accent);box-shadow:0 0 0 3px var(--accent-bg)}.l-select__label{flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.l-select__arrow{flex-shrink:0;color:var(--text-tertiary);transition:transform .15s ease-out}.is-open .l-select__arrow{transform:rotate(180deg)}.l-select__trigger.is-multiple{padding-top:3px;padding-bottom:3px;min-height:34px;gap:6px}.l-select__affixes{display:flex;align-items:center;gap:2px;flex-shrink:0}.l-select__clear,.l-select__tag-remove{display:inline-flex;align-items:center;justify-content:center;flex-shrink:0;padding:2px;border:none;background:transparent;border-radius:4px;color:var(--text-tertiary);cursor:pointer;transition:color .12s ease-out,background .12s ease-out}.l-select__clear:hover,.l-select__tag-remove:hover{color:var(--text-primary);background:var(--separator)}.l-select__clear:focus-visible,.l-select__tag-remove:focus-visible{outline:2px solid var(--accent);outline-offset:1px}.l-select__tags{display:flex;flex:1;min-width:0;flex-wrap:nowrap;align-items:center;gap:4px;overflow:hidden}.l-select__tag{display:inline-flex;align-items:center;flex:0 0 auto;max-width:100%;height:22px;padding:0 2px 0 8px;gap:2px;background:var(--bg-dark);border-radius:4px;font-size:13px;line-height:1;white-space:nowrap}.l-select__tag--count{padding:0 8px;color:var(--text-secondary)}.l-select__tag-label{overflow:hidden;text-overflow:ellipsis}.l-select__tags-measure{position:absolute;visibility:hidden;pointer-events:none;top:0;left:0;display:flex;gap:4px}.l-select__dropdown{position:fixed;z-index:1000;display:flex;flex-direction:column;padding:4px;background:var(--bg-lightest);border:1px solid var(--separator);border-radius:8px;box-shadow:0 6px 16px #0d0d121f;animation:l-select-in .12s ease-out;transform-origin:top center}.l-select__dropdown.is-up{transform-origin:bottom center;animation-name:l-select-in-up}@keyframes l-select-in{0%{opacity:0;transform:translateY(-4px)}}@keyframes l-select-in-up{0%{opacity:0;transform:translateY(4px)}}.l-select__search{padding:4px 4px 8px}.l-select__search-input{width:100%;padding:6px 8px;border:1px solid var(--separator);border-radius:6px;outline:none;font-size:14px;line-height:20px;color:var(--text-primary)}.l-select__search-input::placeholder{color:var(--text-quaternary)}.l-select__search-input:focus{border-color:var(--accent);box-shadow:0 0 0 3px var(--accent-bg)}.l-select__options{max-height:252px;overflow-y:auto}.l-select__spacer{position:relative}.l-select__group-label{padding:6px 8px 4px;font-size:12px;font-weight:600;text-transform:uppercase;letter-spacing:.04em;color:var(--text-quaternary)}.l-select__option{display:flex;align-items:center;justify-content:space-between;gap:8px;padding:0 8px;border-radius:6px;font-size:14px;line-height:20px;color:var(--text-primary);cursor:pointer}.l-select__option.is-active{background:var(--bg-light)}.l-select__option.is-selected{background:var(--accent-bg);color:var(--accent-dark);font-weight:600}.l-select__option.is-disabled{color:var(--text-quaternary);cursor:not-allowed;background:transparent}.l-select__option-label{overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.l-select__check{flex-shrink:0;color:var(--accent)}.l-select__status{display:flex;align-items:center;justify-content:center;gap:8px;padding:16px;font-size:13px;color:var(--text-tertiary)}.l-select__status--empty{color:var(--text-quaternary)}.l-select__spinner{width:16px;height:16px;border:2px solid var(--separator-dark);border-top-color:var(--accent);border-radius:50%;animation:l-select-spin .6s linear infinite}@keyframes l-select-spin{to{transform:rotate(360deg)}}@media(prefers-reduced-motion:reduce){.l-select__trigger,.l-select__arrow,.l-select__dropdown{transition:none;animation:none}.l-select__spinner{animation-duration:1.6s}}\n"]
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		label: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "label",
				required: false
			}]
		}],
		placeholder: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "placeholder",
				required: false
			}]
		}],
		disabled: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "disabled",
				required: false
			}]
		}],
		id: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "id",
				required: false
			}]
		}],
		multiple: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "multiple",
				required: false
			}]
		}],
		maxCount: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "maxCount",
				required: false
			}]
		}],
		maxTagCount: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "maxTagCount",
				required: false
			}]
		}],
		clearable: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "clearable",
				required: false
			}]
		}],
		items: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "items",
				required: false
			}]
		}],
		bindValue: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "bindValue",
				required: false
			}]
		}],
		bindLabel: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "bindLabel",
				required: false
			}]
		}],
		bindDisabled: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "bindDisabled",
				required: false
			}]
		}],
		groupBy: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "groupBy",
				required: false
			}]
		}],
		searchable: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "searchable",
				required: false
			}]
		}],
		showArrow: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "showArrow",
				required: false
			}]
		}],
		showLoading: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "showLoading",
				required: false
			}]
		}],
		virtualScroll: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "virtualScroll",
				required: false
			}]
		}],
		viewMode: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "viewMode",
				required: false
			}]
		}],
		viewValue: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "viewValue",
				required: false
			}]
		}],
		change: [{
			type: i0.Output,
			args: ["change"]
		}],
		search: [{
			type: i0.Output,
			args: ["search"]
		}],
		scrollToEnd: [{
			type: i0.Output,
			args: ["scrollToEnd"]
		}],
		_dropdown: [{
			type: i0.ViewChild,
			args: ["dropdown", { isSignal: true }]
		}],
		_trigger: [{
			type: i0.ViewChild,
			args: ["trigger", { isSignal: true }]
		}],
		_searchInput: [{
			type: i0.ViewChild,
			args: ["searchInput", { isSignal: true }]
		}],
		_viewport: [{
			type: i0.ViewChild,
			args: ["viewport", { isSignal: true }]
		}],
		_tagsArea: [{
			type: i0.ViewChild,
			args: ["tagsArea", { isSignal: true }]
		}],
		_tagsMeasure: [{
			type: i0.ViewChild,
			args: ["tagsMeasure", { isSignal: true }]
		}]
	}
});
const dateConfigMap = {
	"2000": {
		Baisakh: 30,
		Jestha: 32,
		Asar: 31,
		Shrawan: 32,
		Bhadra: 31,
		Aswin: 30,
		Kartik: 30,
		Mangsir: 30,
		Poush: 29,
		Magh: 30,
		Falgun: 29,
		Chaitra: 31
	},
	"2001": {
		Baisakh: 31,
		Jestha: 31,
		Asar: 32,
		Shrawan: 31,
		Bhadra: 31,
		Aswin: 31,
		Kartik: 30,
		Mangsir: 29,
		Poush: 30,
		Magh: 29,
		Falgun: 30,
		Chaitra: 30
	},
	"2002": {
		Baisakh: 31,
		Jestha: 31,
		Asar: 32,
		Shrawan: 32,
		Bhadra: 31,
		Aswin: 30,
		Kartik: 30,
		Mangsir: 29,
		Poush: 30,
		Magh: 29,
		Falgun: 30,
		Chaitra: 30
	},
	"2003": {
		Baisakh: 31,
		Jestha: 32,
		Asar: 31,
		Shrawan: 32,
		Bhadra: 31,
		Aswin: 30,
		Kartik: 30,
		Mangsir: 30,
		Poush: 29,
		Magh: 29,
		Falgun: 30,
		Chaitra: 31
	},
	"2004": {
		Baisakh: 30,
		Jestha: 32,
		Asar: 31,
		Shrawan: 32,
		Bhadra: 31,
		Aswin: 30,
		Kartik: 30,
		Mangsir: 30,
		Poush: 29,
		Magh: 30,
		Falgun: 29,
		Chaitra: 31
	},
	"2005": {
		Baisakh: 31,
		Jestha: 31,
		Asar: 32,
		Shrawan: 31,
		Bhadra: 31,
		Aswin: 31,
		Kartik: 30,
		Mangsir: 29,
		Poush: 30,
		Magh: 29,
		Falgun: 30,
		Chaitra: 30
	},
	"2006": {
		Baisakh: 31,
		Jestha: 31,
		Asar: 32,
		Shrawan: 32,
		Bhadra: 31,
		Aswin: 30,
		Kartik: 30,
		Mangsir: 29,
		Poush: 30,
		Magh: 29,
		Falgun: 30,
		Chaitra: 30
	},
	"2007": {
		Baisakh: 31,
		Jestha: 32,
		Asar: 31,
		Shrawan: 32,
		Bhadra: 31,
		Aswin: 30,
		Kartik: 30,
		Mangsir: 30,
		Poush: 29,
		Magh: 29,
		Falgun: 30,
		Chaitra: 31
	},
	"2008": {
		Baisakh: 31,
		Jestha: 31,
		Asar: 31,
		Shrawan: 32,
		Bhadra: 31,
		Aswin: 31,
		Kartik: 29,
		Mangsir: 30,
		Poush: 30,
		Magh: 29,
		Falgun: 29,
		Chaitra: 31
	},
	"2009": {
		Baisakh: 31,
		Jestha: 31,
		Asar: 32,
		Shrawan: 31,
		Bhadra: 31,
		Aswin: 31,
		Kartik: 30,
		Mangsir: 29,
		Poush: 30,
		Magh: 29,
		Falgun: 30,
		Chaitra: 30
	},
	"2010": {
		Baisakh: 31,
		Jestha: 31,
		Asar: 32,
		Shrawan: 32,
		Bhadra: 31,
		Aswin: 30,
		Kartik: 30,
		Mangsir: 29,
		Poush: 30,
		Magh: 29,
		Falgun: 30,
		Chaitra: 30
	},
	"2011": {
		Baisakh: 31,
		Jestha: 32,
		Asar: 31,
		Shrawan: 32,
		Bhadra: 31,
		Aswin: 30,
		Kartik: 30,
		Mangsir: 30,
		Poush: 29,
		Magh: 29,
		Falgun: 30,
		Chaitra: 31
	},
	"2012": {
		Baisakh: 31,
		Jestha: 31,
		Asar: 31,
		Shrawan: 32,
		Bhadra: 31,
		Aswin: 31,
		Kartik: 29,
		Mangsir: 30,
		Poush: 30,
		Magh: 29,
		Falgun: 30,
		Chaitra: 30
	},
	"2013": {
		Baisakh: 31,
		Jestha: 31,
		Asar: 32,
		Shrawan: 31,
		Bhadra: 31,
		Aswin: 31,
		Kartik: 30,
		Mangsir: 29,
		Poush: 30,
		Magh: 29,
		Falgun: 30,
		Chaitra: 30
	},
	"2014": {
		Baisakh: 31,
		Jestha: 31,
		Asar: 32,
		Shrawan: 32,
		Bhadra: 31,
		Aswin: 30,
		Kartik: 30,
		Mangsir: 29,
		Poush: 30,
		Magh: 29,
		Falgun: 30,
		Chaitra: 30
	},
	"2015": {
		Baisakh: 31,
		Jestha: 32,
		Asar: 31,
		Shrawan: 32,
		Bhadra: 31,
		Aswin: 30,
		Kartik: 30,
		Mangsir: 30,
		Poush: 29,
		Magh: 29,
		Falgun: 30,
		Chaitra: 31
	},
	"2016": {
		Baisakh: 31,
		Jestha: 31,
		Asar: 31,
		Shrawan: 32,
		Bhadra: 31,
		Aswin: 31,
		Kartik: 29,
		Mangsir: 30,
		Poush: 30,
		Magh: 29,
		Falgun: 30,
		Chaitra: 30
	},
	"2017": {
		Baisakh: 31,
		Jestha: 31,
		Asar: 32,
		Shrawan: 31,
		Bhadra: 31,
		Aswin: 31,
		Kartik: 30,
		Mangsir: 29,
		Poush: 30,
		Magh: 29,
		Falgun: 30,
		Chaitra: 30
	},
	"2018": {
		Baisakh: 31,
		Jestha: 32,
		Asar: 31,
		Shrawan: 32,
		Bhadra: 31,
		Aswin: 30,
		Kartik: 30,
		Mangsir: 29,
		Poush: 30,
		Magh: 29,
		Falgun: 30,
		Chaitra: 30
	},
	"2019": {
		Baisakh: 31,
		Jestha: 32,
		Asar: 31,
		Shrawan: 32,
		Bhadra: 31,
		Aswin: 30,
		Kartik: 30,
		Mangsir: 30,
		Poush: 29,
		Magh: 30,
		Falgun: 29,
		Chaitra: 31
	},
	"2020": {
		Baisakh: 31,
		Jestha: 31,
		Asar: 31,
		Shrawan: 32,
		Bhadra: 31,
		Aswin: 31,
		Kartik: 30,
		Mangsir: 29,
		Poush: 30,
		Magh: 29,
		Falgun: 30,
		Chaitra: 30
	},
	"2021": {
		Baisakh: 31,
		Jestha: 31,
		Asar: 32,
		Shrawan: 31,
		Bhadra: 31,
		Aswin: 31,
		Kartik: 30,
		Mangsir: 29,
		Poush: 30,
		Magh: 29,
		Falgun: 30,
		Chaitra: 30
	},
	"2022": {
		Baisakh: 31,
		Jestha: 32,
		Asar: 31,
		Shrawan: 32,
		Bhadra: 31,
		Aswin: 30,
		Kartik: 30,
		Mangsir: 30,
		Poush: 29,
		Magh: 29,
		Falgun: 30,
		Chaitra: 30
	},
	"2023": {
		Baisakh: 31,
		Jestha: 32,
		Asar: 31,
		Shrawan: 32,
		Bhadra: 31,
		Aswin: 30,
		Kartik: 30,
		Mangsir: 30,
		Poush: 29,
		Magh: 30,
		Falgun: 29,
		Chaitra: 31
	},
	"2024": {
		Baisakh: 31,
		Jestha: 31,
		Asar: 31,
		Shrawan: 32,
		Bhadra: 31,
		Aswin: 31,
		Kartik: 30,
		Mangsir: 29,
		Poush: 30,
		Magh: 29,
		Falgun: 30,
		Chaitra: 30
	},
	"2025": {
		Baisakh: 31,
		Jestha: 31,
		Asar: 32,
		Shrawan: 31,
		Bhadra: 31,
		Aswin: 31,
		Kartik: 30,
		Mangsir: 29,
		Poush: 30,
		Magh: 29,
		Falgun: 30,
		Chaitra: 30
	},
	"2026": {
		Baisakh: 31,
		Jestha: 32,
		Asar: 31,
		Shrawan: 32,
		Bhadra: 31,
		Aswin: 30,
		Kartik: 30,
		Mangsir: 30,
		Poush: 29,
		Magh: 29,
		Falgun: 30,
		Chaitra: 31
	},
	"2027": {
		Baisakh: 30,
		Jestha: 32,
		Asar: 31,
		Shrawan: 32,
		Bhadra: 31,
		Aswin: 30,
		Kartik: 30,
		Mangsir: 30,
		Poush: 29,
		Magh: 30,
		Falgun: 29,
		Chaitra: 31
	},
	"2028": {
		Baisakh: 31,
		Jestha: 31,
		Asar: 32,
		Shrawan: 31,
		Bhadra: 31,
		Aswin: 31,
		Kartik: 30,
		Mangsir: 29,
		Poush: 30,
		Magh: 29,
		Falgun: 30,
		Chaitra: 30
	},
	"2029": {
		Baisakh: 31,
		Jestha: 31,
		Asar: 32,
		Shrawan: 31,
		Bhadra: 32,
		Aswin: 30,
		Kartik: 30,
		Mangsir: 29,
		Poush: 30,
		Magh: 29,
		Falgun: 30,
		Chaitra: 30
	},
	"2030": {
		Baisakh: 31,
		Jestha: 32,
		Asar: 31,
		Shrawan: 32,
		Bhadra: 31,
		Aswin: 30,
		Kartik: 30,
		Mangsir: 30,
		Poush: 29,
		Magh: 29,
		Falgun: 30,
		Chaitra: 31
	},
	"2031": {
		Baisakh: 30,
		Jestha: 32,
		Asar: 31,
		Shrawan: 32,
		Bhadra: 31,
		Aswin: 30,
		Kartik: 30,
		Mangsir: 30,
		Poush: 29,
		Magh: 30,
		Falgun: 29,
		Chaitra: 31
	},
	"2032": {
		Baisakh: 31,
		Jestha: 31,
		Asar: 32,
		Shrawan: 31,
		Bhadra: 31,
		Aswin: 31,
		Kartik: 30,
		Mangsir: 29,
		Poush: 30,
		Magh: 29,
		Falgun: 30,
		Chaitra: 30
	},
	"2033": {
		Baisakh: 31,
		Jestha: 31,
		Asar: 32,
		Shrawan: 32,
		Bhadra: 31,
		Aswin: 30,
		Kartik: 30,
		Mangsir: 29,
		Poush: 30,
		Magh: 29,
		Falgun: 30,
		Chaitra: 30
	},
	"2034": {
		Baisakh: 31,
		Jestha: 32,
		Asar: 31,
		Shrawan: 32,
		Bhadra: 31,
		Aswin: 30,
		Kartik: 30,
		Mangsir: 30,
		Poush: 29,
		Magh: 29,
		Falgun: 30,
		Chaitra: 31
	},
	"2035": {
		Baisakh: 30,
		Jestha: 32,
		Asar: 31,
		Shrawan: 32,
		Bhadra: 31,
		Aswin: 31,
		Kartik: 29,
		Mangsir: 30,
		Poush: 30,
		Magh: 29,
		Falgun: 29,
		Chaitra: 31
	},
	"2036": {
		Baisakh: 31,
		Jestha: 31,
		Asar: 32,
		Shrawan: 31,
		Bhadra: 31,
		Aswin: 31,
		Kartik: 30,
		Mangsir: 29,
		Poush: 30,
		Magh: 29,
		Falgun: 30,
		Chaitra: 30
	},
	"2037": {
		Baisakh: 31,
		Jestha: 31,
		Asar: 32,
		Shrawan: 32,
		Bhadra: 31,
		Aswin: 30,
		Kartik: 30,
		Mangsir: 29,
		Poush: 30,
		Magh: 29,
		Falgun: 30,
		Chaitra: 30
	},
	"2038": {
		Baisakh: 31,
		Jestha: 32,
		Asar: 31,
		Shrawan: 32,
		Bhadra: 31,
		Aswin: 30,
		Kartik: 30,
		Mangsir: 30,
		Poush: 29,
		Magh: 29,
		Falgun: 30,
		Chaitra: 31
	},
	"2039": {
		Baisakh: 31,
		Jestha: 31,
		Asar: 31,
		Shrawan: 32,
		Bhadra: 31,
		Aswin: 31,
		Kartik: 29,
		Mangsir: 30,
		Poush: 30,
		Magh: 29,
		Falgun: 30,
		Chaitra: 30
	},
	"2040": {
		Baisakh: 31,
		Jestha: 31,
		Asar: 32,
		Shrawan: 31,
		Bhadra: 31,
		Aswin: 31,
		Kartik: 30,
		Mangsir: 29,
		Poush: 30,
		Magh: 29,
		Falgun: 30,
		Chaitra: 30
	},
	"2041": {
		Baisakh: 31,
		Jestha: 31,
		Asar: 32,
		Shrawan: 32,
		Bhadra: 31,
		Aswin: 30,
		Kartik: 30,
		Mangsir: 29,
		Poush: 30,
		Magh: 29,
		Falgun: 30,
		Chaitra: 30
	},
	"2042": {
		Baisakh: 31,
		Jestha: 32,
		Asar: 31,
		Shrawan: 32,
		Bhadra: 31,
		Aswin: 30,
		Kartik: 30,
		Mangsir: 30,
		Poush: 29,
		Magh: 29,
		Falgun: 30,
		Chaitra: 31
	},
	"2043": {
		Baisakh: 31,
		Jestha: 31,
		Asar: 31,
		Shrawan: 32,
		Bhadra: 31,
		Aswin: 31,
		Kartik: 29,
		Mangsir: 30,
		Poush: 30,
		Magh: 29,
		Falgun: 30,
		Chaitra: 30
	},
	"2044": {
		Baisakh: 31,
		Jestha: 31,
		Asar: 32,
		Shrawan: 31,
		Bhadra: 31,
		Aswin: 31,
		Kartik: 30,
		Mangsir: 29,
		Poush: 30,
		Magh: 29,
		Falgun: 30,
		Chaitra: 30
	},
	"2045": {
		Baisakh: 31,
		Jestha: 32,
		Asar: 31,
		Shrawan: 32,
		Bhadra: 31,
		Aswin: 30,
		Kartik: 30,
		Mangsir: 29,
		Poush: 30,
		Magh: 29,
		Falgun: 30,
		Chaitra: 30
	},
	"2046": {
		Baisakh: 31,
		Jestha: 32,
		Asar: 31,
		Shrawan: 32,
		Bhadra: 31,
		Aswin: 30,
		Kartik: 30,
		Mangsir: 30,
		Poush: 29,
		Magh: 29,
		Falgun: 30,
		Chaitra: 31
	},
	"2047": {
		Baisakh: 31,
		Jestha: 31,
		Asar: 31,
		Shrawan: 32,
		Bhadra: 31,
		Aswin: 31,
		Kartik: 30,
		Mangsir: 29,
		Poush: 30,
		Magh: 29,
		Falgun: 30,
		Chaitra: 30
	},
	"2048": {
		Baisakh: 31,
		Jestha: 31,
		Asar: 32,
		Shrawan: 31,
		Bhadra: 31,
		Aswin: 31,
		Kartik: 30,
		Mangsir: 29,
		Poush: 30,
		Magh: 29,
		Falgun: 30,
		Chaitra: 30
	},
	"2049": {
		Baisakh: 31,
		Jestha: 32,
		Asar: 31,
		Shrawan: 32,
		Bhadra: 31,
		Aswin: 30,
		Kartik: 30,
		Mangsir: 30,
		Poush: 29,
		Magh: 29,
		Falgun: 30,
		Chaitra: 30
	},
	"2050": {
		Baisakh: 31,
		Jestha: 32,
		Asar: 31,
		Shrawan: 32,
		Bhadra: 31,
		Aswin: 30,
		Kartik: 30,
		Mangsir: 30,
		Poush: 29,
		Magh: 30,
		Falgun: 29,
		Chaitra: 31
	},
	"2051": {
		Baisakh: 31,
		Jestha: 31,
		Asar: 31,
		Shrawan: 32,
		Bhadra: 31,
		Aswin: 31,
		Kartik: 30,
		Mangsir: 29,
		Poush: 30,
		Magh: 29,
		Falgun: 30,
		Chaitra: 30
	},
	"2052": {
		Baisakh: 31,
		Jestha: 31,
		Asar: 32,
		Shrawan: 31,
		Bhadra: 31,
		Aswin: 31,
		Kartik: 30,
		Mangsir: 29,
		Poush: 30,
		Magh: 29,
		Falgun: 30,
		Chaitra: 30
	},
	"2053": {
		Baisakh: 31,
		Jestha: 32,
		Asar: 31,
		Shrawan: 32,
		Bhadra: 31,
		Aswin: 30,
		Kartik: 30,
		Mangsir: 30,
		Poush: 29,
		Magh: 29,
		Falgun: 30,
		Chaitra: 30
	},
	"2054": {
		Baisakh: 31,
		Jestha: 32,
		Asar: 31,
		Shrawan: 32,
		Bhadra: 31,
		Aswin: 30,
		Kartik: 30,
		Mangsir: 30,
		Poush: 29,
		Magh: 30,
		Falgun: 29,
		Chaitra: 31
	},
	"2055": {
		Baisakh: 31,
		Jestha: 31,
		Asar: 32,
		Shrawan: 31,
		Bhadra: 31,
		Aswin: 31,
		Kartik: 30,
		Mangsir: 29,
		Poush: 30,
		Magh: 29,
		Falgun: 30,
		Chaitra: 30
	},
	"2056": {
		Baisakh: 31,
		Jestha: 31,
		Asar: 32,
		Shrawan: 31,
		Bhadra: 32,
		Aswin: 30,
		Kartik: 30,
		Mangsir: 29,
		Poush: 30,
		Magh: 29,
		Falgun: 30,
		Chaitra: 30
	},
	"2057": {
		Baisakh: 31,
		Jestha: 32,
		Asar: 31,
		Shrawan: 32,
		Bhadra: 31,
		Aswin: 30,
		Kartik: 30,
		Mangsir: 30,
		Poush: 29,
		Magh: 29,
		Falgun: 30,
		Chaitra: 31
	},
	"2058": {
		Baisakh: 30,
		Jestha: 32,
		Asar: 31,
		Shrawan: 32,
		Bhadra: 31,
		Aswin: 30,
		Kartik: 30,
		Mangsir: 30,
		Poush: 29,
		Magh: 30,
		Falgun: 29,
		Chaitra: 31
	},
	"2059": {
		Baisakh: 31,
		Jestha: 31,
		Asar: 32,
		Shrawan: 31,
		Bhadra: 31,
		Aswin: 31,
		Kartik: 30,
		Mangsir: 29,
		Poush: 30,
		Magh: 29,
		Falgun: 30,
		Chaitra: 30
	},
	"2060": {
		Baisakh: 31,
		Jestha: 31,
		Asar: 32,
		Shrawan: 32,
		Bhadra: 31,
		Aswin: 30,
		Kartik: 30,
		Mangsir: 29,
		Poush: 30,
		Magh: 29,
		Falgun: 30,
		Chaitra: 30
	},
	"2061": {
		Baisakh: 31,
		Jestha: 32,
		Asar: 31,
		Shrawan: 32,
		Bhadra: 31,
		Aswin: 30,
		Kartik: 30,
		Mangsir: 30,
		Poush: 29,
		Magh: 29,
		Falgun: 30,
		Chaitra: 31
	},
	"2062": {
		Baisakh: 30,
		Jestha: 32,
		Asar: 31,
		Shrawan: 32,
		Bhadra: 31,
		Aswin: 31,
		Kartik: 29,
		Mangsir: 30,
		Poush: 29,
		Magh: 30,
		Falgun: 29,
		Chaitra: 31
	},
	"2063": {
		Baisakh: 31,
		Jestha: 31,
		Asar: 32,
		Shrawan: 31,
		Bhadra: 31,
		Aswin: 31,
		Kartik: 30,
		Mangsir: 29,
		Poush: 30,
		Magh: 29,
		Falgun: 30,
		Chaitra: 30
	},
	"2064": {
		Baisakh: 31,
		Jestha: 31,
		Asar: 32,
		Shrawan: 32,
		Bhadra: 31,
		Aswin: 30,
		Kartik: 30,
		Mangsir: 29,
		Poush: 30,
		Magh: 29,
		Falgun: 30,
		Chaitra: 30
	},
	"2065": {
		Baisakh: 31,
		Jestha: 32,
		Asar: 31,
		Shrawan: 32,
		Bhadra: 31,
		Aswin: 30,
		Kartik: 30,
		Mangsir: 30,
		Poush: 29,
		Magh: 29,
		Falgun: 30,
		Chaitra: 31
	},
	"2066": {
		Baisakh: 31,
		Jestha: 31,
		Asar: 31,
		Shrawan: 32,
		Bhadra: 31,
		Aswin: 31,
		Kartik: 29,
		Mangsir: 30,
		Poush: 30,
		Magh: 29,
		Falgun: 29,
		Chaitra: 31
	},
	"2067": {
		Baisakh: 31,
		Jestha: 31,
		Asar: 32,
		Shrawan: 31,
		Bhadra: 31,
		Aswin: 31,
		Kartik: 30,
		Mangsir: 29,
		Poush: 30,
		Magh: 29,
		Falgun: 30,
		Chaitra: 30
	},
	"2068": {
		Baisakh: 31,
		Jestha: 31,
		Asar: 32,
		Shrawan: 32,
		Bhadra: 31,
		Aswin: 30,
		Kartik: 30,
		Mangsir: 29,
		Poush: 30,
		Magh: 29,
		Falgun: 30,
		Chaitra: 30
	},
	"2069": {
		Baisakh: 31,
		Jestha: 32,
		Asar: 31,
		Shrawan: 32,
		Bhadra: 31,
		Aswin: 30,
		Kartik: 30,
		Mangsir: 30,
		Poush: 29,
		Magh: 29,
		Falgun: 30,
		Chaitra: 31
	},
	"2070": {
		Baisakh: 31,
		Jestha: 31,
		Asar: 31,
		Shrawan: 32,
		Bhadra: 31,
		Aswin: 31,
		Kartik: 29,
		Mangsir: 30,
		Poush: 30,
		Magh: 29,
		Falgun: 30,
		Chaitra: 30
	},
	"2071": {
		Baisakh: 31,
		Jestha: 31,
		Asar: 32,
		Shrawan: 31,
		Bhadra: 31,
		Aswin: 31,
		Kartik: 30,
		Mangsir: 29,
		Poush: 30,
		Magh: 29,
		Falgun: 30,
		Chaitra: 30
	},
	"2072": {
		Baisakh: 31,
		Jestha: 32,
		Asar: 31,
		Shrawan: 32,
		Bhadra: 31,
		Aswin: 30,
		Kartik: 30,
		Mangsir: 29,
		Poush: 30,
		Magh: 29,
		Falgun: 30,
		Chaitra: 30
	},
	"2073": {
		Baisakh: 31,
		Jestha: 32,
		Asar: 31,
		Shrawan: 32,
		Bhadra: 31,
		Aswin: 30,
		Kartik: 30,
		Mangsir: 30,
		Poush: 29,
		Magh: 29,
		Falgun: 30,
		Chaitra: 31
	},
	"2074": {
		Baisakh: 31,
		Jestha: 31,
		Asar: 31,
		Shrawan: 32,
		Bhadra: 31,
		Aswin: 31,
		Kartik: 30,
		Mangsir: 29,
		Poush: 30,
		Magh: 29,
		Falgun: 30,
		Chaitra: 30
	},
	"2075": {
		Baisakh: 31,
		Jestha: 31,
		Asar: 32,
		Shrawan: 31,
		Bhadra: 31,
		Aswin: 31,
		Kartik: 30,
		Mangsir: 29,
		Poush: 30,
		Magh: 29,
		Falgun: 30,
		Chaitra: 30
	},
	"2076": {
		Baisakh: 31,
		Jestha: 32,
		Asar: 31,
		Shrawan: 32,
		Bhadra: 31,
		Aswin: 30,
		Kartik: 30,
		Mangsir: 30,
		Poush: 29,
		Magh: 29,
		Falgun: 30,
		Chaitra: 30
	},
	"2077": {
		Baisakh: 31,
		Jestha: 32,
		Asar: 31,
		Shrawan: 32,
		Bhadra: 31,
		Aswin: 30,
		Kartik: 30,
		Mangsir: 30,
		Poush: 29,
		Magh: 30,
		Falgun: 29,
		Chaitra: 31
	},
	"2078": {
		Baisakh: 31,
		Jestha: 31,
		Asar: 31,
		Shrawan: 32,
		Bhadra: 31,
		Aswin: 31,
		Kartik: 30,
		Mangsir: 29,
		Poush: 30,
		Magh: 29,
		Falgun: 30,
		Chaitra: 30
	},
	"2079": {
		Baisakh: 31,
		Jestha: 31,
		Asar: 32,
		Shrawan: 31,
		Bhadra: 31,
		Aswin: 31,
		Kartik: 30,
		Mangsir: 29,
		Poush: 30,
		Magh: 29,
		Falgun: 30,
		Chaitra: 30
	},
	"2080": {
		Baisakh: 31,
		Jestha: 32,
		Asar: 31,
		Shrawan: 32,
		Bhadra: 31,
		Aswin: 30,
		Kartik: 30,
		Mangsir: 30,
		Poush: 29,
		Magh: 29,
		Falgun: 30,
		Chaitra: 30
	},
	"2081": {
		Baisakh: 31,
		Jestha: 32,
		Asar: 31,
		Shrawan: 32,
		Bhadra: 31,
		Aswin: 30,
		Kartik: 30,
		Mangsir: 30,
		Poush: 29,
		Magh: 30,
		Falgun: 29,
		Chaitra: 31
	},
	"2082": {
		Baisakh: 31,
		Jestha: 31,
		Asar: 32,
		Shrawan: 31,
		Bhadra: 31,
		Aswin: 31,
		Kartik: 30,
		Mangsir: 29,
		Poush: 30,
		Magh: 29,
		Falgun: 30,
		Chaitra: 30
	},
	"2083": {
		Baisakh: 31,
		Jestha: 31,
		Asar: 32,
		Shrawan: 31,
		Bhadra: 31,
		Aswin: 31,
		Kartik: 30,
		Mangsir: 29,
		Poush: 30,
		Magh: 29,
		Falgun: 30,
		Chaitra: 30
	},
	"2084": {
		Baisakh: 31,
		Jestha: 32,
		Asar: 31,
		Shrawan: 32,
		Bhadra: 31,
		Aswin: 30,
		Kartik: 30,
		Mangsir: 30,
		Poush: 29,
		Magh: 29,
		Falgun: 30,
		Chaitra: 31
	},
	"2085": {
		Baisakh: 30,
		Jestha: 32,
		Asar: 31,
		Shrawan: 32,
		Bhadra: 31,
		Aswin: 30,
		Kartik: 30,
		Mangsir: 30,
		Poush: 29,
		Magh: 30,
		Falgun: 29,
		Chaitra: 31
	},
	"2086": {
		Baisakh: 31,
		Jestha: 31,
		Asar: 32,
		Shrawan: 31,
		Bhadra: 31,
		Aswin: 31,
		Kartik: 30,
		Mangsir: 29,
		Poush: 30,
		Magh: 29,
		Falgun: 30,
		Chaitra: 30
	},
	"2087": {
		Baisakh: 31,
		Jestha: 31,
		Asar: 32,
		Shrawan: 31,
		Bhadra: 31,
		Aswin: 31,
		Kartik: 30,
		Mangsir: 30,
		Poush: 29,
		Magh: 30,
		Falgun: 30,
		Chaitra: 30
	},
	"2088": {
		Baisakh: 30,
		Jestha: 31,
		Asar: 32,
		Shrawan: 32,
		Bhadra: 30,
		Aswin: 31,
		Kartik: 30,
		Mangsir: 30,
		Poush: 29,
		Magh: 30,
		Falgun: 30,
		Chaitra: 30
	},
	"2089": {
		Baisakh: 30,
		Jestha: 32,
		Asar: 31,
		Shrawan: 32,
		Bhadra: 31,
		Aswin: 30,
		Kartik: 30,
		Mangsir: 30,
		Poush: 29,
		Magh: 30,
		Falgun: 30,
		Chaitra: 30
	},
	"2090": {
		Baisakh: 30,
		Jestha: 32,
		Asar: 31,
		Shrawan: 32,
		Bhadra: 31,
		Aswin: 30,
		Kartik: 30,
		Mangsir: 30,
		Poush: 29,
		Magh: 30,
		Falgun: 30,
		Chaitra: 30
	}
};
var Language;
(function(Language) {
	Language["np"] = "np";
	Language["en"] = "en";
})(Language || (Language = {}));
const yearMonthDaysMapping = Object.values(dateConfigMap).map((year) => Object.values(year));
const monthDaysMappings = yearMonthDaysMapping.map((yearMappings) => {
	let daySum = 0;
	return yearMappings.map((monthDays) => {
		const monthPassedDays = [monthDays, daySum];
		daySum += monthDays;
		return monthPassedDays;
	});
}, []);
let daysPassed = 0;
const yearDaysMapping = yearMonthDaysMapping.map((yearMappings) => {
	const daysInYear = yearMappings.reduce((acc, x) => acc + x, 0);
	const yearDaysPassed = [daysInYear, daysPassed];
	daysPassed += daysInYear;
	return yearDaysPassed;
});
const MAX_DAY = 33238;
if (daysPassed !== MAX_DAY) throw new Error("Invalid constant initialization for Nepali Date.");
const MIN_DAY = 1;
function getYearIndex(year) {
	return year - EPOCH_YEAR;
}
function getYearFromIndex(yearIndex) {
	return yearIndex + EPOCH_YEAR;
}
const EPOCH_YEAR = 2e3;
function mod(m, val) {
	while (val < 0) val += m;
	return val % m;
}
const formatObj = {
	en: {
		day: {
			short: [
				"Sun",
				"Mon",
				"Tue",
				"Wed",
				"Thu",
				"Fri",
				"Sat"
			],
			long: [
				"Sunday",
				"Monday",
				"Tuesday",
				"Wednesday",
				"Thursday",
				"Friday",
				"Saturday"
			]
		},
		month: {
			short: [
				"Bai",
				"Jes",
				"Asa",
				"Shr",
				"Bhd",
				"Asw",
				"Kar",
				"Man",
				"Pou",
				"Mag",
				"Fal",
				"Cha"
			],
			long: [
				"Baisakh",
				"Jestha",
				"Asar",
				"Shrawan",
				"Bhadra",
				"Aswin",
				"Kartik",
				"Mangsir",
				"Poush",
				"Magh",
				"Falgun",
				"Chaitra"
			]
		},
		date: [
			"0",
			"1",
			"2",
			"3",
			"4",
			"5",
			"6",
			"7",
			"8",
			"9"
		]
	},
	np: {
		day: {
			short: [
				"आइत",
				"सोम",
				"मंगल",
				"बुध",
				"बिहि",
				"शुक्र",
				"शनि"
			],
			long: [
				"आइतबार",
				"सोमबार",
				"मंगलबार",
				"बुधबार",
				"बिहिबार",
				"शुक्रबार",
				"शनिबार"
			]
		},
		month: {
			short: [
				"बै",
				"जे",
				"अ",
				"श्रा",
				"भा",
				"आ",
				"का",
				"मं",
				"पौ",
				"मा",
				"फा",
				"चै"
			],
			long: [
				"बैशाख",
				"जेठ",
				"असार",
				"श्रावण",
				"भाद्र",
				"आश्विन",
				"कार्तिक",
				"मंसिर",
				"पौष",
				"माघ",
				"फाल्गुण",
				"चैत्र"
			]
		},
		date: [
			"०",
			"१",
			"२",
			"३",
			"४",
			"५",
			"६",
			"७",
			"८",
			"९"
		]
	}
};
const beginEnglish = {
	year: 1943,
	month: 3,
	date: 13,
	day: 3
};
function findPassedDays(year, month, date) {
	try {
		const yearIndex = getYearIndex(year);
		const pastYearDays = yearDaysMapping[yearIndex][1];
		const extraMonth = mod(12, month);
		const extraYear = Math.floor(month / 12);
		const daysPassed = pastYearDays + (yearDaysMapping[yearIndex + extraYear][1] - pastYearDays + monthDaysMappings[yearIndex + extraYear][extraMonth][1]) + date;
		if (daysPassed < MIN_DAY || daysPassed > MAX_DAY) throw new Error();
		return daysPassed;
	} catch {
		throw new Error("The date doesn't fall within 2000/01/01 - 2090/12/30");
	}
}
function mapDaysToDate(daysPassed) {
	if (daysPassed < MIN_DAY || daysPassed > MAX_DAY) throw new Error(`The epoch difference is not within the boundaries ${MIN_DAY} - ${MAX_DAY}`);
	const yearIndex = yearDaysMapping.findIndex((year) => daysPassed > year[1] && daysPassed <= year[1] + year[0]);
	const monthRemainder = daysPassed - yearDaysMapping[yearIndex][1];
	const monthIndex = monthDaysMappings[yearIndex].findIndex((month) => monthRemainder > month[1] && monthRemainder <= month[1] + month[0]);
	const date = monthRemainder - monthDaysMappings[yearIndex][monthIndex][1];
	return {
		year: getYearFromIndex(yearIndex),
		month: monthIndex,
		date
	};
}
function findPassedDaysAD(year, month, date) {
	const timeDiff = Math.abs(Date.UTC(year, month, date) - Date.UTC(beginEnglish.year, beginEnglish.month, beginEnglish.date));
	return Math.ceil(timeDiff / 864e5);
}
function mapDaysToDateAD(daysPassed) {
	const mappedDate = new Date(Date.UTC(1943, 3, 13 + daysPassed));
	return {
		year: mappedDate.getUTCFullYear(),
		month: mappedDate.getUTCMonth(),
		date: mappedDate.getUTCDate(),
		day: mappedDate.getUTCDay()
	};
}
function convertToAD(bsDateObject) {
	try {
		const daysPassed = findPassedDays(bsDateObject.year, bsDateObject.month, bsDateObject.date);
		const BS = mapDaysToDate(daysPassed);
		const AD = mapDaysToDateAD(daysPassed);
		return {
			AD,
			BS: {
				...BS,
				day: AD.day
			}
		};
	} catch {
		throw new Error("The date doesn't fall within 2000/01/01 - 2090/12/30");
	}
}
function convertToBS(adDateObject) {
	try {
		const daysPassed = findPassedDaysAD(adDateObject.getFullYear(), adDateObject.getMonth(), adDateObject.getDate());
		const BS = mapDaysToDate(daysPassed);
		const AD = mapDaysToDateAD(daysPassed);
		return {
			AD,
			BS: {
				...BS,
				day: AD.day
			}
		};
	} catch {
		throw new Error("The date doesn't fall within 2000/01/01 - 2090/12/30");
	}
}
function mapLanguageNumber(dateNumber, language) {
	return dateNumber.split("").map((num) => formatObj[language].date[parseInt(num, 10)]).join("");
}
function format(bsDate, stringFormat, language) {
	return stringFormat.replace(/((\\[MDYd])|D{1,2}|M{1,4}|Y{2,4}|d{1,3})/g, (match, _, matchedString) => {
		switch (match) {
			case "D": return mapLanguageNumber(bsDate.date.toString(), language);
			case "DD": return mapLanguageNumber(bsDate.date.toString().padStart(2, "0"), language);
			case "M": return mapLanguageNumber((bsDate.month + 1).toString(), language);
			case "MM": return mapLanguageNumber((bsDate.month + 1).toString().padStart(2, "0"), language);
			case "MMM": return formatObj[language].month.short[bsDate.month];
			case "MMMM": return formatObj[language].month.long[bsDate.month];
			case "YY": return mapLanguageNumber(bsDate.year.toString().slice(-2), language);
			case "YYY": return mapLanguageNumber(bsDate.year.toString().slice(-3), language);
			case "YYYY": return mapLanguageNumber(bsDate.year.toString(), language);
			case "d": return mapLanguageNumber(bsDate.day?.toString() || "0", language);
			case "dd": return formatObj[language].day.short[bsDate.day || 0];
			case "ddd": return formatObj[language].day.long[bsDate.day || 0];
			default: return matchedString.replace("/", "");
		}
	}).replace(/\\/g, "");
}
function parse(dateString) {
	const OFFICIAL_FORMAT = /(\d{4})\s*([/-]|\s+)\s*(\d{1,2})\s*([/-]|\s+)\s*(\d{1,2})/;
	const GEORGIAN_FORMAT = /(\d{1,2})\s*([/-]|\s+)\s*(\d{1,2})\s*([/-]|\s+)\s*(\d{4})/;
	let match;
	match = dateString.match(OFFICIAL_FORMAT);
	if (match !== null) return {
		year: parseInt(match[1], 10),
		month: parseInt(match[3], 10) - 1,
		date: parseInt(match[5], 10)
	};
	match = dateString.match(GEORGIAN_FORMAT);
	if (match !== null) return {
		year: parseInt(match[5], 10),
		month: parseInt(match[3], 10) - 1,
		date: parseInt(match[1], 10)
	};
	throw new Error("Invalid date format");
}
const dateSymbol = Symbol("Date");
const daySymbol = Symbol("Day");
const yearSymbol = Symbol("Year");
const monthSymbol = Symbol("MonthIndex");
const jsDateSymbol = Symbol("JsDate");
const convertToBSMethod = Symbol("convertToBS()");
const convertToADMethod = Symbol("convertToAD()");
const setAdBs = Symbol("setADBS()");
const setDayYearMonth = Symbol("setDayYearMonth()");
var NepaliDate = class NepaliDate {
	[jsDateSymbol];
	[yearSymbol];
	[dateSymbol];
	[daySymbol];
	[monthSymbol];
	static language = Language.en;
	constructor() {
		const constructorError = /* @__PURE__ */ new Error("Invalid constructor arguments");
		if (arguments.length === 0) this[convertToBSMethod](/* @__PURE__ */ new Date());
		else if (arguments.length === 1) {
			const argument = arguments[0];
			switch (typeof argument) {
				case "number":
					this[convertToBSMethod](new Date(argument));
					break;
				case "string":
					const { date, year, month } = parse(argument);
					this[setDayYearMonth](year, month, date);
					this[convertToADMethod]();
					break;
				case "object":
					if (argument instanceof Date) this[convertToBSMethod](argument);
					else throw constructorError;
					break;
				default: throw constructorError;
			}
		} else if (arguments.length <= 3) {
			this[setDayYearMonth](arguments[0], arguments[1], arguments[2]);
			this[convertToADMethod]();
		} else throw constructorError;
	}
	[setDayYearMonth](year, month = 0, date = 1, day = 0) {
		this[yearSymbol] = year;
		this[monthSymbol] = month;
		this[dateSymbol] = date;
		this[daySymbol] = day;
	}
	toJsDate() {
		return this[jsDateSymbol];
	}
	getDate() {
		return this[dateSymbol];
	}
	getYear() {
		return this[yearSymbol];
	}
	getDay() {
		return this[daySymbol];
	}
	getMonth() {
		return this[monthSymbol];
	}
	getDateObject() {
		return {
			BS: this.getBS(),
			AD: this.getAD()
		};
	}
	getBS() {
		return {
			year: this[yearSymbol],
			month: this[monthSymbol],
			date: this[dateSymbol],
			day: this[daySymbol]
		};
	}
	getAD() {
		return {
			year: this[jsDateSymbol].getFullYear(),
			month: this[jsDateSymbol].getMonth(),
			date: this[jsDateSymbol].getDate(),
			day: this[jsDateSymbol].getDay()
		};
	}
	setDate(date) {
		const oldDate = this[dateSymbol];
		try {
			this[dateSymbol] = date;
			this[convertToADMethod]();
		} catch (e) {
			this[dateSymbol] = oldDate;
			throw e;
		}
	}
	setMonth(month) {
		const oldMonth = this[monthSymbol];
		try {
			this[monthSymbol] = month;
			this[convertToADMethod]();
		} catch (e) {
			this[monthSymbol] = oldMonth;
			throw e;
		}
	}
	setYear(year) {
		const oldYear = this[yearSymbol];
		try {
			this[yearSymbol] = year;
			this[convertToADMethod]();
		} catch (e) {
			this[yearSymbol] = oldYear;
			throw e;
		}
	}
	format(formatString, language = NepaliDate.language) {
		return format(this.getBS(), formatString, language);
	}
	static parse(dateString) {
		const { date, year, month } = parse(dateString);
		return new NepaliDate(year, month, date);
	}
	static now() {
		return new NepaliDate();
	}
	static fromAD(date) {
		return new NepaliDate(date);
	}
	[convertToBSMethod](date) {
		const { AD, BS } = convertToBS(date);
		this[setAdBs](AD, BS);
	}
	[setAdBs](AD, BS) {
		this[setDayYearMonth](BS.year, BS.month, BS.date, BS.day);
		this[jsDateSymbol] = new Date(AD.year, AD.month, AD.date);
	}
	[convertToADMethod]() {
		const { AD, BS } = convertToAD({
			year: this[yearSymbol],
			month: this[monthSymbol],
			date: this[dateSymbol]
		});
		this[setAdBs](AD, BS);
	}
	valueOf() {
		return this[jsDateSymbol].getTime();
	}
	toString() {
		return this.format("ddd DD, MMMM YYYY");
	}
};
let _uid$5 = 0;
const AD_MONTHS_SHORT = [
	"Jan",
	"Feb",
	"Mar",
	"Apr",
	"May",
	"Jun",
	"Jul",
	"Aug",
	"Sep",
	"Oct",
	"Nov",
	"Dec"
];
const AD_MONTHS_LONG = [
	"January",
	"February",
	"March",
	"April",
	"May",
	"June",
	"July",
	"August",
	"September",
	"October",
	"November",
	"December"
];
const AD_DAYS_SHORT = [
	"Sun",
	"Mon",
	"Tue",
	"Wed",
	"Thu",
	"Fri",
	"Sat"
];
const AD_DAYS_LONG = [
	"Sunday",
	"Monday",
	"Tuesday",
	"Wednesday",
	"Thursday",
	"Friday",
	"Saturday"
];
const WEEKDAYS = [
	"Su",
	"Mo",
	"Tu",
	"We",
	"Th",
	"Fr",
	"Sa"
];
const BS_YEAR_MIN = 2e3;
const BS_YEAR_MAX = 2090;
const AD_YEAR_MIN = 1944;
const AD_YEAR_MAX = 2033;
const PANEL_WIDTH = 288;
const PANEL_HEIGHT = 356;
function startOfDay(date) {
	return new Date(date.getFullYear(), date.getMonth(), date.getDate());
}
function formatAd(date, formatString) {
	return formatString.replace(/((\\[MDYd])|D{1,2}|M{1,4}|Y{2,4}|d{1,3})/g, (match, _, escaped) => {
		switch (match) {
			case "D": return String(date.getDate());
			case "DD": return String(date.getDate()).padStart(2, "0");
			case "M": return String(date.getMonth() + 1);
			case "MM": return String(date.getMonth() + 1).padStart(2, "0");
			case "MMM": return AD_MONTHS_SHORT[date.getMonth()];
			case "MMMM": return AD_MONTHS_LONG[date.getMonth()];
			case "YY": return String(date.getFullYear()).slice(-2);
			case "YYY": return String(date.getFullYear()).slice(-3);
			case "YYYY": return String(date.getFullYear());
			case "d": return String(date.getDay());
			case "dd": return AD_DAYS_SHORT[date.getDay()];
			case "ddd": return AD_DAYS_LONG[date.getDay()];
			default: return escaped.replace("\\", "");
		}
	}).replace(/\\/g, "");
}
var DateInput = class DateInput {
	label = input("", ...ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []);
	placeholder = input("Select date", ...ngDevMode ? [{ debugName: "placeholder" }] : /* istanbul ignore next */ []);
	disabled = input(false, ...ngDevMode ? [{ debugName: "disabled" }] : /* istanbul ignore next */ []);
	id = input(`l-date-input-${_uid$5++}`, ...ngDevMode ? [{ debugName: "id" }] : /* istanbul ignore next */ []);
	calendar = input("ad", ...ngDevMode ? [{ debugName: "calendar" }] : /* istanbul ignore next */ []);
	lang = input("en", ...ngDevMode ? [{ debugName: "lang" }] : /* istanbul ignore next */ []);
	format = input("YYYY-MM-DD", ...ngDevMode ? [{ debugName: "format" }] : /* istanbul ignore next */ []);
	showToday = input(true, ...ngDevMode ? [{ debugName: "showToday" }] : /* istanbul ignore next */ []);
	openCalendarOnFocus = input(false, ...ngDevMode ? [{ debugName: "openCalendarOnFocus" }] : /* istanbul ignore next */ []);
	showCalendarIcon = input(true, ...ngDevMode ? [{ debugName: "showCalendarIcon" }] : /* istanbul ignore next */ []);
	typableDateInput = input(true, ...ngDevMode ? [{ debugName: "typableDateInput" }] : /* istanbul ignore next */ []);
	clearable = input(true, ...ngDevMode ? [{ debugName: "clearable" }] : /* istanbul ignore next */ []);
	min = input(null, ...ngDevMode ? [{ debugName: "min" }] : /* istanbul ignore next */ []);
	max = input(null, ...ngDevMode ? [{ debugName: "max" }] : /* istanbul ignore next */ []);
	viewMode = input(false, ...ngDevMode ? [{ debugName: "viewMode" }] : /* istanbul ignore next */ []);
	viewValue = input(...ngDevMode ? [void 0, { debugName: "viewValue" }] : /* istanbul ignore next */ []);
	change = output();
	calendarChange = output();
	_mode = linkedSignal(() => this.calendar(), ...ngDevMode ? [{ debugName: "_mode" }] : /* istanbul ignore next */ []);
	_view = signal("date", ...ngDevMode ? [{ debugName: "_view" }] : /* istanbul ignore next */ []);
	_open = signal(false, ...ngDevMode ? [{ debugName: "_open" }] : /* istanbul ignore next */ []);
	_viewYear = signal(0, ...ngDevMode ? [{ debugName: "_viewYear" }] : /* istanbul ignore next */ []);
	_viewMonth = signal(0, ...ngDevMode ? [{ debugName: "_viewMonth" }] : /* istanbul ignore next */ []);
	_activeDate = signal(null, ...ngDevMode ? [{ debugName: "_activeDate" }] : /* istanbul ignore next */ []);
	_value = signal(null, ...ngDevMode ? [{ debugName: "_value" }] : /* istanbul ignore next */ []);
	_disabledByForm = signal(false, ...ngDevMode ? [{ debugName: "_disabledByForm" }] : /* istanbul ignore next */ []);
	_touched = signal(false, ...ngDevMode ? [{ debugName: "_touched" }] : /* istanbul ignore next */ []);
	_typedText = signal(null, ...ngDevMode ? [{ debugName: "_typedText" }] : /* istanbul ignore next */ []);
	_todayTime = signal(startOfDay(/* @__PURE__ */ new Date()).getTime(), ...ngDevMode ? [{ debugName: "_todayTime" }] : /* istanbul ignore next */ []);
	_isDisabled = computed(() => this.disabled() || this._disabledByForm(), ...ngDevMode ? [{ debugName: "_isDisabled" }] : /* istanbul ignore next */ []);
	_dropUp = signal(false, ...ngDevMode ? [{ debugName: "_dropUp" }] : /* istanbul ignore next */ []);
	_panelLeft = signal(0, ...ngDevMode ? [{ debugName: "_panelLeft" }] : /* istanbul ignore next */ []);
	_panelTop = signal(null, ...ngDevMode ? [{ debugName: "_panelTop" }] : /* istanbul ignore next */ []);
	_panelBottom = signal(null, ...ngDevMode ? [{ debugName: "_panelBottom" }] : /* istanbul ignore next */ []);
	_host = inject(ElementRef);
	_trigger = viewChild("trigger", ...ngDevMode ? [{ debugName: "_trigger" }] : /* istanbul ignore next */ []);
	_field = viewChild("field", ...ngDevMode ? [{ debugName: "_field" }] : /* istanbul ignore next */ []);
	_grid = viewChild("grid", ...ngDevMode ? [{ debugName: "_grid" }] : /* istanbul ignore next */ []);
	_onViewportChange = () => {
		if (this._open()) this._reposition();
	};
	_skipFocusOpen = false;
	_onChange = () => {};
	_onTouched = () => {};
	constructor() {
		inject(DestroyRef).onDestroy(() => {
			window.removeEventListener("scroll", this._onViewportChange, true);
			window.removeEventListener("resize", this._onViewportChange);
		});
	}
	_minTime = computed(() => this._boundTime(this.min()), ...ngDevMode ? [{ debugName: "_minTime" }] : /* istanbul ignore next */ []);
	_maxTime = computed(() => this._boundTime(this.max()), ...ngDevMode ? [{ debugName: "_maxTime" }] : /* istanbul ignore next */ []);
	_hasValue = computed(() => this._value() !== null, ...ngDevMode ? [{ debugName: "_hasValue" }] : /* istanbul ignore next */ []);
	_showClear = computed(() => this.clearable() && this._hasValue() && !this._isDisabled(), ...ngDevMode ? [{ debugName: "_showClear" }] : /* istanbul ignore next */ []);
	_displayValue = computed(() => {
		const typed = this._typedText();
		if (typed !== null) return typed;
		const value = this._value();
		if (!value) return "";
		if (this._mode() === "bs") try {
			return new NepaliDate(value).format(this.format(), this.lang());
		} catch {}
		return formatAd(value, this.format());
	}, ...ngDevMode ? [{ debugName: "_displayValue" }] : /* istanbul ignore next */ []);
	_weekdays = computed(() => this._mode() === "bs" && this.lang() === "np" ? formatObj.np.day.short : WEEKDAYS, ...ngDevMode ? [{ debugName: "_weekdays" }] : /* istanbul ignore next */ []);
	_headerMonthLabel = computed(() => this._mode() === "bs" ? formatObj[this.lang()].month.long[this._viewMonth()] : AD_MONTHS_SHORT[this._viewMonth()], ...ngDevMode ? [{ debugName: "_headerMonthLabel" }] : /* istanbul ignore next */ []);
	_headerYearLabel = computed(() => this._yearLabel(this._viewYear()), ...ngDevMode ? [{ debugName: "_headerYearLabel" }] : /* istanbul ignore next */ []);
	_yearPageStart = computed(() => Math.floor(this._viewYear() / 12) * 12, ...ngDevMode ? [{ debugName: "_yearPageStart" }] : /* istanbul ignore next */ []);
	_yearRangeLabel = computed(() => {
		const start = this._yearPageStart();
		return `${this._yearLabel(start)} – ${this._yearLabel(start + 11)}`;
	}, ...ngDevMode ? [{ debugName: "_yearRangeLabel" }] : /* istanbul ignore next */ []);
	_cells = computed(() => {
		const mode = this._mode();
		const year = this._viewYear();
		const month = this._viewMonth();
		const first = mode === "bs" ? this._bsToJs(year, month, 1) : new Date(year, month, 1);
		if (!first) return [];
		const startOffset = first.getDay();
		const selectedTime = this._value()?.getTime() ?? null;
		const activeTime = this._activeDate()?.getTime() ?? null;
		const todayTime = this._todayTime();
		const cells = [];
		for (let i = 0; i < 42; i++) {
			const date = new Date(first.getFullYear(), first.getMonth(), first.getDate() + i - startOffset);
			const time = date.getTime();
			let label;
			let aria;
			let inMonth;
			let convertible = true;
			if (mode === "bs") {
				const bs = this._toBs(date);
				if (bs) {
					label = format(bs, "D", this.lang());
					aria = format(bs, "DD MMMM YYYY", this.lang());
					inMonth = bs.year === year && bs.month === month;
				} else {
					label = "";
					aria = "";
					inMonth = false;
					convertible = false;
				}
			} else {
				label = String(date.getDate());
				aria = formatAd(date, "DD MMMM YYYY");
				inMonth = date.getMonth() === month;
			}
			cells.push({
				key: i,
				label,
				date: convertible ? date : null,
				aria,
				inMonth,
				today: time === todayTime,
				selected: selectedTime !== null && time === selectedTime,
				active: activeTime !== null && time === activeTime,
				disabled: !convertible || this._outOfRange(time)
			});
		}
		return cells;
	}, ...ngDevMode ? [{ debugName: "_cells" }] : /* istanbul ignore next */ []);
	_monthCells = computed(() => {
		return (this._mode() === "bs" ? formatObj[this.lang()].month.long : AD_MONTHS_SHORT).map((label, index) => ({
			index,
			label,
			selected: index === this._viewMonth()
		}));
	}, ...ngDevMode ? [{ debugName: "_monthCells" }] : /* istanbul ignore next */ []);
	_yearCells = computed(() => {
		const start = this._yearPageStart();
		const [minYear, maxYear] = this._yearBounds();
		return Array.from({ length: 12 }, (_, i) => {
			const year = start + i;
			return {
				year,
				label: this._yearLabel(year),
				selected: year === this._viewYear(),
				disabled: year < minYear || year > maxYear
			};
		});
	}, ...ngDevMode ? [{ debugName: "_yearCells" }] : /* istanbul ignore next */ []);
	_onTriggerClick() {
		if (this._isDisabled()) return;
		this._openPanel();
		this._field()?.nativeElement.focus();
	}
	_onFocus() {
		if (this._skipFocusOpen) return;
		if (this.openCalendarOnFocus() && !this._isDisabled()) this._openPanel();
	}
	_onTyped(event) {
		const field = event.target;
		if (!this.typableDateInput()) {
			field.value = this._displayValue();
			return;
		}
		const sanitized = field.value.replace(/[^\d/\- ]/g, "").slice(0, 10);
		if (sanitized !== field.value) {
			const caret = Math.max(0, (field.selectionStart ?? sanitized.length) - (field.value.length - sanitized.length));
			field.value = sanitized;
			field.setSelectionRange(caret, caret);
		}
		this._typedText.set(sanitized);
		if (!this._open()) this._openPanel();
	}
	_onInputKeydown(event) {
		switch (event.key) {
			case "Enter":
				event.preventDefault();
				this._commitTyped();
				this._close();
				break;
			case "ArrowDown":
			case "ArrowUp":
				event.preventDefault();
				if (!this._open()) this._openPanel();
				queueMicrotask(() => this._grid()?.nativeElement.focus());
				break;
			case "Escape":
				if (this._open()) {
					event.preventDefault();
					this._typedText.set(null);
					this._close(false);
				}
				break;
			case "Tab":
				this._commitTyped();
				this._close(false);
		}
	}
	_onBlur(event) {
		if (!this._host.nativeElement.contains(event.relatedTarget)) {
			this._commitTyped();
			this._close(false);
			this._touched.set(true);
			this._onTouched();
		}
	}
	_onDocumentPointerDown(event) {
		if (this._open() && !this._host.nativeElement.contains(event.target)) {
			this._commitTyped();
			this._close(false);
		}
	}
	_clear(event) {
		event.stopPropagation();
		if (this._isDisabled()) return;
		this._typedText.set(null);
		this._setValue(null);
		this._refocusField();
	}
	_prev() {
		const view = this._view();
		if (view === "year") this._shiftYear(-12);
		else if (view === "month") this._shiftYear(-1);
		else this._shiftMonth(-1);
	}
	_next() {
		const view = this._view();
		if (view === "year") this._shiftYear(12);
		else if (view === "month") this._shiftYear(1);
		else this._shiftMonth(1);
	}
	_superPrev() {
		this._shiftYear(this._view() === "year" ? -12 : -1);
	}
	_superNext() {
		this._shiftYear(this._view() === "year" ? 12 : 1);
	}
	_showMonthView() {
		this._view.set("month");
	}
	_showYearView() {
		this._view.set("year");
	}
	_selectMonth(index) {
		this._viewMonth.set(index);
		this._view.set("date");
	}
	_selectYear(cell) {
		if (cell.disabled) return;
		this._viewYear.set(cell.year);
		this._view.set("month");
	}
	_selectDay(cell) {
		if (cell.disabled || !cell.date) return;
		this._setValue(cell.date);
		this._activeDate.set(cell.date);
		this._close();
	}
	_selectToday() {
		const today = startOfDay(/* @__PURE__ */ new Date());
		if (this._outOfRange(today.getTime())) return;
		this._setValue(today);
		this._activeDate.set(today);
		this._close();
	}
	_setMode(mode) {
		if (this._mode() === mode || this._isDisabled()) return;
		this._mode.set(mode);
		this._typedText.set(null);
		this._view.set("date");
		this._syncView(this._value() ?? this._activeDate() ?? startOfDay(/* @__PURE__ */ new Date()));
		this.calendarChange.emit(mode);
	}
	_onGridKeydown(event) {
		switch (event.key) {
			case "ArrowLeft":
				event.preventDefault();
				this._moveActive(-1);
				break;
			case "ArrowRight":
				event.preventDefault();
				this._moveActive(1);
				break;
			case "ArrowUp":
				event.preventDefault();
				this._moveActive(-7);
				break;
			case "ArrowDown":
				event.preventDefault();
				this._moveActive(7);
				break;
			case "PageUp":
				event.preventDefault();
				this._moveActiveMonth(-1);
				break;
			case "PageDown":
				event.preventDefault();
				this._moveActiveMonth(1);
				break;
			case "Enter":
			case " ": {
				event.preventDefault();
				const active = this._activeDate();
				if (active && !this._outOfRange(active.getTime())) {
					this._setValue(active);
					this._close();
				}
				break;
			}
			case "Escape":
				event.preventDefault();
				this._close(false);
				break;
			case "Tab": this._close(false);
		}
	}
	_moveActive(deltaDays) {
		const base = this._activeDate() ?? this._value() ?? startOfDay(/* @__PURE__ */ new Date());
		const next = new Date(base.getFullYear(), base.getMonth(), base.getDate() + deltaDays);
		this._setActive(next);
	}
	_moveActiveMonth(delta) {
		const base = this._activeDate() ?? this._value() ?? startOfDay(/* @__PURE__ */ new Date());
		if (this._mode() === "bs") {
			try {
				const nd = new NepaliDate(base);
				const day = Math.min(nd.getDate(), 29);
				const next = new NepaliDate(nd.getYear(), nd.getMonth() + delta, day);
				this._setActive(next.toJsDate());
			} catch {}
			return;
		}
		const daysInTarget = new Date(base.getFullYear(), base.getMonth() + delta + 1, 0).getDate();
		this._setActive(new Date(base.getFullYear(), base.getMonth() + delta, Math.min(base.getDate(), daysInTarget)));
	}
	_setActive(date) {
		if (this._mode() === "bs" && !this._toBs(date)) return;
		this._activeDate.set(date);
		this._syncView(date);
	}
	_openPanel() {
		if (this._isDisabled() || this._open()) return;
		this._todayTime.set(startOfDay(/* @__PURE__ */ new Date()).getTime());
		this._view.set("date");
		const anchor = this._value() ?? startOfDay(/* @__PURE__ */ new Date());
		this._activeDate.set(anchor);
		this._syncView(anchor);
		this._open.set(true);
		this._reposition();
		window.addEventListener("scroll", this._onViewportChange, true);
		window.addEventListener("resize", this._onViewportChange);
		queueMicrotask(() => this._reposition());
	}
	_close(refocus = true) {
		if (!this._open()) return;
		this._open.set(false);
		window.removeEventListener("scroll", this._onViewportChange, true);
		window.removeEventListener("resize", this._onViewportChange);
		if (refocus) this._refocusField();
	}
	_refocusField() {
		this._skipFocusOpen = true;
		this._field()?.nativeElement.focus();
		queueMicrotask(() => this._skipFocusOpen = false);
	}
	_reposition() {
		const el = this._trigger()?.nativeElement;
		if (!el) return;
		const rect = el.getBoundingClientRect();
		const gap = 4;
		const spaceBelow = window.innerHeight - rect.bottom - gap;
		const spaceAbove = rect.top - gap;
		const dropUp = spaceBelow < PANEL_HEIGHT && spaceAbove > spaceBelow;
		const box = fixedContainingBlock(el);
		const left = Math.max(8, Math.min(rect.left, window.innerWidth - PANEL_WIDTH - 8));
		this._dropUp.set(dropUp);
		this._panelLeft.set(left - box.left);
		if (dropUp) {
			this._panelTop.set(null);
			this._panelBottom.set(box.bottom - rect.top + gap);
		} else {
			this._panelTop.set(rect.bottom + gap - box.top);
			this._panelBottom.set(null);
		}
	}
	_commitTyped() {
		const typed = this._typedText();
		if (typed === null) return;
		this._typedText.set(null);
		const text = typed.trim();
		if (!text) {
			if (this._hasValue()) this._setValue(null);
			return;
		}
		try {
			const { year, month, date } = parse(text);
			let parsed = null;
			if (this._mode() === "bs") {
				if (month >= 0 && month <= 11 && date >= 1 && date <= this._daysInBsMonth(year, month)) parsed = this._bsToJs(year, month, date);
			} else {
				const candidate = new Date(year, month, date);
				parsed = candidate.getFullYear() === year && candidate.getMonth() === month && candidate.getDate() === date ? candidate : null;
			}
			if (parsed && !this._outOfRange(parsed.getTime())) {
				this._setValue(parsed);
				this._activeDate.set(parsed);
				this._syncView(parsed);
			}
		} catch {}
	}
	_setValue(value) {
		const normalized = value ? startOfDay(value) : null;
		this._value.set(normalized);
		this._onChange(normalized);
		this.change.emit(normalized);
	}
	_syncView(date) {
		if (this._mode() === "bs") {
			const bs = this._toBs(date) ?? this._toBs(/* @__PURE__ */ new Date());
			if (bs) {
				this._viewYear.set(bs.year);
				this._viewMonth.set(bs.month);
				return;
			}
		}
		this._viewYear.set(date.getFullYear());
		this._viewMonth.set(date.getMonth());
	}
	_shiftMonth(delta) {
		let month = this._viewMonth() + delta;
		let year = this._viewYear();
		while (month < 0) {
			month += 12;
			year--;
		}
		while (month > 11) {
			month -= 12;
			year++;
		}
		const [minYear, maxYear] = this._yearBounds();
		if (year < minYear) {
			year = minYear;
			month = 0;
		} else if (year > maxYear) {
			year = maxYear;
			month = 11;
		}
		this._viewYear.set(year);
		this._viewMonth.set(month);
	}
	_shiftYear(delta) {
		const [minYear, maxYear] = this._yearBounds();
		this._viewYear.set(Math.max(minYear, Math.min(maxYear, this._viewYear() + delta)));
	}
	_yearBounds() {
		return this._mode() === "bs" ? [BS_YEAR_MIN, BS_YEAR_MAX] : [AD_YEAR_MIN, AD_YEAR_MAX];
	}
	_yearLabel(year) {
		return this._mode() === "bs" ? format({
			year,
			month: 0,
			date: 1
		}, "YYYY", this.lang()) : String(year);
	}
	_toBs(date) {
		try {
			return new NepaliDate(date).getBS();
		} catch {
			return null;
		}
	}
	_bsToJs(year, month, date) {
		try {
			return new NepaliDate(year, month, date).toJsDate();
		} catch {
			return null;
		}
	}
	_daysInBsMonth(year, month) {
		const config = dateConfigMap[String(year)];
		return config ? Object.values(config)[month] : 0;
	}
	_boundTime(bound) {
		if (bound == null || bound === "") return null;
		const date = bound instanceof Date ? bound : new Date(bound);
		return isNaN(date.getTime()) ? null : startOfDay(date).getTime();
	}
	_outOfRange(time) {
		const min = this._minTime();
		const max = this._maxTime();
		return min !== null && time < min || max !== null && time > max;
	}
	writeValue(value) {
		if (value == null || value === "") {
			this._value.set(null);
			return;
		}
		const date = value instanceof Date ? value : new Date(value);
		this._value.set(isNaN(date.getTime()) ? null : startOfDay(date));
	}
	registerOnChange(fn) {
		this._onChange = fn;
	}
	registerOnTouched(fn) {
		this._onTouched = fn;
	}
	setDisabledState(isDisabled) {
		this._disabledByForm.set(isDisabled);
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.1",
		ngImport: i0,
		type: DateInput,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.1",
		type: DateInput,
		isStandalone: true,
		selector: "l-date-input",
		inputs: {
			label: {
				classPropertyName: "label",
				publicName: "label",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			placeholder: {
				classPropertyName: "placeholder",
				publicName: "placeholder",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			disabled: {
				classPropertyName: "disabled",
				publicName: "disabled",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			id: {
				classPropertyName: "id",
				publicName: "id",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			calendar: {
				classPropertyName: "calendar",
				publicName: "calendar",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			lang: {
				classPropertyName: "lang",
				publicName: "lang",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			format: {
				classPropertyName: "format",
				publicName: "format",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			showToday: {
				classPropertyName: "showToday",
				publicName: "showToday",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			openCalendarOnFocus: {
				classPropertyName: "openCalendarOnFocus",
				publicName: "openCalendarOnFocus",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			showCalendarIcon: {
				classPropertyName: "showCalendarIcon",
				publicName: "showCalendarIcon",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			typableDateInput: {
				classPropertyName: "typableDateInput",
				publicName: "typableDateInput",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			clearable: {
				classPropertyName: "clearable",
				publicName: "clearable",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			min: {
				classPropertyName: "min",
				publicName: "min",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			max: {
				classPropertyName: "max",
				publicName: "max",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			viewMode: {
				classPropertyName: "viewMode",
				publicName: "viewMode",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			viewValue: {
				classPropertyName: "viewValue",
				publicName: "viewValue",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: {
			change: "change",
			calendarChange: "calendarChange"
		},
		host: { listeners: { "document:pointerdown": "_onDocumentPointerDown($event)" } },
		providers: [provideInputValueAccessor(() => DateInput)],
		viewQueries: [
			{
				propertyName: "_trigger",
				first: true,
				predicate: ["trigger"],
				descendants: true,
				isSignal: true
			},
			{
				propertyName: "_field",
				first: true,
				predicate: ["field"],
				descendants: true,
				isSignal: true
			},
			{
				propertyName: "_grid",
				first: true,
				predicate: ["grid"],
				descendants: true,
				isSignal: true
			}
		],
		hostDirectives: [{
			directive: FormValidation,
			inputs: ["useValidation", "useValidation"]
		}],
		ngImport: i0,
		template: "@if (viewMode()) {\n  <div class=\"form-group view-mode\">\n    @if (label()) {\n      <label>{{ label() }}</label>\n    }\n    <div class=\"view-value\">{{ viewValue() ?? (_displayValue() || '-') }}</div>\n  </div>\n} @else {\n  <div class=\"form-group\">\n    @if (label()) {\n      <label [attr.for]=\"id()\">{{ label() }}</label>\n    }\n\n    <div class=\"l-date-input\" [class.is-open]=\"_open()\" (focusout)=\"_onBlur($event)\">\n      <div\n        #trigger\n        class=\"form-control l-date-input__trigger\"\n        [attr.aria-disabled]=\"_isDisabled()\"\n        (click)=\"_onTriggerClick()\"\n      >\n        <input\n          #field\n          type=\"text\"\n          class=\"l-date-input__field\"\n          [attr.id]=\"id()\"\n          [value]=\"_displayValue()\"\n          [placeholder]=\"placeholder()\"\n          [disabled]=\"_isDisabled()\"\n          [readonly]=\"!typableDateInput()\"\n          [class.is-readonly]=\"!typableDateInput()\"\n          autocomplete=\"off\"\n          role=\"combobox\"\n          aria-haspopup=\"dialog\"\n          [attr.aria-expanded]=\"_open()\"\n          (focus)=\"_onFocus()\"\n          (input)=\"_onTyped($event)\"\n          (keydown)=\"_onInputKeydown($event)\"\n        />\n\n        <div class=\"l-date-input__affixes\">\n          @if (_showClear()) {\n            <button\n              type=\"button\"\n              class=\"l-date-input__clear\"\n              tabindex=\"-1\"\n              aria-label=\"Clear date\"\n              (click)=\"_clear($event)\"\n            >\n              <svg width=\"12\" height=\"12\" viewBox=\"0 0 20 20\" fill=\"none\" aria-hidden=\"true\">\n                <path\n                  d=\"M15 5L5 15M5 5L15 15\"\n                  stroke=\"currentColor\"\n                  stroke-width=\"1.75\"\n                  stroke-linecap=\"round\"\n                  stroke-linejoin=\"round\"\n                />\n              </svg>\n            </button>\n          }\n\n          @if (showCalendarIcon()) {\n            <svg\n              class=\"l-date-input__icon\"\n              width=\"15\"\n              height=\"15\"\n              viewBox=\"0 0 20 20\"\n              fill=\"none\"\n              aria-hidden=\"true\"\n            >\n              <rect\n                x=\"2.75\"\n                y=\"4.25\"\n                width=\"14.5\"\n                height=\"13\"\n                rx=\"2\"\n                stroke=\"currentColor\"\n                stroke-width=\"1.5\"\n              />\n              <path\n                d=\"M2.75 8.25H17.25M6.5 2.5V5.5M13.5 2.5V5.5\"\n                stroke=\"currentColor\"\n                stroke-width=\"1.5\"\n                stroke-linecap=\"round\"\n              />\n            </svg>\n          }\n        </div>\n      </div>\n\n      @if (_open()) {\n        <div\n          class=\"l-date-input__panel\"\n          role=\"dialog\"\n          aria-label=\"Choose date\"\n          [class.is-up]=\"_dropUp()\"\n          [style.left.px]=\"_panelLeft()\"\n          [style.top.px]=\"_panelTop()\"\n          [style.bottom.px]=\"_panelBottom()\"\n        >\n          <div class=\"l-date-input__header\">\n            <button\n              type=\"button\"\n              class=\"l-date-input__nav\"\n              aria-label=\"Previous year\"\n              (click)=\"_superPrev()\"\n            >\n              «\n            </button>\n            <button\n              type=\"button\"\n              class=\"l-date-input__nav\"\n              aria-label=\"Previous month\"\n              (click)=\"_prev()\"\n            >\n              ‹\n            </button>\n\n            <div class=\"l-date-input__header-label\">\n              @if (_view() === 'year') {\n                <span class=\"l-date-input__header-range\">{{ _yearRangeLabel() }}</span>\n              } @else {\n                @if (_view() === 'date') {\n                  <button type=\"button\" class=\"l-date-input__header-btn\" (click)=\"_showMonthView()\">\n                    {{ _headerMonthLabel() }}\n                  </button>\n                }\n                <button type=\"button\" class=\"l-date-input__header-btn\" (click)=\"_showYearView()\">\n                  {{ _headerYearLabel() }}\n                </button>\n              }\n            </div>\n\n            <button\n              type=\"button\"\n              class=\"l-date-input__nav\"\n              aria-label=\"Next month\"\n              (click)=\"_next()\"\n            >\n              ›\n            </button>\n            <button\n              type=\"button\"\n              class=\"l-date-input__nav\"\n              aria-label=\"Next year\"\n              (click)=\"_superNext()\"\n            >\n              »\n            </button>\n          </div>\n\n          @switch (_view()) {\n            @case ('date') {\n              <div class=\"l-date-input__weekdays\" aria-hidden=\"true\">\n                @for (day of _weekdays(); track day) {\n                  <span class=\"l-date-input__weekday\">{{ day }}</span>\n                }\n              </div>\n\n              <div\n                #grid\n                class=\"l-date-input__grid\"\n                role=\"grid\"\n                tabindex=\"0\"\n                aria-label=\"Calendar days\"\n                (keydown)=\"_onGridKeydown($event)\"\n              >\n                @for (cell of _cells(); track cell.key) {\n                  <button\n                    type=\"button\"\n                    class=\"l-date-input__cell\"\n                    role=\"gridcell\"\n                    tabindex=\"-1\"\n                    [class.is-outside]=\"!cell.inMonth\"\n                    [class.is-today]=\"cell.today\"\n                    [class.is-selected]=\"cell.selected\"\n                    [class.is-active]=\"cell.active\"\n                    [disabled]=\"cell.disabled\"\n                    [attr.aria-selected]=\"cell.selected\"\n                    [attr.aria-label]=\"cell.aria || null\"\n                    (click)=\"_selectDay(cell)\"\n                  >\n                    {{ cell.label }}\n                  </button>\n                }\n              </div>\n            }\n            @case ('month') {\n              <div class=\"l-date-input__months\">\n                @for (month of _monthCells(); track month.index) {\n                  <button\n                    type=\"button\"\n                    class=\"l-date-input__unit\"\n                    [class.is-selected]=\"month.selected\"\n                    (click)=\"_selectMonth(month.index)\"\n                  >\n                    {{ month.label }}\n                  </button>\n                }\n              </div>\n            }\n            @case ('year') {\n              <div class=\"l-date-input__years\">\n                @for (year of _yearCells(); track year.year) {\n                  <button\n                    type=\"button\"\n                    class=\"l-date-input__unit\"\n                    [class.is-selected]=\"year.selected\"\n                    [disabled]=\"year.disabled\"\n                    (click)=\"_selectYear(year)\"\n                  >\n                    {{ year.label }}\n                  </button>\n                }\n              </div>\n            }\n          }\n\n          <div class=\"l-date-input__footer\">\n            <div class=\"l-date-input__mode\" role=\"group\" aria-label=\"Calendar system\">\n              <button\n                type=\"button\"\n                class=\"l-date-input__mode-btn\"\n                [class.is-active]=\"_mode() === 'ad'\"\n                [attr.aria-pressed]=\"_mode() === 'ad'\"\n                (click)=\"_setMode('ad')\"\n              >\n                AD\n              </button>\n              <button\n                type=\"button\"\n                class=\"l-date-input__mode-btn\"\n                [class.is-active]=\"_mode() === 'bs'\"\n                [attr.aria-pressed]=\"_mode() === 'bs'\"\n                (click)=\"_setMode('bs')\"\n              >\n                BS\n              </button>\n            </div>\n\n            @if (showToday()) {\n              <button type=\"button\" class=\"l-date-input__today\" (click)=\"_selectToday()\">\n                Today\n              </button>\n            }\n          </div>\n        </div>\n      }\n    </div>\n  </div>\n}\n",
		styles: [":host{display:block;width:100%}.l-date-input{position:relative;width:100%}.l-date-input__trigger{width:100%;align-items:center;gap:8px;cursor:text;transition:border-color .15s ease-out,box-shadow .15s ease-out}.l-date-input__trigger:focus-within{border-color:var(--accent);box-shadow:0 0 0 3px var(--accent-bg)}.l-date-input__trigger[aria-disabled=true]{opacity:.5;cursor:not-allowed;background:var(--bg-light)}.is-open .l-date-input__trigger{border-color:var(--accent);box-shadow:0 0 0 3px var(--accent-bg)}.l-date-input__field{flex:1;min-width:0;padding:0;border:none;outline:none;background:transparent;font:inherit;color:inherit}.l-date-input__field::placeholder{color:var(--text-quaternary)}.l-date-input__field.is-readonly:not(:disabled){cursor:pointer}.l-date-input__affixes{display:flex;align-items:center;gap:2px;flex-shrink:0}.l-date-input__trigger:not([aria-disabled=true]) .l-date-input__icon{cursor:pointer}.l-date-input__icon{color:var(--text-tertiary)}.l-date-input__clear{display:inline-flex;align-items:center;justify-content:center;padding:2px;border:none;background:transparent;border-radius:4px;color:var(--text-tertiary);cursor:pointer;transition:color .12s ease-out,background .12s ease-out}.l-date-input__clear:hover{color:var(--text-primary);background:var(--separator)}.l-date-input__clear:focus-visible{outline:2px solid var(--accent);outline-offset:1px}.l-date-input__panel{position:fixed;z-index:1000;width:288px;padding:8px;background:var(--bg-lightest);border:1px solid var(--separator);border-radius:8px;box-shadow:0 6px 16px #0d0d121f;animation:l-date-input-in .12s ease-out}.l-date-input__panel.is-up{animation-name:l-date-input-in-up}@keyframes l-date-input-in{0%{opacity:0;transform:translateY(-4px)}}@keyframes l-date-input-in-up{0%{opacity:0;transform:translateY(4px)}}.l-date-input__header{display:flex;align-items:center;gap:2px;padding-bottom:8px;margin-bottom:8px;border-bottom:1px solid var(--separator-light)}.l-date-input__nav{display:inline-flex;align-items:center;justify-content:center;width:28px;height:28px;border:none;background:transparent;border-radius:6px;font-size:14px;color:var(--text-quaternary);cursor:pointer;transition:color .12s ease-out,background .12s ease-out}.l-date-input__nav:hover{color:var(--text-primary);background:var(--bg-light)}.l-date-input__nav:focus-visible{outline:2px solid var(--accent);outline-offset:1px}.l-date-input__header-label{display:flex;flex:1;align-items:center;justify-content:center;gap:4px;min-width:0}.l-date-input__header-btn{padding:2px 4px;border:none;background:transparent;border-radius:4px;font-size:14px;font-weight:600;color:var(--text-primary);cursor:pointer;transition:color .12s ease-out}.l-date-input__header-btn:hover{color:var(--accent)}.l-date-input__header-btn:focus-visible{outline:2px solid var(--accent);outline-offset:1px}.l-date-input__header-range{font-size:14px;font-weight:600;color:var(--text-primary)}.l-date-input__weekdays,.l-date-input__grid{display:grid;grid-template-columns:repeat(7,1fr);gap:2px}.l-date-input__weekday{display:flex;align-items:center;justify-content:center;height:28px;font-size:12px;font-weight:500;color:var(--text-tertiary);white-space:nowrap}.l-date-input__grid:focus-visible{outline:2px solid var(--accent);outline-offset:2px}.l-date-input__cell{display:flex;align-items:center;justify-content:center;height:30px;border:none;background:transparent;border-radius:6px;font-size:13px;color:var(--text-primary);cursor:pointer;transition:background .12s ease-out}.l-date-input__cell:hover:not(:disabled){background:var(--bg-light)}.l-date-input__cell.is-outside{color:var(--text-quaternary)}.l-date-input__cell.is-active:not(.is-selected){background:var(--accent-bg)}.l-date-input__cell.is-today{box-shadow:inset 0 0 0 1px var(--accent);color:var(--accent-dark);font-weight:600}.l-date-input__cell.is-selected{background:var(--accent);color:var(--accent-contrast);font-weight:600}.l-date-input__cell.is-selected:hover{background:var(--accent-dark)}.l-date-input__cell:disabled{color:var(--text-quaternary);background:transparent;cursor:not-allowed}.l-date-input__months,.l-date-input__years{display:grid;grid-template-columns:repeat(3,1fr);gap:4px;min-height:224px;align-content:center}.l-date-input__unit{display:flex;align-items:center;justify-content:center;height:40px;border:none;background:transparent;border-radius:6px;font-size:13px;color:var(--text-primary);cursor:pointer;overflow:hidden;transition:background .12s ease-out}.l-date-input__unit:hover:not(:disabled){background:var(--bg-light)}.l-date-input__unit.is-selected{background:var(--accent);color:var(--accent-contrast);font-weight:600}.l-date-input__unit:disabled{color:var(--text-quaternary);cursor:not-allowed}.l-date-input__footer{display:flex;align-items:center;justify-content:space-between;padding-top:8px;margin-top:8px;border-top:1px solid var(--separator-light)}.l-date-input__mode{display:inline-flex;padding:2px;gap:2px;background:var(--bg-light);border-radius:6px}.l-date-input__mode-btn{padding:2px 10px;border:none;background:transparent;border-radius:4px;font-size:12px;font-weight:600;color:var(--text-tertiary);cursor:pointer;transition:color .12s ease-out,background .12s ease-out}.l-date-input__mode-btn:hover{color:var(--text-primary)}.l-date-input__mode-btn.is-active{background:var(--bg-lightest);color:var(--accent-dark);box-shadow:0 1px 2px #0d0d121a}.l-date-input__mode-btn:focus-visible{outline:2px solid var(--accent);outline-offset:1px}.l-date-input__today{padding:2px 4px;border:none;background:transparent;border-radius:4px;font-size:13px;font-weight:500;color:var(--accent);cursor:pointer;transition:color .12s ease-out}.l-date-input__today:hover{color:var(--accent-dark)}.l-date-input__today:focus-visible{outline:2px solid var(--accent);outline-offset:1px}@media(prefers-reduced-motion:reduce){.l-date-input__trigger,.l-date-input__panel,.l-date-input__cell,.l-date-input__unit,.l-date-input__nav{transition:none;animation:none}}\n"],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: DateInput,
	decorators: [{
		type: Component,
		args: [{
			selector: "l-date-input",
			changeDetection: ChangeDetectionStrategy.OnPush,
			imports: [],
			providers: [provideInputValueAccessor(() => DateInput)],
			hostDirectives: [{
				directive: FormValidation,
				inputs: ["useValidation"]
			}],
			host: { "(document:pointerdown)": "_onDocumentPointerDown($event)" },
			template: "@if (viewMode()) {\n  <div class=\"form-group view-mode\">\n    @if (label()) {\n      <label>{{ label() }}</label>\n    }\n    <div class=\"view-value\">{{ viewValue() ?? (_displayValue() || '-') }}</div>\n  </div>\n} @else {\n  <div class=\"form-group\">\n    @if (label()) {\n      <label [attr.for]=\"id()\">{{ label() }}</label>\n    }\n\n    <div class=\"l-date-input\" [class.is-open]=\"_open()\" (focusout)=\"_onBlur($event)\">\n      <div\n        #trigger\n        class=\"form-control l-date-input__trigger\"\n        [attr.aria-disabled]=\"_isDisabled()\"\n        (click)=\"_onTriggerClick()\"\n      >\n        <input\n          #field\n          type=\"text\"\n          class=\"l-date-input__field\"\n          [attr.id]=\"id()\"\n          [value]=\"_displayValue()\"\n          [placeholder]=\"placeholder()\"\n          [disabled]=\"_isDisabled()\"\n          [readonly]=\"!typableDateInput()\"\n          [class.is-readonly]=\"!typableDateInput()\"\n          autocomplete=\"off\"\n          role=\"combobox\"\n          aria-haspopup=\"dialog\"\n          [attr.aria-expanded]=\"_open()\"\n          (focus)=\"_onFocus()\"\n          (input)=\"_onTyped($event)\"\n          (keydown)=\"_onInputKeydown($event)\"\n        />\n\n        <div class=\"l-date-input__affixes\">\n          @if (_showClear()) {\n            <button\n              type=\"button\"\n              class=\"l-date-input__clear\"\n              tabindex=\"-1\"\n              aria-label=\"Clear date\"\n              (click)=\"_clear($event)\"\n            >\n              <svg width=\"12\" height=\"12\" viewBox=\"0 0 20 20\" fill=\"none\" aria-hidden=\"true\">\n                <path\n                  d=\"M15 5L5 15M5 5L15 15\"\n                  stroke=\"currentColor\"\n                  stroke-width=\"1.75\"\n                  stroke-linecap=\"round\"\n                  stroke-linejoin=\"round\"\n                />\n              </svg>\n            </button>\n          }\n\n          @if (showCalendarIcon()) {\n            <svg\n              class=\"l-date-input__icon\"\n              width=\"15\"\n              height=\"15\"\n              viewBox=\"0 0 20 20\"\n              fill=\"none\"\n              aria-hidden=\"true\"\n            >\n              <rect\n                x=\"2.75\"\n                y=\"4.25\"\n                width=\"14.5\"\n                height=\"13\"\n                rx=\"2\"\n                stroke=\"currentColor\"\n                stroke-width=\"1.5\"\n              />\n              <path\n                d=\"M2.75 8.25H17.25M6.5 2.5V5.5M13.5 2.5V5.5\"\n                stroke=\"currentColor\"\n                stroke-width=\"1.5\"\n                stroke-linecap=\"round\"\n              />\n            </svg>\n          }\n        </div>\n      </div>\n\n      @if (_open()) {\n        <div\n          class=\"l-date-input__panel\"\n          role=\"dialog\"\n          aria-label=\"Choose date\"\n          [class.is-up]=\"_dropUp()\"\n          [style.left.px]=\"_panelLeft()\"\n          [style.top.px]=\"_panelTop()\"\n          [style.bottom.px]=\"_panelBottom()\"\n        >\n          <div class=\"l-date-input__header\">\n            <button\n              type=\"button\"\n              class=\"l-date-input__nav\"\n              aria-label=\"Previous year\"\n              (click)=\"_superPrev()\"\n            >\n              «\n            </button>\n            <button\n              type=\"button\"\n              class=\"l-date-input__nav\"\n              aria-label=\"Previous month\"\n              (click)=\"_prev()\"\n            >\n              ‹\n            </button>\n\n            <div class=\"l-date-input__header-label\">\n              @if (_view() === 'year') {\n                <span class=\"l-date-input__header-range\">{{ _yearRangeLabel() }}</span>\n              } @else {\n                @if (_view() === 'date') {\n                  <button type=\"button\" class=\"l-date-input__header-btn\" (click)=\"_showMonthView()\">\n                    {{ _headerMonthLabel() }}\n                  </button>\n                }\n                <button type=\"button\" class=\"l-date-input__header-btn\" (click)=\"_showYearView()\">\n                  {{ _headerYearLabel() }}\n                </button>\n              }\n            </div>\n\n            <button\n              type=\"button\"\n              class=\"l-date-input__nav\"\n              aria-label=\"Next month\"\n              (click)=\"_next()\"\n            >\n              ›\n            </button>\n            <button\n              type=\"button\"\n              class=\"l-date-input__nav\"\n              aria-label=\"Next year\"\n              (click)=\"_superNext()\"\n            >\n              »\n            </button>\n          </div>\n\n          @switch (_view()) {\n            @case ('date') {\n              <div class=\"l-date-input__weekdays\" aria-hidden=\"true\">\n                @for (day of _weekdays(); track day) {\n                  <span class=\"l-date-input__weekday\">{{ day }}</span>\n                }\n              </div>\n\n              <div\n                #grid\n                class=\"l-date-input__grid\"\n                role=\"grid\"\n                tabindex=\"0\"\n                aria-label=\"Calendar days\"\n                (keydown)=\"_onGridKeydown($event)\"\n              >\n                @for (cell of _cells(); track cell.key) {\n                  <button\n                    type=\"button\"\n                    class=\"l-date-input__cell\"\n                    role=\"gridcell\"\n                    tabindex=\"-1\"\n                    [class.is-outside]=\"!cell.inMonth\"\n                    [class.is-today]=\"cell.today\"\n                    [class.is-selected]=\"cell.selected\"\n                    [class.is-active]=\"cell.active\"\n                    [disabled]=\"cell.disabled\"\n                    [attr.aria-selected]=\"cell.selected\"\n                    [attr.aria-label]=\"cell.aria || null\"\n                    (click)=\"_selectDay(cell)\"\n                  >\n                    {{ cell.label }}\n                  </button>\n                }\n              </div>\n            }\n            @case ('month') {\n              <div class=\"l-date-input__months\">\n                @for (month of _monthCells(); track month.index) {\n                  <button\n                    type=\"button\"\n                    class=\"l-date-input__unit\"\n                    [class.is-selected]=\"month.selected\"\n                    (click)=\"_selectMonth(month.index)\"\n                  >\n                    {{ month.label }}\n                  </button>\n                }\n              </div>\n            }\n            @case ('year') {\n              <div class=\"l-date-input__years\">\n                @for (year of _yearCells(); track year.year) {\n                  <button\n                    type=\"button\"\n                    class=\"l-date-input__unit\"\n                    [class.is-selected]=\"year.selected\"\n                    [disabled]=\"year.disabled\"\n                    (click)=\"_selectYear(year)\"\n                  >\n                    {{ year.label }}\n                  </button>\n                }\n              </div>\n            }\n          }\n\n          <div class=\"l-date-input__footer\">\n            <div class=\"l-date-input__mode\" role=\"group\" aria-label=\"Calendar system\">\n              <button\n                type=\"button\"\n                class=\"l-date-input__mode-btn\"\n                [class.is-active]=\"_mode() === 'ad'\"\n                [attr.aria-pressed]=\"_mode() === 'ad'\"\n                (click)=\"_setMode('ad')\"\n              >\n                AD\n              </button>\n              <button\n                type=\"button\"\n                class=\"l-date-input__mode-btn\"\n                [class.is-active]=\"_mode() === 'bs'\"\n                [attr.aria-pressed]=\"_mode() === 'bs'\"\n                (click)=\"_setMode('bs')\"\n              >\n                BS\n              </button>\n            </div>\n\n            @if (showToday()) {\n              <button type=\"button\" class=\"l-date-input__today\" (click)=\"_selectToday()\">\n                Today\n              </button>\n            }\n          </div>\n        </div>\n      }\n    </div>\n  </div>\n}\n",
			styles: [":host{display:block;width:100%}.l-date-input{position:relative;width:100%}.l-date-input__trigger{width:100%;align-items:center;gap:8px;cursor:text;transition:border-color .15s ease-out,box-shadow .15s ease-out}.l-date-input__trigger:focus-within{border-color:var(--accent);box-shadow:0 0 0 3px var(--accent-bg)}.l-date-input__trigger[aria-disabled=true]{opacity:.5;cursor:not-allowed;background:var(--bg-light)}.is-open .l-date-input__trigger{border-color:var(--accent);box-shadow:0 0 0 3px var(--accent-bg)}.l-date-input__field{flex:1;min-width:0;padding:0;border:none;outline:none;background:transparent;font:inherit;color:inherit}.l-date-input__field::placeholder{color:var(--text-quaternary)}.l-date-input__field.is-readonly:not(:disabled){cursor:pointer}.l-date-input__affixes{display:flex;align-items:center;gap:2px;flex-shrink:0}.l-date-input__trigger:not([aria-disabled=true]) .l-date-input__icon{cursor:pointer}.l-date-input__icon{color:var(--text-tertiary)}.l-date-input__clear{display:inline-flex;align-items:center;justify-content:center;padding:2px;border:none;background:transparent;border-radius:4px;color:var(--text-tertiary);cursor:pointer;transition:color .12s ease-out,background .12s ease-out}.l-date-input__clear:hover{color:var(--text-primary);background:var(--separator)}.l-date-input__clear:focus-visible{outline:2px solid var(--accent);outline-offset:1px}.l-date-input__panel{position:fixed;z-index:1000;width:288px;padding:8px;background:var(--bg-lightest);border:1px solid var(--separator);border-radius:8px;box-shadow:0 6px 16px #0d0d121f;animation:l-date-input-in .12s ease-out}.l-date-input__panel.is-up{animation-name:l-date-input-in-up}@keyframes l-date-input-in{0%{opacity:0;transform:translateY(-4px)}}@keyframes l-date-input-in-up{0%{opacity:0;transform:translateY(4px)}}.l-date-input__header{display:flex;align-items:center;gap:2px;padding-bottom:8px;margin-bottom:8px;border-bottom:1px solid var(--separator-light)}.l-date-input__nav{display:inline-flex;align-items:center;justify-content:center;width:28px;height:28px;border:none;background:transparent;border-radius:6px;font-size:14px;color:var(--text-quaternary);cursor:pointer;transition:color .12s ease-out,background .12s ease-out}.l-date-input__nav:hover{color:var(--text-primary);background:var(--bg-light)}.l-date-input__nav:focus-visible{outline:2px solid var(--accent);outline-offset:1px}.l-date-input__header-label{display:flex;flex:1;align-items:center;justify-content:center;gap:4px;min-width:0}.l-date-input__header-btn{padding:2px 4px;border:none;background:transparent;border-radius:4px;font-size:14px;font-weight:600;color:var(--text-primary);cursor:pointer;transition:color .12s ease-out}.l-date-input__header-btn:hover{color:var(--accent)}.l-date-input__header-btn:focus-visible{outline:2px solid var(--accent);outline-offset:1px}.l-date-input__header-range{font-size:14px;font-weight:600;color:var(--text-primary)}.l-date-input__weekdays,.l-date-input__grid{display:grid;grid-template-columns:repeat(7,1fr);gap:2px}.l-date-input__weekday{display:flex;align-items:center;justify-content:center;height:28px;font-size:12px;font-weight:500;color:var(--text-tertiary);white-space:nowrap}.l-date-input__grid:focus-visible{outline:2px solid var(--accent);outline-offset:2px}.l-date-input__cell{display:flex;align-items:center;justify-content:center;height:30px;border:none;background:transparent;border-radius:6px;font-size:13px;color:var(--text-primary);cursor:pointer;transition:background .12s ease-out}.l-date-input__cell:hover:not(:disabled){background:var(--bg-light)}.l-date-input__cell.is-outside{color:var(--text-quaternary)}.l-date-input__cell.is-active:not(.is-selected){background:var(--accent-bg)}.l-date-input__cell.is-today{box-shadow:inset 0 0 0 1px var(--accent);color:var(--accent-dark);font-weight:600}.l-date-input__cell.is-selected{background:var(--accent);color:var(--accent-contrast);font-weight:600}.l-date-input__cell.is-selected:hover{background:var(--accent-dark)}.l-date-input__cell:disabled{color:var(--text-quaternary);background:transparent;cursor:not-allowed}.l-date-input__months,.l-date-input__years{display:grid;grid-template-columns:repeat(3,1fr);gap:4px;min-height:224px;align-content:center}.l-date-input__unit{display:flex;align-items:center;justify-content:center;height:40px;border:none;background:transparent;border-radius:6px;font-size:13px;color:var(--text-primary);cursor:pointer;overflow:hidden;transition:background .12s ease-out}.l-date-input__unit:hover:not(:disabled){background:var(--bg-light)}.l-date-input__unit.is-selected{background:var(--accent);color:var(--accent-contrast);font-weight:600}.l-date-input__unit:disabled{color:var(--text-quaternary);cursor:not-allowed}.l-date-input__footer{display:flex;align-items:center;justify-content:space-between;padding-top:8px;margin-top:8px;border-top:1px solid var(--separator-light)}.l-date-input__mode{display:inline-flex;padding:2px;gap:2px;background:var(--bg-light);border-radius:6px}.l-date-input__mode-btn{padding:2px 10px;border:none;background:transparent;border-radius:4px;font-size:12px;font-weight:600;color:var(--text-tertiary);cursor:pointer;transition:color .12s ease-out,background .12s ease-out}.l-date-input__mode-btn:hover{color:var(--text-primary)}.l-date-input__mode-btn.is-active{background:var(--bg-lightest);color:var(--accent-dark);box-shadow:0 1px 2px #0d0d121a}.l-date-input__mode-btn:focus-visible{outline:2px solid var(--accent);outline-offset:1px}.l-date-input__today{padding:2px 4px;border:none;background:transparent;border-radius:4px;font-size:13px;font-weight:500;color:var(--accent);cursor:pointer;transition:color .12s ease-out}.l-date-input__today:hover{color:var(--accent-dark)}.l-date-input__today:focus-visible{outline:2px solid var(--accent);outline-offset:1px}@media(prefers-reduced-motion:reduce){.l-date-input__trigger,.l-date-input__panel,.l-date-input__cell,.l-date-input__unit,.l-date-input__nav{transition:none;animation:none}}\n"]
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		label: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "label",
				required: false
			}]
		}],
		placeholder: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "placeholder",
				required: false
			}]
		}],
		disabled: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "disabled",
				required: false
			}]
		}],
		id: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "id",
				required: false
			}]
		}],
		calendar: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "calendar",
				required: false
			}]
		}],
		lang: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "lang",
				required: false
			}]
		}],
		format: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "format",
				required: false
			}]
		}],
		showToday: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "showToday",
				required: false
			}]
		}],
		openCalendarOnFocus: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "openCalendarOnFocus",
				required: false
			}]
		}],
		showCalendarIcon: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "showCalendarIcon",
				required: false
			}]
		}],
		typableDateInput: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "typableDateInput",
				required: false
			}]
		}],
		clearable: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "clearable",
				required: false
			}]
		}],
		min: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "min",
				required: false
			}]
		}],
		max: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "max",
				required: false
			}]
		}],
		viewMode: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "viewMode",
				required: false
			}]
		}],
		viewValue: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "viewValue",
				required: false
			}]
		}],
		change: [{
			type: i0.Output,
			args: ["change"]
		}],
		calendarChange: [{
			type: i0.Output,
			args: ["calendarChange"]
		}],
		_trigger: [{
			type: i0.ViewChild,
			args: ["trigger", { isSignal: true }]
		}],
		_field: [{
			type: i0.ViewChild,
			args: ["field", { isSignal: true }]
		}],
		_grid: [{
			type: i0.ViewChild,
			args: ["grid", { isSignal: true }]
		}]
	}
});
var Textarea = class Textarea extends BaseInput {
	type = "text";
	rows = input(4, ...ngDevMode ? [{ debugName: "rows" }] : /* istanbul ignore next */ []);
	resizable = input(false, ...ngDevMode ? [{ debugName: "resizable" }] : /* istanbul ignore next */ []);
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.1",
		ngImport: i0,
		type: Textarea,
		deps: null,
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.1",
		type: Textarea,
		isStandalone: true,
		selector: "l-textarea",
		inputs: {
			rows: {
				classPropertyName: "rows",
				publicName: "rows",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			resizable: {
				classPropertyName: "resizable",
				publicName: "resizable",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		providers: [provideInputValueAccessor(() => Textarea)],
		usesInheritance: true,
		hostDirectives: [{
			directive: FormValidation,
			inputs: ["useValidation", "useValidation"]
		}],
		ngImport: i0,
		template: "@if (viewMode()) {\n  <div class=\"form-group view-mode\">\n    @if (label()) {\n      <label>{{ label() }}</label>\n    }\n    <div class=\"view-value pre-wrap\">{{ viewValue() ?? (_value() || '-') }}</div>\n  </div>\n} @else {\n  <div class=\"form-group\">\n    @if (label()) {\n      <label [attr.for]=\"id()\">{{ label() }}</label>\n    }\n\n    <textarea\n      class=\"form-control\"\n      [class.resizable]=\"resizable()\"\n      [id]=\"id()\"\n      [rows]=\"rows()\"\n      [value]=\"_value()\"\n      [placeholder]=\"placeholder()\"\n      [disabled]=\"_isDisabled()\"\n      (input)=\"_handleInput($event)\"\n      (change)=\"change.emit($event)\"\n      (keyup)=\"keyup.emit($event)\"\n      (keydown)=\"keydown.emit($event)\"\n      (keypress)=\"keypress.emit($event)\"\n      (keydown.enter)=\"_handleEnter($event)\"\n      (blur)=\"_handleBlur()\"\n    ></textarea>\n  </div>\n}\n",
		styles: ["textarea{font-family:inherit;font-size:inherit;font-weight:400}textarea.form-control{width:100%;resize:none;min-height:72px}textarea.form-control.resizable{resize:vertical}\n"],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: Textarea,
	decorators: [{
		type: Component,
		args: [{
			selector: "l-textarea",
			changeDetection: ChangeDetectionStrategy.OnPush,
			imports: [],
			providers: [provideInputValueAccessor(() => Textarea)],
			hostDirectives: [{
				directive: FormValidation,
				inputs: ["useValidation"]
			}],
			template: "@if (viewMode()) {\n  <div class=\"form-group view-mode\">\n    @if (label()) {\n      <label>{{ label() }}</label>\n    }\n    <div class=\"view-value pre-wrap\">{{ viewValue() ?? (_value() || '-') }}</div>\n  </div>\n} @else {\n  <div class=\"form-group\">\n    @if (label()) {\n      <label [attr.for]=\"id()\">{{ label() }}</label>\n    }\n\n    <textarea\n      class=\"form-control\"\n      [class.resizable]=\"resizable()\"\n      [id]=\"id()\"\n      [rows]=\"rows()\"\n      [value]=\"_value()\"\n      [placeholder]=\"placeholder()\"\n      [disabled]=\"_isDisabled()\"\n      (input)=\"_handleInput($event)\"\n      (change)=\"change.emit($event)\"\n      (keyup)=\"keyup.emit($event)\"\n      (keydown)=\"keydown.emit($event)\"\n      (keypress)=\"keypress.emit($event)\"\n      (keydown.enter)=\"_handleEnter($event)\"\n      (blur)=\"_handleBlur()\"\n    ></textarea>\n  </div>\n}\n",
			styles: ["textarea{font-family:inherit;font-size:inherit;font-weight:400}textarea.form-control{width:100%;resize:none;min-height:72px}textarea.form-control.resizable{resize:vertical}\n"]
		}]
	}],
	propDecorators: {
		rows: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "rows",
				required: false
			}]
		}],
		resizable: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "resizable",
				required: false
			}]
		}]
	}
});
var Toggle = class Toggle extends BaseBooleanInput {
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.1",
		ngImport: i0,
		type: Toggle,
		deps: null,
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.1",
		type: Toggle,
		isStandalone: true,
		selector: "l-toggle",
		providers: [provideInputValueAccessor(() => Toggle)],
		usesInheritance: true,
		hostDirectives: [{
			directive: FormValidation,
			inputs: ["useValidation", "useValidation"]
		}],
		ngImport: i0,
		template: "@if (viewMode()) {\n  <div class=\"form-group view-mode\">\n    @if (label()) {\n      <label>{{ label() }}</label>\n    }\n    <div class=\"view-value\">{{ viewValue() ?? (_checked() ? 'Yes' : 'No') }}</div>\n  </div>\n} @else {\n  <div class=\"form-group\">\n    <label\n      class=\"control-row\"\n      [class.label-left]=\"labelPosition() === 'left'\"\n      [class.label-top]=\"labelPosition() === 'top'\"\n    >\n      <span class=\"switch\">\n        <input\n          type=\"checkbox\"\n          [id]=\"id()\"\n          [checked]=\"_checked()\"\n          [disabled]=\"_isDisabled()\"\n          (change)=\"_handleChange($event)\"\n          (blur)=\"_handleBlur()\"\n        />\n        <span class=\"slider round\"></span>\n      </span>\n\n      @if (label()) {\n        <span class=\"control-label\">{{ label() }}</span>\n      }\n    </label>\n  </div>\n}\n",
		styles: [".switch{position:relative;display:inline-block;width:36px;height:20px}.switch input{opacity:0;width:0;height:0}.slider{position:absolute;cursor:pointer;inset:0;background:#ccc;transition:.4s}.slider:before{position:absolute;content:\"\";height:16px;width:16px;left:2px;bottom:2px;background:#fff;transition:.4s}input:checked+.slider{background:var(--success)}input:checked+.slider:before{transform:translate(16px)}.switch input:focus-visible+.slider{outline:none;box-shadow:0 0 0 3px var(--accent-bg)}.slider.round{border-radius:20px}.slider.round:before{border-radius:50%}@media(prefers-reduced-motion:reduce){.slider,.slider:before{transition:none}}\n"],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: Toggle,
	decorators: [{
		type: Component,
		args: [{
			selector: "l-toggle",
			changeDetection: ChangeDetectionStrategy.OnPush,
			imports: [],
			providers: [provideInputValueAccessor(() => Toggle)],
			hostDirectives: [{
				directive: FormValidation,
				inputs: ["useValidation"]
			}],
			template: "@if (viewMode()) {\n  <div class=\"form-group view-mode\">\n    @if (label()) {\n      <label>{{ label() }}</label>\n    }\n    <div class=\"view-value\">{{ viewValue() ?? (_checked() ? 'Yes' : 'No') }}</div>\n  </div>\n} @else {\n  <div class=\"form-group\">\n    <label\n      class=\"control-row\"\n      [class.label-left]=\"labelPosition() === 'left'\"\n      [class.label-top]=\"labelPosition() === 'top'\"\n    >\n      <span class=\"switch\">\n        <input\n          type=\"checkbox\"\n          [id]=\"id()\"\n          [checked]=\"_checked()\"\n          [disabled]=\"_isDisabled()\"\n          (change)=\"_handleChange($event)\"\n          (blur)=\"_handleBlur()\"\n        />\n        <span class=\"slider round\"></span>\n      </span>\n\n      @if (label()) {\n        <span class=\"control-label\">{{ label() }}</span>\n      }\n    </label>\n  </div>\n}\n",
			styles: [".switch{position:relative;display:inline-block;width:36px;height:20px}.switch input{opacity:0;width:0;height:0}.slider{position:absolute;cursor:pointer;inset:0;background:#ccc;transition:.4s}.slider:before{position:absolute;content:\"\";height:16px;width:16px;left:2px;bottom:2px;background:#fff;transition:.4s}input:checked+.slider{background:var(--success)}input:checked+.slider:before{transform:translate(16px)}.switch input:focus-visible+.slider{outline:none;box-shadow:0 0 0 3px var(--accent-bg)}.slider.round{border-radius:20px}.slider.round:before{border-radius:50%}@media(prefers-reduced-motion:reduce){.slider,.slider:before{transition:none}}\n"]
		}]
	}]
});
var Checkbox = class Checkbox extends BaseBooleanInput {
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.1",
		ngImport: i0,
		type: Checkbox,
		deps: null,
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.1",
		type: Checkbox,
		isStandalone: true,
		selector: "l-checkbox",
		providers: [provideInputValueAccessor(() => Checkbox)],
		usesInheritance: true,
		hostDirectives: [{
			directive: FormValidation,
			inputs: ["useValidation", "useValidation"]
		}],
		ngImport: i0,
		template: "@if (viewMode()) {\n  <div class=\"form-group view-mode\">\n    @if (label()) {\n      <label>{{ label() }}</label>\n    }\n    <div class=\"view-value\">{{ viewValue() ?? (_checked() ? 'Yes' : 'No') }}</div>\n  </div>\n} @else {\n  <div class=\"form-group\">\n    <label\n      class=\"control-row checkbox-control\"\n      [class.label-left]=\"labelPosition() === 'left'\"\n      [class.label-top]=\"labelPosition() === 'top'\"\n    >\n      <input\n        type=\"checkbox\"\n        class=\"check-input\"\n        [id]=\"id()\"\n        [checked]=\"_checked()\"\n        [disabled]=\"_isDisabled()\"\n        (change)=\"_handleChange($event)\"\n        (blur)=\"_handleBlur()\"\n      />\n      <span class=\"check-box\" aria-hidden=\"true\">\n        <svg viewBox=\"0 0 16 16\" fill=\"none\" xmlns=\"http://www.w3.org/2000/svg\">\n          <path\n            d=\"M3.5 8.5L6.5 11.5L12.5 5\"\n            stroke=\"currentColor\"\n            stroke-width=\"2\"\n            stroke-linecap=\"round\"\n            stroke-linejoin=\"round\"\n          />\n        </svg>\n      </span>\n\n      @if (label()) {\n        <span class=\"control-label\">{{ label() }}</span>\n      }\n    </label>\n  </div>\n}\n",
		styles: [".check-input{position:absolute;width:1px;height:1px;opacity:0;pointer-events:none}.control-row .check-box{display:inline-flex;align-items:center;justify-content:center;width:18px;height:18px;flex-shrink:0;border:1px solid var(--separator-dark);border-radius:6px;background:var(--bg-lightest);color:transparent;transition:background .15s ease-out,border-color .15s ease-out,color .15s ease-out}.control-row .check-box svg{width:12px;height:12px}.check-input:checked+.check-box{background:var(--accent);border-color:var(--accent);color:var(--accent-contrast)}.check-input:focus-visible+.check-box{outline:none;border-color:var(--accent);box-shadow:0 0 0 3px var(--accent-bg)}@media(prefers-reduced-motion:reduce){.check-box{transition:none}}\n"],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: Checkbox,
	decorators: [{
		type: Component,
		args: [{
			selector: "l-checkbox",
			changeDetection: ChangeDetectionStrategy.OnPush,
			imports: [],
			providers: [provideInputValueAccessor(() => Checkbox)],
			hostDirectives: [{
				directive: FormValidation,
				inputs: ["useValidation"]
			}],
			template: "@if (viewMode()) {\n  <div class=\"form-group view-mode\">\n    @if (label()) {\n      <label>{{ label() }}</label>\n    }\n    <div class=\"view-value\">{{ viewValue() ?? (_checked() ? 'Yes' : 'No') }}</div>\n  </div>\n} @else {\n  <div class=\"form-group\">\n    <label\n      class=\"control-row checkbox-control\"\n      [class.label-left]=\"labelPosition() === 'left'\"\n      [class.label-top]=\"labelPosition() === 'top'\"\n    >\n      <input\n        type=\"checkbox\"\n        class=\"check-input\"\n        [id]=\"id()\"\n        [checked]=\"_checked()\"\n        [disabled]=\"_isDisabled()\"\n        (change)=\"_handleChange($event)\"\n        (blur)=\"_handleBlur()\"\n      />\n      <span class=\"check-box\" aria-hidden=\"true\">\n        <svg viewBox=\"0 0 16 16\" fill=\"none\" xmlns=\"http://www.w3.org/2000/svg\">\n          <path\n            d=\"M3.5 8.5L6.5 11.5L12.5 5\"\n            stroke=\"currentColor\"\n            stroke-width=\"2\"\n            stroke-linecap=\"round\"\n            stroke-linejoin=\"round\"\n          />\n        </svg>\n      </span>\n\n      @if (label()) {\n        <span class=\"control-label\">{{ label() }}</span>\n      }\n    </label>\n  </div>\n}\n",
			styles: [".check-input{position:absolute;width:1px;height:1px;opacity:0;pointer-events:none}.control-row .check-box{display:inline-flex;align-items:center;justify-content:center;width:18px;height:18px;flex-shrink:0;border:1px solid var(--separator-dark);border-radius:6px;background:var(--bg-lightest);color:transparent;transition:background .15s ease-out,border-color .15s ease-out,color .15s ease-out}.control-row .check-box svg{width:12px;height:12px}.check-input:checked+.check-box{background:var(--accent);border-color:var(--accent);color:var(--accent-contrast)}.check-input:focus-visible+.check-box{outline:none;border-color:var(--accent);box-shadow:0 0 0 3px var(--accent-bg)}@media(prefers-reduced-motion:reduce){.check-box{transition:none}}\n"]
		}]
	}]
});
var Radio = class Radio extends BaseRadioInput {
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.1",
		ngImport: i0,
		type: Radio,
		deps: null,
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.1",
		type: Radio,
		isStandalone: true,
		selector: "l-radio",
		providers: [provideInputValueAccessor(() => Radio)],
		usesInheritance: true,
		hostDirectives: [{
			directive: FormValidation,
			inputs: ["useValidation", "useValidation"]
		}],
		ngImport: i0,
		template: "@if (viewMode()) {\n  <div class=\"form-group view-mode\">\n    @if (label()) {\n      <label>{{ label() }}</label>\n    }\n    <div class=\"view-value\">{{ viewValue() ?? _selectedLabel() ?? '-' }}</div>\n  </div>\n} @else {\n  <div class=\"form-group\">\n    @if (label()) {\n      <label>{{ label() }}</label>\n    }\n\n    <div class=\"radio-group\" [class.stacked]=\"orientation() === 'stacked'\">\n      @for (option of options(); track option.value) {\n        <label\n          class=\"control-row radio-control\"\n          [class.label-left]=\"labelPosition() === 'left'\"\n          [class.label-top]=\"labelPosition() === 'top'\"\n        >\n          <input\n            type=\"radio\"\n            class=\"radio-input\"\n            [name]=\"name()\"\n            [checked]=\"_isChecked(option.value)\"\n            [disabled]=\"_isDisabled() || !!option.disabled\"\n            (change)=\"_select(option.value)\"\n            (blur)=\"_handleBlur()\"\n          />\n          <span class=\"radio-dot\" aria-hidden=\"true\"></span>\n          <span class=\"control-label\">{{ option.label }}</span>\n        </label>\n      }\n    </div>\n  </div>\n}\n",
		styles: [".radio-group{display:flex;flex-flow:row wrap;gap:10px 20px}.radio-group.stacked{flex-direction:column}.radio-input{position:absolute;width:1px;height:1px;opacity:0;pointer-events:none}.radio-dot{position:relative;display:inline-block;width:18px;height:18px;flex-shrink:0;border:1px solid var(--separator-dark);border-radius:50%;background:var(--bg-lightest);transition:border-color .15s ease-out}.radio-dot:after{content:\"\";position:absolute;top:50%;left:50%;width:8px;height:8px;border-radius:50%;background:var(--accent);transform:translate(-50%,-50%) scale(0);transition:transform .15s ease-out}.radio-input:checked+.radio-dot{border-color:var(--accent)}.radio-input:checked+.radio-dot:after{transform:translate(-50%,-50%) scale(1)}.radio-input:focus-visible+.radio-dot{outline:none;border-color:var(--accent);box-shadow:0 0 0 3px var(--accent-bg)}@media(prefers-reduced-motion:reduce){.radio-dot,.radio-dot:after{transition:none}}\n"],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: Radio,
	decorators: [{
		type: Component,
		args: [{
			selector: "l-radio",
			changeDetection: ChangeDetectionStrategy.OnPush,
			imports: [],
			providers: [provideInputValueAccessor(() => Radio)],
			hostDirectives: [{
				directive: FormValidation,
				inputs: ["useValidation"]
			}],
			template: "@if (viewMode()) {\n  <div class=\"form-group view-mode\">\n    @if (label()) {\n      <label>{{ label() }}</label>\n    }\n    <div class=\"view-value\">{{ viewValue() ?? _selectedLabel() ?? '-' }}</div>\n  </div>\n} @else {\n  <div class=\"form-group\">\n    @if (label()) {\n      <label>{{ label() }}</label>\n    }\n\n    <div class=\"radio-group\" [class.stacked]=\"orientation() === 'stacked'\">\n      @for (option of options(); track option.value) {\n        <label\n          class=\"control-row radio-control\"\n          [class.label-left]=\"labelPosition() === 'left'\"\n          [class.label-top]=\"labelPosition() === 'top'\"\n        >\n          <input\n            type=\"radio\"\n            class=\"radio-input\"\n            [name]=\"name()\"\n            [checked]=\"_isChecked(option.value)\"\n            [disabled]=\"_isDisabled() || !!option.disabled\"\n            (change)=\"_select(option.value)\"\n            (blur)=\"_handleBlur()\"\n          />\n          <span class=\"radio-dot\" aria-hidden=\"true\"></span>\n          <span class=\"control-label\">{{ option.label }}</span>\n        </label>\n      }\n    </div>\n  </div>\n}\n",
			styles: [".radio-group{display:flex;flex-flow:row wrap;gap:10px 20px}.radio-group.stacked{flex-direction:column}.radio-input{position:absolute;width:1px;height:1px;opacity:0;pointer-events:none}.radio-dot{position:relative;display:inline-block;width:18px;height:18px;flex-shrink:0;border:1px solid var(--separator-dark);border-radius:50%;background:var(--bg-lightest);transition:border-color .15s ease-out}.radio-dot:after{content:\"\";position:absolute;top:50%;left:50%;width:8px;height:8px;border-radius:50%;background:var(--accent);transform:translate(-50%,-50%) scale(0);transition:transform .15s ease-out}.radio-input:checked+.radio-dot{border-color:var(--accent)}.radio-input:checked+.radio-dot:after{transform:translate(-50%,-50%) scale(1)}.radio-input:focus-visible+.radio-dot{outline:none;border-color:var(--accent);box-shadow:0 0 0 3px var(--accent-bg)}@media(prefers-reduced-motion:reduce){.radio-dot,.radio-dot:after{transition:none}}\n"]
		}]
	}]
});
let _uid$4 = 0;
var OtpInput = class OtpInput {
	length = input(6, ...ngDevMode ? [{ debugName: "length" }] : /* istanbul ignore next */ []);
	type = input("number", ...ngDevMode ? [{ debugName: "type" }] : /* istanbul ignore next */ []);
	mask = input(false, ...ngDevMode ? [{ debugName: "mask" }] : /* istanbul ignore next */ []);
	size = input("md", ...ngDevMode ? [{ debugName: "size" }] : /* istanbul ignore next */ []);
	disabled = input(false, ...ngDevMode ? [{ debugName: "disabled" }] : /* istanbul ignore next */ []);
	error = input(false, ...ngDevMode ? [{ debugName: "error" }] : /* istanbul ignore next */ []);
	autoFocus = input(false, ...ngDevMode ? [{ debugName: "autoFocus" }] : /* istanbul ignore next */ []);
	separator = input(false, ...ngDevMode ? [{ debugName: "separator" }] : /* istanbul ignore next */ []);
	ariaLabel = input("One-time code", ...ngDevMode ? [{ debugName: "ariaLabel" }] : /* istanbul ignore next */ []);
	name = input(`l-otp-${_uid$4++}`, ...ngDevMode ? [{ debugName: "name" }] : /* istanbul ignore next */ []);
	change = output();
	completed = output();
	_chars = signal([], ...ngDevMode ? [{ debugName: "_chars" }] : /* istanbul ignore next */ []);
	_disabledByForm = signal(false, ...ngDevMode ? [{ debugName: "_disabledByForm" }] : /* istanbul ignore next */ []);
	_isDisabled = computed(() => this.disabled() || this._disabledByForm(), ...ngDevMode ? [{ debugName: "_isDisabled" }] : /* istanbul ignore next */ []);
	_inputType = computed(() => this.mask() ? "password" : "text", ...ngDevMode ? [{ debugName: "_inputType" }] : /* istanbul ignore next */ []);
	_inputMode = computed(() => this.type() === "number" ? "numeric" : "text", ...ngDevMode ? [{ debugName: "_inputMode" }] : /* istanbul ignore next */ []);
	_hostClasses = computed(() => {
		const classes = ["l-otp", `l-otp--${this.size()}`];
		if (this.error()) classes.push("is-error");
		if (this._isDisabled()) classes.push("is-disabled");
		return classes.join(" ");
	}, ...ngDevMode ? [{ debugName: "_hostClasses" }] : /* istanbul ignore next */ []);
	_cells = viewChildren("cell", ...ngDevMode ? [{ debugName: "_cells" }] : /* istanbul ignore next */ []);
	_onChange = () => {};
	_onTouched = () => {};
	constructor() {
		effect(() => {
			const len = this.length();
			this._chars.update((prev) => {
				const next = prev.slice(0, len);
				while (next.length < len) next.push("");
				return next;
			});
		});
		afterNextRender(() => {
			if (this.autoFocus() && !this._isDisabled()) this._focus(0);
		});
	}
	_onInput(event, index) {
		const el = event.target;
		const char = el.value.slice(-1);
		if (char && !this._isAllowed(char)) {
			el.value = this._chars()[index] ?? "";
			return;
		}
		this._setChar(index, char);
		if (char) this._focus(index + 1);
	}
	_onKeydown(event, index) {
		switch (event.key) {
			case "Backspace":
				event.preventDefault();
				if (this._chars()[index]) this._setChar(index, "");
				else if (index > 0) {
					this._setChar(index - 1, "");
					this._focus(index - 1);
				}
				break;
			case "Delete":
				event.preventDefault();
				this._setChar(index, "");
				break;
			case "ArrowLeft":
				event.preventDefault();
				this._focus(index - 1);
				break;
			case "ArrowRight":
				event.preventDefault();
				this._focus(index + 1);
				break;
			case "Home":
				event.preventDefault();
				this._focus(0);
				break;
			case "End":
				event.preventDefault();
				this._focus(this.length() - 1);
		}
	}
	_onPaste(event, index) {
		event.preventDefault();
		const incoming = [...event.clipboardData?.getData("text") ?? ""].filter((c) => this._isAllowed(c));
		if (!incoming.length) return;
		const chars = this._chars().slice();
		let pos = index;
		for (const c of incoming) {
			if (pos >= chars.length) break;
			chars[pos++] = c;
		}
		this._commit(chars);
		this._focus(pos);
	}
	_onFocus(event) {
		event.target.select();
	}
	_onBlur() {
		this._onTouched();
	}
	_isAllowed(char) {
		return this.type() === "number" ? /[0-9]/.test(char) : /\S/.test(char);
	}
	_setChar(index, char) {
		const chars = this._chars().slice();
		chars[index] = char;
		this._commit(chars);
	}
	_commit(chars) {
		this._chars.set(chars);
		const value = chars.join("");
		this._onChange(value);
		this.change.emit(value);
		if (chars.length > 0 && chars.every((c) => c !== "")) this.completed.emit(value);
	}
	_focus(index) {
		const clamped = Math.max(0, Math.min(index, this.length() - 1));
		const el = this._cells()[clamped]?.nativeElement;
		el?.focus();
		el?.select();
	}
	writeValue(value) {
		const chars = [...value ?? ""].slice(0, this.length());
		while (chars.length < this.length()) chars.push("");
		this._chars.set(chars);
	}
	registerOnChange(fn) {
		this._onChange = fn;
	}
	registerOnTouched(fn) {
		this._onTouched = fn;
	}
	setDisabledState(isDisabled) {
		this._disabledByForm.set(isDisabled);
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.1",
		ngImport: i0,
		type: OtpInput,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.1",
		type: OtpInput,
		isStandalone: true,
		selector: "l-otp-input",
		inputs: {
			length: {
				classPropertyName: "length",
				publicName: "length",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			type: {
				classPropertyName: "type",
				publicName: "type",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			mask: {
				classPropertyName: "mask",
				publicName: "mask",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			size: {
				classPropertyName: "size",
				publicName: "size",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			disabled: {
				classPropertyName: "disabled",
				publicName: "disabled",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			error: {
				classPropertyName: "error",
				publicName: "error",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			autoFocus: {
				classPropertyName: "autoFocus",
				publicName: "autoFocus",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			separator: {
				classPropertyName: "separator",
				publicName: "separator",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			ariaLabel: {
				classPropertyName: "ariaLabel",
				publicName: "ariaLabel",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			name: {
				classPropertyName: "name",
				publicName: "name",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: {
			change: "change",
			completed: "completed"
		},
		host: {
			attributes: { "role": "group" },
			properties: {
				"class": "_hostClasses()",
				"attr.aria-label": "ariaLabel()"
			}
		},
		providers: [provideInputValueAccessor(() => OtpInput)],
		viewQueries: [{
			propertyName: "_cells",
			predicate: ["cell"],
			descendants: true,
			isSignal: true
		}],
		ngImport: i0,
		template: "<div class=\"l-otp__boxes\">\n  @for (char of _chars(); track $index; let i = $index; let last = $last) {\n    <input\n      #cell\n      class=\"l-otp__box\"\n      [class.is-filled]=\"char\"\n      [type]=\"_inputType()\"\n      [attr.inputmode]=\"_inputMode()\"\n      [value]=\"char\"\n      [disabled]=\"_isDisabled()\"\n      [name]=\"name() + '-' + i\"\n      [attr.aria-label]=\"'Character ' + (i + 1) + ' of ' + length()\"\n      autocomplete=\"one-time-code\"\n      autocapitalize=\"off\"\n      spellcheck=\"false\"\n      maxlength=\"1\"\n      (input)=\"_onInput($event, i)\"\n      (keydown)=\"_onKeydown($event, i)\"\n      (paste)=\"_onPaste($event, i)\"\n      (focus)=\"_onFocus($event)\"\n      (blur)=\"_onBlur()\"\n    />\n\n    @if (separator() && !last) {\n      <span class=\"l-otp__separator\" aria-hidden=\"true\">–</span>\n    }\n  }\n</div>\n",
		styles: [":host{display:inline-block;--l-otp-box: 48px;--l-otp-font: 20px;--l-otp-radius: 10px;--l-otp-gap: 10px;--l-otp-border: var(--separator-dark);--l-otp-ring: var(--accent);--l-otp-ring-bg: var(--accent-bg)}:host(.l-otp--sm){--l-otp-box: 40px;--l-otp-font: 16px;--l-otp-gap: 8px}:host(.l-otp--lg){--l-otp-box: 56px;--l-otp-font: 24px;--l-otp-gap: 12px}:host(.is-error){--l-otp-border: var(--error);--l-otp-ring: var(--error);--l-otp-ring-bg: var(--error-bg)}.l-otp__boxes{display:inline-flex;align-items:center;gap:var(--l-otp-gap)}.l-otp__box{width:var(--l-otp-box);height:var(--l-otp-box);padding:0;border:1.5px solid var(--l-otp-border);border-radius:var(--l-otp-radius);background:var(--bg-lightest);color:var(--text-primary);font-size:var(--l-otp-font);font-weight:600;line-height:1;text-align:center;caret-color:var(--l-otp-ring);transition:border-color .15s ease-out,box-shadow .15s ease-out,background-color .15s ease-out}.l-otp__box.is-filled{border-color:var(--l-otp-ring)}.l-otp__box:hover:not(:disabled):not(:focus){border-color:var(--text-quaternary)}.l-otp__box:focus{outline:none;border-color:var(--l-otp-ring);box-shadow:0 0 0 3px var(--l-otp-ring-bg)}.l-otp__box:disabled{background:var(--bg-light);color:var(--text-quaternary);cursor:not-allowed}.l-otp__box::-ms-reveal,.l-otp__box::-ms-clear{display:none}.l-otp__separator{color:var(--text-quaternary);font-size:var(--l-otp-font);font-weight:600;-webkit-user-select:none;user-select:none}@media(prefers-reduced-motion:reduce){.l-otp__box{transition:none}}\n"],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: OtpInput,
	decorators: [{
		type: Component,
		args: [{
			selector: "l-otp-input",
			changeDetection: ChangeDetectionStrategy.OnPush,
			providers: [provideInputValueAccessor(() => OtpInput)],
			host: {
				"[class]": "_hostClasses()",
				role: "group",
				"[attr.aria-label]": "ariaLabel()"
			},
			template: "<div class=\"l-otp__boxes\">\n  @for (char of _chars(); track $index; let i = $index; let last = $last) {\n    <input\n      #cell\n      class=\"l-otp__box\"\n      [class.is-filled]=\"char\"\n      [type]=\"_inputType()\"\n      [attr.inputmode]=\"_inputMode()\"\n      [value]=\"char\"\n      [disabled]=\"_isDisabled()\"\n      [name]=\"name() + '-' + i\"\n      [attr.aria-label]=\"'Character ' + (i + 1) + ' of ' + length()\"\n      autocomplete=\"one-time-code\"\n      autocapitalize=\"off\"\n      spellcheck=\"false\"\n      maxlength=\"1\"\n      (input)=\"_onInput($event, i)\"\n      (keydown)=\"_onKeydown($event, i)\"\n      (paste)=\"_onPaste($event, i)\"\n      (focus)=\"_onFocus($event)\"\n      (blur)=\"_onBlur()\"\n    />\n\n    @if (separator() && !last) {\n      <span class=\"l-otp__separator\" aria-hidden=\"true\">–</span>\n    }\n  }\n</div>\n",
			styles: [":host{display:inline-block;--l-otp-box: 48px;--l-otp-font: 20px;--l-otp-radius: 10px;--l-otp-gap: 10px;--l-otp-border: var(--separator-dark);--l-otp-ring: var(--accent);--l-otp-ring-bg: var(--accent-bg)}:host(.l-otp--sm){--l-otp-box: 40px;--l-otp-font: 16px;--l-otp-gap: 8px}:host(.l-otp--lg){--l-otp-box: 56px;--l-otp-font: 24px;--l-otp-gap: 12px}:host(.is-error){--l-otp-border: var(--error);--l-otp-ring: var(--error);--l-otp-ring-bg: var(--error-bg)}.l-otp__boxes{display:inline-flex;align-items:center;gap:var(--l-otp-gap)}.l-otp__box{width:var(--l-otp-box);height:var(--l-otp-box);padding:0;border:1.5px solid var(--l-otp-border);border-radius:var(--l-otp-radius);background:var(--bg-lightest);color:var(--text-primary);font-size:var(--l-otp-font);font-weight:600;line-height:1;text-align:center;caret-color:var(--l-otp-ring);transition:border-color .15s ease-out,box-shadow .15s ease-out,background-color .15s ease-out}.l-otp__box.is-filled{border-color:var(--l-otp-ring)}.l-otp__box:hover:not(:disabled):not(:focus){border-color:var(--text-quaternary)}.l-otp__box:focus{outline:none;border-color:var(--l-otp-ring);box-shadow:0 0 0 3px var(--l-otp-ring-bg)}.l-otp__box:disabled{background:var(--bg-light);color:var(--text-quaternary);cursor:not-allowed}.l-otp__box::-ms-reveal,.l-otp__box::-ms-clear{display:none}.l-otp__separator{color:var(--text-quaternary);font-size:var(--l-otp-font);font-weight:600;-webkit-user-select:none;user-select:none}@media(prefers-reduced-motion:reduce){.l-otp__box{transition:none}}\n"]
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		length: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "length",
				required: false
			}]
		}],
		type: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "type",
				required: false
			}]
		}],
		mask: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "mask",
				required: false
			}]
		}],
		size: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "size",
				required: false
			}]
		}],
		disabled: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "disabled",
				required: false
			}]
		}],
		error: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "error",
				required: false
			}]
		}],
		autoFocus: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "autoFocus",
				required: false
			}]
		}],
		separator: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "separator",
				required: false
			}]
		}],
		ariaLabel: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "ariaLabel",
				required: false
			}]
		}],
		name: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "name",
				required: false
			}]
		}],
		change: [{
			type: i0.Output,
			args: ["change"]
		}],
		completed: [{
			type: i0.Output,
			args: ["completed"]
		}],
		_cells: [{
			type: i0.ViewChildren,
			args: ["cell", { isSignal: true }]
		}]
	}
});
let _uid$3 = 0;
var FileUpload = class FileUpload {
	accept = input("", ...ngDevMode ? [{ debugName: "accept" }] : /* istanbul ignore next */ []);
	multiple = input(true, ...ngDevMode ? [{ debugName: "multiple" }] : /* istanbul ignore next */ []);
	maxSizeMb = input(0, ...ngDevMode ? [{ debugName: "maxSizeMb" }] : /* istanbul ignore next */ []);
	maxCount = input(0, ...ngDevMode ? [{ debugName: "maxCount" }] : /* istanbul ignore next */ []);
	disabled = input(false, ...ngDevMode ? [{ debugName: "disabled" }] : /* istanbul ignore next */ []);
	variant = input("dropzone", ...ngDevMode ? [{ debugName: "variant" }] : /* istanbul ignore next */ []);
	listType = input("list", ...ngDevMode ? [{ debugName: "listType" }] : /* istanbul ignore next */ []);
	label = input("Click or drag files here to upload", ...ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []);
	hint = input("", ...ngDevMode ? [{ debugName: "hint" }] : /* istanbul ignore next */ []);
	files = model([], ...ngDevMode ? [{ debugName: "files" }] : /* istanbul ignore next */ []);
	added = output();
	removed = output();
	rejected = output();
	_input = viewChild.required("input", ...ngDevMode ? [{ debugName: "_input" }] : /* istanbul ignore next */ []);
	_objectUrls = /* @__PURE__ */ new Set();
	_dragging = signal(false, ...ngDevMode ? [{ debugName: "_dragging" }] : /* istanbul ignore next */ []);
	_hostClasses = computed(() => {
		const classes = [
			"l-upload",
			`l-upload--${this.variant()}`,
			`l-upload--${this.listType()}`
		];
		if (this.disabled()) classes.push("is-disabled");
		if (this._dragging()) classes.push("is-dragging");
		return classes.join(" ");
	}, ...ngDevMode ? [{ debugName: "_hostClasses" }] : /* istanbul ignore next */ []);
	_showTrigger = computed(() => this.multiple() || this.files().length === 0, ...ngDevMode ? [{ debugName: "_showTrigger" }] : /* istanbul ignore next */ []);
	_resolvedHint = computed(() => {
		if (this.hint()) return this.hint();
		const parts = [];
		if (this.accept()) parts.push(this.accept());
		if (this.maxSizeMb()) parts.push(`up to ${this.maxSizeMb()} MB`);
		return parts.join(" · ");
	}, ...ngDevMode ? [{ debugName: "_resolvedHint" }] : /* istanbul ignore next */ []);
	constructor() {
		inject(DestroyRef).onDestroy(() => {
			this._objectUrls.forEach((url) => URL.revokeObjectURL(url));
			this._objectUrls.clear();
		});
	}
	_browse() {
		if (this.disabled()) return;
		this._input().nativeElement.click();
	}
	_onInputChange(event) {
		const input = event.target;
		if (input.files?.length) this._ingest(input.files);
		input.value = "";
	}
	_onDragOver(event) {
		if (this.disabled()) return;
		event.preventDefault();
		this._dragging.set(true);
	}
	_onDragLeave(event) {
		event.preventDefault();
		this._dragging.set(false);
	}
	_onDrop(event) {
		if (this.disabled()) return;
		event.preventDefault();
		this._dragging.set(false);
		if (event.dataTransfer?.files.length) this._ingest(event.dataTransfer.files);
	}
	_remove(item, event) {
		event.stopPropagation();
		if (item.url && this._objectUrls.has(item.url)) {
			URL.revokeObjectURL(item.url);
			this._objectUrls.delete(item.url);
		}
		this.files.update((list) => list.filter((f) => f.id !== item.id));
		this.removed.emit(item);
	}
	_isImage(item) {
		return item.type.startsWith("image/");
	}
	_formatSize(bytes) {
		if (bytes < 1024) return `${bytes} B`;
		const kb = bytes / 1024;
		if (kb < 1024) return `${kb.toFixed(1)} KB`;
		return `${(kb / 1024).toFixed(1)} MB`;
	}
	patchFile(id, patch) {
		this.files.update((list) => list.map((f) => f.id === id ? {
			...f,
			...patch
		} : f));
	}
	clear() {
		this._objectUrls.forEach((url) => URL.revokeObjectURL(url));
		this._objectUrls.clear();
		this.files.set([]);
	}
	_ingest(fileList) {
		const incoming = Array.from(fileList);
		const accepted = [];
		for (const file of incoming) {
			if (!this._matchesAccept(file)) {
				this.rejected.emit({
					file,
					reason: "type"
				});
				continue;
			}
			if (this.maxSizeMb() && file.size > this.maxSizeMb() * 1024 * 1024) {
				this.rejected.emit({
					file,
					reason: "size"
				});
				continue;
			}
			accepted.push(this._toUploadFile(file));
		}
		if (!accepted.length) return;
		if (!this.multiple()) {
			this._revokeAll(this.files());
			this.files.set([accepted[accepted.length - 1]]);
			this.added.emit([accepted[accepted.length - 1]]);
			return;
		}
		let next = [...this.files(), ...accepted];
		let kept = accepted;
		const cap = this.maxCount();
		if (cap && next.length > cap) {
			next.slice(cap).forEach((f) => {
				this._revoke(f);
				this.rejected.emit({
					file: f.file,
					reason: "count"
				});
			});
			next = next.slice(0, cap);
			kept = accepted.filter((f) => next.includes(f));
		}
		this.files.set(next);
		if (kept.length) this.added.emit(kept);
	}
	_toUploadFile(file) {
		let url;
		if (file.type.startsWith("image/")) {
			url = URL.createObjectURL(file);
			this._objectUrls.add(url);
		}
		return {
			id: `l-upload-${_uid$3++}`,
			file,
			name: file.name,
			size: file.size,
			type: file.type,
			status: "pending",
			progress: 0,
			url
		};
	}
	_matchesAccept(file) {
		const accept = this.accept().trim();
		if (!accept) return true;
		const name = file.name.toLowerCase();
		const type = file.type.toLowerCase();
		return accept.split(",").some((raw) => {
			const token = raw.trim().toLowerCase();
			if (!token) return false;
			if (token.startsWith(".")) return name.endsWith(token);
			if (token.endsWith("/*")) return type.startsWith(token.slice(0, -1));
			return type === token;
		});
	}
	_revoke(item) {
		if (item.url && this._objectUrls.has(item.url)) {
			URL.revokeObjectURL(item.url);
			this._objectUrls.delete(item.url);
		}
	}
	_revokeAll(items) {
		items.forEach((item) => this._revoke(item));
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.1",
		ngImport: i0,
		type: FileUpload,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.1",
		type: FileUpload,
		isStandalone: true,
		selector: "l-file-upload",
		inputs: {
			accept: {
				classPropertyName: "accept",
				publicName: "accept",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			multiple: {
				classPropertyName: "multiple",
				publicName: "multiple",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			maxSizeMb: {
				classPropertyName: "maxSizeMb",
				publicName: "maxSizeMb",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			maxCount: {
				classPropertyName: "maxCount",
				publicName: "maxCount",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			disabled: {
				classPropertyName: "disabled",
				publicName: "disabled",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			variant: {
				classPropertyName: "variant",
				publicName: "variant",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			listType: {
				classPropertyName: "listType",
				publicName: "listType",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			label: {
				classPropertyName: "label",
				publicName: "label",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			hint: {
				classPropertyName: "hint",
				publicName: "hint",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			files: {
				classPropertyName: "files",
				publicName: "files",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: {
			files: "filesChange",
			added: "added",
			removed: "removed",
			rejected: "rejected"
		},
		host: { properties: { "class": "_hostClasses()" } },
		viewQueries: [{
			propertyName: "_input",
			first: true,
			predicate: ["input"],
			descendants: true,
			isSignal: true
		}],
		ngImport: i0,
		template: "<input\n  #input\n  type=\"file\"\n  class=\"l-upload__input\"\n  [accept]=\"accept()\"\n  [multiple]=\"multiple()\"\n  [disabled]=\"disabled()\"\n  (change)=\"_onInputChange($event)\"\n/>\n\n@if (_showTrigger() && variant() === 'dropzone') {\n  <button\n    type=\"button\"\n    class=\"l-upload__dropzone\"\n    [disabled]=\"disabled()\"\n    (click)=\"_browse()\"\n    (dragover)=\"_onDragOver($event)\"\n    (dragleave)=\"_onDragLeave($event)\"\n    (drop)=\"_onDrop($event)\"\n  >\n    <svg\n      class=\"l-upload__cloud\"\n      width=\"40\"\n      height=\"40\"\n      viewBox=\"0 0 48 48\"\n      fill=\"none\"\n      aria-hidden=\"true\"\n      xmlns=\"http://www.w3.org/2000/svg\"\n    >\n      <path\n        d=\"M14 30a8 8 0 0 1-.8-15.96A11 11 0 0 1 34.7 16.2 8.5 8.5 0 0 1 34 33\"\n        stroke=\"currentColor\"\n        stroke-width=\"2.5\"\n        stroke-linecap=\"round\"\n        stroke-linejoin=\"round\"\n      />\n      <path\n        d=\"M24 22v14M18.5 27.5 24 22l5.5 5.5\"\n        stroke=\"currentColor\"\n        stroke-width=\"2.5\"\n        stroke-linecap=\"round\"\n        stroke-linejoin=\"round\"\n      />\n    </svg>\n    <span class=\"l-upload__label\">{{ label() }}</span>\n    @if (_resolvedHint()) {\n      <span class=\"l-upload__hint\">{{ _resolvedHint() }}</span>\n    }\n  </button>\n} @else if (_showTrigger()) {\n  <div class=\"l-upload__trigger-row\">\n    <button type=\"button\" class=\"l-upload__trigger\" [disabled]=\"disabled()\" (click)=\"_browse()\">\n      <svg width=\"16\" height=\"16\" viewBox=\"0 0 20 20\" fill=\"none\" aria-hidden=\"true\">\n        <path d=\"M10 4v12M4 10h12\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\" />\n      </svg>\n      <span>Upload</span>\n    </button>\n    @if (_resolvedHint()) {\n      <span class=\"l-upload__hint\">{{ _resolvedHint() }}</span>\n    }\n  </div>\n}\n\n@if (files().length) {\n  <ul class=\"l-upload__files\" [class.is-grid]=\"listType() === 'grid'\">\n    @for (item of files(); track item.id) {\n      <li class=\"l-upload__file\" [class]=\"'is-' + item.status\">\n        <div class=\"l-upload__thumb\">\n          @if (_isImage(item) && item.url) {\n            <img [src]=\"item.url\" [alt]=\"item.name\" />\n          } @else {\n            <svg width=\"20\" height=\"20\" viewBox=\"0 0 20 20\" fill=\"none\" aria-hidden=\"true\">\n              <path\n                d=\"M11 2H5.5A1.5 1.5 0 0 0 4 3.5v13A1.5 1.5 0 0 0 5.5 18h9a1.5 1.5 0 0 0 1.5-1.5V7l-5-5Z\"\n                stroke=\"currentColor\"\n                stroke-width=\"1.5\"\n                stroke-linejoin=\"round\"\n              />\n              <path\n                d=\"M11 2v5h5\"\n                stroke=\"currentColor\"\n                stroke-width=\"1.5\"\n                stroke-linejoin=\"round\"\n              />\n            </svg>\n          }\n\n          @if (item.status === 'success') {\n            <span class=\"l-upload__badge l-upload__badge--success\" aria-label=\"Uploaded\">\n              <svg width=\"12\" height=\"12\" viewBox=\"0 0 20 20\" fill=\"none\" aria-hidden=\"true\">\n                <path\n                  d=\"M5 10.5 8.5 14 15 6.5\"\n                  stroke=\"currentColor\"\n                  stroke-width=\"2.5\"\n                  stroke-linecap=\"round\"\n                  stroke-linejoin=\"round\"\n                />\n              </svg>\n            </span>\n          } @else if (item.status === 'error') {\n            <span class=\"l-upload__badge l-upload__badge--error\" aria-label=\"Failed\">\n              <svg width=\"12\" height=\"12\" viewBox=\"0 0 20 20\" fill=\"none\" aria-hidden=\"true\">\n                <path d=\"M10 5v6\" stroke=\"currentColor\" stroke-width=\"2.5\" stroke-linecap=\"round\" />\n                <circle cx=\"10\" cy=\"14.5\" r=\"1.2\" fill=\"currentColor\" />\n              </svg>\n            </span>\n          }\n        </div>\n\n        <div class=\"l-upload__meta\">\n          <span class=\"l-upload__name\" [title]=\"item.name\">{{ item.name }}</span>\n          <span class=\"l-upload__sub\">\n            @if (item.status === 'error') {\n              {{ item.error || 'Upload failed' }}\n            } @else if (item.status === 'uploading') {\n              {{ item.progress }}%\n            } @else {\n              {{ _formatSize(item.size) }}\n            }\n          </span>\n\n          @if (item.status === 'uploading') {\n            <span class=\"l-upload__progress\">\n              <span class=\"l-upload__progress-bar\" [style.width.%]=\"item.progress\"></span>\n            </span>\n          }\n        </div>\n\n        <button\n          type=\"button\"\n          class=\"l-upload__remove\"\n          [attr.aria-label]=\"'Remove ' + item.name\"\n          (click)=\"_remove(item, $event)\"\n        >\n          <svg width=\"14\" height=\"14\" viewBox=\"0 0 20 20\" fill=\"none\" aria-hidden=\"true\">\n            <path\n              d=\"m6 6 8 8M14 6l-8 8\"\n              stroke=\"currentColor\"\n              stroke-width=\"2\"\n              stroke-linecap=\"round\"\n            />\n          </svg>\n        </button>\n      </li>\n    }\n  </ul>\n}\n",
		styles: [":host{display:block}.l-upload__input{display:none}.l-upload__dropzone{display:flex;flex-direction:column;align-items:center;justify-content:center;gap:8px;width:100%;padding:32px 24px;border:1.5px dashed var(--separator-dark);border-radius:12px;background:var(--bg-light);color:var(--text-secondary);cursor:pointer;transition:border-color .16s ease-out,background-color .16s ease-out,color .16s ease-out}.l-upload__dropzone:hover:not(:disabled){border-color:var(--accent);background:var(--accent-bg);color:var(--text-primary)}.l-upload__dropzone:focus-visible{outline:2px solid var(--accent);outline-offset:2px}.l-upload__dropzone:disabled{opacity:.55;cursor:not-allowed}:host(.is-dragging) .l-upload__dropzone{border-color:var(--accent);background:var(--accent-bg);color:var(--text-primary)}.l-upload__cloud{color:var(--accent)}.l-upload__label{font-size:14px;font-weight:600;color:var(--text-primary)}.l-upload__hint{font-size:12.5px;color:var(--text-quaternary)}.l-upload__trigger-row{display:flex;align-items:center;gap:12px}.l-upload__trigger{display:inline-flex;align-items:center;gap:6px;padding:8px 14px;border:1px solid var(--separator-dark);border-radius:8px;background:var(--bg-lightest);color:var(--text-primary);font-size:14px;font-weight:600;cursor:pointer;transition:border-color .15s ease-out,color .15s ease-out,background-color .15s ease-out}.l-upload__trigger:hover:not(:disabled){border-color:var(--accent);color:var(--accent-dark)}.l-upload__trigger:focus-visible{outline:2px solid var(--accent);outline-offset:2px}.l-upload__trigger:disabled{opacity:.55;cursor:not-allowed}.l-upload__files{list-style:none;display:flex;flex-direction:column;gap:8px;margin:12px 0 0;padding:0}.l-upload__file{position:relative;display:flex;align-items:center;gap:12px;padding:8px 10px;border:1px solid var(--separator);border-radius:10px;background:var(--bg-lightest);animation:l-upload-in .2s ease-out}.l-upload__file.is-error{border-color:var(--error);background:var(--error-bg)}.l-upload__thumb{position:relative;display:inline-flex;align-items:center;justify-content:center;flex:0 0 auto;width:40px;height:40px;border-radius:8px;overflow:hidden;background:var(--bg-dark);color:var(--text-tertiary)}.l-upload__thumb img{width:100%;height:100%;object-fit:cover}.l-upload__badge{position:absolute;right:-3px;bottom:-3px;display:inline-flex;align-items:center;justify-content:center;width:16px;height:16px;border-radius:50%;border:2px solid var(--bg-lightest);color:var(--text-white)}.l-upload__badge--success{background:var(--success)}.l-upload__badge--error{background:var(--error)}.l-upload__meta{display:flex;flex-direction:column;gap:2px;flex:1;min-width:0}.l-upload__name{font-size:13.5px;font-weight:500;color:var(--text-primary);overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.l-upload__sub{font-size:12px;color:var(--text-quaternary)}.is-error .l-upload__sub{color:var(--error)}.l-upload__progress{display:block;height:4px;margin-top:4px;border-radius:2px;background:var(--bg-dark);overflow:hidden}.l-upload__progress-bar{display:block;height:100%;border-radius:2px;background:var(--accent);transition:width .2s ease-out}.l-upload__remove{display:inline-flex;align-items:center;justify-content:center;flex:0 0 auto;width:28px;height:28px;padding:0;border:none;border-radius:6px;background:transparent;color:var(--text-tertiary);cursor:pointer;transition:color .14s ease-out,background-color .14s ease-out}.l-upload__remove:hover{color:var(--error);background:var(--error-bg)}.l-upload__remove:focus-visible{outline:2px solid var(--accent);outline-offset:1px}:host(.l-upload--grid) .l-upload__files{display:grid;grid-template-columns:repeat(auto-fill,minmax(128px,1fr));gap:12px}:host(.l-upload--grid) .l-upload__file{flex-direction:column;align-items:stretch;gap:0;padding:0;overflow:hidden}:host(.l-upload--grid) .l-upload__thumb{width:100%;height:auto;aspect-ratio:1;border-radius:0}:host(.l-upload--grid) .l-upload__badge{right:6px;bottom:6px}:host(.l-upload--grid) .l-upload__meta{padding:8px 10px}:host(.l-upload--grid) .l-upload__remove{position:absolute;top:6px;right:6px;width:24px;height:24px;background:#07090f8c;color:var(--text-white)}:host(.l-upload--grid) .l-upload__remove:hover{background:var(--error);color:var(--text-white)}@keyframes l-upload-in{0%{opacity:0;transform:translateY(4px)}to{opacity:1;transform:none}}@media(prefers-reduced-motion:reduce){.l-upload__dropzone,.l-upload__trigger,.l-upload__remove,.l-upload__progress-bar{transition:none}.l-upload__file{animation:none}}\n"],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: FileUpload,
	decorators: [{
		type: Component,
		args: [{
			selector: "l-file-upload",
			changeDetection: ChangeDetectionStrategy.OnPush,
			host: { "[class]": "_hostClasses()" },
			template: "<input\n  #input\n  type=\"file\"\n  class=\"l-upload__input\"\n  [accept]=\"accept()\"\n  [multiple]=\"multiple()\"\n  [disabled]=\"disabled()\"\n  (change)=\"_onInputChange($event)\"\n/>\n\n@if (_showTrigger() && variant() === 'dropzone') {\n  <button\n    type=\"button\"\n    class=\"l-upload__dropzone\"\n    [disabled]=\"disabled()\"\n    (click)=\"_browse()\"\n    (dragover)=\"_onDragOver($event)\"\n    (dragleave)=\"_onDragLeave($event)\"\n    (drop)=\"_onDrop($event)\"\n  >\n    <svg\n      class=\"l-upload__cloud\"\n      width=\"40\"\n      height=\"40\"\n      viewBox=\"0 0 48 48\"\n      fill=\"none\"\n      aria-hidden=\"true\"\n      xmlns=\"http://www.w3.org/2000/svg\"\n    >\n      <path\n        d=\"M14 30a8 8 0 0 1-.8-15.96A11 11 0 0 1 34.7 16.2 8.5 8.5 0 0 1 34 33\"\n        stroke=\"currentColor\"\n        stroke-width=\"2.5\"\n        stroke-linecap=\"round\"\n        stroke-linejoin=\"round\"\n      />\n      <path\n        d=\"M24 22v14M18.5 27.5 24 22l5.5 5.5\"\n        stroke=\"currentColor\"\n        stroke-width=\"2.5\"\n        stroke-linecap=\"round\"\n        stroke-linejoin=\"round\"\n      />\n    </svg>\n    <span class=\"l-upload__label\">{{ label() }}</span>\n    @if (_resolvedHint()) {\n      <span class=\"l-upload__hint\">{{ _resolvedHint() }}</span>\n    }\n  </button>\n} @else if (_showTrigger()) {\n  <div class=\"l-upload__trigger-row\">\n    <button type=\"button\" class=\"l-upload__trigger\" [disabled]=\"disabled()\" (click)=\"_browse()\">\n      <svg width=\"16\" height=\"16\" viewBox=\"0 0 20 20\" fill=\"none\" aria-hidden=\"true\">\n        <path d=\"M10 4v12M4 10h12\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\" />\n      </svg>\n      <span>Upload</span>\n    </button>\n    @if (_resolvedHint()) {\n      <span class=\"l-upload__hint\">{{ _resolvedHint() }}</span>\n    }\n  </div>\n}\n\n@if (files().length) {\n  <ul class=\"l-upload__files\" [class.is-grid]=\"listType() === 'grid'\">\n    @for (item of files(); track item.id) {\n      <li class=\"l-upload__file\" [class]=\"'is-' + item.status\">\n        <div class=\"l-upload__thumb\">\n          @if (_isImage(item) && item.url) {\n            <img [src]=\"item.url\" [alt]=\"item.name\" />\n          } @else {\n            <svg width=\"20\" height=\"20\" viewBox=\"0 0 20 20\" fill=\"none\" aria-hidden=\"true\">\n              <path\n                d=\"M11 2H5.5A1.5 1.5 0 0 0 4 3.5v13A1.5 1.5 0 0 0 5.5 18h9a1.5 1.5 0 0 0 1.5-1.5V7l-5-5Z\"\n                stroke=\"currentColor\"\n                stroke-width=\"1.5\"\n                stroke-linejoin=\"round\"\n              />\n              <path\n                d=\"M11 2v5h5\"\n                stroke=\"currentColor\"\n                stroke-width=\"1.5\"\n                stroke-linejoin=\"round\"\n              />\n            </svg>\n          }\n\n          @if (item.status === 'success') {\n            <span class=\"l-upload__badge l-upload__badge--success\" aria-label=\"Uploaded\">\n              <svg width=\"12\" height=\"12\" viewBox=\"0 0 20 20\" fill=\"none\" aria-hidden=\"true\">\n                <path\n                  d=\"M5 10.5 8.5 14 15 6.5\"\n                  stroke=\"currentColor\"\n                  stroke-width=\"2.5\"\n                  stroke-linecap=\"round\"\n                  stroke-linejoin=\"round\"\n                />\n              </svg>\n            </span>\n          } @else if (item.status === 'error') {\n            <span class=\"l-upload__badge l-upload__badge--error\" aria-label=\"Failed\">\n              <svg width=\"12\" height=\"12\" viewBox=\"0 0 20 20\" fill=\"none\" aria-hidden=\"true\">\n                <path d=\"M10 5v6\" stroke=\"currentColor\" stroke-width=\"2.5\" stroke-linecap=\"round\" />\n                <circle cx=\"10\" cy=\"14.5\" r=\"1.2\" fill=\"currentColor\" />\n              </svg>\n            </span>\n          }\n        </div>\n\n        <div class=\"l-upload__meta\">\n          <span class=\"l-upload__name\" [title]=\"item.name\">{{ item.name }}</span>\n          <span class=\"l-upload__sub\">\n            @if (item.status === 'error') {\n              {{ item.error || 'Upload failed' }}\n            } @else if (item.status === 'uploading') {\n              {{ item.progress }}%\n            } @else {\n              {{ _formatSize(item.size) }}\n            }\n          </span>\n\n          @if (item.status === 'uploading') {\n            <span class=\"l-upload__progress\">\n              <span class=\"l-upload__progress-bar\" [style.width.%]=\"item.progress\"></span>\n            </span>\n          }\n        </div>\n\n        <button\n          type=\"button\"\n          class=\"l-upload__remove\"\n          [attr.aria-label]=\"'Remove ' + item.name\"\n          (click)=\"_remove(item, $event)\"\n        >\n          <svg width=\"14\" height=\"14\" viewBox=\"0 0 20 20\" fill=\"none\" aria-hidden=\"true\">\n            <path\n              d=\"m6 6 8 8M14 6l-8 8\"\n              stroke=\"currentColor\"\n              stroke-width=\"2\"\n              stroke-linecap=\"round\"\n            />\n          </svg>\n        </button>\n      </li>\n    }\n  </ul>\n}\n",
			styles: [":host{display:block}.l-upload__input{display:none}.l-upload__dropzone{display:flex;flex-direction:column;align-items:center;justify-content:center;gap:8px;width:100%;padding:32px 24px;border:1.5px dashed var(--separator-dark);border-radius:12px;background:var(--bg-light);color:var(--text-secondary);cursor:pointer;transition:border-color .16s ease-out,background-color .16s ease-out,color .16s ease-out}.l-upload__dropzone:hover:not(:disabled){border-color:var(--accent);background:var(--accent-bg);color:var(--text-primary)}.l-upload__dropzone:focus-visible{outline:2px solid var(--accent);outline-offset:2px}.l-upload__dropzone:disabled{opacity:.55;cursor:not-allowed}:host(.is-dragging) .l-upload__dropzone{border-color:var(--accent);background:var(--accent-bg);color:var(--text-primary)}.l-upload__cloud{color:var(--accent)}.l-upload__label{font-size:14px;font-weight:600;color:var(--text-primary)}.l-upload__hint{font-size:12.5px;color:var(--text-quaternary)}.l-upload__trigger-row{display:flex;align-items:center;gap:12px}.l-upload__trigger{display:inline-flex;align-items:center;gap:6px;padding:8px 14px;border:1px solid var(--separator-dark);border-radius:8px;background:var(--bg-lightest);color:var(--text-primary);font-size:14px;font-weight:600;cursor:pointer;transition:border-color .15s ease-out,color .15s ease-out,background-color .15s ease-out}.l-upload__trigger:hover:not(:disabled){border-color:var(--accent);color:var(--accent-dark)}.l-upload__trigger:focus-visible{outline:2px solid var(--accent);outline-offset:2px}.l-upload__trigger:disabled{opacity:.55;cursor:not-allowed}.l-upload__files{list-style:none;display:flex;flex-direction:column;gap:8px;margin:12px 0 0;padding:0}.l-upload__file{position:relative;display:flex;align-items:center;gap:12px;padding:8px 10px;border:1px solid var(--separator);border-radius:10px;background:var(--bg-lightest);animation:l-upload-in .2s ease-out}.l-upload__file.is-error{border-color:var(--error);background:var(--error-bg)}.l-upload__thumb{position:relative;display:inline-flex;align-items:center;justify-content:center;flex:0 0 auto;width:40px;height:40px;border-radius:8px;overflow:hidden;background:var(--bg-dark);color:var(--text-tertiary)}.l-upload__thumb img{width:100%;height:100%;object-fit:cover}.l-upload__badge{position:absolute;right:-3px;bottom:-3px;display:inline-flex;align-items:center;justify-content:center;width:16px;height:16px;border-radius:50%;border:2px solid var(--bg-lightest);color:var(--text-white)}.l-upload__badge--success{background:var(--success)}.l-upload__badge--error{background:var(--error)}.l-upload__meta{display:flex;flex-direction:column;gap:2px;flex:1;min-width:0}.l-upload__name{font-size:13.5px;font-weight:500;color:var(--text-primary);overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.l-upload__sub{font-size:12px;color:var(--text-quaternary)}.is-error .l-upload__sub{color:var(--error)}.l-upload__progress{display:block;height:4px;margin-top:4px;border-radius:2px;background:var(--bg-dark);overflow:hidden}.l-upload__progress-bar{display:block;height:100%;border-radius:2px;background:var(--accent);transition:width .2s ease-out}.l-upload__remove{display:inline-flex;align-items:center;justify-content:center;flex:0 0 auto;width:28px;height:28px;padding:0;border:none;border-radius:6px;background:transparent;color:var(--text-tertiary);cursor:pointer;transition:color .14s ease-out,background-color .14s ease-out}.l-upload__remove:hover{color:var(--error);background:var(--error-bg)}.l-upload__remove:focus-visible{outline:2px solid var(--accent);outline-offset:1px}:host(.l-upload--grid) .l-upload__files{display:grid;grid-template-columns:repeat(auto-fill,minmax(128px,1fr));gap:12px}:host(.l-upload--grid) .l-upload__file{flex-direction:column;align-items:stretch;gap:0;padding:0;overflow:hidden}:host(.l-upload--grid) .l-upload__thumb{width:100%;height:auto;aspect-ratio:1;border-radius:0}:host(.l-upload--grid) .l-upload__badge{right:6px;bottom:6px}:host(.l-upload--grid) .l-upload__meta{padding:8px 10px}:host(.l-upload--grid) .l-upload__remove{position:absolute;top:6px;right:6px;width:24px;height:24px;background:#07090f8c;color:var(--text-white)}:host(.l-upload--grid) .l-upload__remove:hover{background:var(--error);color:var(--text-white)}@keyframes l-upload-in{0%{opacity:0;transform:translateY(4px)}to{opacity:1;transform:none}}@media(prefers-reduced-motion:reduce){.l-upload__dropzone,.l-upload__trigger,.l-upload__remove,.l-upload__progress-bar{transition:none}.l-upload__file{animation:none}}\n"]
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		accept: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "accept",
				required: false
			}]
		}],
		multiple: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "multiple",
				required: false
			}]
		}],
		maxSizeMb: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "maxSizeMb",
				required: false
			}]
		}],
		maxCount: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "maxCount",
				required: false
			}]
		}],
		disabled: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "disabled",
				required: false
			}]
		}],
		variant: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "variant",
				required: false
			}]
		}],
		listType: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "listType",
				required: false
			}]
		}],
		label: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "label",
				required: false
			}]
		}],
		hint: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "hint",
				required: false
			}]
		}],
		files: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "files",
				required: false
			}]
		}, {
			type: i0.Output,
			args: ["filesChange"]
		}],
		added: [{
			type: i0.Output,
			args: ["added"]
		}],
		removed: [{
			type: i0.Output,
			args: ["removed"]
		}],
		rejected: [{
			type: i0.Output,
			args: ["rejected"]
		}],
		_input: [{
			type: i0.ViewChild,
			args: ["input", { isSignal: true }]
		}]
	}
});
var ModalRef = class {
	config;
	componentInstance = null;
	_containerRef;
	_startClose = () => this._finishClose();
	_afterClosed = new Subject();
	_result;
	_closing = false;
	constructor(config) {
		this.config = config;
	}
	close(result) {
		if (this._closing) return;
		this._closing = true;
		this._result = result;
		this._startClose();
	}
	_finishClose() {
		this._afterClosed.next(this._result);
		this._afterClosed.complete();
	}
	afterClosed() {
		return this._afterClosed.asObservable();
	}
};
const MODAL_DEFAULTS = {
	maxWidth: "90vw",
	backdrop: true,
	disableClose: false,
	animation: "slideUp",
	animationDuration: 250
};
const MODAL_DATA = new InjectionToken("MODAL_DATA");
var ModalContainer = class ModalContainer {
	content;
	config;
	modalRef;
	parentInjector;
	_state = signal("enter", ...ngDevMode ? [{ debugName: "_state" }] : /* istanbul ignore next */ []);
	_contentAnchor = viewChild.required("content", {
		...ngDevMode ? { debugName: "_contentAnchor" } : /* istanbul ignore next */ {},
		read: ViewContainerRef
	});
	_cdr = inject(ChangeDetectorRef);
	_panelClasses = computed(() => {
		const classes = [
			"modal-panel",
			`modal-anim-${this.config.animation ?? "slideUp"}`,
			`modal-anim--${this._state()}`
		];
		const extra = this.config.panelClass;
		if (extra) classes.push(...Array.isArray(extra) ? extra : [extra]);
		return classes.join(" ");
	}, ...ngDevMode ? [{ debugName: "_panelClasses" }] : /* istanbul ignore next */ []);
	ngAfterViewInit() {
		this.modalRef._startClose = () => this._startLeave();
		this._renderContent();
		this._cdr.detectChanges();
	}
	_onAnimationEnd(event) {
		if (event.target === event.currentTarget && this._state() === "leave") this.modalRef._finishClose();
	}
	_onBackdropClick() {
		if (!this.config.disableClose) this.modalRef.close();
	}
	_onEscape() {
		if (!this.config.disableClose) this.modalRef.close();
	}
	_renderContent() {
		const anchor = this._contentAnchor();
		if (this.content instanceof TemplateRef) anchor.createEmbeddedView(this.content, {
			$implicit: this.config.data,
			data: this.config.data,
			modalRef: this.modalRef
		});
		else {
			const injector = Injector.create({
				parent: this.parentInjector,
				providers: [{
					provide: ModalRef,
					useValue: this.modalRef
				}, {
					provide: MODAL_DATA,
					useValue: this.config.data ?? null
				}]
			});
			const ref = anchor.createComponent(this.content, { injector });
			this.modalRef.componentInstance = ref.instance;
		}
	}
	_startLeave() {
		if (this._state() === "leave") return;
		this._state.set("leave");
		this._cdr.detectChanges();
		if (this.config.animation === "none") this.modalRef._finishClose();
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.1",
		ngImport: i0,
		type: ModalContainer,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.1",
		type: ModalContainer,
		isStandalone: true,
		selector: "l-modal-container",
		host: { listeners: { "document:keydown.escape": "_onEscape()" } },
		viewQueries: [{
			propertyName: "_contentAnchor",
			first: true,
			predicate: ["content"],
			descendants: true,
			read: ViewContainerRef,
			isSignal: true
		}],
		ngImport: i0,
		template: `
    <div
      class="modal-overlay"
      [class.modal-overlay--leaving]="_state() === 'leave'"
      [style.--modal-duration.ms]="config.animationDuration"
    >
      @if (config.backdrop !== false) {
        <div class="modal-backdrop" (click)="_onBackdropClick()"></div>
      }

      <div class="modal-scroll" (click)="_onBackdropClick()">
        <div
          #panel
          class="modal-panel"
          [class]="_panelClasses()"
          [style.width]="config.width"
          [style.height]="config.height"
          [style.maxWidth]="config.maxWidth"
          (click)="$event.stopPropagation()"
          (animationend)="_onAnimationEnd($event)"
        >
          <ng-container #content />
        </div>
      </div>
    </div>
  `,
		isInline: true,
		styles: [":host{--modal-duration: .25s}.modal-overlay{position:fixed;inset:0;z-index:1000}.modal-backdrop{position:fixed;inset:0;background:#07090f73;animation:modal-backdrop-in var(--modal-duration) ease forwards}.modal-overlay--leaving .modal-backdrop{animation:modal-backdrop-out var(--modal-duration) ease forwards}.modal-scroll{position:fixed;inset:0;display:flex;align-items:center;justify-content:center;padding:24px;overflow:auto}.modal-panel{position:relative;background:var(--bg-lightest);color:var(--text-primary);border-radius:12px;box-shadow:0 12px 40px #0d0d1240;max-width:90vw;animation-duration:var(--modal-duration);animation-timing-function:cubic-bezier(.4,0,.2,1);animation-fill-mode:both}@keyframes modal-backdrop-in{0%{opacity:0}to{opacity:1}}@keyframes modal-backdrop-out{0%{opacity:1}to{opacity:0}}.modal-anim-slideUp.modal-anim--enter{animation-name:modal-slideUp-in}.modal-anim-slideUp.modal-anim--leave{animation-name:modal-slideUp-out}@keyframes modal-slideUp-in{0%{opacity:0;transform:translateY(40px)}to{opacity:1;transform:none}}@keyframes modal-slideUp-out{0%{opacity:1;transform:translateY(0)}to{opacity:0;transform:translateY(40px)}}.modal-anim-slideDown.modal-anim--enter{animation-name:modal-slideDown-in}.modal-anim-slideDown.modal-anim--leave{animation-name:modal-slideDown-out}@keyframes modal-slideDown-in{0%{opacity:0;transform:translateY(-40px)}to{opacity:1;transform:none}}@keyframes modal-slideDown-out{0%{opacity:1;transform:translateY(0)}to{opacity:0;transform:translateY(-40px)}}.modal-anim-slideLeft.modal-anim--enter{animation-name:modal-slideLeft-in}.modal-anim-slideLeft.modal-anim--leave{animation-name:modal-slideLeft-out}@keyframes modal-slideLeft-in{0%{opacity:0;transform:translate(60px)}to{opacity:1;transform:none}}@keyframes modal-slideLeft-out{0%{opacity:1;transform:translate(0)}to{opacity:0;transform:translate(60px)}}.modal-anim-slideRight.modal-anim--enter{animation-name:modal-slideRight-in}.modal-anim-slideRight.modal-anim--leave{animation-name:modal-slideRight-out}@keyframes modal-slideRight-in{0%{opacity:0;transform:translate(-60px)}to{opacity:1;transform:none}}@keyframes modal-slideRight-out{0%{opacity:1;transform:translate(0)}to{opacity:0;transform:translate(-60px)}}.modal-anim-fade.modal-anim--enter{animation-name:modal-fade-in}.modal-anim-fade.modal-anim--leave{animation-name:modal-fade-out}@keyframes modal-fade-in{0%{opacity:0}to{opacity:1}}@keyframes modal-fade-out{0%{opacity:1}to{opacity:0}}.modal-anim-zoom.modal-anim--enter{animation-name:modal-zoom-in}.modal-anim-zoom.modal-anim--leave{animation-name:modal-zoom-out}@keyframes modal-zoom-in{0%{opacity:0;transform:scale(.85)}to{opacity:1;transform:none}}@keyframes modal-zoom-out{0%{opacity:1;transform:scale(1)}to{opacity:0;transform:scale(.85)}}.modal-anim-none{animation:none}@media(prefers-reduced-motion:reduce){.modal-panel,.modal-backdrop{animation-duration:1ms!important}}\n"],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: ModalContainer,
	decorators: [{
		type: Component,
		args: [{
			selector: "l-modal-container",
			changeDetection: ChangeDetectionStrategy.OnPush,
			imports: [],
			template: `
    <div
      class="modal-overlay"
      [class.modal-overlay--leaving]="_state() === 'leave'"
      [style.--modal-duration.ms]="config.animationDuration"
    >
      @if (config.backdrop !== false) {
        <div class="modal-backdrop" (click)="_onBackdropClick()"></div>
      }

      <div class="modal-scroll" (click)="_onBackdropClick()">
        <div
          #panel
          class="modal-panel"
          [class]="_panelClasses()"
          [style.width]="config.width"
          [style.height]="config.height"
          [style.maxWidth]="config.maxWidth"
          (click)="$event.stopPropagation()"
          (animationend)="_onAnimationEnd($event)"
        >
          <ng-container #content />
        </div>
      </div>
    </div>
  `,
			host: { "(document:keydown.escape)": "_onEscape()" },
			styles: [":host{--modal-duration: .25s}.modal-overlay{position:fixed;inset:0;z-index:1000}.modal-backdrop{position:fixed;inset:0;background:#07090f73;animation:modal-backdrop-in var(--modal-duration) ease forwards}.modal-overlay--leaving .modal-backdrop{animation:modal-backdrop-out var(--modal-duration) ease forwards}.modal-scroll{position:fixed;inset:0;display:flex;align-items:center;justify-content:center;padding:24px;overflow:auto}.modal-panel{position:relative;background:var(--bg-lightest);color:var(--text-primary);border-radius:12px;box-shadow:0 12px 40px #0d0d1240;max-width:90vw;animation-duration:var(--modal-duration);animation-timing-function:cubic-bezier(.4,0,.2,1);animation-fill-mode:both}@keyframes modal-backdrop-in{0%{opacity:0}to{opacity:1}}@keyframes modal-backdrop-out{0%{opacity:1}to{opacity:0}}.modal-anim-slideUp.modal-anim--enter{animation-name:modal-slideUp-in}.modal-anim-slideUp.modal-anim--leave{animation-name:modal-slideUp-out}@keyframes modal-slideUp-in{0%{opacity:0;transform:translateY(40px)}to{opacity:1;transform:none}}@keyframes modal-slideUp-out{0%{opacity:1;transform:translateY(0)}to{opacity:0;transform:translateY(40px)}}.modal-anim-slideDown.modal-anim--enter{animation-name:modal-slideDown-in}.modal-anim-slideDown.modal-anim--leave{animation-name:modal-slideDown-out}@keyframes modal-slideDown-in{0%{opacity:0;transform:translateY(-40px)}to{opacity:1;transform:none}}@keyframes modal-slideDown-out{0%{opacity:1;transform:translateY(0)}to{opacity:0;transform:translateY(-40px)}}.modal-anim-slideLeft.modal-anim--enter{animation-name:modal-slideLeft-in}.modal-anim-slideLeft.modal-anim--leave{animation-name:modal-slideLeft-out}@keyframes modal-slideLeft-in{0%{opacity:0;transform:translate(60px)}to{opacity:1;transform:none}}@keyframes modal-slideLeft-out{0%{opacity:1;transform:translate(0)}to{opacity:0;transform:translate(60px)}}.modal-anim-slideRight.modal-anim--enter{animation-name:modal-slideRight-in}.modal-anim-slideRight.modal-anim--leave{animation-name:modal-slideRight-out}@keyframes modal-slideRight-in{0%{opacity:0;transform:translate(-60px)}to{opacity:1;transform:none}}@keyframes modal-slideRight-out{0%{opacity:1;transform:translate(0)}to{opacity:0;transform:translate(-60px)}}.modal-anim-fade.modal-anim--enter{animation-name:modal-fade-in}.modal-anim-fade.modal-anim--leave{animation-name:modal-fade-out}@keyframes modal-fade-in{0%{opacity:0}to{opacity:1}}@keyframes modal-fade-out{0%{opacity:1}to{opacity:0}}.modal-anim-zoom.modal-anim--enter{animation-name:modal-zoom-in}.modal-anim-zoom.modal-anim--leave{animation-name:modal-zoom-out}@keyframes modal-zoom-in{0%{opacity:0;transform:scale(.85)}to{opacity:1;transform:none}}@keyframes modal-zoom-out{0%{opacity:1;transform:scale(1)}to{opacity:0;transform:scale(.85)}}.modal-anim-none{animation:none}@media(prefers-reduced-motion:reduce){.modal-panel,.modal-backdrop{animation-duration:1ms!important}}\n"]
		}]
	}],
	propDecorators: { _contentAnchor: [{
		type: i0.ViewChild,
		args: ["content", {
			read: ViewContainerRef,
			isSignal: true
		}]
	}] }
});
var ModalService = class ModalService {
	appRef = inject(ApplicationRef);
	injector = inject(Injector);
	envInjector = inject(EnvironmentInjector);
	openModals = [];
	open(content, config = {}) {
		const merged = {
			...MODAL_DEFAULTS,
			...config
		};
		const modalRef = new ModalRef(merged);
		const containerRef = createComponent(ModalContainer, { environmentInjector: this.envInjector });
		modalRef._containerRef = containerRef;
		const container = containerRef.instance;
		container.content = content;
		container.config = merged;
		container.modalRef = modalRef;
		container.parentInjector = this.injector;
		this.appRef.attachView(containerRef.hostView);
		document.body.appendChild(containerRef.location.nativeElement);
		this.openModals.push(modalRef);
		this.lockBodyScroll();
		modalRef.afterClosed().subscribe(() => this.dispose(modalRef));
		return modalRef;
	}
	closeAll() {
		[...this.openModals].forEach((m) => m.close());
	}
	dispose(modalRef) {
		const index = this.openModals.indexOf(modalRef);
		if (index === -1) return;
		this.openModals.splice(index, 1);
		const containerRef = modalRef._containerRef;
		if (containerRef) {
			this.appRef.detachView(containerRef.hostView);
			containerRef.destroy();
		}
		if (this.openModals.length === 0) document.body.style.overflow = "";
	}
	lockBodyScroll() {
		document.body.style.overflow = "hidden";
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.1",
		ngImport: i0,
		type: ModalService,
		deps: [],
		target: i0.ɵɵFactoryTarget.Injectable
	});
	static ɵprov = i0.ɵɵngDeclareInjectable({
		minVersion: "12.0.0",
		version: "22.2.1",
		ngImport: i0,
		type: ModalService,
		providedIn: "root"
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: ModalService,
	decorators: [{
		type: Injectable,
		args: [{ providedIn: "root" }]
	}]
});
var ConfirmDialog = class ConfirmDialog {
	ref = inject(ModalRef);
	data = inject(MODAL_DATA) ?? {};
	_loading = signal(false, ...ngDevMode ? [{ debugName: "_loading" }] : /* istanbul ignore next */ []);
	confirm() {
		if (this._loading()) return;
		if (!this.data.onConfirm) {
			this.ref.close(true);
			return;
		}
		this.ref.config.disableClose = true;
		this._loading.set(true);
		this.data.onConfirm().subscribe({
			next: () => {
				this.ref.config.disableClose = false;
				this.ref.close(true);
			},
			error: () => {
				this._loading.set(false);
				this.ref.config.disableClose = false;
			}
		});
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.1",
		ngImport: i0,
		type: ConfirmDialog,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "14.0.0",
		version: "22.2.1",
		type: ConfirmDialog,
		isStandalone: true,
		selector: "l-confirm-dialog",
		ngImport: i0,
		template: `
    <div class="confirm-dialog">
      <h2 class="confirm-dialog__title">{{ data.title || 'Confirm' }}</h2>
      <p class="confirm-dialog__message">{{ data.message || 'Are you sure?' }}</p>

      <div class="confirm-dialog__actions">
        <l-button variant="outlined" [disabled]="_loading()" (click)="ref.close(false)">
          {{ data.cancelText || 'Cancel' }}
        </l-button>
        <l-button
          [variant]="data.confirmVariant || 'danger'"
          [disabled]="_loading()"
          (click)="confirm()"
        >
          {{ _loading() ? 'Working…' : data.confirmText || 'Delete' }}
        </l-button>
      </div>
    </div>
  `,
		isInline: true,
		styles: [".confirm-dialog{width:360px;max-width:100%;padding:20px}.confirm-dialog__title{margin:0 0 8px;font-size:18px;font-weight:700;line-height:24px;color:var(--text-primary)}.confirm-dialog__message{margin:0 0 20px;font-size:14px;line-height:20px;color:var(--text-secondary)}.confirm-dialog__actions{display:flex;align-items:center;justify-content:flex-end;gap:8px}\n"],
		dependencies: [{
			kind: "component",
			type: Button,
			selector: "l-button",
			inputs: [
				"variant",
				"size",
				"width",
				"rounded",
				"disabled"
			]
		}],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: ConfirmDialog,
	decorators: [{
		type: Component,
		args: [{
			selector: "l-confirm-dialog",
			changeDetection: ChangeDetectionStrategy.OnPush,
			imports: [Button],
			template: `
    <div class="confirm-dialog">
      <h2 class="confirm-dialog__title">{{ data.title || 'Confirm' }}</h2>
      <p class="confirm-dialog__message">{{ data.message || 'Are you sure?' }}</p>

      <div class="confirm-dialog__actions">
        <l-button variant="outlined" [disabled]="_loading()" (click)="ref.close(false)">
          {{ data.cancelText || 'Cancel' }}
        </l-button>
        <l-button
          [variant]="data.confirmVariant || 'danger'"
          [disabled]="_loading()"
          (click)="confirm()"
        >
          {{ _loading() ? 'Working…' : data.confirmText || 'Delete' }}
        </l-button>
      </div>
    </div>
  `,
			styles: [".confirm-dialog{width:360px;max-width:100%;padding:20px}.confirm-dialog__title{margin:0 0 8px;font-size:18px;font-weight:700;line-height:24px;color:var(--text-primary)}.confirm-dialog__message{margin:0 0 20px;font-size:14px;line-height:20px;color:var(--text-secondary)}.confirm-dialog__actions{display:flex;align-items:center;justify-content:flex-end;gap:8px}\n"]
		}]
	}]
});
var DrawerRef = class {
	config;
	componentInstance = null;
	_containerRef;
	_startClose = () => this._finishClose();
	_afterClosed = new Subject();
	_result;
	_closing = false;
	constructor(config) {
		this.config = config;
	}
	close(result) {
		if (this._closing) return;
		this._closing = true;
		this._result = result;
		this._startClose();
	}
	_finishClose() {
		this._afterClosed.next(this._result);
		this._afterClosed.complete();
	}
	afterClosed() {
		return this._afterClosed.asObservable();
	}
};
const DRAWER_DEFAULTS = {
	position: "right",
	backdrop: true,
	disableClose: false,
	animationDuration: 280
};
const DRAWER_DATA = new InjectionToken("DRAWER_DATA");
var DrawerContainer = class DrawerContainer {
	content;
	config;
	drawerRef;
	parentInjector;
	_state = signal("enter", ...ngDevMode ? [{ debugName: "_state" }] : /* istanbul ignore next */ []);
	_contentAnchor = viewChild.required("content", {
		...ngDevMode ? { debugName: "_contentAnchor" } : /* istanbul ignore next */ {},
		read: ViewContainerRef
	});
	_cdr = inject(ChangeDetectorRef);
	_isHorizontal = computed(() => {
		const pos = this.config.position ?? "right";
		return pos === "left" || pos === "right";
	}, ...ngDevMode ? [{ debugName: "_isHorizontal" }] : /* istanbul ignore next */ []);
	_panelClasses = computed(() => {
		const classes = [
			"drawer-panel",
			`drawer-panel--${this.config.position ?? "right"}`,
			`drawer-anim--${this._state()}`
		];
		const extra = this.config.panelClass;
		if (extra) classes.push(...Array.isArray(extra) ? extra : [extra]);
		return classes.join(" ");
	}, ...ngDevMode ? [{ debugName: "_panelClasses" }] : /* istanbul ignore next */ []);
	ngAfterViewInit() {
		this.drawerRef._startClose = () => this._startLeave();
		this._renderContent();
		this._cdr.detectChanges();
	}
	_onAnimationEnd(event) {
		if (event.target === event.currentTarget && this._state() === "leave") this.drawerRef._finishClose();
	}
	_onBackdropClick() {
		if (!this.config.disableClose) this.drawerRef.close();
	}
	_onEscape() {
		if (!this.config.disableClose) this.drawerRef.close();
	}
	_renderContent() {
		const anchor = this._contentAnchor();
		if (this.content instanceof TemplateRef) anchor.createEmbeddedView(this.content, {
			$implicit: this.config.data,
			data: this.config.data,
			drawerRef: this.drawerRef
		});
		else {
			const injector = Injector.create({
				parent: this.parentInjector,
				providers: [{
					provide: DrawerRef,
					useValue: this.drawerRef
				}, {
					provide: DRAWER_DATA,
					useValue: this.config.data ?? null
				}]
			});
			const ref = anchor.createComponent(this.content, { injector });
			this.drawerRef.componentInstance = ref.instance;
		}
	}
	_startLeave() {
		if (this._state() === "leave") return;
		this._state.set("leave");
		this._cdr.detectChanges();
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.1",
		ngImport: i0,
		type: DrawerContainer,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.1",
		type: DrawerContainer,
		isStandalone: true,
		selector: "l-drawer-container",
		host: { listeners: { "document:keydown.escape": "_onEscape()" } },
		viewQueries: [{
			propertyName: "_contentAnchor",
			first: true,
			predicate: ["content"],
			descendants: true,
			read: ViewContainerRef,
			isSignal: true
		}],
		ngImport: i0,
		template: `
    <div
      class="drawer-overlay"
      [class.drawer-overlay--leaving]="_state() === 'leave'"
      [style.--drawer-duration.ms]="config.animationDuration"
    >
      @if (config.backdrop !== false) {
        <div class="drawer-backdrop" (click)="_onBackdropClick()"></div>
      }

      <div
        class="drawer-panel"
        [class]="_panelClasses()"
        [style.width]="_isHorizontal() ? config.size : null"
        [style.height]="!_isHorizontal() ? config.size : null"
        role="dialog"
        aria-modal="true"
        (animationend)="_onAnimationEnd($event)"
      >
        <ng-container #content />
      </div>
    </div>
  `,
		isInline: true,
		styles: [":host{--drawer-duration: .28s}.drawer-overlay{position:fixed;inset:0;z-index:1000}.drawer-backdrop{position:fixed;inset:0;background:#07090f73;animation:drawer-backdrop-in var(--drawer-duration) ease forwards}.drawer-overlay--leaving .drawer-backdrop{animation:drawer-backdrop-out var(--drawer-duration) ease forwards}.drawer-panel{position:fixed;background:var(--bg-lightest);color:var(--text-primary);box-shadow:0 12px 40px #0d0d1240;overflow:auto;animation-duration:var(--drawer-duration);animation-timing-function:cubic-bezier(.4,0,.2,1);animation-fill-mode:both}.drawer-panel--left,.drawer-panel--right{top:0;bottom:0;width:380px;max-width:90vw}.drawer-panel--left{left:0}.drawer-panel--right{right:0}.drawer-panel--bottom{left:0;right:0;bottom:0;height:40vh;max-height:96vh}.drawer-panel--left.drawer-anim--enter{animation-name:drawer-left-in}.drawer-panel--left.drawer-anim--leave{animation-name:drawer-left-out}@keyframes drawer-left-in{0%{transform:translate(-100%)}to{transform:none}}@keyframes drawer-left-out{0%{transform:translate(0)}to{transform:translate(-100%)}}.drawer-panel--right.drawer-anim--enter{animation-name:drawer-right-in}.drawer-panel--right.drawer-anim--leave{animation-name:drawer-right-out}@keyframes drawer-right-in{0%{transform:translate(100%)}to{transform:none}}@keyframes drawer-right-out{0%{transform:translate(0)}to{transform:translate(100%)}}.drawer-panel--bottom.drawer-anim--enter{animation-name:drawer-bottom-in}.drawer-panel--bottom.drawer-anim--leave{animation-name:drawer-bottom-out}@keyframes drawer-bottom-in{0%{transform:translateY(100%)}to{transform:none}}@keyframes drawer-bottom-out{0%{transform:translateY(0)}to{transform:translateY(100%)}}@keyframes drawer-backdrop-in{0%{opacity:0}to{opacity:1}}@keyframes drawer-backdrop-out{0%{opacity:1}to{opacity:0}}@media(prefers-reduced-motion:reduce){.drawer-panel,.drawer-backdrop{animation-duration:1ms!important}}\n"],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: DrawerContainer,
	decorators: [{
		type: Component,
		args: [{
			selector: "l-drawer-container",
			changeDetection: ChangeDetectionStrategy.OnPush,
			imports: [],
			template: `
    <div
      class="drawer-overlay"
      [class.drawer-overlay--leaving]="_state() === 'leave'"
      [style.--drawer-duration.ms]="config.animationDuration"
    >
      @if (config.backdrop !== false) {
        <div class="drawer-backdrop" (click)="_onBackdropClick()"></div>
      }

      <div
        class="drawer-panel"
        [class]="_panelClasses()"
        [style.width]="_isHorizontal() ? config.size : null"
        [style.height]="!_isHorizontal() ? config.size : null"
        role="dialog"
        aria-modal="true"
        (animationend)="_onAnimationEnd($event)"
      >
        <ng-container #content />
      </div>
    </div>
  `,
			host: { "(document:keydown.escape)": "_onEscape()" },
			styles: [":host{--drawer-duration: .28s}.drawer-overlay{position:fixed;inset:0;z-index:1000}.drawer-backdrop{position:fixed;inset:0;background:#07090f73;animation:drawer-backdrop-in var(--drawer-duration) ease forwards}.drawer-overlay--leaving .drawer-backdrop{animation:drawer-backdrop-out var(--drawer-duration) ease forwards}.drawer-panel{position:fixed;background:var(--bg-lightest);color:var(--text-primary);box-shadow:0 12px 40px #0d0d1240;overflow:auto;animation-duration:var(--drawer-duration);animation-timing-function:cubic-bezier(.4,0,.2,1);animation-fill-mode:both}.drawer-panel--left,.drawer-panel--right{top:0;bottom:0;width:380px;max-width:90vw}.drawer-panel--left{left:0}.drawer-panel--right{right:0}.drawer-panel--bottom{left:0;right:0;bottom:0;height:40vh;max-height:96vh}.drawer-panel--left.drawer-anim--enter{animation-name:drawer-left-in}.drawer-panel--left.drawer-anim--leave{animation-name:drawer-left-out}@keyframes drawer-left-in{0%{transform:translate(-100%)}to{transform:none}}@keyframes drawer-left-out{0%{transform:translate(0)}to{transform:translate(-100%)}}.drawer-panel--right.drawer-anim--enter{animation-name:drawer-right-in}.drawer-panel--right.drawer-anim--leave{animation-name:drawer-right-out}@keyframes drawer-right-in{0%{transform:translate(100%)}to{transform:none}}@keyframes drawer-right-out{0%{transform:translate(0)}to{transform:translate(100%)}}.drawer-panel--bottom.drawer-anim--enter{animation-name:drawer-bottom-in}.drawer-panel--bottom.drawer-anim--leave{animation-name:drawer-bottom-out}@keyframes drawer-bottom-in{0%{transform:translateY(100%)}to{transform:none}}@keyframes drawer-bottom-out{0%{transform:translateY(0)}to{transform:translateY(100%)}}@keyframes drawer-backdrop-in{0%{opacity:0}to{opacity:1}}@keyframes drawer-backdrop-out{0%{opacity:1}to{opacity:0}}@media(prefers-reduced-motion:reduce){.drawer-panel,.drawer-backdrop{animation-duration:1ms!important}}\n"]
		}]
	}],
	propDecorators: { _contentAnchor: [{
		type: i0.ViewChild,
		args: ["content", {
			read: ViewContainerRef,
			isSignal: true
		}]
	}] }
});
var DrawerService = class DrawerService {
	appRef = inject(ApplicationRef);
	injector = inject(Injector);
	envInjector = inject(EnvironmentInjector);
	openDrawers = [];
	open(content, config = {}) {
		const merged = {
			...DRAWER_DEFAULTS,
			...config
		};
		const drawerRef = new DrawerRef(merged);
		const containerRef = createComponent(DrawerContainer, { environmentInjector: this.envInjector });
		drawerRef._containerRef = containerRef;
		const container = containerRef.instance;
		container.content = content;
		container.config = merged;
		container.drawerRef = drawerRef;
		container.parentInjector = this.injector;
		this.appRef.attachView(containerRef.hostView);
		document.body.appendChild(containerRef.location.nativeElement);
		this.openDrawers.push(drawerRef);
		this.lockBodyScroll();
		drawerRef.afterClosed().subscribe(() => this.dispose(drawerRef));
		return drawerRef;
	}
	closeAll() {
		[...this.openDrawers].forEach((d) => d.close());
	}
	dispose(drawerRef) {
		const index = this.openDrawers.indexOf(drawerRef);
		if (index === -1) return;
		this.openDrawers.splice(index, 1);
		const containerRef = drawerRef._containerRef;
		if (containerRef) {
			this.appRef.detachView(containerRef.hostView);
			containerRef.destroy();
		}
		if (this.openDrawers.length === 0) document.body.style.overflow = "";
	}
	lockBodyScroll() {
		document.body.style.overflow = "hidden";
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.1",
		ngImport: i0,
		type: DrawerService,
		deps: [],
		target: i0.ɵɵFactoryTarget.Injectable
	});
	static ɵprov = i0.ɵɵngDeclareInjectable({
		minVersion: "12.0.0",
		version: "22.2.1",
		ngImport: i0,
		type: DrawerService,
		providedIn: "root"
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: DrawerService,
	decorators: [{
		type: Injectable,
		args: [{ providedIn: "root" }]
	}]
});
var Notification = class Notification {
	type = input("info", ...ngDevMode ? [{ debugName: "type" }] : /* istanbul ignore next */ []);
	title = input(...ngDevMode ? [void 0, { debugName: "title" }] : /* istanbul ignore next */ []);
	message = input(...ngDevMode ? [void 0, { debugName: "message" }] : /* istanbul ignore next */ []);
	position = input("topRight", ...ngDevMode ? [{ debugName: "position" }] : /* istanbul ignore next */ []);
	duration = input(4e3, ...ngDevMode ? [{ debugName: "duration" }] : /* istanbul ignore next */ []);
	pauseOnHover = input(true, ...ngDevMode ? [{ debugName: "pauseOnHover" }] : /* istanbul ignore next */ []);
	showProgress = input(true, ...ngDevMode ? [{ debugName: "showProgress" }] : /* istanbul ignore next */ []);
	showClose = input(true, ...ngDevMode ? [{ debugName: "showClose" }] : /* istanbul ignore next */ []);
	withIcon = input(true, ...ngDevMode ? [{ debugName: "withIcon" }] : /* istanbul ignore next */ []);
	leaving = input(false, ...ngDevMode ? [{ debugName: "leaving" }] : /* istanbul ignore next */ []);
	requestDismiss = output();
	closed = output();
	_hostClasses = computed(() => `l-notification l-notification--${this.type()} l-notification--${this.position()}`, ...ngDevMode ? [{ debugName: "_hostClasses" }] : /* istanbul ignore next */ []);
	_onProgressEnd() {
		this.requestDismiss.emit();
	}
	_onAnimationEnd(event) {
		if (event.target === event.currentTarget && this.leaving()) this.closed.emit();
	}
	_onClose() {
		this.requestDismiss.emit();
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.1",
		ngImport: i0,
		type: Notification,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.1",
		type: Notification,
		isStandalone: true,
		selector: "l-notification",
		inputs: {
			type: {
				classPropertyName: "type",
				publicName: "type",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			title: {
				classPropertyName: "title",
				publicName: "title",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			message: {
				classPropertyName: "message",
				publicName: "message",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			position: {
				classPropertyName: "position",
				publicName: "position",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			duration: {
				classPropertyName: "duration",
				publicName: "duration",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			pauseOnHover: {
				classPropertyName: "pauseOnHover",
				publicName: "pauseOnHover",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			showProgress: {
				classPropertyName: "showProgress",
				publicName: "showProgress",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			showClose: {
				classPropertyName: "showClose",
				publicName: "showClose",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			withIcon: {
				classPropertyName: "withIcon",
				publicName: "withIcon",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			leaving: {
				classPropertyName: "leaving",
				publicName: "leaving",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: {
			requestDismiss: "requestDismiss",
			closed: "closed"
		},
		host: {
			attributes: { "role": "alert" },
			listeners: { "animationend": "_onAnimationEnd($event)" },
			properties: {
				"class": "_hostClasses()",
				"class.pause": "pauseOnHover()",
				"class.is-leaving": "leaving()"
			}
		},
		ngImport: i0,
		template: "@if (withIcon()) {\n  <span class=\"l-notification__icon\" aria-hidden=\"true\">\n    @switch (type()) {\n      @case ('success') {\n        <svg\n          width=\"20\"\n          height=\"20\"\n          viewBox=\"0 0 20 20\"\n          fill=\"none\"\n          xmlns=\"http://www.w3.org/2000/svg\"\n        >\n          <circle cx=\"10\" cy=\"10\" r=\"9\" fill=\"currentColor\" opacity=\"0.14\" />\n          <path\n            d=\"M6 10.5 9 13.5 14.5 7\"\n            stroke=\"currentColor\"\n            stroke-width=\"1.75\"\n            stroke-linecap=\"round\"\n            stroke-linejoin=\"round\"\n          />\n        </svg>\n      }\n      @case ('error') {\n        <svg\n          width=\"20\"\n          height=\"20\"\n          viewBox=\"0 0 20 20\"\n          fill=\"none\"\n          xmlns=\"http://www.w3.org/2000/svg\"\n        >\n          <circle cx=\"10\" cy=\"10\" r=\"9\" fill=\"currentColor\" opacity=\"0.14\" />\n          <path\n            d=\"M7 7l6 6M13 7l-6 6\"\n            stroke=\"currentColor\"\n            stroke-width=\"1.75\"\n            stroke-linecap=\"round\"\n          />\n        </svg>\n      }\n      @case ('warn') {\n        <svg\n          width=\"20\"\n          height=\"20\"\n          viewBox=\"0 0 20 20\"\n          fill=\"none\"\n          xmlns=\"http://www.w3.org/2000/svg\"\n        >\n          <circle cx=\"10\" cy=\"10\" r=\"9\" fill=\"currentColor\" opacity=\"0.14\" />\n          <path d=\"M10 5.5v5\" stroke=\"currentColor\" stroke-width=\"1.75\" stroke-linecap=\"round\" />\n          <circle cx=\"10\" cy=\"14\" r=\"1\" fill=\"currentColor\" />\n        </svg>\n      }\n      @default {\n        <svg\n          width=\"20\"\n          height=\"20\"\n          viewBox=\"0 0 20 20\"\n          fill=\"none\"\n          xmlns=\"http://www.w3.org/2000/svg\"\n        >\n          <circle cx=\"10\" cy=\"10\" r=\"9\" fill=\"currentColor\" opacity=\"0.14\" />\n          <path d=\"M10 9.5v5\" stroke=\"currentColor\" stroke-width=\"1.75\" stroke-linecap=\"round\" />\n          <circle cx=\"10\" cy=\"6\" r=\"1\" fill=\"currentColor\" />\n        </svg>\n      }\n    }\n  </span>\n}\n\n<div class=\"l-notification__body\">\n  @if (title()) {\n    <p class=\"l-notification__title\">{{ title() }}</p>\n  }\n  @if (message()) {\n    <p class=\"l-notification__message\">{{ message() }}</p>\n  }\n</div>\n\n@if (showClose()) {\n  <button type=\"button\" class=\"l-notification__close\" aria-label=\"Dismiss\" (click)=\"_onClose()\">\n    <svg width=\"14\" height=\"14\" viewBox=\"0 0 20 20\" fill=\"none\" xmlns=\"http://www.w3.org/2000/svg\">\n      <path\n        d=\"M15 5 5 15M5 5l10 10\"\n        stroke=\"currentColor\"\n        stroke-width=\"1.6\"\n        stroke-linecap=\"round\"\n      />\n    </svg>\n  </button>\n}\n\n@if (duration() > 0) {\n  <div class=\"l-notification__progress\" [class.is-hidden]=\"!showProgress()\">\n    <span\n      class=\"l-notification__progress-bar\"\n      [style.animation-duration.ms]=\"duration()\"\n      (animationend)=\"_onProgressEnd()\"\n    ></span>\n  </div>\n}\n",
		styles: [":host{position:relative;display:flex;align-items:flex-start;gap:10px;width:360px;max-width:calc(100vw - 32px);padding:14px 14px 14px 16px;border-radius:10px;background:var(--bg-lightest);box-shadow:0 8px 28px #0d0d1229;overflow:hidden;pointer-events:auto}:host:before{content:\"\";position:absolute;inset:0 auto 0 0;width:4px;background:var(--_accent)}:host(.l-notification--success){--_accent: var(--success)}:host(.l-notification--error){--_accent: var(--error)}:host(.l-notification--warn){--_accent: var(--warn)}:host(.l-notification--info){--_accent: var(--info)}.l-notification__icon{flex-shrink:0;display:inline-flex;margin-top:1px;color:var(--_accent)}.l-notification__body{flex:1;min-width:0}.l-notification__title{margin:0;font-size:14px;font-weight:700;line-height:20px;color:var(--text-primary)}.l-notification__message{margin:2px 0 0;font-size:13px;line-height:19px;color:var(--text-secondary);overflow-wrap:anywhere}.l-notification__close{flex-shrink:0;display:inline-flex;align-items:center;justify-content:center;padding:2px;margin:-2px -2px 0 0;border:none;background:transparent;border-radius:4px;color:var(--text-tertiary);cursor:pointer;transition:color .12s ease-out,background-color .12s ease-out}.l-notification__close:hover{color:var(--text-primary);background:var(--bg-dark)}.l-notification__close:focus-visible{outline:2px solid var(--_accent);outline-offset:1px}.l-notification__progress{position:absolute;inset:auto 0 0;height:3px;background:transparent}.l-notification__progress.is-hidden{height:0}.l-notification__progress-bar{display:block;height:100%;width:100%;background:var(--_accent);transform-origin:left center;animation-name:l-notification-progress;animation-timing-function:linear;animation-fill-mode:forwards}:host(.pause:hover) .l-notification__progress-bar{animation-play-state:paused}@keyframes l-notification-progress{0%{transform:scaleX(1)}to{transform:scaleX(0)}}:host{animation:l-notification-in .22s cubic-bezier(.4,0,.2,1) both}:host(.is-leaving){animation:l-notification-out .18s ease-in forwards}:host(.l-notification--topRight),:host(.l-notification--bottomRight){--_enter-x: 24px}:host(.l-notification--topLeft),:host(.l-notification--bottomLeft){--_enter-x: -24px}:host(.l-notification--top){--_enter-y: -24px}:host(.l-notification--bottom){--_enter-y: 24px}@keyframes l-notification-in{0%{opacity:0;transform:translate(var(--_enter-x, 0),var(--_enter-y, 0)) scale(.98)}to{opacity:1;transform:translate(0) scale(1)}}@keyframes l-notification-out{to{opacity:0;transform:translate(var(--_enter-x, 0),var(--_enter-y, 0)) scale(.98)}}@media(prefers-reduced-motion:reduce){:host,:host(.is-leaving){animation-duration:1ms}.l-notification__progress-bar{animation-timing-function:linear}}\n"],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: Notification,
	decorators: [{
		type: Component,
		args: [{
			selector: "l-notification",
			changeDetection: ChangeDetectionStrategy.OnPush,
			host: {
				"[class]": "_hostClasses()",
				"[class.pause]": "pauseOnHover()",
				"[class.is-leaving]": "leaving()",
				role: "alert",
				"(animationend)": "_onAnimationEnd($event)"
			},
			template: "@if (withIcon()) {\n  <span class=\"l-notification__icon\" aria-hidden=\"true\">\n    @switch (type()) {\n      @case ('success') {\n        <svg\n          width=\"20\"\n          height=\"20\"\n          viewBox=\"0 0 20 20\"\n          fill=\"none\"\n          xmlns=\"http://www.w3.org/2000/svg\"\n        >\n          <circle cx=\"10\" cy=\"10\" r=\"9\" fill=\"currentColor\" opacity=\"0.14\" />\n          <path\n            d=\"M6 10.5 9 13.5 14.5 7\"\n            stroke=\"currentColor\"\n            stroke-width=\"1.75\"\n            stroke-linecap=\"round\"\n            stroke-linejoin=\"round\"\n          />\n        </svg>\n      }\n      @case ('error') {\n        <svg\n          width=\"20\"\n          height=\"20\"\n          viewBox=\"0 0 20 20\"\n          fill=\"none\"\n          xmlns=\"http://www.w3.org/2000/svg\"\n        >\n          <circle cx=\"10\" cy=\"10\" r=\"9\" fill=\"currentColor\" opacity=\"0.14\" />\n          <path\n            d=\"M7 7l6 6M13 7l-6 6\"\n            stroke=\"currentColor\"\n            stroke-width=\"1.75\"\n            stroke-linecap=\"round\"\n          />\n        </svg>\n      }\n      @case ('warn') {\n        <svg\n          width=\"20\"\n          height=\"20\"\n          viewBox=\"0 0 20 20\"\n          fill=\"none\"\n          xmlns=\"http://www.w3.org/2000/svg\"\n        >\n          <circle cx=\"10\" cy=\"10\" r=\"9\" fill=\"currentColor\" opacity=\"0.14\" />\n          <path d=\"M10 5.5v5\" stroke=\"currentColor\" stroke-width=\"1.75\" stroke-linecap=\"round\" />\n          <circle cx=\"10\" cy=\"14\" r=\"1\" fill=\"currentColor\" />\n        </svg>\n      }\n      @default {\n        <svg\n          width=\"20\"\n          height=\"20\"\n          viewBox=\"0 0 20 20\"\n          fill=\"none\"\n          xmlns=\"http://www.w3.org/2000/svg\"\n        >\n          <circle cx=\"10\" cy=\"10\" r=\"9\" fill=\"currentColor\" opacity=\"0.14\" />\n          <path d=\"M10 9.5v5\" stroke=\"currentColor\" stroke-width=\"1.75\" stroke-linecap=\"round\" />\n          <circle cx=\"10\" cy=\"6\" r=\"1\" fill=\"currentColor\" />\n        </svg>\n      }\n    }\n  </span>\n}\n\n<div class=\"l-notification__body\">\n  @if (title()) {\n    <p class=\"l-notification__title\">{{ title() }}</p>\n  }\n  @if (message()) {\n    <p class=\"l-notification__message\">{{ message() }}</p>\n  }\n</div>\n\n@if (showClose()) {\n  <button type=\"button\" class=\"l-notification__close\" aria-label=\"Dismiss\" (click)=\"_onClose()\">\n    <svg width=\"14\" height=\"14\" viewBox=\"0 0 20 20\" fill=\"none\" xmlns=\"http://www.w3.org/2000/svg\">\n      <path\n        d=\"M15 5 5 15M5 5l10 10\"\n        stroke=\"currentColor\"\n        stroke-width=\"1.6\"\n        stroke-linecap=\"round\"\n      />\n    </svg>\n  </button>\n}\n\n@if (duration() > 0) {\n  <div class=\"l-notification__progress\" [class.is-hidden]=\"!showProgress()\">\n    <span\n      class=\"l-notification__progress-bar\"\n      [style.animation-duration.ms]=\"duration()\"\n      (animationend)=\"_onProgressEnd()\"\n    ></span>\n  </div>\n}\n",
			styles: [":host{position:relative;display:flex;align-items:flex-start;gap:10px;width:360px;max-width:calc(100vw - 32px);padding:14px 14px 14px 16px;border-radius:10px;background:var(--bg-lightest);box-shadow:0 8px 28px #0d0d1229;overflow:hidden;pointer-events:auto}:host:before{content:\"\";position:absolute;inset:0 auto 0 0;width:4px;background:var(--_accent)}:host(.l-notification--success){--_accent: var(--success)}:host(.l-notification--error){--_accent: var(--error)}:host(.l-notification--warn){--_accent: var(--warn)}:host(.l-notification--info){--_accent: var(--info)}.l-notification__icon{flex-shrink:0;display:inline-flex;margin-top:1px;color:var(--_accent)}.l-notification__body{flex:1;min-width:0}.l-notification__title{margin:0;font-size:14px;font-weight:700;line-height:20px;color:var(--text-primary)}.l-notification__message{margin:2px 0 0;font-size:13px;line-height:19px;color:var(--text-secondary);overflow-wrap:anywhere}.l-notification__close{flex-shrink:0;display:inline-flex;align-items:center;justify-content:center;padding:2px;margin:-2px -2px 0 0;border:none;background:transparent;border-radius:4px;color:var(--text-tertiary);cursor:pointer;transition:color .12s ease-out,background-color .12s ease-out}.l-notification__close:hover{color:var(--text-primary);background:var(--bg-dark)}.l-notification__close:focus-visible{outline:2px solid var(--_accent);outline-offset:1px}.l-notification__progress{position:absolute;inset:auto 0 0;height:3px;background:transparent}.l-notification__progress.is-hidden{height:0}.l-notification__progress-bar{display:block;height:100%;width:100%;background:var(--_accent);transform-origin:left center;animation-name:l-notification-progress;animation-timing-function:linear;animation-fill-mode:forwards}:host(.pause:hover) .l-notification__progress-bar{animation-play-state:paused}@keyframes l-notification-progress{0%{transform:scaleX(1)}to{transform:scaleX(0)}}:host{animation:l-notification-in .22s cubic-bezier(.4,0,.2,1) both}:host(.is-leaving){animation:l-notification-out .18s ease-in forwards}:host(.l-notification--topRight),:host(.l-notification--bottomRight){--_enter-x: 24px}:host(.l-notification--topLeft),:host(.l-notification--bottomLeft){--_enter-x: -24px}:host(.l-notification--top){--_enter-y: -24px}:host(.l-notification--bottom){--_enter-y: 24px}@keyframes l-notification-in{0%{opacity:0;transform:translate(var(--_enter-x, 0),var(--_enter-y, 0)) scale(.98)}to{opacity:1;transform:translate(0) scale(1)}}@keyframes l-notification-out{to{opacity:0;transform:translate(var(--_enter-x, 0),var(--_enter-y, 0)) scale(.98)}}@media(prefers-reduced-motion:reduce){:host,:host(.is-leaving){animation-duration:1ms}.l-notification__progress-bar{animation-timing-function:linear}}\n"]
		}]
	}],
	propDecorators: {
		type: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "type",
				required: false
			}]
		}],
		title: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "title",
				required: false
			}]
		}],
		message: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "message",
				required: false
			}]
		}],
		position: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "position",
				required: false
			}]
		}],
		duration: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "duration",
				required: false
			}]
		}],
		pauseOnHover: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "pauseOnHover",
				required: false
			}]
		}],
		showProgress: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "showProgress",
				required: false
			}]
		}],
		showClose: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "showClose",
				required: false
			}]
		}],
		withIcon: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "withIcon",
				required: false
			}]
		}],
		leaving: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "leaving",
				required: false
			}]
		}],
		requestDismiss: [{
			type: i0.Output,
			args: ["requestDismiss"]
		}],
		closed: [{
			type: i0.Output,
			args: ["closed"]
		}]
	}
});
const POSITIONS = [
	"top",
	"topLeft",
	"topRight",
	"bottom",
	"bottomLeft",
	"bottomRight"
];
var NotificationContainer = class NotificationContainer {
	_positions = POSITIONS;
	_items = signal([], ...ngDevMode ? [{ debugName: "_items" }] : /* istanbul ignore next */ []);
	_grouped = computed(() => {
		const groups = {
			top: [],
			topLeft: [],
			topRight: [],
			bottom: [],
			bottomLeft: [],
			bottomRight: []
		};
		for (const item of this._items()) groups[item.position].push(item);
		return groups;
	}, ...ngDevMode ? [{ debugName: "_grouped" }] : /* istanbul ignore next */ []);
	add(item) {
		this._items.update((items) => [...items, item]);
	}
	dismiss(id) {
		this._items().find((n) => n.id === id)?.leaving.set(true);
	}
	clear() {
		this._items().forEach((n) => n.leaving.set(true));
	}
	_remove(id) {
		this._items.update((items) => items.filter((n) => n.id !== id));
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.1",
		ngImport: i0,
		type: NotificationContainer,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.1",
		type: NotificationContainer,
		isStandalone: true,
		selector: "l-notification-container",
		ngImport: i0,
		template: `
    @for (pos of _positions; track pos) {
      @if (_grouped()[pos].length) {
        <div class="notif-region" [class]="'notif-region--' + pos">
          @for (n of _grouped()[pos]; track n.id) {
            <l-notification
              [type]="n.type"
              [title]="n.title"
              [message]="n.message"
              [position]="n.position"
              [duration]="n.duration"
              [pauseOnHover]="n.pauseOnHover"
              [showProgress]="n.showProgress"
              [showClose]="n.showClose"
              [withIcon]="n.withIcon"
              [leaving]="n.leaving()"
              (requestDismiss)="dismiss(n.id)"
              (closed)="_remove(n.id)"
            />
          }
        </div>
      }
    }
  `,
		isInline: true,
		styles: [".notif-region{position:fixed;z-index:1100;display:flex;flex-direction:column;gap:12px;padding:16px;pointer-events:none;max-height:100vh;overflow:hidden}.notif-region--top,.notif-region--topLeft,.notif-region--topRight{flex-direction:column-reverse}.notif-region--top{top:0;left:50%;transform:translate(-50%);align-items:center}.notif-region--bottom{bottom:0;left:50%;transform:translate(-50%);align-items:center}.notif-region--topLeft{top:0;left:0;align-items:flex-start}.notif-region--topRight{top:0;right:0;align-items:flex-end}.notif-region--bottomLeft{bottom:0;left:0;align-items:flex-start}.notif-region--bottomRight{bottom:0;right:0;align-items:flex-end}\n"],
		dependencies: [{
			kind: "component",
			type: Notification,
			selector: "l-notification",
			inputs: [
				"type",
				"title",
				"message",
				"position",
				"duration",
				"pauseOnHover",
				"showProgress",
				"showClose",
				"withIcon",
				"leaving"
			],
			outputs: ["requestDismiss", "closed"]
		}],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: NotificationContainer,
	decorators: [{
		type: Component,
		args: [{
			selector: "l-notification-container",
			changeDetection: ChangeDetectionStrategy.OnPush,
			imports: [Notification],
			template: `
    @for (pos of _positions; track pos) {
      @if (_grouped()[pos].length) {
        <div class="notif-region" [class]="'notif-region--' + pos">
          @for (n of _grouped()[pos]; track n.id) {
            <l-notification
              [type]="n.type"
              [title]="n.title"
              [message]="n.message"
              [position]="n.position"
              [duration]="n.duration"
              [pauseOnHover]="n.pauseOnHover"
              [showProgress]="n.showProgress"
              [showClose]="n.showClose"
              [withIcon]="n.withIcon"
              [leaving]="n.leaving()"
              (requestDismiss)="dismiss(n.id)"
              (closed)="_remove(n.id)"
            />
          }
        </div>
      }
    }
  `,
			styles: [".notif-region{position:fixed;z-index:1100;display:flex;flex-direction:column;gap:12px;padding:16px;pointer-events:none;max-height:100vh;overflow:hidden}.notif-region--top,.notif-region--topLeft,.notif-region--topRight{flex-direction:column-reverse}.notif-region--top{top:0;left:50%;transform:translate(-50%);align-items:center}.notif-region--bottom{bottom:0;left:50%;transform:translate(-50%);align-items:center}.notif-region--topLeft{top:0;left:0;align-items:flex-start}.notif-region--topRight{top:0;right:0;align-items:flex-end}.notif-region--bottomLeft{bottom:0;left:0;align-items:flex-start}.notif-region--bottomRight{bottom:0;right:0;align-items:flex-end}\n"]
		}]
	}]
});
var NotificationRef = class {
	id;
	_dismiss;
	constructor(id, _dismiss) {
		this.id = id;
		this._dismiss = _dismiss;
	}
	dismiss() {
		this._dismiss();
	}
};
const NOTIFICATION_DEFAULTS = {
	type: "info",
	duration: 4e3,
	position: "topRight",
	pauseOnHover: true,
	showProgress: true,
	showClose: true,
	withIcon: true
};
var NotificationService = class NotificationService {
	_appRef = inject(ApplicationRef);
	_envInjector = inject(EnvironmentInjector);
	_containerRef;
	_nextId = 0;
	show(options) {
		const merged = {
			...NOTIFICATION_DEFAULTS,
			...options
		};
		const id = this._nextId++;
		const data = {
			...merged,
			id,
			leaving: signal(false)
		};
		this._container().add(data);
		return new NotificationRef(id, () => this._containerRef?.instance.dismiss(id));
	}
	success(title, message, options) {
		return this._showTyped("success", title, message, options);
	}
	error(title, message, options) {
		return this._showTyped("error", title, message, options);
	}
	warn(title, message, options) {
		return this._showTyped("warn", title, message, options);
	}
	info(title, message, options) {
		return this._showTyped("info", title, message, options);
	}
	clear() {
		this._containerRef?.instance.clear();
	}
	_showTyped(type, title, message, options) {
		return this.show({
			...options,
			type,
			title,
			message
		});
	}
	_container() {
		if (!this._containerRef) {
			this._containerRef = createComponent(NotificationContainer, { environmentInjector: this._envInjector });
			this._appRef.attachView(this._containerRef.hostView);
			document.body.appendChild(this._containerRef.location.nativeElement);
		}
		return this._containerRef.instance;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.1",
		ngImport: i0,
		type: NotificationService,
		deps: [],
		target: i0.ɵɵFactoryTarget.Injectable
	});
	static ɵprov = i0.ɵɵngDeclareInjectable({
		minVersion: "12.0.0",
		version: "22.2.1",
		ngImport: i0,
		type: NotificationService,
		providedIn: "root"
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: NotificationService,
	decorators: [{
		type: Injectable,
		args: [{ providedIn: "root" }]
	}]
});
var Tooltip = class Tooltip {
	content = input("", ...ngDevMode ? [{ debugName: "content" }] : /* istanbul ignore next */ []);
	side = input("top", ...ngDevMode ? [{ debugName: "side" }] : /* istanbul ignore next */ []);
	arrow = input(true, ...ngDevMode ? [{ debugName: "arrow" }] : /* istanbul ignore next */ []);
	visible = input(false, ...ngDevMode ? [{ debugName: "visible" }] : /* istanbul ignore next */ []);
	id = input("", ...ngDevMode ? [{ debugName: "id" }] : /* istanbul ignore next */ []);
	_showArrow = computed(() => this.arrow(), ...ngDevMode ? [{ debugName: "_showArrow" }] : /* istanbul ignore next */ []);
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.1",
		ngImport: i0,
		type: Tooltip,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.1",
		type: Tooltip,
		isStandalone: true,
		selector: "l-tooltip",
		inputs: {
			content: {
				classPropertyName: "content",
				publicName: "content",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			side: {
				classPropertyName: "side",
				publicName: "side",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			arrow: {
				classPropertyName: "arrow",
				publicName: "arrow",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			visible: {
				classPropertyName: "visible",
				publicName: "visible",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			id: {
				classPropertyName: "id",
				publicName: "id",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		host: {
			attributes: { "role": "tooltip" },
			properties: {
				"id": "id()",
				"class.l-tooltip--top": "side() === 'top'",
				"class.l-tooltip--bottom": "side() === 'bottom'",
				"class.l-tooltip--left": "side() === 'left'",
				"class.l-tooltip--right": "side() === 'right'",
				"class.is-visible": "visible()"
			},
			classAttribute: "l-tooltip"
		},
		ngImport: i0,
		template: "@if (_showArrow()) {\n  <span class=\"l-tooltip__arrow\" aria-hidden=\"true\"></span>\n}\n<span class=\"l-tooltip__inner\">{{ content() }}</span>\n",
		styles: [":host{--l-tooltip-bg: var(--text-primary);--l-tooltip-color: var(--text-white);--l-tooltip-max-width: 240px;--l-tooltip-arrow-pos: 50%;position:fixed;top:0;left:0;z-index:1000;max-width:var(--l-tooltip-max-width);pointer-events:none;opacity:0;transform:scale(.96);transform-origin:center;transition:opacity .14s ease-out,transform .14s ease-out}:host(.is-visible){opacity:1;transform:scale(1)}.l-tooltip__inner{position:relative;z-index:1;display:block;padding:6px 10px;border-radius:6px;background:var(--l-tooltip-bg);color:var(--l-tooltip-color);font-size:13px;font-weight:500;line-height:18px;text-align:left;word-wrap:break-word;box-shadow:0 2px 8px #07090f29,0 1px 2px #07090f1a}.l-tooltip__arrow{position:absolute;z-index:0;width:9px;height:9px;background:var(--l-tooltip-bg);border-radius:1px}:host(.l-tooltip--top) .l-tooltip__arrow{bottom:-3px;left:var(--l-tooltip-arrow-pos);transform:translate(-50%) rotate(45deg)}:host(.l-tooltip--bottom) .l-tooltip__arrow{top:-3px;left:var(--l-tooltip-arrow-pos);transform:translate(-50%) rotate(45deg)}:host(.l-tooltip--left) .l-tooltip__arrow{right:-3px;top:var(--l-tooltip-arrow-pos);transform:translateY(-50%) rotate(45deg)}:host(.l-tooltip--right) .l-tooltip__arrow{left:-3px;top:var(--l-tooltip-arrow-pos);transform:translateY(-50%) rotate(45deg)}@media(prefers-reduced-motion:reduce){:host{transition:opacity .14s ease-out;transform:none}:host(.is-visible){transform:none}}\n"],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: Tooltip,
	decorators: [{
		type: Component,
		args: [{
			selector: "l-tooltip",
			changeDetection: ChangeDetectionStrategy.OnPush,
			host: {
				class: "l-tooltip",
				role: "tooltip",
				"[id]": "id()",
				"[class.l-tooltip--top]": "side() === 'top'",
				"[class.l-tooltip--bottom]": "side() === 'bottom'",
				"[class.l-tooltip--left]": "side() === 'left'",
				"[class.l-tooltip--right]": "side() === 'right'",
				"[class.is-visible]": "visible()"
			},
			template: "@if (_showArrow()) {\n  <span class=\"l-tooltip__arrow\" aria-hidden=\"true\"></span>\n}\n<span class=\"l-tooltip__inner\">{{ content() }}</span>\n",
			styles: [":host{--l-tooltip-bg: var(--text-primary);--l-tooltip-color: var(--text-white);--l-tooltip-max-width: 240px;--l-tooltip-arrow-pos: 50%;position:fixed;top:0;left:0;z-index:1000;max-width:var(--l-tooltip-max-width);pointer-events:none;opacity:0;transform:scale(.96);transform-origin:center;transition:opacity .14s ease-out,transform .14s ease-out}:host(.is-visible){opacity:1;transform:scale(1)}.l-tooltip__inner{position:relative;z-index:1;display:block;padding:6px 10px;border-radius:6px;background:var(--l-tooltip-bg);color:var(--l-tooltip-color);font-size:13px;font-weight:500;line-height:18px;text-align:left;word-wrap:break-word;box-shadow:0 2px 8px #07090f29,0 1px 2px #07090f1a}.l-tooltip__arrow{position:absolute;z-index:0;width:9px;height:9px;background:var(--l-tooltip-bg);border-radius:1px}:host(.l-tooltip--top) .l-tooltip__arrow{bottom:-3px;left:var(--l-tooltip-arrow-pos);transform:translate(-50%) rotate(45deg)}:host(.l-tooltip--bottom) .l-tooltip__arrow{top:-3px;left:var(--l-tooltip-arrow-pos);transform:translate(-50%) rotate(45deg)}:host(.l-tooltip--left) .l-tooltip__arrow{right:-3px;top:var(--l-tooltip-arrow-pos);transform:translateY(-50%) rotate(45deg)}:host(.l-tooltip--right) .l-tooltip__arrow{left:-3px;top:var(--l-tooltip-arrow-pos);transform:translateY(-50%) rotate(45deg)}@media(prefers-reduced-motion:reduce){:host{transition:opacity .14s ease-out;transform:none}:host(.is-visible){transform:none}}\n"]
		}]
	}],
	propDecorators: {
		content: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "content",
				required: false
			}]
		}],
		side: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "side",
				required: false
			}]
		}],
		arrow: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "arrow",
				required: false
			}]
		}],
		visible: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "visible",
				required: false
			}]
		}],
		id: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "id",
				required: false
			}]
		}]
	}
});
const PLACEMENTS = {
	top: {
		side: "top",
		align: "center"
	},
	topLeft: {
		side: "top",
		align: "start"
	},
	topRight: {
		side: "top",
		align: "end"
	},
	bottom: {
		side: "bottom",
		align: "center"
	},
	bottomLeft: {
		side: "bottom",
		align: "start"
	},
	bottomRight: {
		side: "bottom",
		align: "end"
	},
	left: {
		side: "left",
		align: "center"
	},
	leftTop: {
		side: "left",
		align: "start"
	},
	leftBottom: {
		side: "left",
		align: "end"
	},
	right: {
		side: "right",
		align: "center"
	},
	rightTop: {
		side: "right",
		align: "start"
	},
	rightBottom: {
		side: "right",
		align: "end"
	}
};
let _uid$2 = 0;
const _clamp = (value, min, max) => Math.max(min, Math.min(value, max));
var TooltipDirective = class TooltipDirective {
	lTooltip = input("", ...ngDevMode ? [{ debugName: "lTooltip" }] : /* istanbul ignore next */ []);
	lTooltipPlacement = input("top", ...ngDevMode ? [{ debugName: "lTooltipPlacement" }] : /* istanbul ignore next */ []);
	lTooltipTrigger = input("hover", ...ngDevMode ? [{ debugName: "lTooltipTrigger" }] : /* istanbul ignore next */ []);
	lTooltipDisabled = input(false, {
		...ngDevMode ? { debugName: "lTooltipDisabled" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	lTooltipArrow = input(true, {
		...ngDevMode ? { debugName: "lTooltipArrow" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	lTooltipColor = input("", ...ngDevMode ? [{ debugName: "lTooltipColor" }] : /* istanbul ignore next */ []);
	lTooltipMaxWidth = input(null, {
		...ngDevMode ? { debugName: "lTooltipMaxWidth" } : /* istanbul ignore next */ {},
		transform: numberAttribute
	});
	lTooltipOpenDelay = input(120, {
		...ngDevMode ? { debugName: "lTooltipOpenDelay" } : /* istanbul ignore next */ {},
		transform: numberAttribute
	});
	lTooltipCloseDelay = input(80, {
		...ngDevMode ? { debugName: "lTooltipCloseDelay" } : /* istanbul ignore next */ {},
		transform: numberAttribute
	});
	_host = inject(ElementRef);
	_vcr = inject(ViewContainerRef);
	_renderer = inject(Renderer2);
	_id = `l-tooltip-${_uid$2++}`;
	_visible = false;
	_ref = null;
	_openTimer = null;
	_closeTimer = null;
	_onViewportChange = () => {
		if (this._visible) this._position();
	};
	constructor() {
		inject(DestroyRef).onDestroy(() => {
			this._clearTimers();
			this._unbindViewport();
			this._ref?.destroy();
		});
	}
	get _enabled() {
		return !this.lTooltipDisabled() && this.lTooltip().trim().length > 0;
	}
	_onEnter() {
		if (this.lTooltipTrigger() === "hover") this._scheduleShow();
	}
	_onLeave() {
		if (this.lTooltipTrigger() === "hover") this._scheduleHide();
	}
	_onFocus() {
		if (this.lTooltipTrigger() !== "click") this._scheduleShow();
	}
	_onBlur() {
		if (this.lTooltipTrigger() !== "click") this._scheduleHide();
	}
	_onClick() {
		if (this.lTooltipTrigger() !== "click") return;
		this._visible ? this._hide() : this._show();
	}
	_onEscape() {
		if (this._visible) this._hide();
	}
	_scheduleShow() {
		this._clearTimer("close");
		if (this._visible || !this._enabled) return;
		this._openTimer = setTimeout(() => this._show(), this.lTooltipOpenDelay());
	}
	_scheduleHide() {
		this._clearTimer("open");
		if (!this._visible) return;
		this._closeTimer = setTimeout(() => this._hide(), this.lTooltipCloseDelay());
	}
	_show() {
		if (!this._enabled) return;
		const ref = this._ensure();
		ref.setInput("content", this.lTooltip());
		ref.setInput("arrow", this.lTooltipArrow());
		ref.setInput("side", PLACEMENTS[this.lTooltipPlacement()].side);
		const el = ref.location.nativeElement;
		if (this.lTooltipColor()) this._renderer.setStyle(el, "--l-tooltip-bg", this.lTooltipColor());
		const maxWidth = this.lTooltipMaxWidth();
		if (maxWidth) this._renderer.setStyle(el, "--l-tooltip-max-width", `${maxWidth}px`);
		ref.changeDetectorRef.detectChanges();
		this._position();
		this._visible = true;
		requestAnimationFrame(() => {
			ref.setInput("visible", true);
			ref.changeDetectorRef.detectChanges();
		});
		window.addEventListener("scroll", this._onViewportChange, true);
		window.addEventListener("resize", this._onViewportChange);
	}
	_hide() {
		if (!this._ref) return;
		this._visible = false;
		this._ref.setInput("visible", false);
		this._ref.changeDetectorRef.detectChanges();
		this._unbindViewport();
	}
	_ensure() {
		if (this._ref) return this._ref;
		this._ref = this._vcr.createComponent(Tooltip);
		this._ref.setInput("id", this._id);
		this._renderer.appendChild(document.body, this._ref.location.nativeElement);
		return this._ref;
	}
	_position() {
		const ref = this._ref;
		if (!ref) return;
		const el = ref.location.nativeElement;
		const host = this._host.nativeElement.getBoundingClientRect();
		const tw = el.offsetWidth;
		const th = el.offsetHeight;
		const vw = document.documentElement.clientWidth;
		const vh = window.innerHeight;
		const gap = 8;
		const margin = 6;
		let { side, align } = PLACEMENTS[this.lTooltipPlacement()];
		if (side === "top" && host.top - th - gap < margin && host.bottom + th + gap <= vh - margin) side = "bottom";
		else if (side === "bottom" && host.bottom + th + gap > vh - margin && host.top - th - gap >= margin) side = "top";
		else if (side === "left" && host.left - tw - gap < margin && host.right + tw + gap <= vw - margin) side = "right";
		else if (side === "right" && host.right + tw + gap > vw - margin && host.left - tw - gap >= margin) side = "left";
		const cx = host.left + host.width / 2;
		const cy = host.top + host.height / 2;
		let top;
		let left;
		let arrowPos;
		if (side === "top" || side === "bottom") {
			top = side === "top" ? host.top - th - gap : host.bottom + gap;
			left = align === "start" ? host.left : align === "end" ? host.right - tw : cx - tw / 2;
			left = _clamp(left, margin, vw - tw - margin);
			arrowPos = _clamp(cx - left, 12, tw - 12);
		} else {
			left = side === "left" ? host.left - tw - gap : host.right + gap;
			top = align === "start" ? host.top : align === "end" ? host.bottom - th : cy - th / 2;
			top = _clamp(top, margin, vh - th - margin);
			arrowPos = _clamp(cy - top, 12, th - 12);
		}
		ref.setInput("side", side);
		this._renderer.setStyle(el, "top", `${Math.round(top)}px`);
		this._renderer.setStyle(el, "left", `${Math.round(left)}px`);
		this._renderer.setStyle(el, "--l-tooltip-arrow-pos", `${Math.round(arrowPos)}px`);
	}
	_clearTimer(which) {
		if (which === "open" && this._openTimer) {
			clearTimeout(this._openTimer);
			this._openTimer = null;
		}
		if (which === "close" && this._closeTimer) {
			clearTimeout(this._closeTimer);
			this._closeTimer = null;
		}
	}
	_clearTimers() {
		this._clearTimer("open");
		this._clearTimer("close");
	}
	_unbindViewport() {
		window.removeEventListener("scroll", this._onViewportChange, true);
		window.removeEventListener("resize", this._onViewportChange);
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.1",
		ngImport: i0,
		type: TooltipDirective,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "17.1.0",
		version: "22.2.1",
		type: TooltipDirective,
		isStandalone: true,
		selector: "[lTooltip]",
		inputs: {
			lTooltip: {
				classPropertyName: "lTooltip",
				publicName: "lTooltip",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			lTooltipPlacement: {
				classPropertyName: "lTooltipPlacement",
				publicName: "lTooltipPlacement",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			lTooltipTrigger: {
				classPropertyName: "lTooltipTrigger",
				publicName: "lTooltipTrigger",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			lTooltipDisabled: {
				classPropertyName: "lTooltipDisabled",
				publicName: "lTooltipDisabled",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			lTooltipArrow: {
				classPropertyName: "lTooltipArrow",
				publicName: "lTooltipArrow",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			lTooltipColor: {
				classPropertyName: "lTooltipColor",
				publicName: "lTooltipColor",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			lTooltipMaxWidth: {
				classPropertyName: "lTooltipMaxWidth",
				publicName: "lTooltipMaxWidth",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			lTooltipOpenDelay: {
				classPropertyName: "lTooltipOpenDelay",
				publicName: "lTooltipOpenDelay",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			lTooltipCloseDelay: {
				classPropertyName: "lTooltipCloseDelay",
				publicName: "lTooltipCloseDelay",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		host: {
			listeners: {
				"mouseenter": "_onEnter()",
				"mouseleave": "_onLeave()",
				"focusin": "_onFocus()",
				"focusout": "_onBlur()",
				"click": "_onClick()",
				"keydown.escape": "_onEscape()"
			},
			properties: { "attr.aria-describedby": "_visible ? _id : null" }
		},
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: TooltipDirective,
	decorators: [{
		type: Directive,
		args: [{
			selector: "[lTooltip]",
			host: {
				"(mouseenter)": "_onEnter()",
				"(mouseleave)": "_onLeave()",
				"(focusin)": "_onFocus()",
				"(focusout)": "_onBlur()",
				"(click)": "_onClick()",
				"(keydown.escape)": "_onEscape()",
				"[attr.aria-describedby]": "_visible ? _id : null"
			}
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		lTooltip: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "lTooltip",
				required: false
			}]
		}],
		lTooltipPlacement: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "lTooltipPlacement",
				required: false
			}]
		}],
		lTooltipTrigger: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "lTooltipTrigger",
				required: false
			}]
		}],
		lTooltipDisabled: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "lTooltipDisabled",
				required: false
			}]
		}],
		lTooltipArrow: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "lTooltipArrow",
				required: false
			}]
		}],
		lTooltipColor: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "lTooltipColor",
				required: false
			}]
		}],
		lTooltipMaxWidth: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "lTooltipMaxWidth",
				required: false
			}]
		}],
		lTooltipOpenDelay: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "lTooltipOpenDelay",
				required: false
			}]
		}],
		lTooltipCloseDelay: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "lTooltipCloseDelay",
				required: false
			}]
		}]
	}
});
var SpinnerService = class SpinnerService {
	_pending = signal(0, ...ngDevMode ? [{ debugName: "_pending" }] : /* istanbul ignore next */ []);
	visible = computed(() => this._pending() > 0, ...ngDevMode ? [{ debugName: "visible" }] : /* istanbul ignore next */ []);
	show() {
		this._pending.update((count) => count + 1);
	}
	hide() {
		this._pending.update((count) => Math.max(0, count - 1));
	}
	reset() {
		this._pending.set(0);
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.1",
		ngImport: i0,
		type: SpinnerService,
		deps: [],
		target: i0.ɵɵFactoryTarget.Injectable
	});
	static ɵprov = i0.ɵɵngDeclareInjectable({
		minVersion: "12.0.0",
		version: "22.2.1",
		ngImport: i0,
		type: SpinnerService,
		providedIn: "root"
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: SpinnerService,
	decorators: [{
		type: Injectable,
		args: [{ providedIn: "root" }]
	}]
});
var LoadingSpinner = class LoadingSpinner {
	_spinner = inject(SpinnerService);
	_visible = this._spinner.visible;
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.1",
		ngImport: i0,
		type: LoadingSpinner,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.1",
		type: LoadingSpinner,
		isStandalone: true,
		selector: "l-loading-spinner",
		ngImport: i0,
		template: "@if (_visible()) {\n  <div class=\"l-spinner-overlay\">\n    <div class=\"l-spinner-wheel\"></div>\n  </div>\n}\n",
		styles: [".l-spinner-overlay{position:fixed;inset:0;z-index:9999;display:flex;align-items:center;justify-content:center;background:color-mix(in srgb,var(--bg-lightest) 60%,transparent)}.l-spinner-wheel{width:56px;height:56px;border:6px solid var(--separator-dark);border-top-color:var(--accent);border-radius:50%;animation:l-spinner-spin .7s linear infinite}@keyframes l-spinner-spin{to{transform:rotate(360deg)}}@media(prefers-reduced-motion:reduce){.l-spinner-wheel{animation-duration:1.6s}}\n"],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: LoadingSpinner,
	decorators: [{
		type: Component,
		args: [{
			selector: "l-loading-spinner",
			changeDetection: ChangeDetectionStrategy.OnPush,
			imports: [],
			template: "@if (_visible()) {\n  <div class=\"l-spinner-overlay\">\n    <div class=\"l-spinner-wheel\"></div>\n  </div>\n}\n",
			styles: [".l-spinner-overlay{position:fixed;inset:0;z-index:9999;display:flex;align-items:center;justify-content:center;background:color-mix(in srgb,var(--bg-lightest) 60%,transparent)}.l-spinner-wheel{width:56px;height:56px;border:6px solid var(--separator-dark);border-top-color:var(--accent);border-radius:50%;animation:l-spinner-spin .7s linear infinite}@keyframes l-spinner-spin{to{transform:rotate(360deg)}}@media(prefers-reduced-motion:reduce){.l-spinner-wheel{animation-duration:1.6s}}\n"]
		}]
	}]
});
var Skeleton = class Skeleton {
	width = input("100%", ...ngDevMode ? [{ debugName: "width" }] : /* istanbul ignore next */ []);
	height = input(...ngDevMode ? [void 0, { debugName: "height" }] : /* istanbul ignore next */ []);
	radius = input("8px", ...ngDevMode ? [{ debugName: "radius" }] : /* istanbul ignore next */ []);
	circle = input(false, ...ngDevMode ? [{ debugName: "circle" }] : /* istanbul ignore next */ []);
	animate = input(true, ...ngDevMode ? [{ debugName: "animate" }] : /* istanbul ignore next */ []);
	visible = input(true, ...ngDevMode ? [{ debugName: "visible" }] : /* istanbul ignore next */ []);
	_width = computed(() => this.circle() ? this.height() : this.width(), ...ngDevMode ? [{ debugName: "_width" }] : /* istanbul ignore next */ []);
	_radius = computed(() => this.circle() ? "50%" : this.radius(), ...ngDevMode ? [{ debugName: "_radius" }] : /* istanbul ignore next */ []);
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.1",
		ngImport: i0,
		type: Skeleton,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.1",
		type: Skeleton,
		isStandalone: true,
		selector: "l-skeleton",
		inputs: {
			width: {
				classPropertyName: "width",
				publicName: "width",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			height: {
				classPropertyName: "height",
				publicName: "height",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			radius: {
				classPropertyName: "radius",
				publicName: "radius",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			circle: {
				classPropertyName: "circle",
				publicName: "circle",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			animate: {
				classPropertyName: "animate",
				publicName: "animate",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			visible: {
				classPropertyName: "visible",
				publicName: "visible",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		host: { properties: {
			"attr.data-visible": "visible() ? \"\" : null",
			"attr.data-animate": "visible() && animate() ? \"\" : null",
			"attr.aria-hidden": "visible() ? \"true\" : null",
			"style.width": "_width()",
			"style.height": "height()",
			"style.border-radius": "_radius()"
		} },
		ngImport: i0,
		template: "<ng-content />",
		isInline: true,
		styles: [":host{--l-skeleton-base: var(--bg-dark);--l-skeleton-overlay: var(--separator-dark);display:block;position:relative}:host([data-visible]){overflow:hidden;pointer-events:none;user-select:none;-webkit-user-select:none}:host([data-visible]):before{content:\"\";position:absolute;inset:0;z-index:10;background:var(--l-skeleton-base)}:host([data-animate]):after{content:\"\";position:absolute;inset:0;z-index:11;background:var(--l-skeleton-overlay);opacity:0;animation:l-skeleton-pulse 1.4s linear infinite alternate}@keyframes l-skeleton-pulse{to{opacity:1}}@media(prefers-reduced-motion:reduce){:host([data-animate]):after{animation:none}}\n"],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: Skeleton,
	decorators: [{
		type: Component,
		args: [{
			selector: "l-skeleton",
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: "<ng-content />",
			host: {
				"[attr.data-visible]": "visible() ? \"\" : null",
				"[attr.data-animate]": "visible() && animate() ? \"\" : null",
				"[attr.aria-hidden]": "visible() ? \"true\" : null",
				"[style.width]": "_width()",
				"[style.height]": "height()",
				"[style.border-radius]": "_radius()"
			},
			styles: [":host{--l-skeleton-base: var(--bg-dark);--l-skeleton-overlay: var(--separator-dark);display:block;position:relative}:host([data-visible]){overflow:hidden;pointer-events:none;user-select:none;-webkit-user-select:none}:host([data-visible]):before{content:\"\";position:absolute;inset:0;z-index:10;background:var(--l-skeleton-base)}:host([data-animate]):after{content:\"\";position:absolute;inset:0;z-index:11;background:var(--l-skeleton-overlay);opacity:0;animation:l-skeleton-pulse 1.4s linear infinite alternate}@keyframes l-skeleton-pulse{to{opacity:1}}@media(prefers-reduced-motion:reduce){:host([data-animate]):after{animation:none}}\n"]
		}]
	}],
	propDecorators: {
		width: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "width",
				required: false
			}]
		}],
		height: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "height",
				required: false
			}]
		}],
		radius: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "radius",
				required: false
			}]
		}],
		circle: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "circle",
				required: false
			}]
		}],
		animate: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "animate",
				required: false
			}]
		}],
		visible: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "visible",
				required: false
			}]
		}]
	}
});
var Breadcrumb = class Breadcrumb {
	title = input("", ...ngDevMode ? [{ debugName: "title" }] : /* istanbul ignore next */ []);
	items = input([], ...ngDevMode ? [{ debugName: "items" }] : /* istanbul ignore next */ []);
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.1",
		ngImport: i0,
		type: Breadcrumb,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.1",
		type: Breadcrumb,
		isStandalone: true,
		selector: "l-breadcrumb",
		inputs: {
			title: {
				classPropertyName: "title",
				publicName: "title",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			items: {
				classPropertyName: "items",
				publicName: "items",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		ngImport: i0,
		template: "<div class=\"breadcrumb-group\">\n  @if (title()) {\n    <h1 class=\"breadcrumb-title\">{{ title() }}</h1>\n  }\n\n  @if (items().length) {\n    <nav aria-label=\"Breadcrumb\">\n      <ol class=\"breadcrumb-list\">\n        @for (item of items(); track $index; let last = $last) {\n          <li class=\"breadcrumb-item\">\n            @if (last) {\n              <span class=\"breadcrumb-sub-title active\" aria-current=\"page\">{{ item.label }}</span>\n            } @else if (item.link) {\n              <a class=\"breadcrumb-sub-title\" [routerLink]=\"item.link\">{{ item.label }}</a>\n            } @else {\n              <span class=\"breadcrumb-sub-title\">{{ item.label }}</span>\n            }\n\n            @if (!last) {\n              <svg\n                class=\"breadcrumb-caret\"\n                width=\"16\"\n                height=\"16\"\n                viewBox=\"0 0 20 20\"\n                fill=\"none\"\n                aria-hidden=\"true\"\n                xmlns=\"http://www.w3.org/2000/svg\"\n              >\n                <path\n                  d=\"M7.5 5L12.5 10L7.5 15\"\n                  stroke=\"currentColor\"\n                  stroke-width=\"1.5\"\n                  stroke-linecap=\"round\"\n                  stroke-linejoin=\"round\"\n                />\n              </svg>\n            }\n          </li>\n        }\n      </ol>\n    </nav>\n  }\n</div>\n",
		styles: [":host{display:block}.breadcrumb-group{flex:1}.breadcrumb-title{color:var(--text-primary);font-size:18px;font-weight:600;line-height:28px}.breadcrumb-list{display:flex;align-items:center;flex-wrap:wrap;gap:8px;list-style:none}.breadcrumb-item{display:inline-flex;align-items:center;gap:8px}.breadcrumb-sub-title{color:var(--text-secondary);font-size:14px;font-weight:400;line-height:20px;text-decoration:none}.breadcrumb-sub-title.active{color:var(--accent)}a.breadcrumb-sub-title{cursor:pointer;transition:color .12s ease-out}a.breadcrumb-sub-title:hover{color:var(--text-primary)}.breadcrumb-caret{flex-shrink:0;color:var(--text-quaternary)}@media(prefers-reduced-motion:reduce){a.breadcrumb-sub-title{transition:none}}\n"],
		dependencies: [{
			kind: "directive",
			type: RouterLink,
			selector: "[routerLink]",
			inputs: [
				"target",
				"queryParams",
				"fragment",
				"queryParamsHandling",
				"state",
				"info",
				"relativeTo",
				"preserveFragment",
				"skipLocationChange",
				"replaceUrl",
				"browserUrl",
				"routerLink"
			]
		}],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: Breadcrumb,
	decorators: [{
		type: Component,
		args: [{
			selector: "l-breadcrumb",
			changeDetection: ChangeDetectionStrategy.OnPush,
			imports: [RouterLink],
			template: "<div class=\"breadcrumb-group\">\n  @if (title()) {\n    <h1 class=\"breadcrumb-title\">{{ title() }}</h1>\n  }\n\n  @if (items().length) {\n    <nav aria-label=\"Breadcrumb\">\n      <ol class=\"breadcrumb-list\">\n        @for (item of items(); track $index; let last = $last) {\n          <li class=\"breadcrumb-item\">\n            @if (last) {\n              <span class=\"breadcrumb-sub-title active\" aria-current=\"page\">{{ item.label }}</span>\n            } @else if (item.link) {\n              <a class=\"breadcrumb-sub-title\" [routerLink]=\"item.link\">{{ item.label }}</a>\n            } @else {\n              <span class=\"breadcrumb-sub-title\">{{ item.label }}</span>\n            }\n\n            @if (!last) {\n              <svg\n                class=\"breadcrumb-caret\"\n                width=\"16\"\n                height=\"16\"\n                viewBox=\"0 0 20 20\"\n                fill=\"none\"\n                aria-hidden=\"true\"\n                xmlns=\"http://www.w3.org/2000/svg\"\n              >\n                <path\n                  d=\"M7.5 5L12.5 10L7.5 15\"\n                  stroke=\"currentColor\"\n                  stroke-width=\"1.5\"\n                  stroke-linecap=\"round\"\n                  stroke-linejoin=\"round\"\n                />\n              </svg>\n            }\n          </li>\n        }\n      </ol>\n    </nav>\n  }\n</div>\n",
			styles: [":host{display:block}.breadcrumb-group{flex:1}.breadcrumb-title{color:var(--text-primary);font-size:18px;font-weight:600;line-height:28px}.breadcrumb-list{display:flex;align-items:center;flex-wrap:wrap;gap:8px;list-style:none}.breadcrumb-item{display:inline-flex;align-items:center;gap:8px}.breadcrumb-sub-title{color:var(--text-secondary);font-size:14px;font-weight:400;line-height:20px;text-decoration:none}.breadcrumb-sub-title.active{color:var(--accent)}a.breadcrumb-sub-title{cursor:pointer;transition:color .12s ease-out}a.breadcrumb-sub-title:hover{color:var(--text-primary)}.breadcrumb-caret{flex-shrink:0;color:var(--text-quaternary)}@media(prefers-reduced-motion:reduce){a.breadcrumb-sub-title{transition:none}}\n"]
		}]
	}],
	propDecorators: {
		title: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "title",
				required: false
			}]
		}],
		items: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "items",
				required: false
			}]
		}]
	}
});
var Pagination = class Pagination {
	pageSizeOptions = input([
		10,
		25,
		50,
		100
	], ...ngDevMode ? [{ debugName: "pageSizeOptions" }] : /* istanbul ignore next */ []);
	length = input(0, ...ngDevMode ? [{ debugName: "length" }] : /* istanbul ignore next */ []);
	pageSize = model(10, ...ngDevMode ? [{ debugName: "pageSize" }] : /* istanbul ignore next */ []);
	pageIndex = model(0, ...ngDevMode ? [{ debugName: "pageIndex" }] : /* istanbul ignore next */ []);
	pageChange = output();
	_totalPages = computed(() => {
		const len = this.length();
		return len > 0 ? Math.ceil(len / this.pageSize()) : 1;
	}, ...ngDevMode ? [{ debugName: "_totalPages" }] : /* istanbul ignore next */ []);
	_pageNumChars = computed(() => String(this._totalPages()).length, ...ngDevMode ? [{ debugName: "_pageNumChars" }] : /* istanbul ignore next */ []);
	_visiblePages = computed(() => {
		const total = this._totalPages();
		const current = this.pageIndex() + 1;
		let start = Math.max(current - 2, 1);
		let end = start + 4;
		if (end > total) {
			end = total;
			start = Math.max(end - 4, 1);
		}
		return Array.from({ length: end - start + 1 }, (_, i) => start + i);
	}, ...ngDevMode ? [{ debugName: "_visiblePages" }] : /* istanbul ignore next */ []);
	_itemsInView = computed(() => {
		if (this.length() === 0) return 0;
		const remaining = this.length() - this.pageIndex() * this.pageSize();
		return Math.min(this.pageSize(), remaining);
	}, ...ngDevMode ? [{ debugName: "_itemsInView" }] : /* istanbul ignore next */ []);
	_onChangePageOption(size) {
		this.pageSize.set(size);
		this.pageIndex.set(0);
		this._emitChange();
	}
	_onPrevAndNext(direction) {
		this.pageIndex.update((idx) => direction === "prev" ? idx - 1 : idx + 1);
		this._emitChange();
	}
	_goFirstPage() {
		this.pageIndex.set(0);
		this._emitChange();
	}
	_goLastPage() {
		this.pageIndex.set(this._totalPages() - 1);
		this._emitChange();
	}
	_goToPage(index) {
		this.pageIndex.set(index);
		this._emitChange();
	}
	_emitChange() {
		this.pageChange.emit({
			pageIndex: this.pageIndex(),
			pageSize: this.pageSize(),
			length: this.length()
		});
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.1",
		ngImport: i0,
		type: Pagination,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.1",
		type: Pagination,
		isStandalone: true,
		selector: "l-pagination",
		inputs: {
			pageSizeOptions: {
				classPropertyName: "pageSizeOptions",
				publicName: "pageSizeOptions",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			length: {
				classPropertyName: "length",
				publicName: "length",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			pageSize: {
				classPropertyName: "pageSize",
				publicName: "pageSize",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			pageIndex: {
				classPropertyName: "pageIndex",
				publicName: "pageIndex",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: {
			pageSize: "pageSizeChange",
			pageIndex: "pageIndexChange",
			pageChange: "pageChange"
		},
		ngImport: i0,
		template: "<div class=\"paginator\">\n  <span class=\"page-text\">\n    <span class=\"page-text light\">Showing </span>\n    <span class=\"page-text bold\">{{ _itemsInView() }} </span>\n    <span class=\"page-text light\">Entries out of </span>{{ length() }}\n  </span>\n\n  <div class=\"arrow-buttons\" [style.--page-num-chars]=\"_pageNumChars()\">\n    <div\n      [class.disabled]=\"pageIndex() === 0\"\n      (click)=\"pageIndex() !== 0 && _goFirstPage()\"\n      class=\"paginator-btn\"\n    >\n      <svg\n        style=\"transform: rotate(180deg)\"\n        fill=\"currentColor\"\n        width=\"20\"\n        height=\"20\"\n        viewBox=\"0 0 24 24\"\n      >\n        <path\n          d=\"M8.46,8.29A1,1,0,1,0,7,9.71L9.34,12,7,14.29a1,1,0,0,0,0,1.42,1,1,0,0,0,1.42,0l3-3a1,1,0,0,0,0-1.42Zm8.5,3-3-3a1,1,0,0,0-1.42,1.42L14.84,12l-2.3,2.29a1,1,0,0,0,0,1.42,1,1,0,0,0,1.42,0l3-3A1,1,0,0,0,17,11.29Z\"\n        />\n      </svg>\n      First\n    </div>\n\n    <div\n      [class.disabled]=\"pageIndex() === 0\"\n      (click)=\"pageIndex() !== 0 && _onPrevAndNext('prev')\"\n      class=\"paginator-btn\"\n    >\n      <svg\n        style=\"transform: rotate(180deg)\"\n        fill=\"currentColor\"\n        width=\"20\"\n        height=\"20\"\n        viewBox=\"0 0 24 24\"\n      >\n        <path\n          d=\"M14.83,11.29,10.59,7.05a1,1,0,0,0-1.42,0,1,1,0,0,0,0,1.41L12.71,12,9.17,15.54a1,1,0,0,0,0,1.41,1,1,0,0,0,.71.29,1,1,0,0,0,.71-.29l4.24-4.24A1,1,0,0,0,14.83,11.29Z\"\n        />\n      </svg>\n      Prev\n    </div>\n\n    @for (page of _visiblePages(); track page) {\n      <div\n        [class.active]=\"page === pageIndex() + 1\"\n        (click)=\"_goToPage(page - 1)\"\n        class=\"paginator-btn page-num\"\n      >\n        {{ page }}\n      </div>\n    }\n\n    <div\n      [class.disabled]=\"pageIndex() + 1 === _totalPages()\"\n      (click)=\"pageIndex() + 1 !== _totalPages() && _onPrevAndNext('next')\"\n      class=\"paginator-btn\"\n    >\n      Next\n      <svg fill=\"currentColor\" width=\"20\" height=\"20\" viewBox=\"0 0 24 24\">\n        <path\n          d=\"M14.83,11.29,10.59,7.05a1,1,0,0,0-1.42,0,1,1,0,0,0,0,1.41L12.71,12,9.17,15.54a1,1,0,0,0,0,1.41,1,1,0,0,0,.71.29,1,1,0,0,0,.71-.29l4.24-4.24A1,1,0,0,0,14.83,11.29Z\"\n        />\n      </svg>\n    </div>\n\n    <div\n      [class.disabled]=\"pageIndex() + 1 === _totalPages()\"\n      (click)=\"pageIndex() + 1 !== _totalPages() && _goLastPage()\"\n      class=\"paginator-btn\"\n    >\n      Last\n      <svg fill=\"currentColor\" width=\"20\" height=\"20\" viewBox=\"0 0 24 24\">\n        <path\n          d=\"M8.46,8.29A1,1,0,1,0,7,9.71L9.34,12,7,14.29a1,1,0,0,0,0,1.42,1,1,0,0,0,1.42,0l3-3a1,1,0,0,0,0-1.42Zm8.5,3-3-3a1,1,0,0,0-1.42,1.42L14.84,12l-2.3,2.29a1,1,0,0,0,0,1.42,1,1,0,0,0,1.42,0l3-3A1,1,0,0,0,17,11.29Z\"\n        />\n      </svg>\n    </div>\n  </div>\n\n  <div class=\"page-items\">\n    <span class=\"page-text\">Row per page: </span>\n    <l-menu mode=\"right\">\n      <div dropdown-display class=\"paginator-btn paginator-dropdown-btn\">\n        {{ pageSize() }}\n        <svg fill=\"currentColor\" width=\"20\" height=\"20\" viewBox=\"0 0 24 24\">\n          <path\n            d=\"M14.83,11.29,10.59,7.05a1,1,0,0,0-1.42,0,1,1,0,0,0,0,1.41L12.71,12,9.17,15.54a1,1,0,0,0,0,1.41,1,1,0,0,0,.71.29,1,1,0,0,0,.71-.29l4.24-4.24A1,1,0,0,0,14.83,11.29Z\"\n          />\n        </svg>\n      </div>\n\n      @for (item of pageSizeOptions(); track item) {\n        <div dropdown-item [class.active]=\"item === pageSize()\" (click)=\"_onChangePageOption(item)\">\n          {{ item }}\n        </div>\n      }\n    </l-menu>\n  </div>\n</div>\n",
		styles: [":host{display:block}.paginator{display:flex;padding:0 12px;justify-content:space-between;align-items:center;align-self:stretch;row-gap:12px;flex-wrap:wrap}.paginator-dropdown-btn{position:relative;width:auto!important}.paginator-dropdown-btn svg{rotate:90deg}.page-items{display:flex;align-items:center;gap:6px}.page-text{color:var(--text-primary);font-size:14px;font-weight:400;line-height:20px}.page-text.bold{font-weight:700}.page-text.light{color:var(--text-tertiary)}.paginator-btn{display:flex;justify-content:center;align-items:center;gap:4px;padding:6px;border:1px solid var(--accent);border-radius:8px;background:transparent;cursor:pointer;transition:background-color .12s ease-out,color .12s ease-out;color:var(--accent);font-size:14px;font-weight:500;line-height:20px}.paginator-btn:hover{background-color:var(--bg-light)}.paginator-btn.active{background-color:var(--accent);color:var(--accent-contrast)!important}.paginator-btn.disabled{color:var(--text-quaternary);background-color:transparent;cursor:default;border:1px solid var(--separator)}.paginator-btn.page-num{min-width:max(32px,var(--page-num-chars, 1) * 1ch + 14px);height:32px;font-variant-numeric:tabular-nums;color:var(--text-primary)}.arrow-buttons{display:flex;gap:6px;row-gap:12px;flex-wrap:wrap}@media(prefers-reduced-motion:reduce){.paginator-btn{transition:none}}\n"],
		dependencies: [{
			kind: "component",
			type: Menu,
			selector: "l-menu",
			inputs: [
				"mode",
				"closeOnItemClick",
				"contentMode",
				"showActiveState",
				"appendBody"
			]
		}],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: Pagination,
	decorators: [{
		type: Component,
		args: [{
			selector: "l-pagination",
			changeDetection: ChangeDetectionStrategy.OnPush,
			imports: [Menu],
			template: "<div class=\"paginator\">\n  <span class=\"page-text\">\n    <span class=\"page-text light\">Showing </span>\n    <span class=\"page-text bold\">{{ _itemsInView() }} </span>\n    <span class=\"page-text light\">Entries out of </span>{{ length() }}\n  </span>\n\n  <div class=\"arrow-buttons\" [style.--page-num-chars]=\"_pageNumChars()\">\n    <div\n      [class.disabled]=\"pageIndex() === 0\"\n      (click)=\"pageIndex() !== 0 && _goFirstPage()\"\n      class=\"paginator-btn\"\n    >\n      <svg\n        style=\"transform: rotate(180deg)\"\n        fill=\"currentColor\"\n        width=\"20\"\n        height=\"20\"\n        viewBox=\"0 0 24 24\"\n      >\n        <path\n          d=\"M8.46,8.29A1,1,0,1,0,7,9.71L9.34,12,7,14.29a1,1,0,0,0,0,1.42,1,1,0,0,0,1.42,0l3-3a1,1,0,0,0,0-1.42Zm8.5,3-3-3a1,1,0,0,0-1.42,1.42L14.84,12l-2.3,2.29a1,1,0,0,0,0,1.42,1,1,0,0,0,1.42,0l3-3A1,1,0,0,0,17,11.29Z\"\n        />\n      </svg>\n      First\n    </div>\n\n    <div\n      [class.disabled]=\"pageIndex() === 0\"\n      (click)=\"pageIndex() !== 0 && _onPrevAndNext('prev')\"\n      class=\"paginator-btn\"\n    >\n      <svg\n        style=\"transform: rotate(180deg)\"\n        fill=\"currentColor\"\n        width=\"20\"\n        height=\"20\"\n        viewBox=\"0 0 24 24\"\n      >\n        <path\n          d=\"M14.83,11.29,10.59,7.05a1,1,0,0,0-1.42,0,1,1,0,0,0,0,1.41L12.71,12,9.17,15.54a1,1,0,0,0,0,1.41,1,1,0,0,0,.71.29,1,1,0,0,0,.71-.29l4.24-4.24A1,1,0,0,0,14.83,11.29Z\"\n        />\n      </svg>\n      Prev\n    </div>\n\n    @for (page of _visiblePages(); track page) {\n      <div\n        [class.active]=\"page === pageIndex() + 1\"\n        (click)=\"_goToPage(page - 1)\"\n        class=\"paginator-btn page-num\"\n      >\n        {{ page }}\n      </div>\n    }\n\n    <div\n      [class.disabled]=\"pageIndex() + 1 === _totalPages()\"\n      (click)=\"pageIndex() + 1 !== _totalPages() && _onPrevAndNext('next')\"\n      class=\"paginator-btn\"\n    >\n      Next\n      <svg fill=\"currentColor\" width=\"20\" height=\"20\" viewBox=\"0 0 24 24\">\n        <path\n          d=\"M14.83,11.29,10.59,7.05a1,1,0,0,0-1.42,0,1,1,0,0,0,0,1.41L12.71,12,9.17,15.54a1,1,0,0,0,0,1.41,1,1,0,0,0,.71.29,1,1,0,0,0,.71-.29l4.24-4.24A1,1,0,0,0,14.83,11.29Z\"\n        />\n      </svg>\n    </div>\n\n    <div\n      [class.disabled]=\"pageIndex() + 1 === _totalPages()\"\n      (click)=\"pageIndex() + 1 !== _totalPages() && _goLastPage()\"\n      class=\"paginator-btn\"\n    >\n      Last\n      <svg fill=\"currentColor\" width=\"20\" height=\"20\" viewBox=\"0 0 24 24\">\n        <path\n          d=\"M8.46,8.29A1,1,0,1,0,7,9.71L9.34,12,7,14.29a1,1,0,0,0,0,1.42,1,1,0,0,0,1.42,0l3-3a1,1,0,0,0,0-1.42Zm8.5,3-3-3a1,1,0,0,0-1.42,1.42L14.84,12l-2.3,2.29a1,1,0,0,0,0,1.42,1,1,0,0,0,1.42,0l3-3A1,1,0,0,0,17,11.29Z\"\n        />\n      </svg>\n    </div>\n  </div>\n\n  <div class=\"page-items\">\n    <span class=\"page-text\">Row per page: </span>\n    <l-menu mode=\"right\">\n      <div dropdown-display class=\"paginator-btn paginator-dropdown-btn\">\n        {{ pageSize() }}\n        <svg fill=\"currentColor\" width=\"20\" height=\"20\" viewBox=\"0 0 24 24\">\n          <path\n            d=\"M14.83,11.29,10.59,7.05a1,1,0,0,0-1.42,0,1,1,0,0,0,0,1.41L12.71,12,9.17,15.54a1,1,0,0,0,0,1.41,1,1,0,0,0,.71.29,1,1,0,0,0,.71-.29l4.24-4.24A1,1,0,0,0,14.83,11.29Z\"\n          />\n        </svg>\n      </div>\n\n      @for (item of pageSizeOptions(); track item) {\n        <div dropdown-item [class.active]=\"item === pageSize()\" (click)=\"_onChangePageOption(item)\">\n          {{ item }}\n        </div>\n      }\n    </l-menu>\n  </div>\n</div>\n",
			styles: [":host{display:block}.paginator{display:flex;padding:0 12px;justify-content:space-between;align-items:center;align-self:stretch;row-gap:12px;flex-wrap:wrap}.paginator-dropdown-btn{position:relative;width:auto!important}.paginator-dropdown-btn svg{rotate:90deg}.page-items{display:flex;align-items:center;gap:6px}.page-text{color:var(--text-primary);font-size:14px;font-weight:400;line-height:20px}.page-text.bold{font-weight:700}.page-text.light{color:var(--text-tertiary)}.paginator-btn{display:flex;justify-content:center;align-items:center;gap:4px;padding:6px;border:1px solid var(--accent);border-radius:8px;background:transparent;cursor:pointer;transition:background-color .12s ease-out,color .12s ease-out;color:var(--accent);font-size:14px;font-weight:500;line-height:20px}.paginator-btn:hover{background-color:var(--bg-light)}.paginator-btn.active{background-color:var(--accent);color:var(--accent-contrast)!important}.paginator-btn.disabled{color:var(--text-quaternary);background-color:transparent;cursor:default;border:1px solid var(--separator)}.paginator-btn.page-num{min-width:max(32px,var(--page-num-chars, 1) * 1ch + 14px);height:32px;font-variant-numeric:tabular-nums;color:var(--text-primary)}.arrow-buttons{display:flex;gap:6px;row-gap:12px;flex-wrap:wrap}@media(prefers-reduced-motion:reduce){.paginator-btn{transition:none}}\n"]
		}]
	}],
	propDecorators: {
		pageSizeOptions: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "pageSizeOptions",
				required: false
			}]
		}],
		length: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "length",
				required: false
			}]
		}],
		pageSize: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "pageSize",
				required: false
			}]
		}, {
			type: i0.Output,
			args: ["pageSizeChange"]
		}],
		pageIndex: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "pageIndex",
				required: false
			}]
		}, {
			type: i0.Output,
			args: ["pageIndexChange"]
		}],
		pageChange: [{
			type: i0.Output,
			args: ["pageChange"]
		}]
	}
});
var Tabs = class Tabs {
	orientation = input("horizontal", ...ngDevMode ? [{ debugName: "orientation" }] : /* istanbul ignore next */ []);
	variant = input("line", ...ngDevMode ? [{ debugName: "variant" }] : /* istanbul ignore next */ []);
	size = input("md", ...ngDevMode ? [{ debugName: "size" }] : /* istanbul ignore next */ []);
	grow = input(false, ...ngDevMode ? [{ debugName: "grow" }] : /* istanbul ignore next */ []);
	value = model(null, ...ngDevMode ? [{ debugName: "value" }] : /* istanbul ignore next */ []);
	activeChange = output();
	_tabs = signal([], ...ngDevMode ? [{ debugName: "_tabs" }] : /* istanbul ignore next */ []);
	tabs = this._tabs.asReadonly();
	_buttons = viewChildren("tabBtn", ...ngDevMode ? [{ debugName: "_buttons" }] : /* istanbul ignore next */ []);
	_host = inject(ElementRef);
	_indicator = signal({
		x: 0,
		y: 0,
		width: 0,
		height: 0,
		visible: false
	}, ...ngDevMode ? [{ debugName: "_indicator" }] : /* istanbul ignore next */ []);
	_ready = signal(false, ...ngDevMode ? [{ debugName: "_ready" }] : /* istanbul ignore next */ []);
	_hostClasses = computed(() => {
		const classes = [
			"l-tabs",
			`l-tabs--${this.orientation()}`,
			`l-tabs--${this.variant()}`,
			`l-tabs--${this.size()}`
		];
		if (this.grow()) classes.push("l-tabs--grow");
		return classes.join(" ");
	}, ...ngDevMode ? [{ debugName: "_hostClasses" }] : /* istanbul ignore next */ []);
	constructor() {
		const destroyRef = inject(DestroyRef);
		effect(() => {
			this.value();
			this._tabs();
			this.orientation();
			this.variant();
			this.size();
			this.grow();
			queueMicrotask(() => this._positionIndicator());
		});
		afterNextRender(() => {
			this._positionIndicator();
			requestAnimationFrame(() => this._ready.set(true));
			const observer = new ResizeObserver(() => this._positionIndicator());
			observer.observe(this._host.nativeElement);
			destroyRef.onDestroy(() => observer.disconnect());
		});
	}
	_register(tab) {
		this._tabs.update((tabs) => [...tabs, tab]);
		if (this.value() == null && !tab.disabled()) this.value.set(this._valueOf(tab));
	}
	_unregister(tab) {
		this._tabs.update((tabs) => tabs.filter((t) => t !== tab));
	}
	_valueOf(tab) {
		const value = tab.value();
		return value === void 0 || value === null ? this._tabs().indexOf(tab) : value;
	}
	isActive(tab) {
		return this.value() === this._valueOf(tab);
	}
	_select(tab) {
		if (tab.disabled()) return;
		const value = this._valueOf(tab);
		if (value === this.value()) return;
		this.value.set(value);
		this.activeChange.emit(value);
	}
	_onKeydown(event, index) {
		const vertical = this.orientation() === "vertical";
		let target = -1;
		switch (event.key) {
			case vertical ? "ArrowDown" : "ArrowRight":
				target = this._nextEnabled(index, 1);
				break;
			case vertical ? "ArrowUp" : "ArrowLeft":
				target = this._nextEnabled(index, -1);
				break;
			case "Home":
				target = this._nextEnabled(-1, 1);
				break;
			case "End":
				target = this._nextEnabled(this._tabs().length, -1);
				break;
			default: return;
		}
		if (target < 0) return;
		event.preventDefault();
		this._select(this._tabs()[target]);
		this._buttons()[target]?.nativeElement.focus();
	}
	_nextEnabled(from, direction) {
		const tabs = this._tabs();
		const count = tabs.length;
		for (let step = 1; step <= count; step++) {
			const index = (from + direction * step + count * 2) % count;
			if (!tabs[index].disabled()) return index;
		}
		return -1;
	}
	_positionIndicator() {
		const index = this._tabs().findIndex((t) => this.isActive(t));
		const button = this._buttons()[index]?.nativeElement;
		if (index < 0 || !button) {
			this._indicator.update((i) => ({
				...i,
				visible: false
			}));
			return;
		}
		const line = this.variant() === "line";
		const thickness = 2;
		let geometry;
		if (line && this.orientation() === "horizontal") geometry = {
			x: button.offsetLeft,
			y: button.offsetTop + button.offsetHeight - thickness,
			width: button.offsetWidth,
			height: thickness
		};
		else if (line) geometry = {
			x: button.offsetLeft + button.offsetWidth - thickness,
			y: button.offsetTop,
			width: thickness,
			height: button.offsetHeight
		};
		else geometry = {
			x: button.offsetLeft,
			y: button.offsetTop,
			width: button.offsetWidth,
			height: button.offsetHeight
		};
		this._indicator.set({
			...geometry,
			visible: true
		});
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.1",
		ngImport: i0,
		type: Tabs,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.1",
		type: Tabs,
		isStandalone: true,
		selector: "l-tabs",
		inputs: {
			orientation: {
				classPropertyName: "orientation",
				publicName: "orientation",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			variant: {
				classPropertyName: "variant",
				publicName: "variant",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			size: {
				classPropertyName: "size",
				publicName: "size",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			grow: {
				classPropertyName: "grow",
				publicName: "grow",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			value: {
				classPropertyName: "value",
				publicName: "value",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: {
			value: "valueChange",
			activeChange: "activeChange"
		},
		host: { properties: { "class": "_hostClasses()" } },
		viewQueries: [{
			propertyName: "_buttons",
			predicate: ["tabBtn"],
			descendants: true,
			isSignal: true
		}],
		ngImport: i0,
		template: "<div class=\"l-tabs__list\" role=\"tablist\" [attr.aria-orientation]=\"orientation()\">\n  @for (tab of tabs(); track tab; let i = $index) {\n    <button\n      #tabBtn\n      type=\"button\"\n      role=\"tab\"\n      class=\"l-tabs__tab\"\n      [id]=\"tab.tabId\"\n      [class.is-active]=\"isActive(tab)\"\n      [disabled]=\"tab.disabled()\"\n      [attr.aria-selected]=\"isActive(tab)\"\n      [attr.aria-controls]=\"tab.panelId\"\n      [attr.tabindex]=\"isActive(tab) ? 0 : -1\"\n      (click)=\"_select(tab)\"\n      (keydown)=\"_onKeydown($event, i)\"\n    >\n      @if (tab.icon()) {\n        <span class=\"l-tabs__icon\" aria-hidden=\"true\">{{ tab.icon() }}</span>\n      }\n      <span class=\"l-tabs__label\">{{ tab.label() }}</span>\n    </button>\n  }\n\n  <span\n    class=\"l-tabs__indicator\"\n    [class.is-visible]=\"_indicator().visible\"\n    [class.is-ready]=\"_ready()\"\n    [style.width.px]=\"_indicator().width\"\n    [style.height.px]=\"_indicator().height\"\n    [style.transform]=\"'translate(' + _indicator().x + 'px,' + _indicator().y + 'px)'\"\n    aria-hidden=\"true\"\n  ></span>\n</div>\n\n<div class=\"l-tabs__panels\">\n  <ng-content />\n</div>\n",
		styles: [":host{display:flex;--l-tabs-pad-x: 16px;--l-tabs-pad-y: 10px;--l-tabs-font: 14px;--l-tabs-gap: 2px}:host(.l-tabs--sm){--l-tabs-pad-x: 12px;--l-tabs-pad-y: 7px;--l-tabs-font: 13px}:host(.l-tabs--lg){--l-tabs-pad-x: 20px;--l-tabs-pad-y: 13px;--l-tabs-font: 15px}:host(.l-tabs--horizontal){flex-direction:column}:host(.l-tabs--vertical){flex-direction:row;gap:24px}.l-tabs__list{position:relative;display:flex;gap:var(--l-tabs-gap)}:host(.l-tabs--horizontal) .l-tabs__list{flex-direction:row}:host(.l-tabs--vertical) .l-tabs__list{flex-direction:column;min-width:168px}:host(.l-tabs--line.l-tabs--horizontal) .l-tabs__list{border-bottom:1px solid var(--separator)}:host(.l-tabs--line.l-tabs--vertical) .l-tabs__list{border-right:1px solid var(--separator)}:host(.l-tabs--pills) .l-tabs__list{gap:4px;padding:4px;border-radius:12px;background:var(--bg-light)}:host(.l-tabs--pills.l-tabs--horizontal) .l-tabs__list{align-self:flex-start}.l-tabs__tab{position:relative;z-index:1;display:inline-flex;align-items:center;justify-content:center;gap:8px;padding:var(--l-tabs-pad-y) var(--l-tabs-pad-x);border:none;border-radius:8px;background:transparent;color:var(--text-secondary);font-size:var(--l-tabs-font);font-weight:500;line-height:20px;white-space:nowrap;cursor:pointer;transition:color .16s ease-out,background-color .16s ease-out}.l-tabs__tab:hover:not(:disabled):not(.is-active){color:var(--text-primary)}.l-tabs__tab.is-active{color:var(--accent-dark);font-weight:600}.l-tabs__tab:focus-visible{outline:2px solid var(--accent);outline-offset:-2px}.l-tabs__tab:disabled{opacity:.45;cursor:not-allowed}.l-tabs__icon{font-size:15px;line-height:1}:host(.l-tabs--vertical) .l-tabs__tab{justify-content:flex-start;width:100%;text-align:left}.l-tabs__indicator{position:absolute;top:0;left:0;opacity:0;pointer-events:none}.l-tabs__indicator.is-visible{opacity:1}.l-tabs__indicator.is-ready{transition:transform .26s cubic-bezier(.4,0,.2,1),width .26s cubic-bezier(.4,0,.2,1),height .26s cubic-bezier(.4,0,.2,1)}:host(.l-tabs--line) .l-tabs__indicator{z-index:0;border-radius:2px;background:var(--accent)}:host(.l-tabs--pills) .l-tabs__indicator{z-index:0;border-radius:8px;background:var(--accent);box-shadow:0 1px 3px #07090f2e}:host(.l-tabs--pills) .l-tabs__tab.is-active{color:var(--accent-contrast)}:host(.l-tabs--grow.l-tabs--horizontal) .l-tabs__list{width:100%}:host(.l-tabs--grow.l-tabs--horizontal) .l-tabs__tab{flex:1}.l-tabs__panels{position:relative}:host(.l-tabs--horizontal) .l-tabs__panels{padding-top:16px}:host(.l-tabs--vertical) .l-tabs__panels{flex:1;min-width:0}@media(prefers-reduced-motion:reduce){.l-tabs__tab,.l-tabs__indicator.is-ready{transition:none}}\n"],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: Tabs,
	decorators: [{
		type: Component,
		args: [{
			selector: "l-tabs",
			changeDetection: ChangeDetectionStrategy.OnPush,
			host: { "[class]": "_hostClasses()" },
			template: "<div class=\"l-tabs__list\" role=\"tablist\" [attr.aria-orientation]=\"orientation()\">\n  @for (tab of tabs(); track tab; let i = $index) {\n    <button\n      #tabBtn\n      type=\"button\"\n      role=\"tab\"\n      class=\"l-tabs__tab\"\n      [id]=\"tab.tabId\"\n      [class.is-active]=\"isActive(tab)\"\n      [disabled]=\"tab.disabled()\"\n      [attr.aria-selected]=\"isActive(tab)\"\n      [attr.aria-controls]=\"tab.panelId\"\n      [attr.tabindex]=\"isActive(tab) ? 0 : -1\"\n      (click)=\"_select(tab)\"\n      (keydown)=\"_onKeydown($event, i)\"\n    >\n      @if (tab.icon()) {\n        <span class=\"l-tabs__icon\" aria-hidden=\"true\">{{ tab.icon() }}</span>\n      }\n      <span class=\"l-tabs__label\">{{ tab.label() }}</span>\n    </button>\n  }\n\n  <span\n    class=\"l-tabs__indicator\"\n    [class.is-visible]=\"_indicator().visible\"\n    [class.is-ready]=\"_ready()\"\n    [style.width.px]=\"_indicator().width\"\n    [style.height.px]=\"_indicator().height\"\n    [style.transform]=\"'translate(' + _indicator().x + 'px,' + _indicator().y + 'px)'\"\n    aria-hidden=\"true\"\n  ></span>\n</div>\n\n<div class=\"l-tabs__panels\">\n  <ng-content />\n</div>\n",
			styles: [":host{display:flex;--l-tabs-pad-x: 16px;--l-tabs-pad-y: 10px;--l-tabs-font: 14px;--l-tabs-gap: 2px}:host(.l-tabs--sm){--l-tabs-pad-x: 12px;--l-tabs-pad-y: 7px;--l-tabs-font: 13px}:host(.l-tabs--lg){--l-tabs-pad-x: 20px;--l-tabs-pad-y: 13px;--l-tabs-font: 15px}:host(.l-tabs--horizontal){flex-direction:column}:host(.l-tabs--vertical){flex-direction:row;gap:24px}.l-tabs__list{position:relative;display:flex;gap:var(--l-tabs-gap)}:host(.l-tabs--horizontal) .l-tabs__list{flex-direction:row}:host(.l-tabs--vertical) .l-tabs__list{flex-direction:column;min-width:168px}:host(.l-tabs--line.l-tabs--horizontal) .l-tabs__list{border-bottom:1px solid var(--separator)}:host(.l-tabs--line.l-tabs--vertical) .l-tabs__list{border-right:1px solid var(--separator)}:host(.l-tabs--pills) .l-tabs__list{gap:4px;padding:4px;border-radius:12px;background:var(--bg-light)}:host(.l-tabs--pills.l-tabs--horizontal) .l-tabs__list{align-self:flex-start}.l-tabs__tab{position:relative;z-index:1;display:inline-flex;align-items:center;justify-content:center;gap:8px;padding:var(--l-tabs-pad-y) var(--l-tabs-pad-x);border:none;border-radius:8px;background:transparent;color:var(--text-secondary);font-size:var(--l-tabs-font);font-weight:500;line-height:20px;white-space:nowrap;cursor:pointer;transition:color .16s ease-out,background-color .16s ease-out}.l-tabs__tab:hover:not(:disabled):not(.is-active){color:var(--text-primary)}.l-tabs__tab.is-active{color:var(--accent-dark);font-weight:600}.l-tabs__tab:focus-visible{outline:2px solid var(--accent);outline-offset:-2px}.l-tabs__tab:disabled{opacity:.45;cursor:not-allowed}.l-tabs__icon{font-size:15px;line-height:1}:host(.l-tabs--vertical) .l-tabs__tab{justify-content:flex-start;width:100%;text-align:left}.l-tabs__indicator{position:absolute;top:0;left:0;opacity:0;pointer-events:none}.l-tabs__indicator.is-visible{opacity:1}.l-tabs__indicator.is-ready{transition:transform .26s cubic-bezier(.4,0,.2,1),width .26s cubic-bezier(.4,0,.2,1),height .26s cubic-bezier(.4,0,.2,1)}:host(.l-tabs--line) .l-tabs__indicator{z-index:0;border-radius:2px;background:var(--accent)}:host(.l-tabs--pills) .l-tabs__indicator{z-index:0;border-radius:8px;background:var(--accent);box-shadow:0 1px 3px #07090f2e}:host(.l-tabs--pills) .l-tabs__tab.is-active{color:var(--accent-contrast)}:host(.l-tabs--grow.l-tabs--horizontal) .l-tabs__list{width:100%}:host(.l-tabs--grow.l-tabs--horizontal) .l-tabs__tab{flex:1}.l-tabs__panels{position:relative}:host(.l-tabs--horizontal) .l-tabs__panels{padding-top:16px}:host(.l-tabs--vertical) .l-tabs__panels{flex:1;min-width:0}@media(prefers-reduced-motion:reduce){.l-tabs__tab,.l-tabs__indicator.is-ready{transition:none}}\n"]
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		orientation: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "orientation",
				required: false
			}]
		}],
		variant: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "variant",
				required: false
			}]
		}],
		size: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "size",
				required: false
			}]
		}],
		grow: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "grow",
				required: false
			}]
		}],
		value: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "value",
				required: false
			}]
		}, {
			type: i0.Output,
			args: ["valueChange"]
		}],
		activeChange: [{
			type: i0.Output,
			args: ["activeChange"]
		}],
		_buttons: [{
			type: i0.ViewChildren,
			args: ["tabBtn", { isSignal: true }]
		}]
	}
});
let _uid$1 = 0;
var Tab = class Tab {
	label = input("", ...ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []);
	icon = input("", ...ngDevMode ? [{ debugName: "icon" }] : /* istanbul ignore next */ []);
	value = input(...ngDevMode ? [void 0, { debugName: "value" }] : /* istanbul ignore next */ []);
	disabled = input(false, ...ngDevMode ? [{ debugName: "disabled" }] : /* istanbul ignore next */ []);
	tabId = `l-tab-${_uid$1++}`;
	panelId = `${this.tabId}-panel`;
	_tabs = inject(Tabs);
	_active = computed(() => this._tabs.isActive(this), ...ngDevMode ? [{ debugName: "_active" }] : /* istanbul ignore next */ []);
	ngOnInit() {
		this._tabs._register(this);
	}
	ngOnDestroy() {
		this._tabs._unregister(this);
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.1",
		ngImport: i0,
		type: Tab,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.1",
		type: Tab,
		isStandalone: true,
		selector: "l-tab",
		inputs: {
			label: {
				classPropertyName: "label",
				publicName: "label",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			icon: {
				classPropertyName: "icon",
				publicName: "icon",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			value: {
				classPropertyName: "value",
				publicName: "value",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			disabled: {
				classPropertyName: "disabled",
				publicName: "disabled",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		ngImport: i0,
		template: "<div\n  class=\"l-tab__panel\"\n  role=\"tabpanel\"\n  [id]=\"panelId\"\n  [attr.aria-labelledby]=\"tabId\"\n  [class.is-active]=\"_active()\"\n  [hidden]=\"!_active()\"\n  [attr.inert]=\"_active() ? null : ''\"\n>\n  <ng-content />\n</div>\n",
		styles: [":host{display:block}.l-tab__panel{font-size:14px;line-height:21px;color:var(--text-secondary)}.l-tab__panel.is-active{animation:l-tab-fade .22s ease-out}@keyframes l-tab-fade{0%{opacity:0;transform:translateY(4px)}to{opacity:1;transform:none}}@media(prefers-reduced-motion:reduce){.l-tab__panel.is-active{animation:none}}\n"],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: Tab,
	decorators: [{
		type: Component,
		args: [{
			selector: "l-tab",
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: "<div\n  class=\"l-tab__panel\"\n  role=\"tabpanel\"\n  [id]=\"panelId\"\n  [attr.aria-labelledby]=\"tabId\"\n  [class.is-active]=\"_active()\"\n  [hidden]=\"!_active()\"\n  [attr.inert]=\"_active() ? null : ''\"\n>\n  <ng-content />\n</div>\n",
			styles: [":host{display:block}.l-tab__panel{font-size:14px;line-height:21px;color:var(--text-secondary)}.l-tab__panel.is-active{animation:l-tab-fade .22s ease-out}@keyframes l-tab-fade{0%{opacity:0;transform:translateY(4px)}to{opacity:1;transform:none}}@media(prefers-reduced-motion:reduce){.l-tab__panel.is-active{animation:none}}\n"]
		}]
	}],
	propDecorators: {
		label: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "label",
				required: false
			}]
		}],
		icon: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "icon",
				required: false
			}]
		}],
		value: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "value",
				required: false
			}]
		}],
		disabled: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "disabled",
				required: false
			}]
		}]
	}
});
var Stepper = class Stepper {
	steps = input([], ...ngDevMode ? [{ debugName: "steps" }] : /* istanbul ignore next */ []);
	active = model(0, ...ngDevMode ? [{ debugName: "active" }] : /* istanbul ignore next */ []);
	orientation = input("horizontal", ...ngDevMode ? [{ debugName: "orientation" }] : /* istanbul ignore next */ []);
	showLines = input(true, ...ngDevMode ? [{ debugName: "showLines" }] : /* istanbul ignore next */ []);
	clickable = input(false, ...ngDevMode ? [{ debugName: "clickable" }] : /* istanbul ignore next */ []);
	allowStepSkip = input(false, ...ngDevMode ? [{ debugName: "allowStepSkip" }] : /* istanbul ignore next */ []);
	stepChange = output();
	_steps = computed(() => {
		const active = this.active();
		const clickable = this.clickable();
		const allowSkip = this.allowStepSkip();
		return this.steps().map((step, index) => ({
			...step,
			index,
			number: index + 1,
			status: this._resolveStatus(step, index, active),
			selectable: clickable && !step.disabled && (allowSkip || index <= active)
		}));
	}, ...ngDevMode ? [{ debugName: "_steps" }] : /* istanbul ignore next */ []);
	_hostClasses = computed(() => {
		const classes = ["l-stepper", `l-stepper--${this.orientation()}`];
		if (!this.showLines()) classes.push("l-stepper--no-lines");
		return classes.join(" ");
	}, ...ngDevMode ? [{ debugName: "_hostClasses" }] : /* istanbul ignore next */ []);
	_resolveStatus(step, index, active) {
		if (step.error) return "error";
		if (step.completed || index < active) return "completed";
		if (index === active) return "active";
		return "upcoming";
	}
	_select(step) {
		if (!step.selectable || step.index === this.active()) return;
		this.active.set(step.index);
		this.stepChange.emit(step.index);
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.1",
		ngImport: i0,
		type: Stepper,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.1",
		type: Stepper,
		isStandalone: true,
		selector: "l-stepper",
		inputs: {
			steps: {
				classPropertyName: "steps",
				publicName: "steps",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			active: {
				classPropertyName: "active",
				publicName: "active",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			orientation: {
				classPropertyName: "orientation",
				publicName: "orientation",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			showLines: {
				classPropertyName: "showLines",
				publicName: "showLines",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			clickable: {
				classPropertyName: "clickable",
				publicName: "clickable",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			allowStepSkip: {
				classPropertyName: "allowStepSkip",
				publicName: "allowStepSkip",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: {
			active: "activeChange",
			stepChange: "stepChange"
		},
		host: { properties: { "class": "_hostClasses()" } },
		ngImport: i0,
		template: "<div class=\"l-stepper__list\" role=\"list\">\n  @for (step of _steps(); track step.index; let last = $last) {\n    <button\n      type=\"button\"\n      class=\"l-stepper__step\"\n      role=\"listitem\"\n      [class]=\"'is-' + step.status\"\n      [class.is-selectable]=\"step.selectable\"\n      [class.is-disabled]=\"step.disabled\"\n      [disabled]=\"!step.selectable\"\n      [attr.aria-current]=\"step.status === 'active' ? 'step' : null\"\n      (click)=\"_select(step)\"\n    >\n      <span class=\"l-stepper__indicator-wrap\">\n        <span class=\"l-stepper__indicator\">\n          @switch (step.status) {\n            @case ('completed') {\n              <svg\n                class=\"l-stepper__icon\"\n                width=\"18\"\n                height=\"18\"\n                viewBox=\"0 0 20 20\"\n                fill=\"none\"\n                aria-hidden=\"true\"\n                xmlns=\"http://www.w3.org/2000/svg\"\n              >\n                <path\n                  d=\"M5 10.5L8.5 14L15 6.5\"\n                  stroke=\"currentColor\"\n                  stroke-width=\"2\"\n                  stroke-linecap=\"round\"\n                  stroke-linejoin=\"round\"\n                />\n              </svg>\n            }\n            @case ('error') {\n              <svg\n                class=\"l-stepper__icon\"\n                width=\"18\"\n                height=\"18\"\n                viewBox=\"0 0 20 20\"\n                fill=\"none\"\n                aria-hidden=\"true\"\n                xmlns=\"http://www.w3.org/2000/svg\"\n              >\n                <path\n                  d=\"M10 5.5V11\"\n                  stroke=\"currentColor\"\n                  stroke-width=\"2\"\n                  stroke-linecap=\"round\"\n                />\n                <circle cx=\"10\" cy=\"14.5\" r=\"1.1\" fill=\"currentColor\" />\n              </svg>\n            }\n            @default {\n              @if (step.icon) {\n                <span class=\"l-stepper__custom-icon\" aria-hidden=\"true\">{{ step.icon }}</span>\n              } @else {\n                <span class=\"l-stepper__number\">{{ step.number }}</span>\n              }\n            }\n          }\n        </span>\n\n        @if (orientation() === 'vertical' && !last) {\n          <span\n            class=\"l-stepper__connector\"\n            [class.is-done]=\"step.status === 'completed'\"\n            aria-hidden=\"true\"\n          ></span>\n        }\n      </span>\n\n      <span class=\"l-stepper__label\">\n        <span class=\"l-stepper__title\">{{ step.title }}</span>\n        @if (step.description) {\n          <span class=\"l-stepper__description\">{{ step.description }}</span>\n        }\n      </span>\n    </button>\n\n    @if (orientation() === 'horizontal' && !last) {\n      <span\n        class=\"l-stepper__connector\"\n        [class.is-done]=\"step.status === 'completed'\"\n        aria-hidden=\"true\"\n      ></span>\n    }\n  }\n</div>\n",
		styles: [":host{display:block;--l-stepper-size: 34px;--l-stepper-line: var(--separator-dark);--l-stepper-line-done: var(--accent);--l-stepper-gap: 12px}.l-stepper__list{display:flex}.l-stepper__step{display:flex;align-items:center;gap:var(--l-stepper-gap);padding:8px 10px;border:none;border-radius:12px;background:transparent;color:inherit;font:inherit;text-align:left;cursor:default;transition:background-color .15s ease-out}.l-stepper__step.is-selectable{cursor:pointer}.l-stepper__step.is-selectable:hover{background:var(--bg-light)}.l-stepper__step.is-selectable:active{background:var(--bg-dark)}.l-stepper__step:focus-visible{outline:2px solid var(--accent);outline-offset:1px}.l-stepper__step.is-disabled{opacity:.45}.l-stepper__indicator-wrap{display:flex;align-items:center;flex-shrink:0}.l-stepper__indicator{display:inline-flex;align-items:center;justify-content:center;flex-shrink:0;width:var(--l-stepper-size);height:var(--l-stepper-size);border:2px solid var(--separator-dark);border-radius:50%;background:var(--bg-lightest);color:var(--text-tertiary);font-size:14px;font-weight:600;line-height:1;transition:background-color .18s ease-out,border-color .18s ease-out,color .18s ease-out,box-shadow .18s ease-out}.l-stepper__custom-icon{font-size:15px}.l-stepper__step.is-selectable:hover .l-stepper__indicator{border-color:var(--text-quaternary)}.l-stepper__step.is-active .l-stepper__indicator{border-color:var(--accent);background:var(--accent);color:var(--accent-contrast);box-shadow:0 0 0 4px var(--accent-bg)}.l-stepper__step.is-active .l-stepper__title{color:var(--text-primary)}.l-stepper__step.is-active.is-selectable:hover .l-stepper__indicator{border-color:var(--accent)}.l-stepper__step.is-completed .l-stepper__indicator{border-color:var(--success);background:var(--success);color:var(--text-white)}.l-stepper__step.is-completed.is-selectable:hover .l-stepper__indicator{border-color:var(--success)}.l-stepper__step.is-error .l-stepper__indicator{border-color:var(--error);background:var(--error);color:var(--text-white)}.l-stepper__step.is-error .l-stepper__title{color:var(--error)}.l-stepper__step.is-error.is-selectable:hover .l-stepper__indicator{border-color:var(--error)}.l-stepper__label{display:flex;flex-direction:column;gap:1px;min-width:0}.l-stepper__title{font-size:14px;font-weight:600;line-height:20px;color:var(--text-secondary);transition:color .15s ease-out}.l-stepper__description{font-size:12.5px;line-height:17px;color:var(--text-quaternary)}.l-stepper__connector{background:var(--l-stepper-line);border-radius:2px;transition:background-color .2s ease-out}.l-stepper__connector.is-done{background:var(--l-stepper-line-done)}:host(.l-stepper--no-lines) .l-stepper__connector{background:transparent}:host(.l-stepper--horizontal) .l-stepper__list{align-items:center}:host(.l-stepper--horizontal) .l-stepper__connector{flex:1;height:2px;min-width:24px;margin:0 8px}:host(.l-stepper--vertical) .l-stepper__list{flex-direction:column;align-items:stretch}:host(.l-stepper--vertical) .l-stepper__step{align-items:flex-start}:host(.l-stepper--vertical) .l-stepper__indicator-wrap{flex-direction:column;align-self:stretch}:host(.l-stepper--vertical) .l-stepper__connector{width:2px;flex:1;min-height:22px;margin:6px 0}:host(.l-stepper--vertical) .l-stepper__label{padding-top:6px;padding-bottom:20px}:host(.l-stepper--vertical) .l-stepper__step:last-child .l-stepper__label{padding-bottom:0}@media(prefers-reduced-motion:reduce){.l-stepper__step,.l-stepper__indicator,.l-stepper__connector,.l-stepper__title{transition:none}}\n"],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: Stepper,
	decorators: [{
		type: Component,
		args: [{
			selector: "l-stepper",
			changeDetection: ChangeDetectionStrategy.OnPush,
			host: { "[class]": "_hostClasses()" },
			template: "<div class=\"l-stepper__list\" role=\"list\">\n  @for (step of _steps(); track step.index; let last = $last) {\n    <button\n      type=\"button\"\n      class=\"l-stepper__step\"\n      role=\"listitem\"\n      [class]=\"'is-' + step.status\"\n      [class.is-selectable]=\"step.selectable\"\n      [class.is-disabled]=\"step.disabled\"\n      [disabled]=\"!step.selectable\"\n      [attr.aria-current]=\"step.status === 'active' ? 'step' : null\"\n      (click)=\"_select(step)\"\n    >\n      <span class=\"l-stepper__indicator-wrap\">\n        <span class=\"l-stepper__indicator\">\n          @switch (step.status) {\n            @case ('completed') {\n              <svg\n                class=\"l-stepper__icon\"\n                width=\"18\"\n                height=\"18\"\n                viewBox=\"0 0 20 20\"\n                fill=\"none\"\n                aria-hidden=\"true\"\n                xmlns=\"http://www.w3.org/2000/svg\"\n              >\n                <path\n                  d=\"M5 10.5L8.5 14L15 6.5\"\n                  stroke=\"currentColor\"\n                  stroke-width=\"2\"\n                  stroke-linecap=\"round\"\n                  stroke-linejoin=\"round\"\n                />\n              </svg>\n            }\n            @case ('error') {\n              <svg\n                class=\"l-stepper__icon\"\n                width=\"18\"\n                height=\"18\"\n                viewBox=\"0 0 20 20\"\n                fill=\"none\"\n                aria-hidden=\"true\"\n                xmlns=\"http://www.w3.org/2000/svg\"\n              >\n                <path\n                  d=\"M10 5.5V11\"\n                  stroke=\"currentColor\"\n                  stroke-width=\"2\"\n                  stroke-linecap=\"round\"\n                />\n                <circle cx=\"10\" cy=\"14.5\" r=\"1.1\" fill=\"currentColor\" />\n              </svg>\n            }\n            @default {\n              @if (step.icon) {\n                <span class=\"l-stepper__custom-icon\" aria-hidden=\"true\">{{ step.icon }}</span>\n              } @else {\n                <span class=\"l-stepper__number\">{{ step.number }}</span>\n              }\n            }\n          }\n        </span>\n\n        @if (orientation() === 'vertical' && !last) {\n          <span\n            class=\"l-stepper__connector\"\n            [class.is-done]=\"step.status === 'completed'\"\n            aria-hidden=\"true\"\n          ></span>\n        }\n      </span>\n\n      <span class=\"l-stepper__label\">\n        <span class=\"l-stepper__title\">{{ step.title }}</span>\n        @if (step.description) {\n          <span class=\"l-stepper__description\">{{ step.description }}</span>\n        }\n      </span>\n    </button>\n\n    @if (orientation() === 'horizontal' && !last) {\n      <span\n        class=\"l-stepper__connector\"\n        [class.is-done]=\"step.status === 'completed'\"\n        aria-hidden=\"true\"\n      ></span>\n    }\n  }\n</div>\n",
			styles: [":host{display:block;--l-stepper-size: 34px;--l-stepper-line: var(--separator-dark);--l-stepper-line-done: var(--accent);--l-stepper-gap: 12px}.l-stepper__list{display:flex}.l-stepper__step{display:flex;align-items:center;gap:var(--l-stepper-gap);padding:8px 10px;border:none;border-radius:12px;background:transparent;color:inherit;font:inherit;text-align:left;cursor:default;transition:background-color .15s ease-out}.l-stepper__step.is-selectable{cursor:pointer}.l-stepper__step.is-selectable:hover{background:var(--bg-light)}.l-stepper__step.is-selectable:active{background:var(--bg-dark)}.l-stepper__step:focus-visible{outline:2px solid var(--accent);outline-offset:1px}.l-stepper__step.is-disabled{opacity:.45}.l-stepper__indicator-wrap{display:flex;align-items:center;flex-shrink:0}.l-stepper__indicator{display:inline-flex;align-items:center;justify-content:center;flex-shrink:0;width:var(--l-stepper-size);height:var(--l-stepper-size);border:2px solid var(--separator-dark);border-radius:50%;background:var(--bg-lightest);color:var(--text-tertiary);font-size:14px;font-weight:600;line-height:1;transition:background-color .18s ease-out,border-color .18s ease-out,color .18s ease-out,box-shadow .18s ease-out}.l-stepper__custom-icon{font-size:15px}.l-stepper__step.is-selectable:hover .l-stepper__indicator{border-color:var(--text-quaternary)}.l-stepper__step.is-active .l-stepper__indicator{border-color:var(--accent);background:var(--accent);color:var(--accent-contrast);box-shadow:0 0 0 4px var(--accent-bg)}.l-stepper__step.is-active .l-stepper__title{color:var(--text-primary)}.l-stepper__step.is-active.is-selectable:hover .l-stepper__indicator{border-color:var(--accent)}.l-stepper__step.is-completed .l-stepper__indicator{border-color:var(--success);background:var(--success);color:var(--text-white)}.l-stepper__step.is-completed.is-selectable:hover .l-stepper__indicator{border-color:var(--success)}.l-stepper__step.is-error .l-stepper__indicator{border-color:var(--error);background:var(--error);color:var(--text-white)}.l-stepper__step.is-error .l-stepper__title{color:var(--error)}.l-stepper__step.is-error.is-selectable:hover .l-stepper__indicator{border-color:var(--error)}.l-stepper__label{display:flex;flex-direction:column;gap:1px;min-width:0}.l-stepper__title{font-size:14px;font-weight:600;line-height:20px;color:var(--text-secondary);transition:color .15s ease-out}.l-stepper__description{font-size:12.5px;line-height:17px;color:var(--text-quaternary)}.l-stepper__connector{background:var(--l-stepper-line);border-radius:2px;transition:background-color .2s ease-out}.l-stepper__connector.is-done{background:var(--l-stepper-line-done)}:host(.l-stepper--no-lines) .l-stepper__connector{background:transparent}:host(.l-stepper--horizontal) .l-stepper__list{align-items:center}:host(.l-stepper--horizontal) .l-stepper__connector{flex:1;height:2px;min-width:24px;margin:0 8px}:host(.l-stepper--vertical) .l-stepper__list{flex-direction:column;align-items:stretch}:host(.l-stepper--vertical) .l-stepper__step{align-items:flex-start}:host(.l-stepper--vertical) .l-stepper__indicator-wrap{flex-direction:column;align-self:stretch}:host(.l-stepper--vertical) .l-stepper__connector{width:2px;flex:1;min-height:22px;margin:6px 0}:host(.l-stepper--vertical) .l-stepper__label{padding-top:6px;padding-bottom:20px}:host(.l-stepper--vertical) .l-stepper__step:last-child .l-stepper__label{padding-bottom:0}@media(prefers-reduced-motion:reduce){.l-stepper__step,.l-stepper__indicator,.l-stepper__connector,.l-stepper__title{transition:none}}\n"]
		}]
	}],
	propDecorators: {
		steps: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "steps",
				required: false
			}]
		}],
		active: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "active",
				required: false
			}]
		}, {
			type: i0.Output,
			args: ["activeChange"]
		}],
		orientation: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "orientation",
				required: false
			}]
		}],
		showLines: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "showLines",
				required: false
			}]
		}],
		clickable: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "clickable",
				required: false
			}]
		}],
		allowStepSkip: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "allowStepSkip",
				required: false
			}]
		}],
		stepChange: [{
			type: i0.Output,
			args: ["stepChange"]
		}]
	}
});
var TreeItem = class TreeItem {
	node = input.required(...ngDevMode ? [{ debugName: "node" }] : /* istanbul ignore next */ []);
	guides = input([], ...ngDevMode ? [{ debugName: "guides" }] : /* istanbul ignore next */ []);
	isLast = input(false, ...ngDevMode ? [{ debugName: "isLast" }] : /* istanbul ignore next */ []);
	_tree = inject(Tree);
	_hasChildren = computed(() => !!this.node().children?.length, ...ngDevMode ? [{ debugName: "_hasChildren" }] : /* istanbul ignore next */ []);
	_expanded = computed(() => this._tree.isExpanded(this.node()), ...ngDevMode ? [{ debugName: "_expanded" }] : /* istanbul ignore next */ []);
	_selected = computed(() => this._tree.isSelected(this.node()), ...ngDevMode ? [{ debugName: "_selected" }] : /* istanbul ignore next */ []);
	_checkState = computed(() => this._tree.checkState(this.node()), ...ngDevMode ? [{ debugName: "_checkState" }] : /* istanbul ignore next */ []);
	_showLine = computed(() => this._tree.showLine(), ...ngDevMode ? [{ debugName: "_showLine" }] : /* istanbul ignore next */ []);
	_checkable = computed(() => this._tree.checkable(), ...ngDevMode ? [{ debugName: "_checkable" }] : /* istanbul ignore next */ []);
	_showIcon = computed(() => this._tree.showIcon(), ...ngDevMode ? [{ debugName: "_showIcon" }] : /* istanbul ignore next */ []);
	_childGuides = computed(() => [...this.guides(), !this.isLast()], ...ngDevMode ? [{ debugName: "_childGuides" }] : /* istanbul ignore next */ []);
	_mounted = signal(false, ...ngDevMode ? [{ debugName: "_mounted" }] : /* istanbul ignore next */ []);
	_renderChildren = computed(() => this._mounted(), ...ngDevMode ? [{ debugName: "_renderChildren" }] : /* istanbul ignore next */ []);
	constructor() {
		effect(() => {
			if (this._expanded()) this._mounted.set(true);
		});
	}
	_onRow() {
		this._tree.onRowClick(this.node());
	}
	_onToggle(event) {
		event.stopPropagation();
		this._tree.toggleExpand(this.node());
	}
	_onCheck() {
		this._tree.toggleCheck(this.node());
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.1",
		ngImport: i0,
		type: TreeItem,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.1",
		type: TreeItem,
		isStandalone: true,
		selector: "l-tree-item",
		inputs: {
			node: {
				classPropertyName: "node",
				publicName: "node",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			guides: {
				classPropertyName: "guides",
				publicName: "guides",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			isLast: {
				classPropertyName: "isLast",
				publicName: "isLast",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		host: { classAttribute: "l-tree-item" },
		ngImport: i0,
		template: "<div\n  class=\"l-tree-item__row\"\n  role=\"treeitem\"\n  [attr.aria-expanded]=\"_hasChildren() ? _expanded() : null\"\n  [attr.aria-selected]=\"_selected()\"\n  [attr.aria-disabled]=\"node().disabled || null\"\n  [class.is-selected]=\"_selected()\"\n  [class.is-disabled]=\"node().disabled\"\n  (click)=\"_onRow()\"\n>\n  @if (_showLine()) {\n    @for (g of guides(); track $index; let cellLast = $last) {\n      <span class=\"l-tree-item__guide\" [class.is-connector]=\"cellLast\">\n        @if (cellLast) {\n          <span class=\"l-tree-item__elbow\"></span>\n          @if (!isLast()) {\n            <span class=\"l-tree-item__continue\"></span>\n          }\n        } @else if (g) {\n          <span class=\"l-tree-item__through\"></span>\n        }\n      </span>\n    }\n  } @else {\n    @for (g of guides(); track $index) {\n      <span class=\"l-tree-item__indent\"></span>\n    }\n  }\n\n  <span\n    class=\"l-tree-item__switch\"\n    [class.line-down]=\"_showLine() && _hasChildren() && _expanded()\"\n  >\n    @if (_hasChildren()) {\n      <button\n        type=\"button\"\n        class=\"l-tree-item__toggle\"\n        [class.is-expanded]=\"_expanded()\"\n        [attr.aria-label]=\"_expanded() ? 'Collapse' : 'Expand'\"\n        (click)=\"_onToggle($event)\"\n      >\n        <svg\n          class=\"l-tree-item__chevron\"\n          width=\"10\"\n          height=\"10\"\n          viewBox=\"0 0 10 10\"\n          fill=\"none\"\n          aria-hidden=\"true\"\n          xmlns=\"http://www.w3.org/2000/svg\"\n        >\n          <path\n            d=\"M3 1.5L6.5 5L3 8.5\"\n            stroke=\"currentColor\"\n            stroke-width=\"1.5\"\n            stroke-linecap=\"round\"\n            stroke-linejoin=\"round\"\n          />\n        </svg>\n      </button>\n    }\n  </span>\n\n  @if (_checkable()) {\n    <input\n      type=\"checkbox\"\n      class=\"l-tree-item__checkbox\"\n      [checked]=\"_checkState() === 'checked'\"\n      [indeterminate]=\"_checkState() === 'indeterminate'\"\n      [disabled]=\"node().disabled || node().disableCheckbox\"\n      (click)=\"$event.stopPropagation()\"\n      (change)=\"_onCheck()\"\n    />\n  }\n\n  <span class=\"l-tree-item__content\">\n    @if (_showIcon() && node().icon) {\n      <span class=\"l-tree-item__icon\" aria-hidden=\"true\">{{ node().icon }}</span>\n    }\n    <span class=\"l-tree-item__label\">{{ node().label }}</span>\n  </span>\n</div>\n\n@if (_hasChildren()) {\n  <div\n    class=\"l-tree-item__children\"\n    role=\"group\"\n    [class.is-open]=\"_expanded()\"\n    [attr.inert]=\"_expanded() ? null : ''\"\n  >\n    <div class=\"l-tree-item__children-inner\">\n      @if (_renderChildren()) {\n        @for (child of node().children; track child.key; let last = $last) {\n          <l-tree-item [node]=\"child\" [guides]=\"_childGuides()\" [isLast]=\"last\" />\n        }\n      }\n    </div>\n  </div>\n}\n",
		styles: [":host{display:block}.l-tree-item__row{display:flex;align-items:center;min-height:var(--l-tree-row-min-height, 30px);cursor:pointer}.l-tree-item__row.is-disabled{cursor:not-allowed}.l-tree-item__row.is-disabled .l-tree-item__content{color:var(--text-quaternary)}.l-tree-item__guide,.l-tree-item__indent{position:relative;flex:0 0 auto;align-self:stretch;width:var(--l-tree-indent)}.l-tree-item__through{position:absolute;top:0;bottom:0;left:50%;width:2px;margin-left:-1px;background:var(--l-tree-line)}.l-tree-item__elbow{position:absolute;top:0;left:50%;right:calc(var(--l-tree-indent) / -2);height:50%;border-left:2px solid var(--l-tree-line);border-bottom:2px solid var(--l-tree-line);border-bottom-left-radius:10px}.l-tree-item__continue{position:absolute;top:50%;bottom:0;left:50%;width:2px;margin-left:-1px;background:var(--l-tree-line)}.l-tree-item__switch{position:relative;display:inline-flex;align-items:center;justify-content:center;flex:0 0 auto;align-self:stretch;width:var(--l-tree-indent)}.l-tree-item__switch.line-down:after{content:\"\";position:absolute;top:50%;bottom:0;left:50%;width:2px;margin-left:-1px;background:var(--l-tree-line)}.l-tree-item__toggle{position:relative;z-index:1;display:inline-flex;align-items:center;justify-content:center;width:18px;height:18px;padding:0;border:none;border-radius:5px;background:var(--bg-lightest);color:var(--text-tertiary);cursor:pointer;transition:background-color .15s ease-out,color .15s ease-out}.l-tree-item__toggle:hover{background:var(--bg-dark);color:var(--text-primary)}.l-tree-item__toggle:focus-visible{outline:2px solid var(--accent);outline-offset:1px}.l-tree-item__chevron{transition:transform .16s cubic-bezier(.4,0,.2,1)}.l-tree-item__toggle.is-expanded .l-tree-item__chevron{transform:rotate(90deg)}.l-tree-item__checkbox{flex:0 0 auto;appearance:none;width:16px;height:16px;margin:0 8px 0 2px;border:1.5px solid var(--separator-dark);border-radius:4px;background:var(--bg-lightest);cursor:pointer;position:relative;transition:background-color .14s ease-out,border-color .14s ease-out}.l-tree-item__checkbox:hover:not(:disabled){border-color:var(--accent)}.l-tree-item__checkbox:checked,.l-tree-item__checkbox:indeterminate{border-color:var(--accent);background:var(--accent)}.l-tree-item__checkbox:checked:after{content:\"\";position:absolute;left:4.5px;top:1px;width:4px;height:8px;border:solid var(--accent-contrast);border-width:0 2px 2px 0;transform:rotate(45deg)}.l-tree-item__checkbox:indeterminate:after{content:\"\";position:absolute;left:3px;top:6px;width:8px;height:2px;background:var(--accent-contrast);border-radius:1px}.l-tree-item__checkbox:focus-visible{outline:2px solid var(--accent);outline-offset:1px}.l-tree-item__checkbox:disabled{opacity:.5;cursor:not-allowed}.l-tree-item__content{display:inline-flex;align-items:center;gap:6px;min-width:0;padding:3px 8px;border-radius:6px;line-height:20px;transition:background-color .14s ease-out,color .14s ease-out}.l-tree-item__icon{flex:0 0 auto;font-size:15px;line-height:1}.l-tree-item__label{overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.l-tree-item__children{display:grid;grid-template-rows:0fr;transition:grid-template-rows .24s cubic-bezier(.4,0,.2,1)}.l-tree-item__children.is-open{grid-template-rows:1fr}.l-tree-item__children-inner{overflow:hidden;min-height:0}.l-tree-item__row:not(.is-disabled):hover .l-tree-item__content{background:var(--bg-light)}.l-tree-item__row.is-selected .l-tree-item__content{background:var(--accent-bg);color:var(--accent-dark);font-weight:500}@media(prefers-reduced-motion:reduce){.l-tree-item__chevron,.l-tree-item__toggle,.l-tree-item__content,.l-tree-item__checkbox,.l-tree-item__children{transition:none}}\n"],
		dependencies: [{
			kind: "component",
			type: TreeItem,
			selector: "l-tree-item",
			inputs: [
				"node",
				"guides",
				"isLast"
			]
		}],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: TreeItem,
	decorators: [{
		type: Component,
		args: [{
			selector: "l-tree-item",
			changeDetection: ChangeDetectionStrategy.OnPush,
			imports: [TreeItem],
			host: { class: "l-tree-item" },
			template: "<div\n  class=\"l-tree-item__row\"\n  role=\"treeitem\"\n  [attr.aria-expanded]=\"_hasChildren() ? _expanded() : null\"\n  [attr.aria-selected]=\"_selected()\"\n  [attr.aria-disabled]=\"node().disabled || null\"\n  [class.is-selected]=\"_selected()\"\n  [class.is-disabled]=\"node().disabled\"\n  (click)=\"_onRow()\"\n>\n  @if (_showLine()) {\n    @for (g of guides(); track $index; let cellLast = $last) {\n      <span class=\"l-tree-item__guide\" [class.is-connector]=\"cellLast\">\n        @if (cellLast) {\n          <span class=\"l-tree-item__elbow\"></span>\n          @if (!isLast()) {\n            <span class=\"l-tree-item__continue\"></span>\n          }\n        } @else if (g) {\n          <span class=\"l-tree-item__through\"></span>\n        }\n      </span>\n    }\n  } @else {\n    @for (g of guides(); track $index) {\n      <span class=\"l-tree-item__indent\"></span>\n    }\n  }\n\n  <span\n    class=\"l-tree-item__switch\"\n    [class.line-down]=\"_showLine() && _hasChildren() && _expanded()\"\n  >\n    @if (_hasChildren()) {\n      <button\n        type=\"button\"\n        class=\"l-tree-item__toggle\"\n        [class.is-expanded]=\"_expanded()\"\n        [attr.aria-label]=\"_expanded() ? 'Collapse' : 'Expand'\"\n        (click)=\"_onToggle($event)\"\n      >\n        <svg\n          class=\"l-tree-item__chevron\"\n          width=\"10\"\n          height=\"10\"\n          viewBox=\"0 0 10 10\"\n          fill=\"none\"\n          aria-hidden=\"true\"\n          xmlns=\"http://www.w3.org/2000/svg\"\n        >\n          <path\n            d=\"M3 1.5L6.5 5L3 8.5\"\n            stroke=\"currentColor\"\n            stroke-width=\"1.5\"\n            stroke-linecap=\"round\"\n            stroke-linejoin=\"round\"\n          />\n        </svg>\n      </button>\n    }\n  </span>\n\n  @if (_checkable()) {\n    <input\n      type=\"checkbox\"\n      class=\"l-tree-item__checkbox\"\n      [checked]=\"_checkState() === 'checked'\"\n      [indeterminate]=\"_checkState() === 'indeterminate'\"\n      [disabled]=\"node().disabled || node().disableCheckbox\"\n      (click)=\"$event.stopPropagation()\"\n      (change)=\"_onCheck()\"\n    />\n  }\n\n  <span class=\"l-tree-item__content\">\n    @if (_showIcon() && node().icon) {\n      <span class=\"l-tree-item__icon\" aria-hidden=\"true\">{{ node().icon }}</span>\n    }\n    <span class=\"l-tree-item__label\">{{ node().label }}</span>\n  </span>\n</div>\n\n@if (_hasChildren()) {\n  <div\n    class=\"l-tree-item__children\"\n    role=\"group\"\n    [class.is-open]=\"_expanded()\"\n    [attr.inert]=\"_expanded() ? null : ''\"\n  >\n    <div class=\"l-tree-item__children-inner\">\n      @if (_renderChildren()) {\n        @for (child of node().children; track child.key; let last = $last) {\n          <l-tree-item [node]=\"child\" [guides]=\"_childGuides()\" [isLast]=\"last\" />\n        }\n      }\n    </div>\n  </div>\n}\n",
			styles: [":host{display:block}.l-tree-item__row{display:flex;align-items:center;min-height:var(--l-tree-row-min-height, 30px);cursor:pointer}.l-tree-item__row.is-disabled{cursor:not-allowed}.l-tree-item__row.is-disabled .l-tree-item__content{color:var(--text-quaternary)}.l-tree-item__guide,.l-tree-item__indent{position:relative;flex:0 0 auto;align-self:stretch;width:var(--l-tree-indent)}.l-tree-item__through{position:absolute;top:0;bottom:0;left:50%;width:2px;margin-left:-1px;background:var(--l-tree-line)}.l-tree-item__elbow{position:absolute;top:0;left:50%;right:calc(var(--l-tree-indent) / -2);height:50%;border-left:2px solid var(--l-tree-line);border-bottom:2px solid var(--l-tree-line);border-bottom-left-radius:10px}.l-tree-item__continue{position:absolute;top:50%;bottom:0;left:50%;width:2px;margin-left:-1px;background:var(--l-tree-line)}.l-tree-item__switch{position:relative;display:inline-flex;align-items:center;justify-content:center;flex:0 0 auto;align-self:stretch;width:var(--l-tree-indent)}.l-tree-item__switch.line-down:after{content:\"\";position:absolute;top:50%;bottom:0;left:50%;width:2px;margin-left:-1px;background:var(--l-tree-line)}.l-tree-item__toggle{position:relative;z-index:1;display:inline-flex;align-items:center;justify-content:center;width:18px;height:18px;padding:0;border:none;border-radius:5px;background:var(--bg-lightest);color:var(--text-tertiary);cursor:pointer;transition:background-color .15s ease-out,color .15s ease-out}.l-tree-item__toggle:hover{background:var(--bg-dark);color:var(--text-primary)}.l-tree-item__toggle:focus-visible{outline:2px solid var(--accent);outline-offset:1px}.l-tree-item__chevron{transition:transform .16s cubic-bezier(.4,0,.2,1)}.l-tree-item__toggle.is-expanded .l-tree-item__chevron{transform:rotate(90deg)}.l-tree-item__checkbox{flex:0 0 auto;appearance:none;width:16px;height:16px;margin:0 8px 0 2px;border:1.5px solid var(--separator-dark);border-radius:4px;background:var(--bg-lightest);cursor:pointer;position:relative;transition:background-color .14s ease-out,border-color .14s ease-out}.l-tree-item__checkbox:hover:not(:disabled){border-color:var(--accent)}.l-tree-item__checkbox:checked,.l-tree-item__checkbox:indeterminate{border-color:var(--accent);background:var(--accent)}.l-tree-item__checkbox:checked:after{content:\"\";position:absolute;left:4.5px;top:1px;width:4px;height:8px;border:solid var(--accent-contrast);border-width:0 2px 2px 0;transform:rotate(45deg)}.l-tree-item__checkbox:indeterminate:after{content:\"\";position:absolute;left:3px;top:6px;width:8px;height:2px;background:var(--accent-contrast);border-radius:1px}.l-tree-item__checkbox:focus-visible{outline:2px solid var(--accent);outline-offset:1px}.l-tree-item__checkbox:disabled{opacity:.5;cursor:not-allowed}.l-tree-item__content{display:inline-flex;align-items:center;gap:6px;min-width:0;padding:3px 8px;border-radius:6px;line-height:20px;transition:background-color .14s ease-out,color .14s ease-out}.l-tree-item__icon{flex:0 0 auto;font-size:15px;line-height:1}.l-tree-item__label{overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.l-tree-item__children{display:grid;grid-template-rows:0fr;transition:grid-template-rows .24s cubic-bezier(.4,0,.2,1)}.l-tree-item__children.is-open{grid-template-rows:1fr}.l-tree-item__children-inner{overflow:hidden;min-height:0}.l-tree-item__row:not(.is-disabled):hover .l-tree-item__content{background:var(--bg-light)}.l-tree-item__row.is-selected .l-tree-item__content{background:var(--accent-bg);color:var(--accent-dark);font-weight:500}@media(prefers-reduced-motion:reduce){.l-tree-item__chevron,.l-tree-item__toggle,.l-tree-item__content,.l-tree-item__checkbox,.l-tree-item__children{transition:none}}\n"]
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		node: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "node",
				required: true
			}]
		}],
		guides: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "guides",
				required: false
			}]
		}],
		isLast: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "isLast",
				required: false
			}]
		}]
	}
});
var Tree = class Tree {
	nodes = input([], ...ngDevMode ? [{ debugName: "nodes" }] : /* istanbul ignore next */ []);
	checkable = input(false, ...ngDevMode ? [{ debugName: "checkable" }] : /* istanbul ignore next */ []);
	showLine = input(true, ...ngDevMode ? [{ debugName: "showLine" }] : /* istanbul ignore next */ []);
	showIcon = input(false, ...ngDevMode ? [{ debugName: "showIcon" }] : /* istanbul ignore next */ []);
	selectable = input(true, ...ngDevMode ? [{ debugName: "selectable" }] : /* istanbul ignore next */ []);
	multiple = input(false, ...ngDevMode ? [{ debugName: "multiple" }] : /* istanbul ignore next */ []);
	checkStrictly = input(false, ...ngDevMode ? [{ debugName: "checkStrictly" }] : /* istanbul ignore next */ []);
	expandedKeys = model([], ...ngDevMode ? [{ debugName: "expandedKeys" }] : /* istanbul ignore next */ []);
	checkedKeys = model([], ...ngDevMode ? [{ debugName: "checkedKeys" }] : /* istanbul ignore next */ []);
	selectedKeys = model([], ...ngDevMode ? [{ debugName: "selectedKeys" }] : /* istanbul ignore next */ []);
	nodeClick = output();
	selectedChange = output();
	checkedChange = output();
	expandedChange = output();
	_expandedSet = computed(() => new Set(this.expandedKeys()), ...ngDevMode ? [{ debugName: "_expandedSet" }] : /* istanbul ignore next */ []);
	_checkedSet = computed(() => new Set(this.checkedKeys()), ...ngDevMode ? [{ debugName: "_checkedSet" }] : /* istanbul ignore next */ []);
	_selectedSet = computed(() => new Set(this.selectedKeys()), ...ngDevMode ? [{ debugName: "_selectedSet" }] : /* istanbul ignore next */ []);
	_index = computed(() => {
		const map = /* @__PURE__ */ new Map();
		const parent = /* @__PURE__ */ new Map();
		const walk = (list, parentKey) => {
			for (const node of list) {
				map.set(node.key, node);
				parent.set(node.key, parentKey);
				if (node.children?.length) walk(node.children, node.key);
			}
		};
		walk(this.nodes(), void 0);
		return {
			map,
			parent
		};
	}, ...ngDevMode ? [{ debugName: "_index" }] : /* istanbul ignore next */ []);
	_branchKeys = computed(() => {
		const keys = [];
		for (const node of this._index().map.values()) if (node.children?.length) keys.push(node.key);
		return keys;
	}, ...ngDevMode ? [{ debugName: "_branchKeys" }] : /* istanbul ignore next */ []);
	isExpanded(node) {
		return this._expandedSet().has(node.key);
	}
	isSelected(node) {
		return this._selectedSet().has(node.key);
	}
	checkState(node) {
		const checked = this._checkedSet();
		if (checked.has(node.key)) return "checked";
		if (!this.checkStrictly() && this._hasCheckedDescendant(node, checked)) return "indeterminate";
		return "unchecked";
	}
	toggleExpand(node) {
		const set = new Set(this.expandedKeys());
		set.has(node.key) ? set.delete(node.key) : set.add(node.key);
		this.expandedKeys.set([...set]);
		this.expandedChange.emit({
			node,
			expanded: set.has(node.key)
		});
	}
	onRowClick(node) {
		this.nodeClick.emit(node);
		if (!this.selectable() || node.disabled) return;
		const wasSelected = this._selectedSet().has(node.key);
		let next;
		if (this.multiple()) {
			const set = new Set(this.selectedKeys());
			wasSelected ? set.delete(node.key) : set.add(node.key);
			next = [...set];
		} else next = wasSelected ? [] : [node.key];
		this.selectedKeys.set(next);
		this.selectedChange.emit(next.map((k) => this._index().map.get(k)).filter(Boolean));
	}
	toggleCheck(node) {
		if (node.disabled || node.disableCheckbox) return;
		const set = new Set(this.checkedKeys());
		if (this.checkStrictly()) set.has(node.key) ? set.delete(node.key) : set.add(node.key);
		else {
			const target = this.checkState(node) !== "checked";
			this._setSubtree(node, target, set);
			this._recomputeAncestors(node, set);
		}
		this.checkedKeys.set([...set]);
		this.checkedChange.emit([...set].map((k) => this._index().map.get(k)).filter(Boolean));
	}
	expandAll() {
		this.expandedKeys.set([...this._branchKeys()]);
	}
	collapseAll() {
		this.expandedKeys.set([]);
	}
	_hasCheckedDescendant(node, checked) {
		return node.children?.some((child) => checked.has(child.key) || this._hasCheckedDescendant(child, checked)) ?? false;
	}
	_setSubtree(node, target, set) {
		if (!node.disabled && !node.disableCheckbox) target ? set.add(node.key) : set.delete(node.key);
		node.children?.forEach((child) => this._setSubtree(child, target, set));
	}
	_recomputeAncestors(node, set) {
		const { map, parent } = this._index();
		let parentKey = parent.get(node.key);
		while (parentKey) {
			const kids = (map.get(parentKey).children ?? []).filter((c) => !c.disabled && !c.disableCheckbox);
			kids.length > 0 && kids.every((c) => set.has(c.key)) ? set.add(parentKey) : set.delete(parentKey);
			parentKey = parent.get(parentKey);
		}
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.1",
		ngImport: i0,
		type: Tree,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.1",
		type: Tree,
		isStandalone: true,
		selector: "l-tree",
		inputs: {
			nodes: {
				classPropertyName: "nodes",
				publicName: "nodes",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			checkable: {
				classPropertyName: "checkable",
				publicName: "checkable",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			showLine: {
				classPropertyName: "showLine",
				publicName: "showLine",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			showIcon: {
				classPropertyName: "showIcon",
				publicName: "showIcon",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			selectable: {
				classPropertyName: "selectable",
				publicName: "selectable",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			multiple: {
				classPropertyName: "multiple",
				publicName: "multiple",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			checkStrictly: {
				classPropertyName: "checkStrictly",
				publicName: "checkStrictly",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			expandedKeys: {
				classPropertyName: "expandedKeys",
				publicName: "expandedKeys",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			checkedKeys: {
				classPropertyName: "checkedKeys",
				publicName: "checkedKeys",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			selectedKeys: {
				classPropertyName: "selectedKeys",
				publicName: "selectedKeys",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: {
			expandedKeys: "expandedKeysChange",
			checkedKeys: "checkedKeysChange",
			selectedKeys: "selectedKeysChange",
			nodeClick: "nodeClick",
			selectedChange: "selectedChange",
			checkedChange: "checkedChange",
			expandedChange: "expandedChange"
		},
		host: {
			attributes: { "role": "tree" },
			classAttribute: "l-tree"
		},
		ngImport: i0,
		template: "@for (node of nodes(); track node.key; let last = $last) {\n  <l-tree-item [node]=\"node\" [guides]=\"[]\" [isLast]=\"last\" />\n}\n",
		styles: [":host{display:block;--l-tree-indent: 24px;--l-tree-line: var(--separator-dark);--l-tree-row-min-height: 30px;font-size:14px;color:var(--text-primary)}\n"],
		dependencies: [{
			kind: "component",
			type: TreeItem,
			selector: "l-tree-item",
			inputs: [
				"node",
				"guides",
				"isLast"
			]
		}],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: Tree,
	decorators: [{
		type: Component,
		args: [{
			selector: "l-tree",
			changeDetection: ChangeDetectionStrategy.OnPush,
			imports: [TreeItem],
			host: {
				class: "l-tree",
				role: "tree"
			},
			template: "@for (node of nodes(); track node.key; let last = $last) {\n  <l-tree-item [node]=\"node\" [guides]=\"[]\" [isLast]=\"last\" />\n}\n",
			styles: [":host{display:block;--l-tree-indent: 24px;--l-tree-line: var(--separator-dark);--l-tree-row-min-height: 30px;font-size:14px;color:var(--text-primary)}\n"]
		}]
	}],
	propDecorators: {
		nodes: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "nodes",
				required: false
			}]
		}],
		checkable: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "checkable",
				required: false
			}]
		}],
		showLine: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "showLine",
				required: false
			}]
		}],
		showIcon: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "showIcon",
				required: false
			}]
		}],
		selectable: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "selectable",
				required: false
			}]
		}],
		multiple: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "multiple",
				required: false
			}]
		}],
		checkStrictly: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "checkStrictly",
				required: false
			}]
		}],
		expandedKeys: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "expandedKeys",
				required: false
			}]
		}, {
			type: i0.Output,
			args: ["expandedKeysChange"]
		}],
		checkedKeys: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "checkedKeys",
				required: false
			}]
		}, {
			type: i0.Output,
			args: ["checkedKeysChange"]
		}],
		selectedKeys: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "selectedKeys",
				required: false
			}]
		}, {
			type: i0.Output,
			args: ["selectedKeysChange"]
		}],
		nodeClick: [{
			type: i0.Output,
			args: ["nodeClick"]
		}],
		selectedChange: [{
			type: i0.Output,
			args: ["selectedChange"]
		}],
		checkedChange: [{
			type: i0.Output,
			args: ["checkedChange"]
		}],
		expandedChange: [{
			type: i0.Output,
			args: ["expandedChange"]
		}]
	}
});
var TableCellDirective = class TableCellDirective {
	lTableCell = input.required(...ngDevMode ? [{ debugName: "lTableCell" }] : /* istanbul ignore next */ []);
	template = inject(TemplateRef);
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.1",
		ngImport: i0,
		type: TableCellDirective,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "17.1.0",
		version: "22.2.1",
		type: TableCellDirective,
		isStandalone: true,
		selector: "ng-template[lTableCell]",
		inputs: { lTableCell: {
			classPropertyName: "lTableCell",
			publicName: "lTableCell",
			isSignal: true,
			isRequired: true,
			transformFunction: null
		} },
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: TableCellDirective,
	decorators: [{
		type: Directive,
		args: [{ selector: "ng-template[lTableCell]" }]
	}],
	propDecorators: { lTableCell: [{
		type: i0.Input,
		args: [{
			isSignal: true,
			alias: "lTableCell",
			required: true
		}]
	}] }
});
var Table = class Table {
	columns = input([], ...ngDevMode ? [{ debugName: "columns" }] : /* istanbul ignore next */ []);
	data = input([], ...ngDevMode ? [{ debugName: "data" }] : /* istanbul ignore next */ []);
	serverSort = input(false, ...ngDevMode ? [{ debugName: "serverSort" }] : /* istanbul ignore next */ []);
	sort = model(null, ...ngDevMode ? [{ debugName: "sort" }] : /* istanbul ignore next */ []);
	loading = input(false, ...ngDevMode ? [{ debugName: "loading" }] : /* istanbul ignore next */ []);
	emptyText = input("No data to display", ...ngDevMode ? [{ debugName: "emptyText" }] : /* istanbul ignore next */ []);
	rowKey = input(...ngDevMode ? [void 0, { debugName: "rowKey" }] : /* istanbul ignore next */ []);
	rowClick = output();
	_cells = contentChildren(TableCellDirective, ...ngDevMode ? [{ debugName: "_cells" }] : /* istanbul ignore next */ []);
	_cellMap = computed(() => new Map(this._cells().map((c) => [c.lTableCell(), c.template])), ...ngDevMode ? [{ debugName: "_cellMap" }] : /* istanbul ignore next */ []);
	_rows = computed(() => {
		const sort = this.sort();
		const rows = this.data();
		if (this.serverSort() || !sort) return rows;
		const { key, direction } = sort;
		const factor = direction === "asc" ? 1 : -1;
		return [...rows].sort((a, b) => this._compare(a?.[key], b?.[key]) * factor);
	}, ...ngDevMode ? [{ debugName: "_rows" }] : /* istanbul ignore next */ []);
	_cellTemplate(key) {
		return this._cellMap().get(key);
	}
	_value(row, key) {
		return row?.[key];
	}
	_sortClass(column) {
		const sort = this.sort();
		return sort && sort.key === column.key ? sort.direction : "none";
	}
	_ariaSort(column) {
		if (!column.sortable) return null;
		const sort = this.sort();
		if (!sort || sort.key !== column.key) return "none";
		return sort.direction === "asc" ? "ascending" : "descending";
	}
	_toggleSort(column) {
		if (!column.sortable) return;
		const current = this.sort();
		let next;
		if (!current || current.key !== column.key) next = {
			key: column.key,
			direction: "asc"
		};
		else if (current.direction === "asc") next = {
			key: column.key,
			direction: "desc"
		};
		else next = null;
		this.sort.set(next);
	}
	_onHeaderKeydown(event, column) {
		if (!column.sortable) return;
		if (event.key === "Enter" || event.key === " ") {
			event.preventDefault();
			this._toggleSort(column);
		}
	}
	_trackRow = (index, row) => {
		const key = this.rowKey();
		if (typeof key === "function") return key(row);
		if (typeof key === "string") return row?.[key];
		return index;
	};
	_compare(a, b) {
		if (a === b) return 0;
		if (a === null || a === void 0) return 1;
		if (b === null || b === void 0) return -1;
		if (typeof a === "number" && typeof b === "number") return a - b;
		if (a instanceof Date && b instanceof Date) return a.getTime() - b.getTime();
		return String(a).localeCompare(String(b), void 0, {
			numeric: true,
			sensitivity: "base"
		});
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.1",
		ngImport: i0,
		type: Table,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.1",
		type: Table,
		isStandalone: true,
		selector: "l-table",
		inputs: {
			columns: {
				classPropertyName: "columns",
				publicName: "columns",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			data: {
				classPropertyName: "data",
				publicName: "data",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			serverSort: {
				classPropertyName: "serverSort",
				publicName: "serverSort",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			sort: {
				classPropertyName: "sort",
				publicName: "sort",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			loading: {
				classPropertyName: "loading",
				publicName: "loading",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			emptyText: {
				classPropertyName: "emptyText",
				publicName: "emptyText",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			rowKey: {
				classPropertyName: "rowKey",
				publicName: "rowKey",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: {
			sort: "sortChange",
			rowClick: "rowClick"
		},
		host: { classAttribute: "l-table-host" },
		queries: [{
			propertyName: "_cells",
			predicate: TableCellDirective,
			isSignal: true
		}],
		ngImport: i0,
		template: "<div class=\"table-responsive\">\n  <table class=\"table\">\n    <thead>\n      <tr>\n        @for (col of columns(); track col.key) {\n          <th\n            [class.sort-by]=\"col.sortable\"\n            [class.asc]=\"col.sortable && _sortClass(col) === 'asc'\"\n            [class.desc]=\"col.sortable && _sortClass(col) === 'desc'\"\n            [class.none]=\"col.sortable && _sortClass(col) === 'none'\"\n            [class.text-center]=\"col.align === 'center'\"\n            [class.text-end]=\"col.align === 'right'\"\n            [style.width]=\"col.width || null\"\n            [attr.tabindex]=\"col.sortable ? 0 : null\"\n            [attr.aria-sort]=\"_ariaSort(col)\"\n            (click)=\"_toggleSort(col)\"\n            (keydown)=\"_onHeaderKeydown($event, col)\"\n          >\n            <span class=\"th-label\">{{ col.header }}</span>\n          </th>\n        }\n      </tr>\n    </thead>\n\n    <tbody>\n      @for (row of _rows(); track _trackRow($index, row); let i = $index) {\n        <tr (click)=\"rowClick.emit(row)\">\n          @for (col of columns(); track col.key) {\n            <td\n              [class.text-center]=\"col.align === 'center'\"\n              [class.text-end]=\"col.align === 'right'\"\n            >\n              @if (_cellTemplate(col.key); as tpl) {\n                <ng-container\n                  [ngTemplateOutlet]=\"tpl\"\n                  [ngTemplateOutletContext]=\"{\n                    $implicit: row,\n                    value: _value(row, col.key),\n                    row: row,\n                    column: col,\n                    index: i,\n                  }\"\n                />\n              } @else {\n                {{ _value(row, col.key) }}\n              }\n            </td>\n          }\n        </tr>\n      }\n    </tbody>\n  </table>\n\n  @if (loading()) {\n    <div class=\"l-table__overlay\">\n      <span class=\"l-table__spinner\" aria-hidden=\"true\"></span>\n      <span class=\"l-table__overlay-text\">Loading…</span>\n    </div>\n  } @else if (!_rows().length) {\n    <div class=\"no-data\">\n      <svg\n        class=\"no-data__icon\"\n        width=\"112\"\n        height=\"112\"\n        viewBox=\"0 0 120 120\"\n        fill=\"none\"\n        aria-hidden=\"true\"\n      >\n        <circle cx=\"60\" cy=\"60\" r=\"48\" fill=\"var(--accent-bg)\" />\n        <rect\n          x=\"41\"\n          y=\"29\"\n          width=\"38\"\n          height=\"60\"\n          rx=\"6\"\n          fill=\"var(--bg-lightest)\"\n          stroke=\"var(--separator-light)\"\n        />\n        <rect x=\"51\" y=\"72\" width=\"18\" height=\"3\" rx=\"1.5\" fill=\"var(--separator-dark)\" />\n        <rect x=\"55\" y=\"79\" width=\"10\" height=\"3\" rx=\"1.5\" fill=\"var(--separator-dark)\" />\n        <circle cx=\"60\" cy=\"53\" r=\"13\" fill=\"var(--accent)\" />\n        <rect x=\"58.5\" y=\"45.5\" width=\"3\" height=\"9\" rx=\"1.5\" fill=\"var(--bg-lightest)\" />\n        <circle cx=\"60\" cy=\"58.5\" r=\"2\" fill=\"var(--bg-lightest)\" />\n      </svg>\n      <p>{{ emptyText() }}</p>\n    </div>\n  }\n</div>\n",
		styles: [".sort-by{cursor:pointer}.sort-by .th-label{position:relative;display:inline-block;padding-right:20px}.sort-by .th-label:before,.sort-by .th-label:after{content:\"\";display:block;width:0;height:0;border-left:5px solid transparent;border-right:5px solid transparent;border-bottom:5px solid;position:absolute;color:#bcbdbe;right:4px}.sort-by .th-label:after{transform:rotate(180deg);margin-top:-8px}.sort-by .th-label:before{margin-top:2px}.sort-by.asc .th-label:before,.sort-by.desc .th-label:after{color:var(--text-primary)}.sort-by.asc .th-label:after,.sort-by.desc .th-label:before{color:#bcbdbe}.sort-by.none .th-label:before,.sort-by.none .th-label:after{color:#bcbdbe}.table-responsive{width:100%;overflow:auto}.table{width:100%;border-collapse:separate;border-spacing:0}.table thead{position:sticky;top:0;z-index:2}.table th{border-top:1px solid var(--separator);border-bottom:1px solid var(--separator);text-align:left;white-space:nowrap;color:var(--text-secondary);background:var(--bg-semi-light);font-weight:500;line-height:20px;padding:6px 8px}.table td{padding:6px 8px;font-weight:400;font-size:14px;white-space:nowrap;color:var(--text-primary);border-bottom:1px solid var(--separator)}.table td .actions{display:flex;align-items:center;justify-content:center;gap:10px}.table td .actions img{cursor:pointer}.text-end{text-align:right}.text-center{text-align:center}.status{display:flex;padding:4px 8px;align-items:center;gap:8px;width:fit-content;border-radius:8px;font-size:12px;font-weight:400;line-height:16px}.status .circle{height:6px;width:6px;border-radius:50%;background:var(--text-primary)}.status.success{background:var(--success-bg);color:var(--success)}.status.success .circle{background:var(--success)}.status.error{background:var(--error-bg);color:var(--error)}.status.error .circle{background:var(--error)}.status.warn{background:var(--warn-bg);color:var(--warn)}.status.warn .circle{background:var(--warn)}.status.info{background:var(--info-bg);color:var(--info)}.status.info .circle{background:var(--warn)}.status.primary{background:var(--accent-bg);color:var(--accent)}.status.primary .circle{background:var(--accent)}.status.cancel{background:var(--cancel-bg);color:var(--cancel)}.status.cancel .circle{background:var(--cancel)}.no-data{padding:48px 0;text-align:center;width:100%;height:100%}.no-data p{color:var(--text-quaternary);font-size:14px;line-height:21px}.no-data__icon{display:block;margin:0 auto 12px}:host{display:block}.table-responsive{position:relative}.table th.sort-by:focus-visible{outline:2px solid var(--accent);outline-offset:-2px}.l-table__overlay{position:absolute;inset:0;display:flex;align-items:center;justify-content:center;gap:10px;background:color-mix(in srgb,var(--bg-lightest) 70%,transparent);-webkit-backdrop-filter:blur(1px);backdrop-filter:blur(1px);z-index:3}.l-table__overlay-text{font-size:13px;color:var(--text-secondary)}.l-table__spinner{width:18px;height:18px;border:2px solid var(--separator-dark);border-top-color:var(--accent);border-radius:50%;animation:l-table-spin .7s linear infinite}@keyframes l-table-spin{to{transform:rotate(360deg)}}@media(prefers-reduced-motion:reduce){.l-table__spinner{animation-duration:1.6s}}\n"],
		dependencies: [{
			kind: "directive",
			type: NgTemplateOutlet,
			selector: "[ngTemplateOutlet]",
			inputs: [
				"ngTemplateOutletContext",
				"ngTemplateOutlet",
				"ngTemplateOutletInjector"
			]
		}],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: Table,
	decorators: [{
		type: Component,
		args: [{
			selector: "l-table",
			changeDetection: ChangeDetectionStrategy.OnPush,
			imports: [NgTemplateOutlet],
			host: { class: "l-table-host" },
			template: "<div class=\"table-responsive\">\n  <table class=\"table\">\n    <thead>\n      <tr>\n        @for (col of columns(); track col.key) {\n          <th\n            [class.sort-by]=\"col.sortable\"\n            [class.asc]=\"col.sortable && _sortClass(col) === 'asc'\"\n            [class.desc]=\"col.sortable && _sortClass(col) === 'desc'\"\n            [class.none]=\"col.sortable && _sortClass(col) === 'none'\"\n            [class.text-center]=\"col.align === 'center'\"\n            [class.text-end]=\"col.align === 'right'\"\n            [style.width]=\"col.width || null\"\n            [attr.tabindex]=\"col.sortable ? 0 : null\"\n            [attr.aria-sort]=\"_ariaSort(col)\"\n            (click)=\"_toggleSort(col)\"\n            (keydown)=\"_onHeaderKeydown($event, col)\"\n          >\n            <span class=\"th-label\">{{ col.header }}</span>\n          </th>\n        }\n      </tr>\n    </thead>\n\n    <tbody>\n      @for (row of _rows(); track _trackRow($index, row); let i = $index) {\n        <tr (click)=\"rowClick.emit(row)\">\n          @for (col of columns(); track col.key) {\n            <td\n              [class.text-center]=\"col.align === 'center'\"\n              [class.text-end]=\"col.align === 'right'\"\n            >\n              @if (_cellTemplate(col.key); as tpl) {\n                <ng-container\n                  [ngTemplateOutlet]=\"tpl\"\n                  [ngTemplateOutletContext]=\"{\n                    $implicit: row,\n                    value: _value(row, col.key),\n                    row: row,\n                    column: col,\n                    index: i,\n                  }\"\n                />\n              } @else {\n                {{ _value(row, col.key) }}\n              }\n            </td>\n          }\n        </tr>\n      }\n    </tbody>\n  </table>\n\n  @if (loading()) {\n    <div class=\"l-table__overlay\">\n      <span class=\"l-table__spinner\" aria-hidden=\"true\"></span>\n      <span class=\"l-table__overlay-text\">Loading…</span>\n    </div>\n  } @else if (!_rows().length) {\n    <div class=\"no-data\">\n      <svg\n        class=\"no-data__icon\"\n        width=\"112\"\n        height=\"112\"\n        viewBox=\"0 0 120 120\"\n        fill=\"none\"\n        aria-hidden=\"true\"\n      >\n        <circle cx=\"60\" cy=\"60\" r=\"48\" fill=\"var(--accent-bg)\" />\n        <rect\n          x=\"41\"\n          y=\"29\"\n          width=\"38\"\n          height=\"60\"\n          rx=\"6\"\n          fill=\"var(--bg-lightest)\"\n          stroke=\"var(--separator-light)\"\n        />\n        <rect x=\"51\" y=\"72\" width=\"18\" height=\"3\" rx=\"1.5\" fill=\"var(--separator-dark)\" />\n        <rect x=\"55\" y=\"79\" width=\"10\" height=\"3\" rx=\"1.5\" fill=\"var(--separator-dark)\" />\n        <circle cx=\"60\" cy=\"53\" r=\"13\" fill=\"var(--accent)\" />\n        <rect x=\"58.5\" y=\"45.5\" width=\"3\" height=\"9\" rx=\"1.5\" fill=\"var(--bg-lightest)\" />\n        <circle cx=\"60\" cy=\"58.5\" r=\"2\" fill=\"var(--bg-lightest)\" />\n      </svg>\n      <p>{{ emptyText() }}</p>\n    </div>\n  }\n</div>\n",
			styles: [".sort-by{cursor:pointer}.sort-by .th-label{position:relative;display:inline-block;padding-right:20px}.sort-by .th-label:before,.sort-by .th-label:after{content:\"\";display:block;width:0;height:0;border-left:5px solid transparent;border-right:5px solid transparent;border-bottom:5px solid;position:absolute;color:#bcbdbe;right:4px}.sort-by .th-label:after{transform:rotate(180deg);margin-top:-8px}.sort-by .th-label:before{margin-top:2px}.sort-by.asc .th-label:before,.sort-by.desc .th-label:after{color:var(--text-primary)}.sort-by.asc .th-label:after,.sort-by.desc .th-label:before{color:#bcbdbe}.sort-by.none .th-label:before,.sort-by.none .th-label:after{color:#bcbdbe}.table-responsive{width:100%;overflow:auto}.table{width:100%;border-collapse:separate;border-spacing:0}.table thead{position:sticky;top:0;z-index:2}.table th{border-top:1px solid var(--separator);border-bottom:1px solid var(--separator);text-align:left;white-space:nowrap;color:var(--text-secondary);background:var(--bg-semi-light);font-weight:500;line-height:20px;padding:6px 8px}.table td{padding:6px 8px;font-weight:400;font-size:14px;white-space:nowrap;color:var(--text-primary);border-bottom:1px solid var(--separator)}.table td .actions{display:flex;align-items:center;justify-content:center;gap:10px}.table td .actions img{cursor:pointer}.text-end{text-align:right}.text-center{text-align:center}.status{display:flex;padding:4px 8px;align-items:center;gap:8px;width:fit-content;border-radius:8px;font-size:12px;font-weight:400;line-height:16px}.status .circle{height:6px;width:6px;border-radius:50%;background:var(--text-primary)}.status.success{background:var(--success-bg);color:var(--success)}.status.success .circle{background:var(--success)}.status.error{background:var(--error-bg);color:var(--error)}.status.error .circle{background:var(--error)}.status.warn{background:var(--warn-bg);color:var(--warn)}.status.warn .circle{background:var(--warn)}.status.info{background:var(--info-bg);color:var(--info)}.status.info .circle{background:var(--warn)}.status.primary{background:var(--accent-bg);color:var(--accent)}.status.primary .circle{background:var(--accent)}.status.cancel{background:var(--cancel-bg);color:var(--cancel)}.status.cancel .circle{background:var(--cancel)}.no-data{padding:48px 0;text-align:center;width:100%;height:100%}.no-data p{color:var(--text-quaternary);font-size:14px;line-height:21px}.no-data__icon{display:block;margin:0 auto 12px}:host{display:block}.table-responsive{position:relative}.table th.sort-by:focus-visible{outline:2px solid var(--accent);outline-offset:-2px}.l-table__overlay{position:absolute;inset:0;display:flex;align-items:center;justify-content:center;gap:10px;background:color-mix(in srgb,var(--bg-lightest) 70%,transparent);-webkit-backdrop-filter:blur(1px);backdrop-filter:blur(1px);z-index:3}.l-table__overlay-text{font-size:13px;color:var(--text-secondary)}.l-table__spinner{width:18px;height:18px;border:2px solid var(--separator-dark);border-top-color:var(--accent);border-radius:50%;animation:l-table-spin .7s linear infinite}@keyframes l-table-spin{to{transform:rotate(360deg)}}@media(prefers-reduced-motion:reduce){.l-table__spinner{animation-duration:1.6s}}\n"]
		}]
	}],
	propDecorators: {
		columns: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "columns",
				required: false
			}]
		}],
		data: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "data",
				required: false
			}]
		}],
		serverSort: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "serverSort",
				required: false
			}]
		}],
		sort: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "sort",
				required: false
			}]
		}, {
			type: i0.Output,
			args: ["sortChange"]
		}],
		loading: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "loading",
				required: false
			}]
		}],
		emptyText: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "emptyText",
				required: false
			}]
		}],
		rowKey: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "rowKey",
				required: false
			}]
		}],
		rowClick: [{
			type: i0.Output,
			args: ["rowClick"]
		}],
		_cells: [{
			type: i0.ContentChildren,
			args: [i0.forwardRef(() => TableCellDirective), { isSignal: true }]
		}]
	}
});
var Card = class Card {
	variant = input("default", ...ngDevMode ? [{ debugName: "variant" }] : /* istanbul ignore next */ []);
	padding = input("md", ...ngDevMode ? [{ debugName: "padding" }] : /* istanbul ignore next */ []);
	shadow = input("none", ...ngDevMode ? [{ debugName: "shadow" }] : /* istanbul ignore next */ []);
	bordered = input(true, ...ngDevMode ? [{ debugName: "bordered" }] : /* istanbul ignore next */ []);
	hoverable = input(false, ...ngDevMode ? [{ debugName: "hoverable" }] : /* istanbul ignore next */ []);
	title = input("", ...ngDevMode ? [{ debugName: "title" }] : /* istanbul ignore next */ []);
	_hostClasses = computed(() => [
		"lui-card",
		this.variant() === "dark" ? "lui-card-dark" : "",
		`lui-card-pad-${this.padding()}`,
		this.shadow() !== "none" ? `lui-card-shadow-${this.shadow()}` : "",
		this.bordered() ? "" : "lui-card-borderless",
		this.hoverable() ? "lui-card-hoverable" : ""
	].filter(Boolean).join(" "), ...ngDevMode ? [{ debugName: "_hostClasses" }] : /* istanbul ignore next */ []);
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.1",
		ngImport: i0,
		type: Card,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.1",
		type: Card,
		isStandalone: true,
		selector: "l-card",
		inputs: {
			variant: {
				classPropertyName: "variant",
				publicName: "variant",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			padding: {
				classPropertyName: "padding",
				publicName: "padding",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			shadow: {
				classPropertyName: "shadow",
				publicName: "shadow",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			bordered: {
				classPropertyName: "bordered",
				publicName: "bordered",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			hoverable: {
				classPropertyName: "hoverable",
				publicName: "hoverable",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			title: {
				classPropertyName: "title",
				publicName: "title",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		host: { properties: { "class": "_hostClasses()" } },
		ngImport: i0,
		template: "<div class=\"lui-card__header\">\n  @if (title()) {\n    <div class=\"lui-card__title\">{{ title() }}</div>\n  }\n  <div class=\"lui-card__extra\"><ng-content select=\"[card-extra]\" /></div>\n</div>\n<div class=\"lui-card__body\"><ng-content /></div>\n<div class=\"lui-card__footer\"><ng-content select=\"[card-footer]\" /></div>\n",
		styles: [".lui-card{--l-card-pad: 12px;display:block;align-self:stretch;border-radius:12px;border:1px solid var(--separator);background:var(--bg-lightest);overflow:hidden;min-height:fit-content}.lui-card.lui-card-dark{background:var(--bg-light)}.lui-card-pad-none{--l-card-pad: 0px}.lui-card-pad-sm{--l-card-pad: 8px}.lui-card-pad-md{--l-card-pad: 12px}.lui-card-pad-lg{--l-card-pad: 20px}.lui-card-borderless{border-color:transparent}.lui-card-shadow-sm{box-shadow:0 1px 2px #07090f0f}.lui-card-shadow-md{box-shadow:0 2px 8px #07090f14}.lui-card-shadow-lg{box-shadow:0 8px 24px #07090f1f}.lui-card-hoverable{cursor:pointer;transition:box-shadow .2s ease,transform .2s ease}.lui-card-hoverable:hover{box-shadow:0 8px 24px #07090f1f;transform:translateY(-2px)}.lui-card__header{display:flex;align-items:center;justify-content:space-between;gap:8px;padding:var(--l-card-pad);border-bottom:1px solid var(--separator)}.lui-card__header:not(:has(>.lui-card__title,>.lui-card__extra:not(:empty))){display:none}.lui-card__title{font-weight:600;color:var(--text-primary)}.lui-card__extra{display:flex;align-items:center;gap:8px;color:var(--text-secondary)}.lui-card__extra:empty{display:none}.lui-card__body{padding:var(--l-card-pad)}.lui-card__footer{padding:var(--l-card-pad);border-top:1px solid var(--separator);color:var(--text-secondary)}.lui-card__footer:empty{display:none}@media(prefers-reduced-motion:reduce){.lui-card-hoverable{transition:none}}\n"],
		changeDetection: i0.ChangeDetectionStrategy.OnPush,
		encapsulation: i0.ViewEncapsulation.None
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: Card,
	decorators: [{
		type: Component,
		args: [{
			selector: "l-card",
			changeDetection: ChangeDetectionStrategy.OnPush,
			encapsulation: ViewEncapsulation.None,
			host: { "[class]": "_hostClasses()" },
			template: "<div class=\"lui-card__header\">\n  @if (title()) {\n    <div class=\"lui-card__title\">{{ title() }}</div>\n  }\n  <div class=\"lui-card__extra\"><ng-content select=\"[card-extra]\" /></div>\n</div>\n<div class=\"lui-card__body\"><ng-content /></div>\n<div class=\"lui-card__footer\"><ng-content select=\"[card-footer]\" /></div>\n",
			styles: [".lui-card{--l-card-pad: 12px;display:block;align-self:stretch;border-radius:12px;border:1px solid var(--separator);background:var(--bg-lightest);overflow:hidden;min-height:fit-content}.lui-card.lui-card-dark{background:var(--bg-light)}.lui-card-pad-none{--l-card-pad: 0px}.lui-card-pad-sm{--l-card-pad: 8px}.lui-card-pad-md{--l-card-pad: 12px}.lui-card-pad-lg{--l-card-pad: 20px}.lui-card-borderless{border-color:transparent}.lui-card-shadow-sm{box-shadow:0 1px 2px #07090f0f}.lui-card-shadow-md{box-shadow:0 2px 8px #07090f14}.lui-card-shadow-lg{box-shadow:0 8px 24px #07090f1f}.lui-card-hoverable{cursor:pointer;transition:box-shadow .2s ease,transform .2s ease}.lui-card-hoverable:hover{box-shadow:0 8px 24px #07090f1f;transform:translateY(-2px)}.lui-card__header{display:flex;align-items:center;justify-content:space-between;gap:8px;padding:var(--l-card-pad);border-bottom:1px solid var(--separator)}.lui-card__header:not(:has(>.lui-card__title,>.lui-card__extra:not(:empty))){display:none}.lui-card__title{font-weight:600;color:var(--text-primary)}.lui-card__extra{display:flex;align-items:center;gap:8px;color:var(--text-secondary)}.lui-card__extra:empty{display:none}.lui-card__body{padding:var(--l-card-pad)}.lui-card__footer{padding:var(--l-card-pad);border-top:1px solid var(--separator);color:var(--text-secondary)}.lui-card__footer:empty{display:none}@media(prefers-reduced-motion:reduce){.lui-card-hoverable{transition:none}}\n"]
		}]
	}],
	propDecorators: {
		variant: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "variant",
				required: false
			}]
		}],
		padding: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "padding",
				required: false
			}]
		}],
		shadow: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "shadow",
				required: false
			}]
		}],
		bordered: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "bordered",
				required: false
			}]
		}],
		hoverable: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "hoverable",
				required: false
			}]
		}],
		title: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "title",
				required: false
			}]
		}]
	}
});
var Avatar = class Avatar {
	imageUrl = model("", ...ngDevMode ? [{ debugName: "imageUrl" }] : /* istanbul ignore next */ []);
	name = input("", ...ngDevMode ? [{ debugName: "name" }] : /* istanbul ignore next */ []);
	size = input("32px", ...ngDevMode ? [{ debugName: "size" }] : /* istanbul ignore next */ []);
	color = input("var(--accent)", ...ngDevMode ? [{ debugName: "color" }] : /* istanbul ignore next */ []);
	textColor = input("var(--accent-contrast)", ...ngDevMode ? [{ debugName: "textColor" }] : /* istanbul ignore next */ []);
	_initials = computed(() => {
		const value = this.name()?.trim();
		if (!value) return "";
		const parts = value.split(/\s+/).filter(Boolean);
		if (parts.length === 1) return parts[0].charAt(0).toUpperCase();
		return (parts[0].charAt(0) + parts[parts.length - 1].charAt(0)).toUpperCase();
	}, ...ngDevMode ? [{ debugName: "_initials" }] : /* istanbul ignore next */ []);
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.1",
		ngImport: i0,
		type: Avatar,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.1",
		type: Avatar,
		isStandalone: true,
		selector: "l-avatar",
		inputs: {
			imageUrl: {
				classPropertyName: "imageUrl",
				publicName: "imageUrl",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			name: {
				classPropertyName: "name",
				publicName: "name",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			size: {
				classPropertyName: "size",
				publicName: "size",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			color: {
				classPropertyName: "color",
				publicName: "color",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			textColor: {
				classPropertyName: "textColor",
				publicName: "textColor",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: { imageUrl: "imageUrlChange" },
		ngImport: i0,
		template: "@if (imageUrl()) {\n  <img\n    class=\"avatar avatar-image\"\n    [src]=\"imageUrl()\"\n    [alt]=\"name()\"\n    [style.width]=\"size()\"\n    [style.height]=\"size()\"\n  />\n} @else {\n  <span\n    class=\"avatar avatar-initials\"\n    [style.width]=\"size()\"\n    [style.height]=\"size()\"\n    [style.background]=\"color()\"\n    [style.color]=\"textColor()\"\n  >\n    {{ _initials() }}\n  </span>\n}\n",
		styles: [":host{display:inline-flex;vertical-align:middle}.avatar{display:inline-flex;align-items:center;justify-content:center;border-radius:50%;flex-shrink:0;overflow:hidden}.avatar-image{object-fit:cover}.avatar-initials{font-size:.875em;font-weight:600;line-height:1;text-transform:uppercase;-webkit-user-select:none;user-select:none}\n"],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: Avatar,
	decorators: [{
		type: Component,
		args: [{
			selector: "l-avatar",
			changeDetection: ChangeDetectionStrategy.OnPush,
			imports: [],
			template: "@if (imageUrl()) {\n  <img\n    class=\"avatar avatar-image\"\n    [src]=\"imageUrl()\"\n    [alt]=\"name()\"\n    [style.width]=\"size()\"\n    [style.height]=\"size()\"\n  />\n} @else {\n  <span\n    class=\"avatar avatar-initials\"\n    [style.width]=\"size()\"\n    [style.height]=\"size()\"\n    [style.background]=\"color()\"\n    [style.color]=\"textColor()\"\n  >\n    {{ _initials() }}\n  </span>\n}\n",
			styles: [":host{display:inline-flex;vertical-align:middle}.avatar{display:inline-flex;align-items:center;justify-content:center;border-radius:50%;flex-shrink:0;overflow:hidden}.avatar-image{object-fit:cover}.avatar-initials{font-size:.875em;font-weight:600;line-height:1;text-transform:uppercase;-webkit-user-select:none;user-select:none}\n"]
		}]
	}],
	propDecorators: {
		imageUrl: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "imageUrl",
				required: false
			}]
		}, {
			type: i0.Output,
			args: ["imageUrlChange"]
		}],
		name: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "name",
				required: false
			}]
		}],
		size: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "size",
				required: false
			}]
		}],
		color: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "color",
				required: false
			}]
		}],
		textColor: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "textColor",
				required: false
			}]
		}]
	}
});
var Badge = class Badge {
	count = input(null, ...ngDevMode ? [{ debugName: "count" }] : /* istanbul ignore next */ []);
	color = input("", ...ngDevMode ? [{ debugName: "color" }] : /* istanbul ignore next */ []);
	size = input("md", ...ngDevMode ? [{ debugName: "size" }] : /* istanbul ignore next */ []);
	overflowCount = input(99, ...ngDevMode ? [{ debugName: "overflowCount" }] : /* istanbul ignore next */ []);
	showZero = input(false, ...ngDevMode ? [{ debugName: "showZero" }] : /* istanbul ignore next */ []);
	dynamic = input(false, ...ngDevMode ? [{ debugName: "dynamic" }] : /* istanbul ignore next */ []);
	clicked = output();
	_pop = signal(false, ...ngDevMode ? [{ debugName: "_pop" }] : /* istanbul ignore next */ []);
	_count = computed(() => this.count() ?? 0, ...ngDevMode ? [{ debugName: "_count" }] : /* istanbul ignore next */ []);
	_visible = computed(() => this._count() !== 0 || this.showZero(), ...ngDevMode ? [{ debugName: "_visible" }] : /* istanbul ignore next */ []);
	_display = computed(() => {
		const count = this._count();
		const max = this.overflowCount();
		return count > max ? `${max}+` : `${count}`;
	}, ...ngDevMode ? [{ debugName: "_display" }] : /* istanbul ignore next */ []);
	_hostClasses = computed(() => `l-badge l-badge--${this.size()}`, ...ngDevMode ? [{ debugName: "_hostClasses" }] : /* istanbul ignore next */ []);
	constructor() {
		let previous = this.count();
		effect(() => {
			const current = this.count();
			if (this.dynamic() && current !== previous) {
				this._pop.set(false);
				queueMicrotask(() => this._pop.set(true));
			}
			previous = current;
		});
	}
	_onClick(event) {
		event.stopPropagation();
		this.clicked.emit(event);
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.1",
		ngImport: i0,
		type: Badge,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.1",
		type: Badge,
		isStandalone: true,
		selector: "l-badge",
		inputs: {
			count: {
				classPropertyName: "count",
				publicName: "count",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			color: {
				classPropertyName: "color",
				publicName: "color",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			size: {
				classPropertyName: "size",
				publicName: "size",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			overflowCount: {
				classPropertyName: "overflowCount",
				publicName: "overflowCount",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			showZero: {
				classPropertyName: "showZero",
				publicName: "showZero",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dynamic: {
				classPropertyName: "dynamic",
				publicName: "dynamic",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: { clicked: "clicked" },
		host: {
			attributes: { "aria-hidden": "true" },
			listeners: {
				"click": "_onClick($event)",
				"animationend": "_pop.set(false)"
			},
			properties: {
				"class": "_hostClasses()",
				"class.is-hidden": "!_visible()",
				"class.is-pop": "_pop()",
				"style.--l-badge-color": "color() || null"
			}
		},
		ngImport: i0,
		template: "{{ _display() }}",
		isInline: true,
		styles: [":host{--l-badge-color: var(--error);position:absolute;top:0;right:0;z-index:2;transform:translate(50%,-50%);transform-origin:center;display:inline-flex;align-items:center;justify-content:center;box-sizing:border-box;padding:0 5px;border-radius:999px;background:var(--l-badge-color);color:var(--text-white);font-weight:700;font-variant-numeric:tabular-nums;line-height:1;white-space:nowrap;pointer-events:auto;cursor:default;box-shadow:0 0 0 2px var(--bg-lightest);animation:l-badge-in .18s cubic-bezier(.34,1.56,.64,1)}:host.is-hidden{display:none}:host.l-badge--sm{min-width:16px;height:16px;font-size:10px}:host.l-badge--md{min-width:18px;height:18px;font-size:11px}:host.l-badge--lg{min-width:22px;height:22px;font-size:13px;padding:0 6px}:host.is-pop{animation:l-badge-pop .32s cubic-bezier(.34,1.56,.64,1)}@keyframes l-badge-in{0%{opacity:0;transform:translate(50%,-50%) scale(0)}}@keyframes l-badge-pop{0%{transform:translate(50%,-50%) scale(1)}40%{transform:translate(50%,-50%) scale(1.35)}to{transform:translate(50%,-50%) scale(1)}}@media(prefers-reduced-motion:reduce){:host,:host.is-pop{animation:none}}\n"],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: Badge,
	decorators: [{
		type: Component,
		args: [{
			selector: "l-badge",
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: "{{ _display() }}",
			host: {
				"[class]": "_hostClasses()",
				"[class.is-hidden]": "!_visible()",
				"[class.is-pop]": "_pop()",
				"[style.--l-badge-color]": "color() || null",
				"(click)": "_onClick($event)",
				"(animationend)": "_pop.set(false)",
				"aria-hidden": "true"
			},
			styles: [":host{--l-badge-color: var(--error);position:absolute;top:0;right:0;z-index:2;transform:translate(50%,-50%);transform-origin:center;display:inline-flex;align-items:center;justify-content:center;box-sizing:border-box;padding:0 5px;border-radius:999px;background:var(--l-badge-color);color:var(--text-white);font-weight:700;font-variant-numeric:tabular-nums;line-height:1;white-space:nowrap;pointer-events:auto;cursor:default;box-shadow:0 0 0 2px var(--bg-lightest);animation:l-badge-in .18s cubic-bezier(.34,1.56,.64,1)}:host.is-hidden{display:none}:host.l-badge--sm{min-width:16px;height:16px;font-size:10px}:host.l-badge--md{min-width:18px;height:18px;font-size:11px}:host.l-badge--lg{min-width:22px;height:22px;font-size:13px;padding:0 6px}:host.is-pop{animation:l-badge-pop .32s cubic-bezier(.34,1.56,.64,1)}@keyframes l-badge-in{0%{opacity:0;transform:translate(50%,-50%) scale(0)}}@keyframes l-badge-pop{0%{transform:translate(50%,-50%) scale(1)}40%{transform:translate(50%,-50%) scale(1.35)}to{transform:translate(50%,-50%) scale(1)}}@media(prefers-reduced-motion:reduce){:host,:host.is-pop{animation:none}}\n"]
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		count: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "count",
				required: false
			}]
		}],
		color: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "color",
				required: false
			}]
		}],
		size: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "size",
				required: false
			}]
		}],
		overflowCount: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "overflowCount",
				required: false
			}]
		}],
		showZero: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "showZero",
				required: false
			}]
		}],
		dynamic: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dynamic",
				required: false
			}]
		}],
		clicked: [{
			type: i0.Output,
			args: ["clicked"]
		}]
	}
});
var BadgeDirective = class BadgeDirective {
	lBadge = input(null, ...ngDevMode ? [{ debugName: "lBadge" }] : /* istanbul ignore next */ []);
	lBadgeColor = input("", ...ngDevMode ? [{ debugName: "lBadgeColor" }] : /* istanbul ignore next */ []);
	lBadgeSize = input("md", ...ngDevMode ? [{ debugName: "lBadgeSize" }] : /* istanbul ignore next */ []);
	lBadgeOverflowCount = input(99, {
		...ngDevMode ? { debugName: "lBadgeOverflowCount" } : /* istanbul ignore next */ {},
		transform: numberAttribute
	});
	lBadgeShowZero = input(false, {
		...ngDevMode ? { debugName: "lBadgeShowZero" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	lBadgeDynamic = input(false, {
		...ngDevMode ? { debugName: "lBadgeDynamic" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	lBadgeClick = output();
	_host = inject(ElementRef);
	_vcr = inject(ViewContainerRef);
	_renderer = inject(Renderer2);
	_ref = this._vcr.createComponent(Badge);
	constructor() {
		this._renderer.appendChild(this._host.nativeElement, this._ref.location.nativeElement);
		this._ref.instance.clicked.subscribe((event) => this.lBadgeClick.emit(event));
		afterNextRender(() => {
			const host = this._host.nativeElement;
			if (getComputedStyle(host).position === "static") this._renderer.setStyle(host, "position", "relative");
		});
		effect(() => {
			this._ref.setInput("count", this.lBadge());
			this._ref.setInput("color", this.lBadgeColor());
			this._ref.setInput("size", this.lBadgeSize());
			this._ref.setInput("overflowCount", this.lBadgeOverflowCount());
			this._ref.setInput("showZero", this.lBadgeShowZero());
			this._ref.setInput("dynamic", this.lBadgeDynamic());
		});
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.1",
		ngImport: i0,
		type: BadgeDirective,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "17.1.0",
		version: "22.2.1",
		type: BadgeDirective,
		isStandalone: true,
		selector: "[lBadge]",
		inputs: {
			lBadge: {
				classPropertyName: "lBadge",
				publicName: "lBadge",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			lBadgeColor: {
				classPropertyName: "lBadgeColor",
				publicName: "lBadgeColor",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			lBadgeSize: {
				classPropertyName: "lBadgeSize",
				publicName: "lBadgeSize",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			lBadgeOverflowCount: {
				classPropertyName: "lBadgeOverflowCount",
				publicName: "lBadgeOverflowCount",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			lBadgeShowZero: {
				classPropertyName: "lBadgeShowZero",
				publicName: "lBadgeShowZero",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			lBadgeDynamic: {
				classPropertyName: "lBadgeDynamic",
				publicName: "lBadgeDynamic",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: { lBadgeClick: "lBadgeClick" },
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: BadgeDirective,
	decorators: [{
		type: Directive,
		args: [{ selector: "[lBadge]" }]
	}],
	ctorParameters: () => [],
	propDecorators: {
		lBadge: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "lBadge",
				required: false
			}]
		}],
		lBadgeColor: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "lBadgeColor",
				required: false
			}]
		}],
		lBadgeSize: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "lBadgeSize",
				required: false
			}]
		}],
		lBadgeOverflowCount: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "lBadgeOverflowCount",
				required: false
			}]
		}],
		lBadgeShowZero: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "lBadgeShowZero",
				required: false
			}]
		}],
		lBadgeDynamic: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "lBadgeDynamic",
				required: false
			}]
		}],
		lBadgeClick: [{
			type: i0.Output,
			args: ["lBadgeClick"]
		}]
	}
});
var Chip = class Chip {
	variant = input("default", ...ngDevMode ? [{ debugName: "variant" }] : /* istanbul ignore next */ []);
	size = input("md", ...ngDevMode ? [{ debugName: "size" }] : /* istanbul ignore next */ []);
	dot = input(false, ...ngDevMode ? [{ debugName: "dot" }] : /* istanbul ignore next */ []);
	removable = input(false, ...ngDevMode ? [{ debugName: "removable" }] : /* istanbul ignore next */ []);
	removeLabel = input("Remove", ...ngDevMode ? [{ debugName: "removeLabel" }] : /* istanbul ignore next */ []);
	removed = output();
	_hostClasses = computed(() => `l-chip l-chip--${this.variant()} l-chip--${this.size()}`, ...ngDevMode ? [{ debugName: "_hostClasses" }] : /* istanbul ignore next */ []);
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.1",
		ngImport: i0,
		type: Chip,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.1",
		type: Chip,
		isStandalone: true,
		selector: "l-chip",
		inputs: {
			variant: {
				classPropertyName: "variant",
				publicName: "variant",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			size: {
				classPropertyName: "size",
				publicName: "size",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dot: {
				classPropertyName: "dot",
				publicName: "dot",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			removable: {
				classPropertyName: "removable",
				publicName: "removable",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			removeLabel: {
				classPropertyName: "removeLabel",
				publicName: "removeLabel",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: { removed: "removed" },
		host: { properties: { "class": "_hostClasses()" } },
		ngImport: i0,
		template: "@if (dot()) {\n  <span class=\"l-chip__dot\" aria-hidden=\"true\"></span>\n}\n<ng-content />\n@if (removable()) {\n  <button\n    type=\"button\"\n    class=\"l-chip__remove\"\n    [attr.aria-label]=\"removeLabel()\"\n    (click)=\"removed.emit()\"\n  >\n    <svg viewBox=\"0 0 12 12\" aria-hidden=\"true\" focusable=\"false\">\n      <path d=\"M3 3l6 6M9 3l-6 6\" />\n    </svg>\n  </button>\n}\n",
		styles: [":host{--l-chip-bg: var(--bg-dark);--l-chip-color: var(--text-primary);display:inline-flex;align-items:center;gap:8px;width:fit-content;border-radius:999px;background:var(--l-chip-bg);color:var(--l-chip-color);font-weight:400;white-space:nowrap}:host.l-chip--primary{--l-chip-bg: var(--accent-bg);--l-chip-color: var(--accent)}:host.l-chip--success{--l-chip-bg: var(--success-bg);--l-chip-color: var(--success)}:host.l-chip--error{--l-chip-bg: var(--error-bg);--l-chip-color: var(--error)}:host.l-chip--warn{--l-chip-bg: var(--warn-bg);--l-chip-color: var(--warn)}:host.l-chip--info{--l-chip-bg: var(--info-bg);--l-chip-color: var(--info)}:host.l-chip--premium{--l-chip-bg: var(--premium-bg);--l-chip-color: var(--premium)}:host.l-chip--sm{padding:4px 10px;font-size:11px;line-height:14px}:host.l-chip--md{padding:6px 16px;font-size:12px;line-height:16px}:host.l-chip--lg{padding:8px 20px;font-size:14px;line-height:20px}.l-chip__dot{flex-shrink:0;width:6px;height:6px;border-radius:50%;background:currentColor}.l-chip__remove{display:inline-flex;align-items:center;justify-content:center;flex-shrink:0;width:16px;height:16px;margin-right:-8px;padding:0;border:0;border-radius:50%;background:transparent;color:inherit;cursor:pointer;transition:background-color .15s ease-out}.l-chip__remove svg{width:8px;height:8px;fill:none;stroke:currentColor;stroke-width:1.5;stroke-linecap:round}.l-chip__remove:hover{background:color-mix(in srgb,currentColor 14%,transparent)}.l-chip__remove:focus-visible{outline:2px solid currentColor;outline-offset:1px}@media(prefers-reduced-motion:reduce){.l-chip__remove{transition:none}}\n"],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: Chip,
	decorators: [{
		type: Component,
		args: [{
			selector: "l-chip",
			changeDetection: ChangeDetectionStrategy.OnPush,
			host: { "[class]": "_hostClasses()" },
			template: "@if (dot()) {\n  <span class=\"l-chip__dot\" aria-hidden=\"true\"></span>\n}\n<ng-content />\n@if (removable()) {\n  <button\n    type=\"button\"\n    class=\"l-chip__remove\"\n    [attr.aria-label]=\"removeLabel()\"\n    (click)=\"removed.emit()\"\n  >\n    <svg viewBox=\"0 0 12 12\" aria-hidden=\"true\" focusable=\"false\">\n      <path d=\"M3 3l6 6M9 3l-6 6\" />\n    </svg>\n  </button>\n}\n",
			styles: [":host{--l-chip-bg: var(--bg-dark);--l-chip-color: var(--text-primary);display:inline-flex;align-items:center;gap:8px;width:fit-content;border-radius:999px;background:var(--l-chip-bg);color:var(--l-chip-color);font-weight:400;white-space:nowrap}:host.l-chip--primary{--l-chip-bg: var(--accent-bg);--l-chip-color: var(--accent)}:host.l-chip--success{--l-chip-bg: var(--success-bg);--l-chip-color: var(--success)}:host.l-chip--error{--l-chip-bg: var(--error-bg);--l-chip-color: var(--error)}:host.l-chip--warn{--l-chip-bg: var(--warn-bg);--l-chip-color: var(--warn)}:host.l-chip--info{--l-chip-bg: var(--info-bg);--l-chip-color: var(--info)}:host.l-chip--premium{--l-chip-bg: var(--premium-bg);--l-chip-color: var(--premium)}:host.l-chip--sm{padding:4px 10px;font-size:11px;line-height:14px}:host.l-chip--md{padding:6px 16px;font-size:12px;line-height:16px}:host.l-chip--lg{padding:8px 20px;font-size:14px;line-height:20px}.l-chip__dot{flex-shrink:0;width:6px;height:6px;border-radius:50%;background:currentColor}.l-chip__remove{display:inline-flex;align-items:center;justify-content:center;flex-shrink:0;width:16px;height:16px;margin-right:-8px;padding:0;border:0;border-radius:50%;background:transparent;color:inherit;cursor:pointer;transition:background-color .15s ease-out}.l-chip__remove svg{width:8px;height:8px;fill:none;stroke:currentColor;stroke-width:1.5;stroke-linecap:round}.l-chip__remove:hover{background:color-mix(in srgb,currentColor 14%,transparent)}.l-chip__remove:focus-visible{outline:2px solid currentColor;outline-offset:1px}@media(prefers-reduced-motion:reduce){.l-chip__remove{transition:none}}\n"]
		}]
	}],
	propDecorators: {
		variant: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "variant",
				required: false
			}]
		}],
		size: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "size",
				required: false
			}]
		}],
		dot: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dot",
				required: false
			}]
		}],
		removable: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "removable",
				required: false
			}]
		}],
		removeLabel: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "removeLabel",
				required: false
			}]
		}],
		removed: [{
			type: i0.Output,
			args: ["removed"]
		}]
	}
});
var Accordion = class Accordion {
	multiple = input(false, ...ngDevMode ? [{ debugName: "multiple" }] : /* istanbul ignore next */ []);
	variant = input("contained", ...ngDevMode ? [{ debugName: "variant" }] : /* istanbul ignore next */ []);
	iconPosition = input("right", ...ngDevMode ? [{ debugName: "iconPosition" }] : /* istanbul ignore next */ []);
	_items = signal([], ...ngDevMode ? [{ debugName: "_items" }] : /* istanbul ignore next */ []);
	_open = signal(/* @__PURE__ */ new Set(), ...ngDevMode ? [{ debugName: "_open" }] : /* istanbul ignore next */ []);
	_hostClasses = computed(() => `l-accordion l-accordion--${this.variant()}`, ...ngDevMode ? [{ debugName: "_hostClasses" }] : /* istanbul ignore next */ []);
	_register(item) {
		this._items.update((items) => [...items, item]);
		if (item.expanded()) this._open.update((prev) => {
			const next = new Set(this.multiple() ? prev : []);
			next.add(item);
			return next;
		});
	}
	_unregister(item) {
		this._items.update((items) => items.filter((i) => i !== item));
		this._open.update((prev) => {
			if (!prev.has(item)) return prev;
			const next = new Set(prev);
			next.delete(item);
			return next;
		});
	}
	_isOpen(item) {
		return this._open().has(item);
	}
	_toggle(item) {
		if (item.disabled()) return;
		const isOpen = this._open().has(item);
		this._open.update((prev) => {
			const next = new Set(this.multiple() ? prev : []);
			if (this.multiple() && isOpen) next.delete(item);
			else if (!isOpen) next.add(item);
			return next;
		});
	}
	_moveFocus(from, key) {
		const items = this._items().filter((i) => !i.disabled());
		if (!items.length) return;
		const index = items.indexOf(from);
		let target;
		switch (key) {
			case "ArrowDown":
				target = items[(index + 1) % items.length];
				break;
			case "ArrowUp":
				target = items[(index - 1 + items.length) % items.length];
				break;
			case "Home":
				target = items[0];
				break;
			case "End": target = items[items.length - 1];
		}
		target?._focusHeader();
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.1",
		ngImport: i0,
		type: Accordion,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.1",
		type: Accordion,
		isStandalone: true,
		selector: "l-accordion",
		inputs: {
			multiple: {
				classPropertyName: "multiple",
				publicName: "multiple",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			variant: {
				classPropertyName: "variant",
				publicName: "variant",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			iconPosition: {
				classPropertyName: "iconPosition",
				publicName: "iconPosition",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		host: { properties: { "class": "_hostClasses()" } },
		ngImport: i0,
		template: "<ng-content />",
		isInline: true,
		styles: [":host{display:flex;flex-direction:column;width:100%}:host(.l-accordion--separated){gap:10px}:host(.l-accordion--contained){border:1px solid var(--separator);border-radius:10px;background:var(--bg-lightest);overflow:hidden}\n"],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: Accordion,
	decorators: [{
		type: Component,
		args: [{
			selector: "l-accordion",
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: "<ng-content />",
			host: { "[class]": "_hostClasses()" },
			styles: [":host{display:flex;flex-direction:column;width:100%}:host(.l-accordion--separated){gap:10px}:host(.l-accordion--contained){border:1px solid var(--separator);border-radius:10px;background:var(--bg-lightest);overflow:hidden}\n"]
		}]
	}],
	propDecorators: {
		multiple: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "multiple",
				required: false
			}]
		}],
		variant: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "variant",
				required: false
			}]
		}],
		iconPosition: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "iconPosition",
				required: false
			}]
		}]
	}
});
let _uid = 0;
var AccordionItem = class AccordionItem {
	title = input("", ...ngDevMode ? [{ debugName: "title" }] : /* istanbul ignore next */ []);
	disabled = input(false, ...ngDevMode ? [{ debugName: "disabled" }] : /* istanbul ignore next */ []);
	expanded = input(false, ...ngDevMode ? [{ debugName: "expanded" }] : /* istanbul ignore next */ []);
	id = input(`l-accordion-item-${_uid++}`, ...ngDevMode ? [{ debugName: "id" }] : /* istanbul ignore next */ []);
	openedChange = output();
	_accordion = inject(Accordion);
	_header = viewChild.required("header", ...ngDevMode ? [{ debugName: "_header" }] : /* istanbul ignore next */ []);
	_open = computed(() => this._accordion._isOpen(this), ...ngDevMode ? [{ debugName: "_open" }] : /* istanbul ignore next */ []);
	_iconPosition = computed(() => this._accordion.iconPosition(), ...ngDevMode ? [{ debugName: "_iconPosition" }] : /* istanbul ignore next */ []);
	_hostClasses = computed(() => `l-accordion-item l-accordion-item--${this._accordion.variant()}`, ...ngDevMode ? [{ debugName: "_hostClasses" }] : /* istanbul ignore next */ []);
	_emitted = false;
	constructor() {
		effect(() => {
			const open = this._open();
			if (this._emitted) this.openedChange.emit(open);
			else this._emitted = true;
		});
	}
	ngOnInit() {
		this._accordion._register(this);
	}
	ngOnDestroy() {
		this._accordion._unregister(this);
	}
	_toggle() {
		this._accordion._toggle(this);
	}
	_onKeydown(event) {
		if ([
			"ArrowDown",
			"ArrowUp",
			"Home",
			"End"
		].includes(event.key)) {
			event.preventDefault();
			this._accordion._moveFocus(this, event.key);
		}
	}
	_focusHeader() {
		this._header().nativeElement.focus();
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.1",
		ngImport: i0,
		type: AccordionItem,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.2.0",
		version: "22.2.1",
		type: AccordionItem,
		isStandalone: true,
		selector: "l-accordion-item",
		inputs: {
			title: {
				classPropertyName: "title",
				publicName: "title",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			disabled: {
				classPropertyName: "disabled",
				publicName: "disabled",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			expanded: {
				classPropertyName: "expanded",
				publicName: "expanded",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			id: {
				classPropertyName: "id",
				publicName: "id",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: { openedChange: "openedChange" },
		host: { properties: { "class": "_hostClasses()" } },
		viewQueries: [{
			propertyName: "_header",
			first: true,
			predicate: ["header"],
			descendants: true,
			isSignal: true
		}],
		ngImport: i0,
		template: "<h3 class=\"l-accordion-item__heading\">\n  <button\n    #header\n    type=\"button\"\n    class=\"l-accordion-item__trigger\"\n    [class.icon-left]=\"_iconPosition() === 'left'\"\n    [disabled]=\"disabled()\"\n    [id]=\"id() + '-trigger'\"\n    [attr.aria-expanded]=\"_open()\"\n    [attr.aria-controls]=\"id() + '-panel'\"\n    (click)=\"_toggle()\"\n    (keydown)=\"_onKeydown($event)\"\n  >\n    <span class=\"l-accordion-item__title\">\n      <ng-content select=\"[slot=title]\">{{ title() }}</ng-content>\n    </span>\n\n    <svg\n      class=\"l-accordion-item__chevron\"\n      width=\"16\"\n      height=\"16\"\n      viewBox=\"0 0 20 20\"\n      fill=\"none\"\n      aria-hidden=\"true\"\n      xmlns=\"http://www.w3.org/2000/svg\"\n    >\n      <path\n        d=\"M5 7.5L10 12.5L15 7.5\"\n        stroke=\"currentColor\"\n        stroke-width=\"1.5\"\n        stroke-linecap=\"round\"\n        stroke-linejoin=\"round\"\n      />\n    </svg>\n  </button>\n</h3>\n\n<div\n  class=\"l-accordion-item__panel\"\n  role=\"region\"\n  [id]=\"id() + '-panel'\"\n  [class.is-open]=\"_open()\"\n  [attr.aria-labelledby]=\"id() + '-trigger'\"\n  [attr.inert]=\"_open() ? null : ''\"\n>\n  <div class=\"l-accordion-item__panel-inner\">\n    <div class=\"l-accordion-item__content\">\n      <ng-content />\n    </div>\n  </div>\n</div>\n",
		styles: [":host{display:block}:host(.l-accordion-item--separated){border:1px solid var(--separator);border-radius:10px;background:var(--bg-lightest);overflow:hidden}:host(.l-accordion-item--contained){border-bottom:1px solid var(--separator)}:host(.l-accordion-item--contained):last-of-type{border-bottom:none}.l-accordion-item__heading{margin:0;font:inherit}.l-accordion-item__trigger{display:flex;align-items:center;gap:12px;width:100%;padding:14px 16px;border:none;background:transparent;font-size:15px;font-weight:600;line-height:22px;color:var(--text-primary);text-align:left;cursor:pointer;transition:background-color .15s ease-out}.l-accordion-item__trigger.icon-left{flex-direction:row-reverse}.l-accordion-item__trigger:hover:not(:disabled){background:var(--bg-light)}.l-accordion-item__trigger:focus-visible{outline:2px solid var(--accent);outline-offset:-2px;border-radius:6px}.l-accordion-item__trigger:disabled{opacity:.5;cursor:not-allowed}.l-accordion-item__title{flex:1;min-width:0}.l-accordion-item__chevron{flex-shrink:0;color:var(--text-tertiary);transition:transform .2s cubic-bezier(.4,0,.2,1)}.l-accordion-item__trigger[aria-expanded=true] .l-accordion-item__chevron{transform:rotate(180deg)}.l-accordion-item__panel{display:grid;grid-template-rows:0fr;transition:grid-template-rows .22s cubic-bezier(.4,0,.2,1)}.l-accordion-item__panel.is-open{grid-template-rows:1fr}.l-accordion-item__panel-inner{overflow:hidden;min-height:0}.l-accordion-item__content{padding:16px;font-size:14px;line-height:21px;color:var(--text-secondary)}@media(prefers-reduced-motion:reduce){.l-accordion-item__trigger,.l-accordion-item__chevron,.l-accordion-item__panel{transition:none}}\n"],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: AccordionItem,
	decorators: [{
		type: Component,
		args: [{
			selector: "l-accordion-item",
			changeDetection: ChangeDetectionStrategy.OnPush,
			host: { "[class]": "_hostClasses()" },
			template: "<h3 class=\"l-accordion-item__heading\">\n  <button\n    #header\n    type=\"button\"\n    class=\"l-accordion-item__trigger\"\n    [class.icon-left]=\"_iconPosition() === 'left'\"\n    [disabled]=\"disabled()\"\n    [id]=\"id() + '-trigger'\"\n    [attr.aria-expanded]=\"_open()\"\n    [attr.aria-controls]=\"id() + '-panel'\"\n    (click)=\"_toggle()\"\n    (keydown)=\"_onKeydown($event)\"\n  >\n    <span class=\"l-accordion-item__title\">\n      <ng-content select=\"[slot=title]\">{{ title() }}</ng-content>\n    </span>\n\n    <svg\n      class=\"l-accordion-item__chevron\"\n      width=\"16\"\n      height=\"16\"\n      viewBox=\"0 0 20 20\"\n      fill=\"none\"\n      aria-hidden=\"true\"\n      xmlns=\"http://www.w3.org/2000/svg\"\n    >\n      <path\n        d=\"M5 7.5L10 12.5L15 7.5\"\n        stroke=\"currentColor\"\n        stroke-width=\"1.5\"\n        stroke-linecap=\"round\"\n        stroke-linejoin=\"round\"\n      />\n    </svg>\n  </button>\n</h3>\n\n<div\n  class=\"l-accordion-item__panel\"\n  role=\"region\"\n  [id]=\"id() + '-panel'\"\n  [class.is-open]=\"_open()\"\n  [attr.aria-labelledby]=\"id() + '-trigger'\"\n  [attr.inert]=\"_open() ? null : ''\"\n>\n  <div class=\"l-accordion-item__panel-inner\">\n    <div class=\"l-accordion-item__content\">\n      <ng-content />\n    </div>\n  </div>\n</div>\n",
			styles: [":host{display:block}:host(.l-accordion-item--separated){border:1px solid var(--separator);border-radius:10px;background:var(--bg-lightest);overflow:hidden}:host(.l-accordion-item--contained){border-bottom:1px solid var(--separator)}:host(.l-accordion-item--contained):last-of-type{border-bottom:none}.l-accordion-item__heading{margin:0;font:inherit}.l-accordion-item__trigger{display:flex;align-items:center;gap:12px;width:100%;padding:14px 16px;border:none;background:transparent;font-size:15px;font-weight:600;line-height:22px;color:var(--text-primary);text-align:left;cursor:pointer;transition:background-color .15s ease-out}.l-accordion-item__trigger.icon-left{flex-direction:row-reverse}.l-accordion-item__trigger:hover:not(:disabled){background:var(--bg-light)}.l-accordion-item__trigger:focus-visible{outline:2px solid var(--accent);outline-offset:-2px;border-radius:6px}.l-accordion-item__trigger:disabled{opacity:.5;cursor:not-allowed}.l-accordion-item__title{flex:1;min-width:0}.l-accordion-item__chevron{flex-shrink:0;color:var(--text-tertiary);transition:transform .2s cubic-bezier(.4,0,.2,1)}.l-accordion-item__trigger[aria-expanded=true] .l-accordion-item__chevron{transform:rotate(180deg)}.l-accordion-item__panel{display:grid;grid-template-rows:0fr;transition:grid-template-rows .22s cubic-bezier(.4,0,.2,1)}.l-accordion-item__panel.is-open{grid-template-rows:1fr}.l-accordion-item__panel-inner{overflow:hidden;min-height:0}.l-accordion-item__content{padding:16px;font-size:14px;line-height:21px;color:var(--text-secondary)}@media(prefers-reduced-motion:reduce){.l-accordion-item__trigger,.l-accordion-item__chevron,.l-accordion-item__panel{transition:none}}\n"]
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		title: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "title",
				required: false
			}]
		}],
		disabled: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "disabled",
				required: false
			}]
		}],
		expanded: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "expanded",
				required: false
			}]
		}],
		id: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "id",
				required: false
			}]
		}],
		openedChange: [{
			type: i0.Output,
			args: ["openedChange"]
		}],
		_header: [{
			type: i0.ViewChild,
			args: ["header", { isSignal: true }]
		}]
	}
});
var Filter = class Filter {
	filterColumns = input([], ...ngDevMode ? [{ debugName: "filterColumns" }] : /* istanbul ignore next */ []);
	searchBy = input("", ...ngDevMode ? [{ debugName: "searchBy" }] : /* istanbul ignore next */ []);
	filterChange = output();
	_filterDropdown = viewChild("filterDropdown", ...ngDevMode ? [{ debugName: "_filterDropdown" }] : /* istanbul ignore next */ []);
	_filterList = signal([], ...ngDevMode ? [{ debugName: "_filterList" }] : /* istanbul ignore next */ []);
	_searchText = signal("", ...ngDevMode ? [{ debugName: "_searchText" }] : /* istanbul ignore next */ []);
	_applyFilter() {
		const applied = [];
		for (const filter of this.filterColumns()) {
			if (!filter.value) continue;
			applied.push({
				filterName: filter.name,
				formcontrolName: filter.formcontrolName,
				displayValue: filter.type === "select" ? filter.data?.find((item) => item.id == filter.value)?.name ?? "" : String(filter.value),
				value: filter.value
			});
		}
		const search = this._filterList().find((f) => f.type === "search");
		this._filterList.set(search ? [...applied, search] : applied);
		this._closeDropdown();
		this._emitFilterList();
	}
	_onSearch() {
		const text = this._searchText();
		this._filterList.update((list) => {
			const withoutSearch = list.filter((f) => f.type !== "search");
			return text ? [...withoutSearch, {
				formcontrolName: this.searchBy(),
				displayValue: text,
				value: text,
				type: "search"
			}] : withoutSearch;
		});
		this._emitFilterList();
	}
	_removeFilter(filter) {
		this._filterList.update((list) => list.filter((item) => item !== filter));
		const column = this.filterColumns().find((c) => c.name === filter.filterName);
		if (column) column.value = null;
		this._emitFilterList();
	}
	_removeAllFilter() {
		this._filterList.set([]);
		this.filterColumns().forEach((item) => item.value = null);
		this._searchText.set("");
		this._emitFilterList();
	}
	_closeDropdown() {
		this._filterDropdown()?.close();
	}
	_emitFilterList() {
		const mapped = this._filterList().map((f) => ({
			field: f.formcontrolName,
			value: f.value != null ? String(f.value) : "",
			displayValue: f.displayValue
		}));
		this.filterChange.emit(mapped);
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.1",
		ngImport: i0,
		type: Filter,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.1",
		type: Filter,
		isStandalone: true,
		selector: "l-filter",
		inputs: {
			filterColumns: {
				classPropertyName: "filterColumns",
				publicName: "filterColumns",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			searchBy: {
				classPropertyName: "searchBy",
				publicName: "searchBy",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: { filterChange: "filterChange" },
		viewQueries: [{
			propertyName: "_filterDropdown",
			first: true,
			predicate: ["filterDropdown"],
			descendants: true,
			isSignal: true
		}],
		ngImport: i0,
		template: "<div class=\"filter-section\">\n  @if (searchBy() !== '') {\n    <div class=\"filter-search\">\n      <svg\n        class=\"filter-search__icon\"\n        width=\"18\"\n        height=\"18\"\n        viewBox=\"0 0 20 20\"\n        fill=\"none\"\n        aria-hidden=\"true\"\n        xmlns=\"http://www.w3.org/2000/svg\"\n      >\n        <circle cx=\"9\" cy=\"9\" r=\"6\" stroke=\"currentColor\" stroke-width=\"1.6\" />\n        <path\n          d=\"M13.5 13.5 17 17\"\n          stroke=\"currentColor\"\n          stroke-width=\"1.6\"\n          stroke-linecap=\"round\"\n        />\n      </svg>\n      <input\n        class=\"filter-search__input\"\n        type=\"text\"\n        placeholder=\"Search\"\n        [ngModel]=\"_searchText()\"\n        (ngModelChange)=\"_searchText.set($event)\"\n        (keyup.enter)=\"_onSearch()\"\n      />\n    </div>\n  }\n\n  <l-menu #filterDropdown [contentMode]=\"true\" [closeOnItemClick]=\"false\" [showActiveState]=\"false\">\n    <l-button dropdown-display variant=\"outlined\">\n      <svg\n        width=\"16\"\n        height=\"16\"\n        viewBox=\"0 0 20 20\"\n        fill=\"none\"\n        aria-hidden=\"true\"\n        xmlns=\"http://www.w3.org/2000/svg\"\n      >\n        <path\n          d=\"M3.5 5h13l-5 6v4l-3-1.5V11l-5-6Z\"\n          stroke=\"currentColor\"\n          stroke-width=\"1.5\"\n          stroke-linejoin=\"round\"\n        />\n      </svg>\n      Filters\n      <svg\n        width=\"14\"\n        height=\"14\"\n        viewBox=\"0 0 20 20\"\n        fill=\"none\"\n        aria-hidden=\"true\"\n        xmlns=\"http://www.w3.org/2000/svg\"\n      >\n        <path\n          d=\"M5 7.5 10 12.5 15 7.5\"\n          stroke=\"currentColor\"\n          stroke-width=\"1.5\"\n          stroke-linecap=\"round\"\n          stroke-linejoin=\"round\"\n        />\n      </svg>\n    </l-button>\n\n    <div dropdown-content class=\"filter-dropdown\">\n      <div class=\"filter-header\">\n        <h1 class=\"filter-header-title\">Filter</h1>\n        <l-button\n          variant=\"outlined\"\n          [rounded]=\"true\"\n          (click)=\"_closeDropdown()\"\n          aria-label=\"Close filters\"\n        >\n          <svg\n            width=\"16\"\n            height=\"16\"\n            viewBox=\"0 0 20 20\"\n            fill=\"none\"\n            aria-hidden=\"true\"\n            xmlns=\"http://www.w3.org/2000/svg\"\n          >\n            <path\n              d=\"M15 5 5 15M5 5l10 10\"\n              stroke=\"currentColor\"\n              stroke-width=\"1.6\"\n              stroke-linecap=\"round\"\n            />\n          </svg>\n        </l-button>\n      </div>\n\n      <div class=\"filter-body\">\n        @for (filter of filterColumns(); track $index) {\n          <div class=\"filter-field\">\n            <label>{{ filter.name }}</label>\n\n            @if (filter.type === 'text') {\n              <l-text-input\n                [placeholder]=\"filter.name\"\n                [(ngModel)]=\"filter.value\"\n                (enter)=\"_applyFilter()\"\n              />\n            } @else if (filter.type === 'select') {\n              <l-select\n                [items]=\"filter.data ?? []\"\n                bindLabel=\"name\"\n                bindValue=\"id\"\n                [groupBy]=\"filter.groupBy\"\n                placeholder=\"Select\"\n                [(ngModel)]=\"filter.value\"\n              />\n            }\n          </div>\n        }\n      </div>\n\n      <div class=\"filter-footer\">\n        <l-button variant=\"secondary\" (click)=\"_closeDropdown()\">Cancel</l-button>\n        <l-button variant=\"primary\" (click)=\"_applyFilter()\">Apply</l-button>\n      </div>\n    </div>\n  </l-menu>\n</div>\n\n@if (_filterList().length > 0) {\n  <div class=\"filter-options\">\n    @for (item of _filterList(); track item.formcontrolName) {\n      @if (item.type !== 'search') {\n        <div class=\"filter-item\">\n          <span>{{ item.filterName }}: {{ item.displayValue }}</span>\n          <button\n            class=\"filter-item__remove\"\n            (click)=\"_removeFilter(item)\"\n            aria-label=\"Remove filter\"\n          >\n            <svg\n              width=\"14\"\n              height=\"14\"\n              viewBox=\"0 0 20 20\"\n              fill=\"none\"\n              aria-hidden=\"true\"\n              xmlns=\"http://www.w3.org/2000/svg\"\n            >\n              <path\n                d=\"M15 5 5 15M5 5l10 10\"\n                stroke=\"currentColor\"\n                stroke-width=\"1.75\"\n                stroke-linecap=\"round\"\n              />\n            </svg>\n          </button>\n        </div>\n      }\n    }\n\n    <span class=\"reset-text\" (click)=\"_removeAllFilter()\">Reset Filters</span>\n  </div>\n}\n",
		styles: [":host{display:block}.filter-section{display:flex;align-items:center;gap:12px;flex-wrap:wrap}.filter-search{position:relative;width:250px}.filter-search .filter-search__icon{position:absolute;top:50%;transform:translateY(-50%);left:8px;width:18px;height:18px;opacity:.7}.filter-search__input{width:100%;padding:6px 32px;border:1px solid var(--separator);background:var(--bg-lightest);border-radius:8px;outline:none;display:flex;align-self:stretch;align-items:flex-start;gap:12px;box-shadow:0 1px 2px #0d0d120f;color:var(--text-primary);font-size:14px;font-weight:400;line-height:20px}.filter-search__input::placeholder{color:var(--text-quaternary)}.filter-search__input:focus{outline:none;border:1px solid var(--accent);box-shadow:0 0 0 3px var(--accent-bg)}.filter-field{display:flex;flex-direction:column;align-items:flex-start;align-self:stretch;gap:6px}.filter-field>label{color:var(--text-primary);font-size:14px;font-weight:500;line-height:20px}.filter-options{margin:10px 0;display:flex;align-items:center;gap:12px;flex-wrap:wrap}.filter-options .filter-item{display:flex;align-items:center;gap:4px;padding:4px 8px 4px 12px;border-radius:48px;background:var(--bg-semi-light)}.filter-options .filter-item span{color:var(--text-secondary);font-size:14px;font-weight:500;line-height:20px}.filter-item__remove{display:inline-flex;align-items:center;justify-content:center;padding:2px;border:none;background:transparent;border-radius:50%;color:var(--text-tertiary);cursor:pointer;transition:color .12s ease-out,background .12s ease-out}.filter-item__remove:hover{color:var(--text-primary);background:var(--separator)}.filter-item__remove:focus-visible{outline:2px solid var(--accent);outline-offset:1px}.reset-text{color:var(--accent);font-size:14px;font-weight:400;line-height:20px;text-decoration:underline;text-underline-offset:2px;cursor:pointer}.filter-dropdown{width:328px}.filter-header{display:flex;padding:12px;align-items:center;justify-content:space-between;border-bottom:1px solid var(--separator);gap:16px;align-self:stretch}.filter-header .filter-header-title{color:var(--text-primary);font-size:16px;font-weight:500;line-height:24px}.filter-body{align-self:stretch;padding:12px;max-height:300px;overflow:auto}.filter-body .filter-field{margin-bottom:12px}.filter-body .filter-field:last-child{margin-bottom:0}.filter-footer{display:flex;padding:12px;justify-content:flex-end;gap:12px;align-items:center;align-self:stretch;border-top:1px solid var(--separator)}@media(prefers-reduced-motion:reduce){.filter-item__remove{transition:none}}\n"],
		dependencies: [
			{
				kind: "ngmodule",
				type: FormsModule
			},
			{
				kind: "directive",
				type: i1.DefaultValueAccessor,
				selector: "input:not([type=checkbox]):not([ngNoCva])[formControlName],textarea:not([ngNoCva])[formControlName],input:not([type=checkbox]):not([ngNoCva])[formControl],textarea:not([ngNoCva])[formControl],input:not([type=checkbox]):not([ngNoCva])[ngModel],textarea:not([ngNoCva])[ngModel],[ngDefaultControl]"
			},
			{
				kind: "directive",
				type: i1.NgControlStatus,
				selector: "[formControlName],[ngModel],[formControl]"
			},
			{
				kind: "directive",
				type: i1.NgModel,
				selector: "[ngModel]:not([formControlName]):not([formControl])",
				inputs: [
					"name",
					"disabled",
					"ngModel",
					"ngModelOptions"
				],
				outputs: ["ngModelChange"],
				exportAs: ["ngModel"]
			},
			{
				kind: "component",
				type: Menu,
				selector: "l-menu",
				inputs: [
					"mode",
					"closeOnItemClick",
					"contentMode",
					"showActiveState",
					"appendBody"
				]
			},
			{
				kind: "component",
				type: Button,
				selector: "l-button",
				inputs: [
					"variant",
					"size",
					"width",
					"rounded",
					"disabled"
				]
			},
			{
				kind: "component",
				type: Select,
				selector: "l-select",
				inputs: [
					"label",
					"placeholder",
					"disabled",
					"id",
					"multiple",
					"maxCount",
					"maxTagCount",
					"clearable",
					"items",
					"bindValue",
					"bindLabel",
					"bindDisabled",
					"groupBy",
					"searchable",
					"showArrow",
					"showLoading",
					"virtualScroll",
					"viewMode",
					"viewValue"
				],
				outputs: [
					"change",
					"search",
					"scrollToEnd"
				]
			},
			{
				kind: "component",
				type: TextInput,
				selector: "l-text-input"
			}
		],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: Filter,
	decorators: [{
		type: Component,
		args: [{
			selector: "l-filter",
			changeDetection: ChangeDetectionStrategy.OnPush,
			imports: [
				FormsModule,
				Menu,
				Button,
				Select,
				TextInput
			],
			template: "<div class=\"filter-section\">\n  @if (searchBy() !== '') {\n    <div class=\"filter-search\">\n      <svg\n        class=\"filter-search__icon\"\n        width=\"18\"\n        height=\"18\"\n        viewBox=\"0 0 20 20\"\n        fill=\"none\"\n        aria-hidden=\"true\"\n        xmlns=\"http://www.w3.org/2000/svg\"\n      >\n        <circle cx=\"9\" cy=\"9\" r=\"6\" stroke=\"currentColor\" stroke-width=\"1.6\" />\n        <path\n          d=\"M13.5 13.5 17 17\"\n          stroke=\"currentColor\"\n          stroke-width=\"1.6\"\n          stroke-linecap=\"round\"\n        />\n      </svg>\n      <input\n        class=\"filter-search__input\"\n        type=\"text\"\n        placeholder=\"Search\"\n        [ngModel]=\"_searchText()\"\n        (ngModelChange)=\"_searchText.set($event)\"\n        (keyup.enter)=\"_onSearch()\"\n      />\n    </div>\n  }\n\n  <l-menu #filterDropdown [contentMode]=\"true\" [closeOnItemClick]=\"false\" [showActiveState]=\"false\">\n    <l-button dropdown-display variant=\"outlined\">\n      <svg\n        width=\"16\"\n        height=\"16\"\n        viewBox=\"0 0 20 20\"\n        fill=\"none\"\n        aria-hidden=\"true\"\n        xmlns=\"http://www.w3.org/2000/svg\"\n      >\n        <path\n          d=\"M3.5 5h13l-5 6v4l-3-1.5V11l-5-6Z\"\n          stroke=\"currentColor\"\n          stroke-width=\"1.5\"\n          stroke-linejoin=\"round\"\n        />\n      </svg>\n      Filters\n      <svg\n        width=\"14\"\n        height=\"14\"\n        viewBox=\"0 0 20 20\"\n        fill=\"none\"\n        aria-hidden=\"true\"\n        xmlns=\"http://www.w3.org/2000/svg\"\n      >\n        <path\n          d=\"M5 7.5 10 12.5 15 7.5\"\n          stroke=\"currentColor\"\n          stroke-width=\"1.5\"\n          stroke-linecap=\"round\"\n          stroke-linejoin=\"round\"\n        />\n      </svg>\n    </l-button>\n\n    <div dropdown-content class=\"filter-dropdown\">\n      <div class=\"filter-header\">\n        <h1 class=\"filter-header-title\">Filter</h1>\n        <l-button\n          variant=\"outlined\"\n          [rounded]=\"true\"\n          (click)=\"_closeDropdown()\"\n          aria-label=\"Close filters\"\n        >\n          <svg\n            width=\"16\"\n            height=\"16\"\n            viewBox=\"0 0 20 20\"\n            fill=\"none\"\n            aria-hidden=\"true\"\n            xmlns=\"http://www.w3.org/2000/svg\"\n          >\n            <path\n              d=\"M15 5 5 15M5 5l10 10\"\n              stroke=\"currentColor\"\n              stroke-width=\"1.6\"\n              stroke-linecap=\"round\"\n            />\n          </svg>\n        </l-button>\n      </div>\n\n      <div class=\"filter-body\">\n        @for (filter of filterColumns(); track $index) {\n          <div class=\"filter-field\">\n            <label>{{ filter.name }}</label>\n\n            @if (filter.type === 'text') {\n              <l-text-input\n                [placeholder]=\"filter.name\"\n                [(ngModel)]=\"filter.value\"\n                (enter)=\"_applyFilter()\"\n              />\n            } @else if (filter.type === 'select') {\n              <l-select\n                [items]=\"filter.data ?? []\"\n                bindLabel=\"name\"\n                bindValue=\"id\"\n                [groupBy]=\"filter.groupBy\"\n                placeholder=\"Select\"\n                [(ngModel)]=\"filter.value\"\n              />\n            }\n          </div>\n        }\n      </div>\n\n      <div class=\"filter-footer\">\n        <l-button variant=\"secondary\" (click)=\"_closeDropdown()\">Cancel</l-button>\n        <l-button variant=\"primary\" (click)=\"_applyFilter()\">Apply</l-button>\n      </div>\n    </div>\n  </l-menu>\n</div>\n\n@if (_filterList().length > 0) {\n  <div class=\"filter-options\">\n    @for (item of _filterList(); track item.formcontrolName) {\n      @if (item.type !== 'search') {\n        <div class=\"filter-item\">\n          <span>{{ item.filterName }}: {{ item.displayValue }}</span>\n          <button\n            class=\"filter-item__remove\"\n            (click)=\"_removeFilter(item)\"\n            aria-label=\"Remove filter\"\n          >\n            <svg\n              width=\"14\"\n              height=\"14\"\n              viewBox=\"0 0 20 20\"\n              fill=\"none\"\n              aria-hidden=\"true\"\n              xmlns=\"http://www.w3.org/2000/svg\"\n            >\n              <path\n                d=\"M15 5 5 15M5 5l10 10\"\n                stroke=\"currentColor\"\n                stroke-width=\"1.75\"\n                stroke-linecap=\"round\"\n              />\n            </svg>\n          </button>\n        </div>\n      }\n    }\n\n    <span class=\"reset-text\" (click)=\"_removeAllFilter()\">Reset Filters</span>\n  </div>\n}\n",
			styles: [":host{display:block}.filter-section{display:flex;align-items:center;gap:12px;flex-wrap:wrap}.filter-search{position:relative;width:250px}.filter-search .filter-search__icon{position:absolute;top:50%;transform:translateY(-50%);left:8px;width:18px;height:18px;opacity:.7}.filter-search__input{width:100%;padding:6px 32px;border:1px solid var(--separator);background:var(--bg-lightest);border-radius:8px;outline:none;display:flex;align-self:stretch;align-items:flex-start;gap:12px;box-shadow:0 1px 2px #0d0d120f;color:var(--text-primary);font-size:14px;font-weight:400;line-height:20px}.filter-search__input::placeholder{color:var(--text-quaternary)}.filter-search__input:focus{outline:none;border:1px solid var(--accent);box-shadow:0 0 0 3px var(--accent-bg)}.filter-field{display:flex;flex-direction:column;align-items:flex-start;align-self:stretch;gap:6px}.filter-field>label{color:var(--text-primary);font-size:14px;font-weight:500;line-height:20px}.filter-options{margin:10px 0;display:flex;align-items:center;gap:12px;flex-wrap:wrap}.filter-options .filter-item{display:flex;align-items:center;gap:4px;padding:4px 8px 4px 12px;border-radius:48px;background:var(--bg-semi-light)}.filter-options .filter-item span{color:var(--text-secondary);font-size:14px;font-weight:500;line-height:20px}.filter-item__remove{display:inline-flex;align-items:center;justify-content:center;padding:2px;border:none;background:transparent;border-radius:50%;color:var(--text-tertiary);cursor:pointer;transition:color .12s ease-out,background .12s ease-out}.filter-item__remove:hover{color:var(--text-primary);background:var(--separator)}.filter-item__remove:focus-visible{outline:2px solid var(--accent);outline-offset:1px}.reset-text{color:var(--accent);font-size:14px;font-weight:400;line-height:20px;text-decoration:underline;text-underline-offset:2px;cursor:pointer}.filter-dropdown{width:328px}.filter-header{display:flex;padding:12px;align-items:center;justify-content:space-between;border-bottom:1px solid var(--separator);gap:16px;align-self:stretch}.filter-header .filter-header-title{color:var(--text-primary);font-size:16px;font-weight:500;line-height:24px}.filter-body{align-self:stretch;padding:12px;max-height:300px;overflow:auto}.filter-body .filter-field{margin-bottom:12px}.filter-body .filter-field:last-child{margin-bottom:0}.filter-footer{display:flex;padding:12px;justify-content:flex-end;gap:12px;align-items:center;align-self:stretch;border-top:1px solid var(--separator)}@media(prefers-reduced-motion:reduce){.filter-item__remove{transition:none}}\n"]
		}]
	}],
	propDecorators: {
		filterColumns: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "filterColumns",
				required: false
			}]
		}],
		searchBy: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "searchBy",
				required: false
			}]
		}],
		filterChange: [{
			type: i0.Output,
			args: ["filterChange"]
		}],
		_filterDropdown: [{
			type: i0.ViewChild,
			args: ["filterDropdown", { isSignal: true }]
		}]
	}
});
const SPACING_PRESETS = {
	xs: "4px",
	sm: "8px",
	md: "16px",
	lg: "24px",
	xl: "32px"
};
function toSpacing(value) {
	if (value === void 0) return null;
	if (typeof value === "number") return `${value}px`;
	return SPACING_PRESETS[value] ?? value;
}
function toSize(value) {
	if (value === void 0) return null;
	return typeof value === "number" ? `${value}px` : value;
}
var Box = class Box {
	m = input(...ngDevMode ? [void 0, { debugName: "m" }] : /* istanbul ignore next */ []);
	mx = input(...ngDevMode ? [void 0, { debugName: "mx" }] : /* istanbul ignore next */ []);
	my = input(...ngDevMode ? [void 0, { debugName: "my" }] : /* istanbul ignore next */ []);
	mt = input(...ngDevMode ? [void 0, { debugName: "mt" }] : /* istanbul ignore next */ []);
	mb = input(...ngDevMode ? [void 0, { debugName: "mb" }] : /* istanbul ignore next */ []);
	ml = input(...ngDevMode ? [void 0, { debugName: "ml" }] : /* istanbul ignore next */ []);
	mr = input(...ngDevMode ? [void 0, { debugName: "mr" }] : /* istanbul ignore next */ []);
	p = input(...ngDevMode ? [void 0, { debugName: "p" }] : /* istanbul ignore next */ []);
	px = input(...ngDevMode ? [void 0, { debugName: "px" }] : /* istanbul ignore next */ []);
	py = input(...ngDevMode ? [void 0, { debugName: "py" }] : /* istanbul ignore next */ []);
	pt = input(...ngDevMode ? [void 0, { debugName: "pt" }] : /* istanbul ignore next */ []);
	pb = input(...ngDevMode ? [void 0, { debugName: "pb" }] : /* istanbul ignore next */ []);
	pl = input(...ngDevMode ? [void 0, { debugName: "pl" }] : /* istanbul ignore next */ []);
	pr = input(...ngDevMode ? [void 0, { debugName: "pr" }] : /* istanbul ignore next */ []);
	w = input(...ngDevMode ? [void 0, { debugName: "w" }] : /* istanbul ignore next */ []);
	miw = input(...ngDevMode ? [void 0, { debugName: "miw" }] : /* istanbul ignore next */ []);
	maw = input(...ngDevMode ? [void 0, { debugName: "maw" }] : /* istanbul ignore next */ []);
	h = input(...ngDevMode ? [void 0, { debugName: "h" }] : /* istanbul ignore next */ []);
	mih = input(...ngDevMode ? [void 0, { debugName: "mih" }] : /* istanbul ignore next */ []);
	mah = input(...ngDevMode ? [void 0, { debugName: "mah" }] : /* istanbul ignore next */ []);
	bg = input(...ngDevMode ? [void 0, { debugName: "bg" }] : /* istanbul ignore next */ []);
	c = input(...ngDevMode ? [void 0, { debugName: "c" }] : /* istanbul ignore next */ []);
	_display = inject(ElementRef).nativeElement.tagName === "L-BOX" ? "block" : null;
	_marginTop = computed(() => toSpacing(this.mt() ?? this.my() ?? this.m()), ...ngDevMode ? [{ debugName: "_marginTop" }] : /* istanbul ignore next */ []);
	_marginBottom = computed(() => toSpacing(this.mb() ?? this.my() ?? this.m()), ...ngDevMode ? [{ debugName: "_marginBottom" }] : /* istanbul ignore next */ []);
	_marginLeft = computed(() => toSpacing(this.ml() ?? this.mx() ?? this.m()), ...ngDevMode ? [{ debugName: "_marginLeft" }] : /* istanbul ignore next */ []);
	_marginRight = computed(() => toSpacing(this.mr() ?? this.mx() ?? this.m()), ...ngDevMode ? [{ debugName: "_marginRight" }] : /* istanbul ignore next */ []);
	_paddingTop = computed(() => toSpacing(this.pt() ?? this.py() ?? this.p()), ...ngDevMode ? [{ debugName: "_paddingTop" }] : /* istanbul ignore next */ []);
	_paddingBottom = computed(() => toSpacing(this.pb() ?? this.py() ?? this.p()), ...ngDevMode ? [{ debugName: "_paddingBottom" }] : /* istanbul ignore next */ []);
	_paddingLeft = computed(() => toSpacing(this.pl() ?? this.px() ?? this.p()), ...ngDevMode ? [{ debugName: "_paddingLeft" }] : /* istanbul ignore next */ []);
	_paddingRight = computed(() => toSpacing(this.pr() ?? this.px() ?? this.p()), ...ngDevMode ? [{ debugName: "_paddingRight" }] : /* istanbul ignore next */ []);
	_width = computed(() => toSize(this.w()), ...ngDevMode ? [{ debugName: "_width" }] : /* istanbul ignore next */ []);
	_minWidth = computed(() => toSize(this.miw()), ...ngDevMode ? [{ debugName: "_minWidth" }] : /* istanbul ignore next */ []);
	_maxWidth = computed(() => toSize(this.maw()), ...ngDevMode ? [{ debugName: "_maxWidth" }] : /* istanbul ignore next */ []);
	_height = computed(() => toSize(this.h()), ...ngDevMode ? [{ debugName: "_height" }] : /* istanbul ignore next */ []);
	_minHeight = computed(() => toSize(this.mih()), ...ngDevMode ? [{ debugName: "_minHeight" }] : /* istanbul ignore next */ []);
	_maxHeight = computed(() => toSize(this.mah()), ...ngDevMode ? [{ debugName: "_maxHeight" }] : /* istanbul ignore next */ []);
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.1",
		ngImport: i0,
		type: Box,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.1",
		type: Box,
		isStandalone: true,
		selector: "l-box, [l-box]",
		inputs: {
			m: {
				classPropertyName: "m",
				publicName: "m",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			mx: {
				classPropertyName: "mx",
				publicName: "mx",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			my: {
				classPropertyName: "my",
				publicName: "my",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			mt: {
				classPropertyName: "mt",
				publicName: "mt",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			mb: {
				classPropertyName: "mb",
				publicName: "mb",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			ml: {
				classPropertyName: "ml",
				publicName: "ml",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			mr: {
				classPropertyName: "mr",
				publicName: "mr",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			p: {
				classPropertyName: "p",
				publicName: "p",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			px: {
				classPropertyName: "px",
				publicName: "px",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			py: {
				classPropertyName: "py",
				publicName: "py",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			pt: {
				classPropertyName: "pt",
				publicName: "pt",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			pb: {
				classPropertyName: "pb",
				publicName: "pb",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			pl: {
				classPropertyName: "pl",
				publicName: "pl",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			pr: {
				classPropertyName: "pr",
				publicName: "pr",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			w: {
				classPropertyName: "w",
				publicName: "w",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			miw: {
				classPropertyName: "miw",
				publicName: "miw",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			maw: {
				classPropertyName: "maw",
				publicName: "maw",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			h: {
				classPropertyName: "h",
				publicName: "h",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			mih: {
				classPropertyName: "mih",
				publicName: "mih",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			mah: {
				classPropertyName: "mah",
				publicName: "mah",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			bg: {
				classPropertyName: "bg",
				publicName: "bg",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			c: {
				classPropertyName: "c",
				publicName: "c",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		host: { properties: {
			"style.display": "_display",
			"style.margin-top": "_marginTop()",
			"style.margin-bottom": "_marginBottom()",
			"style.margin-left": "_marginLeft()",
			"style.margin-right": "_marginRight()",
			"style.padding-top": "_paddingTop()",
			"style.padding-bottom": "_paddingBottom()",
			"style.padding-left": "_paddingLeft()",
			"style.padding-right": "_paddingRight()",
			"style.width": "_width()",
			"style.min-width": "_minWidth()",
			"style.max-width": "_maxWidth()",
			"style.height": "_height()",
			"style.min-height": "_minHeight()",
			"style.max-height": "_maxHeight()",
			"style.background": "bg() ?? null",
			"style.color": "c() ?? null"
		} },
		ngImport: i0,
		template: "<ng-content />",
		isInline: true,
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: Box,
	decorators: [{
		type: Component,
		args: [{
			selector: "l-box, [l-box]",
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: "<ng-content />",
			host: {
				"[style.display]": "_display",
				"[style.margin-top]": "_marginTop()",
				"[style.margin-bottom]": "_marginBottom()",
				"[style.margin-left]": "_marginLeft()",
				"[style.margin-right]": "_marginRight()",
				"[style.padding-top]": "_paddingTop()",
				"[style.padding-bottom]": "_paddingBottom()",
				"[style.padding-left]": "_paddingLeft()",
				"[style.padding-right]": "_paddingRight()",
				"[style.width]": "_width()",
				"[style.min-width]": "_minWidth()",
				"[style.max-width]": "_maxWidth()",
				"[style.height]": "_height()",
				"[style.min-height]": "_minHeight()",
				"[style.max-height]": "_maxHeight()",
				"[style.background]": "bg() ?? null",
				"[style.color]": "c() ?? null"
			}
		}]
	}],
	propDecorators: {
		m: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "m",
				required: false
			}]
		}],
		mx: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "mx",
				required: false
			}]
		}],
		my: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "my",
				required: false
			}]
		}],
		mt: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "mt",
				required: false
			}]
		}],
		mb: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "mb",
				required: false
			}]
		}],
		ml: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "ml",
				required: false
			}]
		}],
		mr: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "mr",
				required: false
			}]
		}],
		p: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "p",
				required: false
			}]
		}],
		px: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "px",
				required: false
			}]
		}],
		py: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "py",
				required: false
			}]
		}],
		pt: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "pt",
				required: false
			}]
		}],
		pb: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "pb",
				required: false
			}]
		}],
		pl: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "pl",
				required: false
			}]
		}],
		pr: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "pr",
				required: false
			}]
		}],
		w: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "w",
				required: false
			}]
		}],
		miw: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "miw",
				required: false
			}]
		}],
		maw: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "maw",
				required: false
			}]
		}],
		h: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "h",
				required: false
			}]
		}],
		mih: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "mih",
				required: false
			}]
		}],
		mah: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "mah",
				required: false
			}]
		}],
		bg: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "bg",
				required: false
			}]
		}],
		c: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "c",
				required: false
			}]
		}]
	}
});
const GAP_PRESETS = {
	small: "8px",
	middle: "16px",
	large: "24px"
};
var Flex = class Flex {
	vertical = input(false, ...ngDevMode ? [{ debugName: "vertical" }] : /* istanbul ignore next */ []);
	justify = input("normal", ...ngDevMode ? [{ debugName: "justify" }] : /* istanbul ignore next */ []);
	align = input("normal", ...ngDevMode ? [{ debugName: "align" }] : /* istanbul ignore next */ []);
	wrap = input(false, ...ngDevMode ? [{ debugName: "wrap" }] : /* istanbul ignore next */ []);
	gap = input(0, ...ngDevMode ? [{ debugName: "gap" }] : /* istanbul ignore next */ []);
	_wrapStyle = computed(() => {
		const wrap = this.wrap();
		return typeof wrap === "boolean" ? wrap ? "wrap" : "nowrap" : wrap;
	}, ...ngDevMode ? [{ debugName: "_wrapStyle" }] : /* istanbul ignore next */ []);
	_justifyStyle = computed(() => toCssAlignment(this.justify()), ...ngDevMode ? [{ debugName: "_justifyStyle" }] : /* istanbul ignore next */ []);
	_alignStyle = computed(() => toCssAlignment(this.align()), ...ngDevMode ? [{ debugName: "_alignStyle" }] : /* istanbul ignore next */ []);
	_gapStyle = computed(() => {
		const gap = this.gap();
		if (typeof gap === "number") return gap ? `${gap}px` : null;
		return GAP_PRESETS[gap] ?? gap;
	}, ...ngDevMode ? [{ debugName: "_gapStyle" }] : /* istanbul ignore next */ []);
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.1",
		ngImport: i0,
		type: Flex,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.1",
		type: Flex,
		isStandalone: true,
		selector: "l-flex",
		inputs: {
			vertical: {
				classPropertyName: "vertical",
				publicName: "vertical",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			justify: {
				classPropertyName: "justify",
				publicName: "justify",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			align: {
				classPropertyName: "align",
				publicName: "align",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			wrap: {
				classPropertyName: "wrap",
				publicName: "wrap",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			gap: {
				classPropertyName: "gap",
				publicName: "gap",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		host: { properties: {
			"style.display": "'flex'",
			"style.flex-direction": "vertical() ? 'column' : 'row'",
			"style.flex-wrap": "_wrapStyle()",
			"style.justify-content": "_justifyStyle()",
			"style.align-items": "_alignStyle()",
			"style.gap": "_gapStyle()"
		} },
		ngImport: i0,
		template: "<ng-content />",
		isInline: true,
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: Flex,
	decorators: [{
		type: Component,
		args: [{
			selector: "l-flex",
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: "<ng-content />",
			host: {
				"[style.display]": "'flex'",
				"[style.flex-direction]": "vertical() ? 'column' : 'row'",
				"[style.flex-wrap]": "_wrapStyle()",
				"[style.justify-content]": "_justifyStyle()",
				"[style.align-items]": "_alignStyle()",
				"[style.gap]": "_gapStyle()"
			}
		}]
	}],
	propDecorators: {
		vertical: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "vertical",
				required: false
			}]
		}],
		justify: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "justify",
				required: false
			}]
		}],
		align: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "align",
				required: false
			}]
		}],
		wrap: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "wrap",
				required: false
			}]
		}],
		gap: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "gap",
				required: false
			}]
		}]
	}
});
function toCssAlignment(value) {
	if (value === "normal") return null;
	return value === "start" || value === "end" ? `flex-${value}` : value;
}
const COLUMNS = 12;
const BREAKPOINT_MIN_WIDTH = {
	xs: 0,
	sm: 576,
	md: 768,
	lg: 992,
	xl: 1200,
	xxl: 1400
};
const BREAKPOINT_ORDER = [
	"xs",
	"sm",
	"md",
	"lg",
	"xl",
	"xxl"
];
const ROW_ALIGN_MAP = {
	top: "flex-start",
	middle: "center",
	bottom: "flex-end",
	stretch: "stretch"
};
var GridBreakpoints = class GridBreakpoints {
	_width = signal(window.innerWidth, ...ngDevMode ? [{ debugName: "_width" }] : /* istanbul ignore next */ []);
	active = computed(() => BREAKPOINT_ORDER.filter((bp) => this._width() >= BREAKPOINT_MIN_WIDTH[bp]), ...ngDevMode ? [{ debugName: "active" }] : /* istanbul ignore next */ []);
	constructor() {
		window.addEventListener("resize", () => this._width.set(window.innerWidth));
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.1",
		ngImport: i0,
		type: GridBreakpoints,
		deps: [],
		target: i0.ɵɵFactoryTarget.Injectable
	});
	static ɵprov = i0.ɵɵngDeclareInjectable({
		minVersion: "12.0.0",
		version: "22.2.1",
		ngImport: i0,
		type: GridBreakpoints,
		providedIn: "root"
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: GridBreakpoints,
	decorators: [{
		type: Injectable,
		args: [{ providedIn: "root" }]
	}],
	ctorParameters: () => []
});
var Row = class Row {
	gutter = input(0, ...ngDevMode ? [{ debugName: "gutter" }] : /* istanbul ignore next */ []);
	justify = input("start", ...ngDevMode ? [{ debugName: "justify" }] : /* istanbul ignore next */ []);
	align = input("top", ...ngDevMode ? [{ debugName: "align" }] : /* istanbul ignore next */ []);
	wrap = input(true, ...ngDevMode ? [{ debugName: "wrap" }] : /* istanbul ignore next */ []);
	gutterX = computed(() => {
		const gutter = this.gutter();
		return Array.isArray(gutter) ? gutter[0] : gutter;
	}, ...ngDevMode ? [{ debugName: "gutterX" }] : /* istanbul ignore next */ []);
	gutterY = computed(() => {
		const gutter = this.gutter();
		return Array.isArray(gutter) ? gutter[1] : 0;
	}, ...ngDevMode ? [{ debugName: "gutterY" }] : /* istanbul ignore next */ []);
	_justifyStyle = computed(() => {
		const justify = this.justify();
		return justify === "start" || justify === "end" ? `flex-${justify}` : justify;
	}, ...ngDevMode ? [{ debugName: "_justifyStyle" }] : /* istanbul ignore next */ []);
	_alignStyle = computed(() => ROW_ALIGN_MAP[this.align()], ...ngDevMode ? [{ debugName: "_alignStyle" }] : /* istanbul ignore next */ []);
	_gutterMargin = computed(() => this.gutterX() ? -this.gutterX() / 2 : null, ...ngDevMode ? [{ debugName: "_gutterMargin" }] : /* istanbul ignore next */ []);
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.1",
		ngImport: i0,
		type: Row,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.1",
		type: Row,
		isStandalone: true,
		selector: "l-row",
		inputs: {
			gutter: {
				classPropertyName: "gutter",
				publicName: "gutter",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			justify: {
				classPropertyName: "justify",
				publicName: "justify",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			align: {
				classPropertyName: "align",
				publicName: "align",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			wrap: {
				classPropertyName: "wrap",
				publicName: "wrap",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		host: { properties: {
			"style.display": "'flex'",
			"style.flex-wrap": "wrap() ? 'wrap' : 'nowrap'",
			"style.justify-content": "_justifyStyle()",
			"style.align-items": "_alignStyle()",
			"style.margin-left.px": "_gutterMargin()",
			"style.margin-right.px": "_gutterMargin()",
			"style.row-gap.px": "gutterY() || null"
		} },
		ngImport: i0,
		template: "<ng-content />",
		isInline: true,
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: Row,
	decorators: [{
		type: Component,
		args: [{
			selector: "l-row",
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: "<ng-content />",
			host: {
				"[style.display]": "'flex'",
				"[style.flex-wrap]": "wrap() ? 'wrap' : 'nowrap'",
				"[style.justify-content]": "_justifyStyle()",
				"[style.align-items]": "_alignStyle()",
				"[style.margin-left.px]": "_gutterMargin()",
				"[style.margin-right.px]": "_gutterMargin()",
				"[style.row-gap.px]": "gutterY() || null"
			}
		}]
	}],
	propDecorators: {
		gutter: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "gutter",
				required: false
			}]
		}],
		justify: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "justify",
				required: false
			}]
		}],
		align: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "align",
				required: false
			}]
		}],
		wrap: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "wrap",
				required: false
			}]
		}]
	}
});
var Col = class Col {
	span = input(null, ...ngDevMode ? [{ debugName: "span" }] : /* istanbul ignore next */ []);
	offset = input(0, ...ngDevMode ? [{ debugName: "offset" }] : /* istanbul ignore next */ []);
	order = input(null, ...ngDevMode ? [{ debugName: "order" }] : /* istanbul ignore next */ []);
	flex = input(null, ...ngDevMode ? [{ debugName: "flex" }] : /* istanbul ignore next */ []);
	xs = input(null, ...ngDevMode ? [{ debugName: "xs" }] : /* istanbul ignore next */ []);
	sm = input(null, ...ngDevMode ? [{ debugName: "sm" }] : /* istanbul ignore next */ []);
	md = input(null, ...ngDevMode ? [{ debugName: "md" }] : /* istanbul ignore next */ []);
	lg = input(null, ...ngDevMode ? [{ debugName: "lg" }] : /* istanbul ignore next */ []);
	xl = input(null, ...ngDevMode ? [{ debugName: "xl" }] : /* istanbul ignore next */ []);
	xxl = input(null, ...ngDevMode ? [{ debugName: "xxl" }] : /* istanbul ignore next */ []);
	_row = inject(Row, { optional: true });
	_breakpoints = inject(GridBreakpoints);
	_byBreakpoint = {
		xs: this.xs,
		sm: this.sm,
		md: this.md,
		lg: this.lg,
		xl: this.xl,
		xxl: this.xxl
	};
	_size = computed(() => {
		const merged = {
			span: this.span() ?? void 0,
			offset: this.offset(),
			order: this.order() ?? void 0
		};
		for (const bp of this._breakpoints.active()) {
			const value = this._byBreakpoint[bp]();
			if (value == null) continue;
			if (typeof value === "number") merged.span = value;
			else Object.assign(merged, value);
		}
		return merged;
	}, ...ngDevMode ? [{ debugName: "_size" }] : /* istanbul ignore next */ []);
	_hidden = computed(() => this._size().span === 0, ...ngDevMode ? [{ debugName: "_hidden" }] : /* istanbul ignore next */ []);
	_flexStyle = computed(() => {
		const flex = this.flex();
		if (flex !== null && flex !== "") {
			if (typeof flex === "number") return `${flex} ${flex} auto`;
			if (flex === "auto") return "1 1 auto";
			if (flex === "none") return "none";
			return /^\d+(\.\d+)?(px|%|em|rem|vw|vh)$/.test(flex) ? `0 0 ${flex}` : flex;
		}
		const span = this._size().span;
		return span != null ? `0 0 ${percent(span)}` : null;
	}, ...ngDevMode ? [{ debugName: "_flexStyle" }] : /* istanbul ignore next */ []);
	_maxWidthStyle = computed(() => {
		if (this.flex() !== null) return null;
		const span = this._size().span;
		return span != null ? percent(span) : null;
	}, ...ngDevMode ? [{ debugName: "_maxWidthStyle" }] : /* istanbul ignore next */ []);
	_offsetStyle = computed(() => {
		const offset = this._size().offset;
		return offset ? percent(offset) : null;
	}, ...ngDevMode ? [{ debugName: "_offsetStyle" }] : /* istanbul ignore next */ []);
	_orderStyle = computed(() => this._size().order ?? null, ...ngDevMode ? [{ debugName: "_orderStyle" }] : /* istanbul ignore next */ []);
	_gutterPad = computed(() => {
		const gutterX = this._row?.gutterX() ?? 0;
		return gutterX ? gutterX / 2 : null;
	}, ...ngDevMode ? [{ debugName: "_gutterPad" }] : /* istanbul ignore next */ []);
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.1",
		ngImport: i0,
		type: Col,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.1",
		type: Col,
		isStandalone: true,
		selector: "l-col",
		inputs: {
			span: {
				classPropertyName: "span",
				publicName: "span",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			offset: {
				classPropertyName: "offset",
				publicName: "offset",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			order: {
				classPropertyName: "order",
				publicName: "order",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			flex: {
				classPropertyName: "flex",
				publicName: "flex",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			xs: {
				classPropertyName: "xs",
				publicName: "xs",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			sm: {
				classPropertyName: "sm",
				publicName: "sm",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			md: {
				classPropertyName: "md",
				publicName: "md",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			lg: {
				classPropertyName: "lg",
				publicName: "lg",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			xl: {
				classPropertyName: "xl",
				publicName: "xl",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			xxl: {
				classPropertyName: "xxl",
				publicName: "xxl",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		host: { properties: {
			"style.display": "_hidden() ? 'none' : 'block'",
			"style.box-sizing": "'border-box'",
			"style.min-width": "'0'",
			"style.flex": "_flexStyle()",
			"style.max-width": "_maxWidthStyle()",
			"style.margin-left": "_offsetStyle()",
			"style.order": "_orderStyle()",
			"style.padding-left.px": "_gutterPad()",
			"style.padding-right.px": "_gutterPad()"
		} },
		ngImport: i0,
		template: "<ng-content />",
		isInline: true,
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: Col,
	decorators: [{
		type: Component,
		args: [{
			selector: "l-col",
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: "<ng-content />",
			host: {
				"[style.display]": "_hidden() ? 'none' : 'block'",
				"[style.box-sizing]": "'border-box'",
				"[style.min-width]": "'0'",
				"[style.flex]": "_flexStyle()",
				"[style.max-width]": "_maxWidthStyle()",
				"[style.margin-left]": "_offsetStyle()",
				"[style.order]": "_orderStyle()",
				"[style.padding-left.px]": "_gutterPad()",
				"[style.padding-right.px]": "_gutterPad()"
			}
		}]
	}],
	propDecorators: {
		span: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "span",
				required: false
			}]
		}],
		offset: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "offset",
				required: false
			}]
		}],
		order: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "order",
				required: false
			}]
		}],
		flex: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "flex",
				required: false
			}]
		}],
		xs: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "xs",
				required: false
			}]
		}],
		sm: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "sm",
				required: false
			}]
		}],
		md: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "md",
				required: false
			}]
		}],
		lg: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "lg",
				required: false
			}]
		}],
		xl: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "xl",
				required: false
			}]
		}],
		xxl: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "xxl",
				required: false
			}]
		}]
	}
});
function percent(span) {
	return `${span / COLUMNS * 100}%`;
}
const SIZE_PRESETS = {
	xs: "4px",
	sm: "8px",
	md: "16px",
	lg: "24px",
	xl: "32px"
};
function toCssSize(size) {
	if (size === void 0) return null;
	if (typeof size === "number") return `${size}px`;
	return SIZE_PRESETS[size] ?? size;
}
var Spacer = class Spacer {
	h = input(...ngDevMode ? [void 0, { debugName: "h" }] : /* istanbul ignore next */ []);
	w = input(...ngDevMode ? [void 0, { debugName: "w" }] : /* istanbul ignore next */ []);
	_height = computed(() => toCssSize(this.h()), ...ngDevMode ? [{ debugName: "_height" }] : /* istanbul ignore next */ []);
	_width = computed(() => toCssSize(this.w()), ...ngDevMode ? [{ debugName: "_width" }] : /* istanbul ignore next */ []);
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.1",
		ngImport: i0,
		type: Spacer,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.1",
		type: Spacer,
		isStandalone: true,
		selector: "l-spacer",
		inputs: {
			h: {
				classPropertyName: "h",
				publicName: "h",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			w: {
				classPropertyName: "w",
				publicName: "w",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		host: {
			attributes: { "aria-hidden": "true" },
			properties: {
				"style.display": "'block'",
				"style.height": "_height()",
				"style.width": "_width()",
				"style.flex-shrink": "0"
			}
		},
		ngImport: i0,
		template: "",
		isInline: true,
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: Spacer,
	decorators: [{
		type: Component,
		args: [{
			selector: "l-spacer",
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: "",
			host: {
				"aria-hidden": "true",
				"[style.display]": "'block'",
				"[style.height]": "_height()",
				"[style.width]": "_width()",
				"[style.flex-shrink]": "0"
			}
		}]
	}],
	propDecorators: {
		h: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "h",
				required: false
			}]
		}],
		w: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "w",
				required: false
			}]
		}]
	}
});
export { Accordion, AccordionItem, Avatar, Badge, BadgeDirective, BaseBooleanInput, BaseInput, BaseRadioInput, Box, Breadcrumb, Button, Card, Checkbox, Chip, Col, ConfirmDialog, DRAWER_DATA, DateInput, DrawerRef, DrawerService, EmailInput, FileUpload, Filter, Flex, FormValidation, GridBreakpoints, Icon, IconRegistry, L_ICON_NAMES, LoadingSpinner, MODAL_DATA, Menu, ModalRef, ModalService, Notification, NotificationRef, NotificationService, NumberInput, OtpInput, Pagination, PasswordInput, Radio, Row, SegmentedControl, Select, Skeleton, Spacer, SpinnerService, Stepper, Tab, Table, TableCellDirective, Tabs, TextInput, Textarea, ThemeService, Toggle, Tooltip, TooltipDirective, Tree, TreeItem, UsernameInput, provideInputValidator, provideInputValueAccessor, provideTheme, themeVars };

//# sourceMappingURL=lumen-ui-angular.mjs.map