var search_default = "<svg width=\"18\" height=\"18\" viewBox=\"0 0 18 18\" fill=\"none\" xmlns=\"http://www.w3.org/2000/svg\">\n<path d=\"M13.1328 13.1328C15.6224 10.6432 15.6224 6.60679 13.1328 4.11719C10.6432 1.6276 6.60679 1.6276 4.11719 4.11719C1.6276 6.60679 1.6276 10.6432 4.11719 13.1328C6.60679 15.6224 10.6432 15.6224 13.1328 13.1328ZM13.1328 13.1328L15.75 15.75\" stroke=\"#979996\" stroke-width=\"1.5\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>\n</svg>";
export { search_default as default };

//# sourceMappingURL=lumen-ui-angular-search-DYgQippv.mjs.map