var checkroom_default = "<svg fill=\"currentColor\" xmlns=\"http://www.w3.org/2000/svg\" width=\"48\" height=\"48\" viewBox=\"0 -960 960 960\"><path d=\"M110-160q-13 0-21.5-8.5T80-190q0-7 3-13t9-11l358-281v-55q0-12 8.5-21t20.5-9q34 0 57.5-23.5T560-661q0-33-23.5-56T480-740q-33 0-56.5 23.5T400-660h-60q0-58 41-99t99-41q58 0 99 40.5t41 98.5q0 49-31 86.5T510-523v28l358 281q6 5 9 11t3 13q0 13-8.5 21.5T850-160H110Zm90-60h560L480-443 200-220Z\"/></svg>";
export { checkroom_default as default };

//# sourceMappingURL=lumen-ui-angular-checkroom-DLf2nU0S.mjs.map