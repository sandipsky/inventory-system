var download_default = "<svg width=\"20\" height=\"20\" viewBox=\"0 0 20 20\" fill=\"none\" xmlns=\"http://www.w3.org/2000/svg\">\n<path d=\"M9.99967 5V11.6667M9.99967 11.6667L12.083 9.58333M9.99967 11.6667L7.91634 9.58333M16.6663 10V12.5C16.6663 13.8807 15.5471 15 14.1663 15H5.83301C4.4523 15 3.33301 13.8807 3.33301 12.5V10\" stroke=\"#555755\" stroke-width=\"1.5\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>\n</svg>";
export { download_default as default };

//# sourceMappingURL=lumen-ui-angular-download-CgrDVSG2.mjs.map