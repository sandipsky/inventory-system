var bar_chart_default = "<svg fill=\"currentColor\" xmlns=\"http://www.w3.org/2000/svg\" width=\"48\" height=\"48\" viewBox=\"0 -960 960 960\"><path d=\"M660-160v-280h140v280H660Zm-250 0v-640h140v640H410Zm-250 0v-440h140v440H160Z\"/></svg>";
export { bar_chart_default as default };

//# sourceMappingURL=lumen-ui-angular-bar_chart-ldicCVnG.mjs.map