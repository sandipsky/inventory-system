var configuration_default = "<svg width=\"20\" height=\"20\" viewBox=\"0 0 20 20\" fill=\"none\" xmlns=\"http://www.w3.org/2000/svg\">\n<path d=\"M17.292 4.16667H14.792M11.4587 2.5V5.83333M11.4587 4.16667H2.29199M5.62533 10H2.29199M8.95866 8.33333V11.6667M18.1253 10H8.95866M17.292 15.8333H14.792M11.4587 14.1667V17.5M11.4587 15.8333H2.29199\" stroke=\"#646663\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>\n</svg>";
export { configuration_default as default };

//# sourceMappingURL=lumen-ui-angular-configuration-Ct8il9xB.mjs.map