var add_default = "<svg width=\"20\" height=\"20\" viewBox=\"0 0 20 20\" fill=\"none\" xmlns=\"http://www.w3.org/2000/svg\">\n<path d=\"M9.99968 10.0002V5.8335M9.99968 10.0002V14.1668M9.99968 10.0002H14.1663M9.99968 10.0002H5.83301\" stroke=\"#646663\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>\n</svg>";
export { add_default as default };

//# sourceMappingURL=lumen-ui-angular-add-CWm-IazY.mjs.map