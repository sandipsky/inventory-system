import * as i0 from "@angular/core";
import { ComponentRef, EnvironmentProviders, InjectionToken, OnDestroy, OnInit, TemplateRef, Type, WritableSignal } from "@angular/core";
import { SafeHtml } from "@angular/platform-browser";
import { AbstractControl, ControlValueAccessor, ValidationErrors, Validator } from "@angular/forms";
import { Observable } from "rxjs";
/**
 * Design-token overrides. Each key is a LumenUI color token in camelCase
 * (`accentBg` → `--accent-bg`); values are any CSS color, including
 * `var(--…)` references. Leave a key out to keep its default.
 *
 * Every color with a `…Bg` partner gets that tint derived when you set the
 * color alone, so `{ accent: '#2563eb' }` is a complete brand change.
 */
export interface Theme {
  /** Brand color: primary buttons, checked inputs, active tabs, focus borders. Default `#4cb139`. */
  accent?: string;
  /** Tinted surface behind accent content (chips, hovers, focus rings). Derived from `accent`. */
  accentBg?: string;
  /** Hover shade of the accent, e.g. primary button hover. Derived from `accent`. */
  accentDark?: string;
  /**
   * Text and icons drawn on an accent background. Default `var(--text-white)`;
   * set a dark color when the accent is light (yellow, lime, …).
   */
  accentContrast?: string;
  success?: string;
  successBg?: string;
  error?: string;
  errorBg?: string;
  warn?: string;
  warnBg?: string;
  info?: string;
  infoBg?: string;
  premium?: string;
  premiumBg?: string;
  /** Cancelled status, e.g. table status cells. Default `var(--text-tertiary)`. */
  cancel?: string;
  cancelBg?: string;
  textPrimary?: string;
  textSecondary?: string;
  textTertiary?: string;
  textQuaternary?: string;
  /** Light text on dark or colored fills (badges, tooltips, filled status icons). */
  textWhite?: string;
  separator?: string;
  separatorLight?: string;
  separatorDark?: string;
  /** Surface color of inputs, cards, menus, modals and other raised elements. */
  bgLightest?: string;
  bgLight?: string;
  bgSemiLight?: string;
  bgDark?: string;
}
/**
 * Turns a {@link Theme} into CSS custom properties, filling in derived tints
 * and shades the theme doesn't set. Bind the result with `[style]` to theme
 * one part of the page:
 *
 * ```html
 * <section [style]="danger">…</section>
 * ```
 * ```ts
 * protected readonly danger = themeVars({ accent: 'var(--error)' });
 * ```
 *
 * Overlays (modals, drawers, notifications, select menus) render under
 * `<body>`, outside the section, so they keep the page-wide theme.
 */
export declare function themeVars(theme: Theme): Record<string, string>;
/**
 * Applies a page-wide {@link Theme} on `<html>`, so it reaches overlays
 * rendered under `<body>` too. Set the initial theme with
 * {@link provideTheme}; inject this to change it at runtime:
 *
 * ```ts
 * inject(ThemeService).set({ accent: tenant.brandColor });
 * ```
 */
export declare class ThemeService {
  private readonly _root;
  private readonly _theme;
  private _applied;
  /** The overrides currently applied; tokens not in it use their defaults. */
  readonly theme: import("@angular/core").Signal<Theme>;
  /** Replace the current overrides. Tokens `theme` leaves out revert to their defaults. */
  set(theme: Theme): void;
  /** Drop every override and go back to the stylesheet defaults. */
  reset(): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<ThemeService, never>;
  static ɵprov: i0.ɵɵInjectableDeclaration<any>;
}
/**
 * Applies a page-wide {@link Theme} before the app renders. Add it to the
 * application providers:
 *
 * ```ts
 * bootstrapApplication(App, {
 *   providers: [provideTheme({ accent: '#2563eb' })],
 * });
 * ```
 */
export declare function provideTheme(theme: Theme): EnvironmentProviders;
export type ButtonVariant = 'primary' | 'secondary' | 'outlined' | 'outlined-primary' | 'danger' | 'ghost';
export type ButtonSize = 'sm' | 'md' | 'lg';
export type ButtonWidth = 'auto' | 'full';
export declare class Button {
  readonly variant: import("@angular/core").InputSignal<ButtonVariant>;
  /** `sm` 4×8, `md` 6×12, `lg` 8×16 (px). */
  readonly size: import("@angular/core").InputSignal<ButtonSize>;
  /** `auto` fits content, `full` fills the parent width. */
  readonly width: import("@angular/core").InputSignal<ButtonWidth>;
  /** Render as a circular icon button. */
  readonly rounded: import("@angular/core").InputSignal<boolean>;
  readonly disabled: import("@angular/core").InputSignal<boolean>;
  protected readonly _classes: import("@angular/core").Signal<string>;
  static ɵfac: i0.ɵɵFactoryDeclaration<Button, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<Button, "l-button", never, {
    "variant": {
      "alias": "variant";
      "required": false;
      "isSignal": true;
    };
    "size": {
      "alias": "size";
      "required": false;
      "isSignal": true;
    };
    "width": {
      "alias": "width";
      "required": false;
      "isSignal": true;
    };
    "rounded": {
      "alias": "rounded";
      "required": false;
      "isSignal": true;
    };
    "disabled": {
      "alias": "disabled";
      "required": false;
      "isSignal": true;
    };
  }, {}, never, ["*"], true, never>;
}
declare const ICON_NAMES: readonly ["add", "attach_file", "backup", "bag", "bank", "bar_chart", "bolt", "bookmark", "box", "building", "calculator", "calendar", "calendar_month", "call", "car", "card", "caret", "caret_down", "cart", "cart_add", "cart_return", "category", "checklist", "checklist_alt", "checkroom", "clock", "configuration", "content_copy", "controller", "cross", "dashboard", "dashboard_alt", "dislike", "donut_large", "download", "drawer", "edit", "education", "error", "event_repeat", "eye", "eye_slash", "factory", "family", "file", "file_add", "file_alt", "files", "filter", "filter_list", "fitness", "flight", "fuel", "hand", "hash", "heart", "help", "home", "hospital", "image", "like", "list", "location", "lock", "logout", "mail", "money", "moneys", "more", "music", "notebook", "notification", "notifications_alt", "pie_chart", "printer", "receipt", "refresh", "savings", "savings_alt", "search", "settings", "shield", "star", "train", "trash", "truck", "undo", "upload_file", "user", "user_add", "user_card", "user_config", "users", "verified_user", "view", "wallet", "wallet_alt", "warning", "wifi", "work"];
declare const ICON_LOADERS: Readonly<Record<string, () => Promise<{
  default: string;
}>>>;
/**
 * Icon names — the file names (minus `.svg`) under the repo-root `icons/`
 * folder shared with the React package, listed by the generated `./svg`
 * index (`npm run icons`). `(string & {})` keeps the union open so a name
 * typed as a plain `string` still compiles, while known names autocomplete.
 */
export type IconName = (typeof ICON_NAMES)[number] | (string & {});
/** Every bundled icon name, sorted — handy for galleries and pickers. */
export declare const L_ICON_NAMES: readonly IconName[];
/**
 * Lazy-loads the svg files from the shared `icons/` folder, normalized and
 * cached per name. The folder sits outside the library, so
 * `scripts/generate-icons.mjs` wraps each file in a TS module under `./svg`;
 * the `import()` loaders there keep one lazy chunk per icon in the app build.
 */
export declare class IconRegistry {
  private readonly _cache;
  /** Resolves to `''` (with a dev warning) when the icon doesn't exist. */
  load(name: string): Promise<string>;
  static ɵfac: i0.ɵɵFactoryDeclaration<IconRegistry, never>;
  static ɵprov: i0.ɵɵInjectableDeclaration<any>;
}
/**
 * Inline SVG icon. Renders the named file from `icons/` with its colors
 * rebound to `currentColor`, so it tints via the `color` input — defaulting
 * to `var(--text-tertiary)` (#646663), the gray the icons were drawn with.
 *
 * ```html
 * <l-icon name="user" />
 * <l-icon name="trash" [size]="16" color="var(--error)" />
 * ```
 */
export declare class Icon {
  /** Icon to draw — an svg file name from `icons/` without the extension. */
  readonly name: import("@angular/core").InputSignal<IconName>;
  /** Width/height. A number is pixels; any CSS size string works too. */
  readonly size: import("@angular/core").InputSignal<string | number>;
  /**
   * Icon color — any CSS color, including `var(--…)` tokens. Defaults to
   * `var(--text-tertiary)` (#646663); pass `"inherit"` to follow the
   * surrounding text color instead.
   */
  readonly color: import("@angular/core").InputSignal<string>;
  private readonly _registry;
  private readonly _sanitizer;
  protected readonly _dimension: import("@angular/core").Signal<string>;
  protected readonly _svg: import("@angular/core").WritableSignal<SafeHtml | null>;
  constructor();
  static ɵfac: i0.ɵɵFactoryDeclaration<Icon, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<Icon, "l-icon", never, {
    "name": {
      "alias": "name";
      "required": true;
      "isSignal": true;
    };
    "size": {
      "alias": "size";
      "required": false;
      "isSignal": true;
    };
    "color": {
      "alias": "color";
      "required": false;
      "isSignal": true;
    };
  }, {}, never, never, true, never>;
}
type MenuMode = 'left' | 'right';
/**
 * Lightweight dropdown/popover. Project the trigger via `[dropdown-display]`
 * and the panel contents via `[dropdown-item]` / `[dropdown-content]`:
 *
 * ```html
 * <l-menu mode="right">
 *   <button dropdown-display>Open</button>
 *   <div dropdown-item (click)="…">Action</div>
 * </l-menu>
 * ```
 *
 * The panel renders in a fixed layer anchored to the trigger, so it escapes any
 * `overflow` clipping on ancestors, flips above the trigger when there isn't
 * room below, and stays anchored while the page scrolls — mirroring the
 * `l-select` dropdown behavior. It stays anchored inside transformed or
 * filtered ancestors too, which make `position: fixed` relative to themselves.
 * Such an ancestor can still clip the panel when it also scrolls or hides
 * overflow; set `appendBody` to render the panel under `<body>` instead.
 */
export declare class Menu {
  /** Which trigger edge the panel aligns to. */
  readonly mode: import("@angular/core").InputSignal<MenuMode>;
  /** Close the panel when a projected item is clicked. */
  readonly closeOnItemClick: import("@angular/core").InputSignal<boolean>;
  /** Drop the panel's inner padding (for custom, edge-to-edge content). */
  readonly contentMode: import("@angular/core").InputSignal<boolean>;
  /** Highlight the trigger while the panel is open. */
  readonly showActiveState: import("@angular/core").InputSignal<boolean>;
  /**
   * Render the panel under `<body>` instead of inside the component, so no
   * ancestor can clip it (e.g. a scrolling container with a `transform`).
   */
  readonly appendBody: import("@angular/core").InputSignal<boolean>;
  private readonly _open;
  /** Whether the panel is currently open — read by consumers via a template ref. */
  readonly isOpen: import("@angular/core").Signal<boolean>;
  protected readonly _isReady: import("@angular/core").WritableSignal<boolean>;
  protected readonly _dropUp: import("@angular/core").WritableSignal<boolean>;
  protected readonly _top: import("@angular/core").WritableSignal<number | null>;
  protected readonly _bottom: import("@angular/core").WritableSignal<number | null>;
  protected readonly _left: import("@angular/core").WritableSignal<number | null>;
  protected readonly _right: import("@angular/core").WritableSignal<number | null>;
  protected readonly _maxHeight: import("@angular/core").WritableSignal<number | null>;
  private readonly _host;
  private readonly _panel;
  private readonly _onViewportChange;
  constructor();
  /** Open when closed, close when open. */
  toggle(): void;
  close(): void;
  protected _onDocumentClick(event: MouseEvent): void;
  /** Trigger clicks toggle; clicks that bubbled up from the panel are the panel's business. */
  protected _onTriggerClick(event: MouseEvent): void;
  protected _onPanelClick(): void;
  /** True when the node lives in the trigger host or the (possibly body-level) panel. */
  private _isInside;
  private _openMenu;
  /**
   * Anchor the fixed panel to the trigger rect: align the requested edge
   * horizontally, drop below by default, flip above when room runs out, and cap
   * the height to the space available.
   */
  private _reposition;
  private _unbindViewport;
  static ɵfac: i0.ɵɵFactoryDeclaration<Menu, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<Menu, "l-menu", never, {
    "mode": {
      "alias": "mode";
      "required": false;
      "isSignal": true;
    };
    "closeOnItemClick": {
      "alias": "closeOnItemClick";
      "required": false;
      "isSignal": true;
    };
    "contentMode": {
      "alias": "contentMode";
      "required": false;
      "isSignal": true;
    };
    "showActiveState": {
      "alias": "showActiveState";
      "required": false;
      "isSignal": true;
    };
    "appendBody": {
      "alias": "appendBody";
      "required": false;
      "isSignal": true;
    };
  }, {}, never, ["[dropdown-display]", "[dropdown-item]", "[dropdown-content]"], true, never>;
}
type SegmentedOrientation = 'horizontal' | 'vertical';
type SegmentedSize = 'sm' | 'md' | 'lg';
interface SegmentedOption {
  label: string;
  value: unknown;
  disabled?: boolean;
}
/**
 * Segmented control — a single-select switch rendered as a row (or column) of
 * connected buttons, like iOS / Ant Design `Segmented`. Accepts plain strings
 * or `{ label, value, disabled }` objects, bridges to `ControlValueAccessor`
 * (so it works with `[(ngModel)]` and reactive forms), and follows the WAI-ARIA
 * radio-group keyboard pattern.
 *
 * ```html
 * <l-segmented-control [options]="['Daily', 'Weekly', 'Monthly']" [(ngModel)]="range" />
 * <l-segmented-control [options]="opts" orientation="vertical" [(ngModel)]="view" />
 * ```
 */
export declare class SegmentedControl implements ControlValueAccessor {
  /** Options to choose from — plain strings or `{ label, value, disabled }` objects. */
  readonly options: import("@angular/core").InputSignal<readonly (string | SegmentedOption)[]>;
  readonly orientation: import("@angular/core").InputSignal<SegmentedOrientation>;
  readonly size: import("@angular/core").InputSignal<SegmentedSize>;
  /** Disable the whole control. */
  readonly disabled: import("@angular/core").InputSignal<boolean>;
  /** Stretch to the container width with equal-width segments. */
  readonly fullWidth: import("@angular/core").InputSignal<boolean>;
  readonly name: import("@angular/core").InputSignal<string>;
  /** Emits the selected value when it changes. */
  readonly change: import("@angular/core").OutputEmitterRef<unknown>;
  protected readonly _value: import("@angular/core").WritableSignal<unknown>;
  protected readonly _disabledByForm: import("@angular/core").WritableSignal<boolean>;
  protected readonly _isDisabled: import("@angular/core").Signal<boolean>;
  private readonly _segments;
  private readonly _host;
  /** Geometry of the sliding thumb behind the selected segment. */
  protected readonly _thumb: import("@angular/core").WritableSignal<{
    x: number;
    y: number;
    width: number;
    height: number;
    visible: boolean;
  }>;
  /** Gate the slide transition on until after the first paint (avoid a flash from 0,0). */
  protected readonly _ready: import("@angular/core").WritableSignal<boolean>;
  constructor();
  private _positionThumb;
  protected readonly _options: import("@angular/core").Signal<SegmentedOption[]>;
  /** The single segment that is keyboard-tabbable (the selected one, else the first enabled). */
  protected readonly _tabbableValue: import("@angular/core").Signal<unknown>;
  protected readonly _hostClasses: import("@angular/core").Signal<string>;
  private _onChange;
  private _onTouched;
  protected _isSelected(value: unknown): boolean;
  protected _select(option: SegmentedOption): void;
  protected _onKeydown(event: KeyboardEvent, index: number): void;
  private _nextEnabled;
  writeValue(value: unknown): void;
  registerOnChange(fn: (value: unknown) => void): void;
  registerOnTouched(fn: () => void): void;
  setDisabledState(isDisabled: boolean): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<SegmentedControl, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<SegmentedControl, "l-segmented-control", never, {
    "options": {
      "alias": "options";
      "required": false;
      "isSignal": true;
    };
    "orientation": {
      "alias": "orientation";
      "required": false;
      "isSignal": true;
    };
    "size": {
      "alias": "size";
      "required": false;
      "isSignal": true;
    };
    "disabled": {
      "alias": "disabled";
      "required": false;
      "isSignal": true;
    };
    "fullWidth": {
      "alias": "fullWidth";
      "required": false;
      "isSignal": true;
    };
    "name": {
      "alias": "name";
      "required": false;
      "isSignal": true;
    };
  }, {
    "change": "change";
  }, never, never, true, never>;
}
/**
 * Registers a concrete input component as the value accessor for itself, so it
 * works with both `[(ngModel)]` and reactive forms. Pass a thunk because the
 * component class isn't defined yet when its own `providers` are evaluated.
 */
export declare function provideInputValueAccessor(component: () => Type<unknown>): {
  provide: import("@angular/core").InjectionToken<readonly ControlValueAccessor[]>;
  useExisting: Type<any>;
  multi: boolean;
};
/**
 * Registers a concrete input component as a `Validator` for its own bound
 * control, so format errors (e.g. email) surface in `ngModel`/reactive forms.
 */
export declare function provideInputValidator(component: () => Type<unknown>): {
  provide: import("@angular/core").InjectionToken<readonly (Function | import("@angular/forms").Validator)[]>;
  useExisting: Type<any>;
  multi: boolean;
};
/**
 * Shared logic for all LumenUI text-like inputs. Holds the common inputs,
 * native event outputs and the `ControlValueAccessor` bridge; concrete
 * components (`TextInput`, …) extend this and set {@link type}.
 */
export declare abstract class BaseInput implements ControlValueAccessor {
  /** Native input `type` — set by the concrete subclass. */
  protected abstract readonly type: string;
  readonly label: import("@angular/core").InputSignal<string>;
  readonly placeholder: import("@angular/core").InputSignal<string>;
  readonly disabled: import("@angular/core").InputSignal<boolean>;
  readonly id: import("@angular/core").InputSignal<string>;
  /** Render the value as plain text instead of the input. */
  readonly viewMode: import("@angular/core").InputSignal<boolean>;
  /** Custom text shown in view mode; falls back to the value when omitted. */
  readonly viewValue: import("@angular/core").InputSignal<string | undefined>;
  readonly input: import("@angular/core").OutputEmitterRef<Event>;
  readonly change: import("@angular/core").OutputEmitterRef<Event>;
  readonly keyup: import("@angular/core").OutputEmitterRef<KeyboardEvent>;
  readonly keydown: import("@angular/core").OutputEmitterRef<KeyboardEvent>;
  readonly keypress: import("@angular/core").OutputEmitterRef<KeyboardEvent>;
  readonly enter: import("@angular/core").OutputEmitterRef<KeyboardEvent>;
  protected readonly _value: import("@angular/core").WritableSignal<string>;
  protected readonly _disabledByForm: import("@angular/core").WritableSignal<boolean>;
  protected readonly _touched: import("@angular/core").WritableSignal<boolean>;
  protected readonly _isDisabled: import("@angular/core").Signal<boolean>;
  private _onChange;
  private _onTouched;
  protected _handleInput(event: Event): void;
  protected _handleEnter(event: Event): void;
  protected _handleBlur(): void;
  writeValue(value: string | null): void;
  registerOnChange(fn: (value: string) => void): void;
  registerOnTouched(fn: () => void): void;
  setDisabledState(isDisabled: boolean): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<BaseInput, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<BaseInput, never, never, {
    "label": {
      "alias": "label";
      "required": false;
      "isSignal": true;
    };
    "placeholder": {
      "alias": "placeholder";
      "required": false;
      "isSignal": true;
    };
    "disabled": {
      "alias": "disabled";
      "required": false;
      "isSignal": true;
    };
    "id": {
      "alias": "id";
      "required": false;
      "isSignal": true;
    };
    "viewMode": {
      "alias": "viewMode";
      "required": false;
      "isSignal": true;
    };
    "viewValue": {
      "alias": "viewValue";
      "required": false;
      "isSignal": true;
    };
  }, {
    "input": "input";
    "change": "change";
    "keyup": "keyup";
    "keydown": "keydown";
    "keypress": "keypress";
    "enter": "enter";
  }, never, never, true, never>;
}
/**
 * Shared logic for boolean LumenUI controls (`Toggle`, `Checkbox`). Bridges a
 * `checked` state to a boolean `ControlValueAccessor` and exposes the common
 * label/disabled inputs plus `labelPosition`.
 */
export declare abstract class BaseBooleanInput implements ControlValueAccessor {
  readonly label: import("@angular/core").InputSignal<string>;
  readonly disabled: import("@angular/core").InputSignal<boolean>;
  readonly id: import("@angular/core").InputSignal<string>;
  /** Where the label sits relative to the control. */
  readonly labelPosition: import("@angular/core").InputSignal<"top" | "right" | "left">;
  /** Render the state as plain "Yes"/"No" text instead of the control. */
  readonly viewMode: import("@angular/core").InputSignal<boolean>;
  /** Custom text shown in view mode; falls back to "Yes"/"No" when omitted. */
  readonly viewValue: import("@angular/core").InputSignal<string | undefined>;
  readonly change: import("@angular/core").OutputEmitterRef<boolean>;
  protected readonly _checked: import("@angular/core").WritableSignal<boolean>;
  protected readonly _disabledByForm: import("@angular/core").WritableSignal<boolean>;
  protected readonly _touched: import("@angular/core").WritableSignal<boolean>;
  protected readonly _isDisabled: import("@angular/core").Signal<boolean>;
  private _onChange;
  private _onTouched;
  protected _handleChange(event: Event): void;
  protected _handleBlur(): void;
  writeValue(value: boolean | null): void;
  registerOnChange(fn: (value: boolean) => void): void;
  registerOnTouched(fn: () => void): void;
  setDisabledState(isDisabled: boolean): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<BaseBooleanInput, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<BaseBooleanInput, never, never, {
    "label": {
      "alias": "label";
      "required": false;
      "isSignal": true;
    };
    "disabled": {
      "alias": "disabled";
      "required": false;
      "isSignal": true;
    };
    "id": {
      "alias": "id";
      "required": false;
      "isSignal": true;
    };
    "labelPosition": {
      "alias": "labelPosition";
      "required": false;
      "isSignal": true;
    };
    "viewMode": {
      "alias": "viewMode";
      "required": false;
      "isSignal": true;
    };
    "viewValue": {
      "alias": "viewValue";
      "required": false;
      "isSignal": true;
    };
  }, {
    "change": "change";
  }, never, never, true, never>;
}
/** A single selectable option in a radio group. */
export interface RadioOption {
  label: string;
  value: unknown;
  /** Disable just this option while leaving the rest of the group interactive. */
  disabled?: boolean;
}
/**
 * Shared logic for a radio group. Renders one radio per {@link options} entry
 * and bridges the selected option's `value` to a `ControlValueAccessor`.
 */
export declare abstract class BaseRadioInput implements ControlValueAccessor {
  /** Optional group label rendered above the options. */
  readonly label: import("@angular/core").InputSignal<string>;
  readonly options: import("@angular/core").InputSignal<RadioOption[]>;
  /** Native `name` shared across the group so only one option can be selected. */
  readonly name: import("@angular/core").InputSignal<string>;
  readonly disabled: import("@angular/core").InputSignal<boolean>;
  /** Where each option label sits relative to its control. */
  readonly labelPosition: import("@angular/core").InputSignal<"top" | "right" | "left">;
  /** `inline` lays options out in a row (default); `stacked` in a column. */
  readonly orientation: import("@angular/core").InputSignal<"inline" | "stacked">;
  /** Render the selected option's label as plain text instead of the radio group. */
  readonly viewMode: import("@angular/core").InputSignal<boolean>;
  /** Custom text shown in view mode; falls back to the selected option's label when omitted. */
  readonly viewValue: import("@angular/core").InputSignal<string | undefined>;
  readonly change: import("@angular/core").OutputEmitterRef<unknown>;
  protected readonly _value: import("@angular/core").WritableSignal<unknown>;
  protected readonly _disabledByForm: import("@angular/core").WritableSignal<boolean>;
  protected readonly _touched: import("@angular/core").WritableSignal<boolean>;
  protected readonly _isDisabled: import("@angular/core").Signal<boolean>;
  /** The selected option's label — the view-mode fallback text. */
  protected readonly _selectedLabel: import("@angular/core").Signal<string | undefined>;
  protected _isChecked(value: unknown): boolean;
  protected _select(value: unknown): void;
  private _onChange;
  private _onTouched;
  protected _handleBlur(): void;
  writeValue(value: unknown): void;
  registerOnChange(fn: (value: unknown) => void): void;
  registerOnTouched(fn: () => void): void;
  setDisabledState(isDisabled: boolean): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<BaseRadioInput, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<BaseRadioInput, never, never, {
    "label": {
      "alias": "label";
      "required": false;
      "isSignal": true;
    };
    "options": {
      "alias": "options";
      "required": false;
      "isSignal": true;
    };
    "name": {
      "alias": "name";
      "required": false;
      "isSignal": true;
    };
    "disabled": {
      "alias": "disabled";
      "required": false;
      "isSignal": true;
    };
    "labelPosition": {
      "alias": "labelPosition";
      "required": false;
      "isSignal": true;
    };
    "orientation": {
      "alias": "orientation";
      "required": false;
      "isSignal": true;
    };
    "viewMode": {
      "alias": "viewMode";
      "required": false;
      "isSignal": true;
    };
    "viewValue": {
      "alias": "viewValue";
      "required": false;
      "isSignal": true;
    };
  }, {
    "change": "change";
  }, never, never, true, never>;
}
declare namespace form_validation_d_exports {
  export { FormValidation };
}
/**
 * Renders inline validation feedback for a bound form control: a `*` on the
 * label when the control is required, an error state on the field, and a
 * message below it once the control is touched/dirty and invalid.
 *
 * Applied automatically to every LumenUI input via `hostDirectives`, so it sits
 * on the `l-*` host element where the `formControl`/`formControlName`/`ngModel`
 * binding (and therefore the `NgControl`) lives. The DOM lookups fall back to a
 * descendant search so the directive also works when placed directly on a
 * native `input`/`textarea`.
 */
export declare class FormValidation implements OnDestroy {
  /** Set to false to opt a single field out of the inline validation UI. */
  readonly useValidation: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
  private readonly _host;
  private readonly _renderer;
  private readonly _ngControl;
  private _errorEl;
  private _asteriskEl;
  private readonly _destroy$;
  constructor();
  ngOnDestroy(): void;
  private _init;
  private _refresh;
  /** Maps the first matching validator error to a human message. */
  private _messageFor;
  private _isRequired;
  private _query;
  private get _formGroup();
  private get _controlEl();
  private _showError;
  private _removeError;
  private _addAsterisk;
  private _removeAsterisk;
  static ɵfac: i0.ɵɵFactoryDeclaration<FormValidation, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<FormValidation, "    input[formControlName], input[formControl], input[ngModel],    textarea[formControlName], textarea[formControl], textarea[ngModel]  ", never, {
    "useValidation": {
      "alias": "useValidation";
      "required": false;
      "isSignal": true;
    };
  }, {}, never, never, true, never>;
}
export declare class TextInput extends BaseInput {
  protected readonly type = "text";
  static ɵfac: i0.ɵɵFactoryDeclaration<TextInput, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<TextInput, "l-text-input", never, {}, {}, never, never, true, [{
    directive: typeof FormValidation;
    inputs: {
      "useValidation": "useValidation";
    };
    outputs: {};
  }]>;
}
export declare class PasswordInput extends BaseInput {
  /** Show the password-requirements checklist below the field. */
  readonly showRules: import("@angular/core").InputSignal<boolean>;
  protected readonly _visible: import("@angular/core").WritableSignal<boolean>;
  protected get type(): string;
  protected readonly hasMinLength: import("@angular/core").Signal<boolean>;
  protected readonly hasUpperLower: import("@angular/core").Signal<boolean>;
  protected readonly hasSpecialChar: import("@angular/core").Signal<boolean>;
  protected readonly hasNumber: import("@angular/core").Signal<boolean>;
  protected _toggleVisible(): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<PasswordInput, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<PasswordInput, "l-password-input", never, {
    "showRules": {
      "alias": "showRules";
      "required": false;
      "isSignal": true;
    };
  }, {}, never, never, true, [{
    directive: typeof FormValidation;
    inputs: {
      "useValidation": "useValidation";
    };
    outputs: {};
  }]>;
}
export declare class EmailInput extends BaseInput implements Validator {
  protected readonly type = "email";
  /** Inline error: only once the field has been touched and holds an invalid value. */
  protected readonly _invalid: import("@angular/core").Signal<boolean>;
  validate(control: AbstractControl): ValidationErrors | null;
  static ɵfac: i0.ɵɵFactoryDeclaration<EmailInput, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<EmailInput, "l-email-input", never, {}, {}, never, never, true, [{
    directive: typeof FormValidation;
    inputs: {
      "useValidation": "useValidation";
    };
    outputs: {};
  }]>;
}
/**
 * Username field with a user icon — a text input variant. There is no
 * built-in format validator: validate in the consumer (e.g. `Validators.pattern`)
 * and the shared `FormValidation` directive surfaces the message inline.
 */
export declare class UsernameInput extends BaseInput {
  protected readonly type = "text";
  static ɵfac: i0.ɵɵFactoryDeclaration<UsernameInput, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<UsernameInput, "l-username-input", never, {}, {}, never, never, true, [{
    directive: typeof FormValidation;
    inputs: {
      "useValidation": "useValidation";
    };
    outputs: {};
  }]>;
}
/**
 * Numeric field whose form value stays a plain `number`. Non-numeric keystrokes
 * are blocked outright, and an optional `prefix`/`suffix` are shown as static,
 * non-editable adornments that never become part of the value.
 */
export declare class NumberInput implements ControlValueAccessor {
  readonly label: import("@angular/core").InputSignal<string>;
  readonly placeholder: import("@angular/core").InputSignal<string>;
  readonly disabled: import("@angular/core").InputSignal<boolean>;
  readonly id: import("@angular/core").InputSignal<string>;
  /**
   * `0` forbids decimals; a positive number rounds the value to that many
   * places; left unset, any number of decimals is allowed.
   */
  readonly decimalPlaces: import("@angular/core").InputSignal<number | undefined>;
  /** Display-only adornments — they never change the stored value. */
  readonly prefix: import("@angular/core").InputSignal<string>;
  readonly suffix: import("@angular/core").InputSignal<string>;
  /** Allow typing negative numbers. Off by default (the `-` key is blocked). */
  readonly allowNegative: import("@angular/core").InputSignal<boolean>;
  /** Allow a value of `0`. On by default; when off, typing a bare `0` is blocked. */
  readonly allowZero: import("@angular/core").InputSignal<boolean>;
  /** Render the value (with `prefix`/`suffix`) as plain text instead of the input. */
  readonly viewMode: import("@angular/core").InputSignal<boolean>;
  /** Custom text shown in view mode; falls back to the affixed value when omitted. */
  readonly viewValue: import("@angular/core").InputSignal<string | undefined>;
  readonly valueChange: import("@angular/core").OutputEmitterRef<number | null>;
  protected readonly _value: import("@angular/core").WritableSignal<number | null>;
  protected readonly _buffer: import("@angular/core").WritableSignal<string>;
  protected readonly _focused: import("@angular/core").WritableSignal<boolean>;
  protected readonly _disabledByForm: import("@angular/core").WritableSignal<boolean>;
  protected readonly _touched: import("@angular/core").WritableSignal<boolean>;
  protected readonly _isDisabled: import("@angular/core").Signal<boolean>;
  protected readonly _inputMode: import("@angular/core").Signal<"numeric" | "decimal">;
  /** While focused show the editable buffer; otherwise the formatted value. */
  protected readonly _display: import("@angular/core").Signal<string>;
  /** The affixed value shown in view mode. */
  protected readonly _viewText: import("@angular/core").Signal<string>;
  private _onChange;
  private _onTouched;
  protected _handleKeydown(event: KeyboardEvent): void;
  protected _handleFocus(): void;
  protected _handleInput(event: Event): void;
  protected _handleBlur(): void;
  writeValue(value: number | null): void;
  registerOnChange(fn: (value: number | null) => void): void;
  registerOnTouched(fn: () => void): void;
  setDisabledState(isDisabled: boolean): void;
  /** Decides whether a printable key may be inserted at the current caret/selection. */
  private _isKeyAllowed;
  private _commit;
  private _rawString;
  /** Safety net for pasted text — strips anything the keystroke filter would have blocked. */
  private _sanitize;
  private _parse;
  private _round;
  private _format;
  static ɵfac: i0.ɵɵFactoryDeclaration<NumberInput, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<NumberInput, "l-number-input", never, {
    "label": {
      "alias": "label";
      "required": false;
      "isSignal": true;
    };
    "placeholder": {
      "alias": "placeholder";
      "required": false;
      "isSignal": true;
    };
    "disabled": {
      "alias": "disabled";
      "required": false;
      "isSignal": true;
    };
    "id": {
      "alias": "id";
      "required": false;
      "isSignal": true;
    };
    "decimalPlaces": {
      "alias": "decimalPlaces";
      "required": false;
      "isSignal": true;
    };
    "prefix": {
      "alias": "prefix";
      "required": false;
      "isSignal": true;
    };
    "suffix": {
      "alias": "suffix";
      "required": false;
      "isSignal": true;
    };
    "allowNegative": {
      "alias": "allowNegative";
      "required": false;
      "isSignal": true;
    };
    "allowZero": {
      "alias": "allowZero";
      "required": false;
      "isSignal": true;
    };
    "viewMode": {
      "alias": "viewMode";
      "required": false;
      "isSignal": true;
    };
    "viewValue": {
      "alias": "viewValue";
      "required": false;
      "isSignal": true;
    };
  }, {
    "valueChange": "valueChange";
  }, never, never, true, [{
    directive: typeof FormValidation;
    inputs: {
      "useValidation": "useValidation";
    };
    outputs: {};
  }]>;
}
/** A single option after normalization, carrying its flat position in the visible list. */
interface NormalizedOption {
  /** The value patched into the form control when selected. */
  value: unknown;
  /** The text shown in the trigger and dropdown row. */
  label: string;
  disabled: boolean;
  /** Group key (only set when `groupBy` is configured). */
  group: unknown;
  /** Index into the flat, filtered list — drives keyboard navigation. */
  index: number;
}
/**
 * Single-select dropdown inspired by Ant Design. Accepts a plain array of
 * primitives or an array of objects (mapped via `bindValue`/`bindLabel`),
 * supports optional in-place search, grouping, a loading state for async
 * search, and a windowed virtual scroller for large datasets.
 *
 * Bridges the selected value to a `ControlValueAccessor`, so it works with both
 * `[(ngModel)]` and reactive forms.
 */
export declare class Select implements ControlValueAccessor {
  readonly label: import("@angular/core").InputSignal<string>;
  readonly placeholder: import("@angular/core").InputSignal<string>;
  readonly disabled: import("@angular/core").InputSignal<boolean>;
  readonly id: import("@angular/core").InputSignal<string>;
  /** Allow selecting more than one option. The value becomes an array and the trigger shows tags. */
  readonly multiple: import("@angular/core").InputSignal<boolean>;
  /** Cap the number of options that can be selected (multi-select only). Unset → unlimited. */
  readonly maxCount: import("@angular/core").InputSignal<number | undefined>;
  /**
   * How many tags to show before collapsing the rest into a "+N" badge (multi-select only).
   * `'responsive'` (default) fits as many tags as the trigger width allows; a number shows
   * exactly that many.
   */
  readonly maxTagCount: import("@angular/core").InputSignal<number | "responsive">;
  /** Show a clear (×) affix that empties the selection. */
  readonly clearable: import("@angular/core").InputSignal<boolean>;
  /** Options to choose from — primitives (`string[]`/`number[]`) or objects. */
  readonly items: import("@angular/core").InputSignal<readonly unknown[]>;
  /** For object items: the property to use as the patched value. Unset → the whole item. */
  readonly bindValue: import("@angular/core").InputSignal<string | undefined>;
  /** For object items: the property to display. Unset → falls back to the value, then `String(item)`. */
  readonly bindLabel: import("@angular/core").InputSignal<string | undefined>;
  /** For object items: a truthy property that disables that single option. */
  readonly bindDisabled: import("@angular/core").InputSignal<string | undefined>;
  /** For object items: the property to group options by, rendered under sticky headers. */
  readonly groupBy: import("@angular/core").InputSignal<string | undefined>;
  /** Show an in-dropdown search box that filters options by label. */
  readonly searchable: import("@angular/core").InputSignal<boolean>;
  /** Show the chevron affix on the right. */
  readonly showArrow: import("@angular/core").InputSignal<boolean>;
  /** Replace the option list with a spinner — useful while an async `search` is in flight. */
  readonly showLoading: import("@angular/core").InputSignal<boolean>;
  /** Render only the visible window of rows. Best for large, ungrouped lists. */
  readonly virtualScroll: import("@angular/core").InputSignal<boolean>;
  /** Render the selected option label(s) as plain text instead of the select. */
  readonly viewMode: import("@angular/core").InputSignal<boolean>;
  /** Custom text shown in view mode; falls back to the selected option label(s) when omitted. */
  readonly viewValue: import("@angular/core").InputSignal<string | undefined>;
  /** Emits the selected value whenever it changes. */
  readonly change: import("@angular/core").OutputEmitterRef<unknown>;
  /** Emits the search text on every keystroke — wire this to an API call for server-side search. */
  readonly search: import("@angular/core").OutputEmitterRef<string>;
  /** Emits when the option list scrolls near the bottom — append the next page to `items` for paged loading. */
  readonly scrollToEnd: import("@angular/core").OutputEmitterRef<void>;
  protected readonly _open: import("@angular/core").WritableSignal<boolean>;
  protected readonly _searchText: import("@angular/core").WritableSignal<string>;
  protected readonly _activeIndex: import("@angular/core").WritableSignal<number>;
  protected readonly _scrollTop: import("@angular/core").WritableSignal<number>;
  /** Latched once the list scrolls near the bottom so `scrollToEnd` emits once per approach. */
  private _endReached;
  protected readonly _value: import("@angular/core").WritableSignal<unknown>;
  protected readonly _disabledByForm: import("@angular/core").WritableSignal<boolean>;
  protected readonly _touched: import("@angular/core").WritableSignal<boolean>;
  protected readonly _isDisabled: import("@angular/core").Signal<boolean>;
  protected readonly _rowHeight = 36;
  private readonly _host;
  private readonly _dropdown;
  private readonly _trigger;
  private readonly _searchInput;
  private readonly _viewport;
  private readonly _tagsArea;
  private readonly _tagsMeasure;
  /** Number of tags that fit on one line — recomputed on resize / selection change (responsive mode). */
  private readonly _responsiveCount;
  protected readonly _dropUp: import("@angular/core").WritableSignal<boolean>;
  protected readonly _menuLeft: import("@angular/core").WritableSignal<number>;
  protected readonly _menuWidth: import("@angular/core").WritableSignal<number>;
  protected readonly _menuTop: import("@angular/core").WritableSignal<number | null>;
  protected readonly _menuBottom: import("@angular/core").WritableSignal<number | null>;
  /** Max height of the scrollable option list, shrunk to fit the available space. */
  protected readonly _maxListHeight: import("@angular/core").WritableSignal<number>;
  private readonly _onViewportChange;
  private _onChange;
  private _onTouched;
  constructor();
  /** Selected values as a flat array, regardless of single/multi mode. */
  private readonly _selectedArray;
  /** The normalized options currently selected, in selection order — drives the trigger tags. */
  protected readonly _selectedOptions: import("@angular/core").Signal<NormalizedOption[]>;
  protected readonly _isResponsive: import("@angular/core").Signal<boolean>;
  /** How many tags to render before the "+N" badge. */
  private readonly _visibleTagCount;
  protected readonly _shownTags: import("@angular/core").Signal<NormalizedOption[]>;
  protected readonly _overflowCount: import("@angular/core").Signal<number>;
  protected readonly _limitReached: import("@angular/core").Signal<boolean>;
  protected readonly _hasValue: import("@angular/core").Signal<boolean>;
  protected readonly _showClear: import("@angular/core").Signal<boolean>;
  /** Every item normalized, in source order — the source of truth for the selected label. */
  private readonly _all;
  /** Options surviving the current search text, re-indexed to their rendered position. */
  protected readonly _visible: import("@angular/core").Signal<NormalizedOption[]>;
  protected readonly _groups: import("@angular/core").Signal<{
    label: string;
    options: NormalizedOption[];
  }[]>;
  protected readonly _selectedLabel: import("@angular/core").Signal<string>;
  /** The selected option label(s) shown in view mode — comma-separated when multiple. */
  protected readonly _viewText: import("@angular/core").Signal<string>;
  protected readonly _useVirtual: import("@angular/core").Signal<boolean>;
  protected readonly _totalHeight: import("@angular/core").Signal<number>;
  protected readonly _viewportHeight: import("@angular/core").Signal<number>;
  private readonly _startIndex;
  protected readonly _window: import("@angular/core").Signal<NormalizedOption[]>;
  protected readonly _offsetTop: import("@angular/core").Signal<number>;
  protected _toggle(): void;
  protected _onOptionClick(option: NormalizedOption): void;
  protected _setActive(option: NormalizedOption): void;
  /** True when an option can't be picked — disabled at source, or the max-count limit is reached. */
  protected _optionDisabled(option: NormalizedOption): boolean;
  protected _onSearch(event: Event): void;
  protected _onScroll(event: Event): void;
  /** True when the node lives in the trigger host or the body-portaled dropdown. */
  private _isInside;
  protected _onDocumentPointerDown(event: PointerEvent): void;
  protected _onKeydown(event: KeyboardEvent, fromSearch: boolean): void;
  protected _onBlur(event: FocusEvent): void;
  private _openDropdown;
  private _close;
  /**
   * Position the fixed dropdown from the trigger's viewport rect. Anchors below
   * the trigger by default, flips above when there isn't room below, and caps
   * the option list height to the available space.
   */
  private _reposition;
  private _select;
  protected _removeTag(option: NormalizedOption, event: Event): void;
  protected _clear(event: Event): void;
  private _selectActive;
  private _move;
  private _firstSelectable;
  private _measureTags;
  private _scrollActiveIntoView;
  protected _isSelected(value: unknown): boolean;
  private _normalize;
  writeValue(value: unknown): void;
  registerOnChange(fn: (value: unknown) => void): void;
  registerOnTouched(fn: () => void): void;
  setDisabledState(isDisabled: boolean): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<Select, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<Select, "l-select", never, {
    "label": {
      "alias": "label";
      "required": false;
      "isSignal": true;
    };
    "placeholder": {
      "alias": "placeholder";
      "required": false;
      "isSignal": true;
    };
    "disabled": {
      "alias": "disabled";
      "required": false;
      "isSignal": true;
    };
    "id": {
      "alias": "id";
      "required": false;
      "isSignal": true;
    };
    "multiple": {
      "alias": "multiple";
      "required": false;
      "isSignal": true;
    };
    "maxCount": {
      "alias": "maxCount";
      "required": false;
      "isSignal": true;
    };
    "maxTagCount": {
      "alias": "maxTagCount";
      "required": false;
      "isSignal": true;
    };
    "clearable": {
      "alias": "clearable";
      "required": false;
      "isSignal": true;
    };
    "items": {
      "alias": "items";
      "required": false;
      "isSignal": true;
    };
    "bindValue": {
      "alias": "bindValue";
      "required": false;
      "isSignal": true;
    };
    "bindLabel": {
      "alias": "bindLabel";
      "required": false;
      "isSignal": true;
    };
    "bindDisabled": {
      "alias": "bindDisabled";
      "required": false;
      "isSignal": true;
    };
    "groupBy": {
      "alias": "groupBy";
      "required": false;
      "isSignal": true;
    };
    "searchable": {
      "alias": "searchable";
      "required": false;
      "isSignal": true;
    };
    "showArrow": {
      "alias": "showArrow";
      "required": false;
      "isSignal": true;
    };
    "showLoading": {
      "alias": "showLoading";
      "required": false;
      "isSignal": true;
    };
    "virtualScroll": {
      "alias": "virtualScroll";
      "required": false;
      "isSignal": true;
    };
    "viewMode": {
      "alias": "viewMode";
      "required": false;
      "isSignal": true;
    };
    "viewValue": {
      "alias": "viewValue";
      "required": false;
      "isSignal": true;
    };
  }, {
    "change": "change";
    "search": "search";
    "scrollToEnd": "scrollToEnd";
  }, never, never, true, [{
    directive: typeof FormValidation;
    inputs: {
      "useValidation": "useValidation";
    };
    outputs: {};
  }]>;
}
export type CalendarSystem = 'ad' | 'bs';
/** One cell of the 6×7 day grid. */
interface DayCell {
  key: number;
  label: string;
  /** AD date at local midnight — `null` only for cells outside the convertible BS range. */
  date: Date | null;
  aria: string;
  inMonth: boolean;
  today: boolean;
  selected: boolean;
  active: boolean;
  disabled: boolean;
}
interface MonthCell {
  index: number;
  label: string;
  selected: boolean;
}
interface YearCell {
  year: number;
  label: string;
  selected: boolean;
  disabled: boolean;
}
/**
 * Date picker input inspired by Ant Design, with a twist for Nepal: the popup
 * calendar renders in either the Gregorian (AD) or Bikram Sambat (BS) system
 * and carries an AD/BS toggle so users can switch on the fly.
 *
 * The model value is always a JS `Date` (local midnight), regardless of which
 * calendar is displayed — so forms stay calendar-agnostic. Typing is supported
 * (`YYYY-MM-DD`, `YYYY/MM/DD`, `DD-MM-YYYY`, …) and parsed in the active
 * calendar. Bridges to a `ControlValueAccessor`, so it works with both
 * `[(ngModel)]` and reactive forms.
 */
export declare class DateInput implements ControlValueAccessor {
  readonly label: import("@angular/core").InputSignal<string>;
  readonly placeholder: import("@angular/core").InputSignal<string>;
  readonly disabled: import("@angular/core").InputSignal<boolean>;
  readonly id: import("@angular/core").InputSignal<string>;
  /** Calendar system the picker starts in. The popup toggle can switch it later. */
  readonly calendar: import("@angular/core").InputSignal<CalendarSystem>;
  /** Display language for the BS calendar — `np` renders Nepali month names and digits. */
  readonly lang: import("@angular/core").InputSignal<"np" | "en">;
  /** Display format, using the lib's tokens (`YYYY`, `MM`, `DD`, `MMMM`, `dd`, …). */
  readonly format: import("@angular/core").InputSignal<string>;
  /** Show the "Today" shortcut in the popup footer. */
  readonly showToday: import("@angular/core").InputSignal<boolean>;
  /** Open the calendar as soon as the input gains focus (e.g. when tabbing in). */
  readonly openCalendarOnFocus: import("@angular/core").InputSignal<boolean>;
  /** Show the calendar affix icon. */
  readonly showCalendarIcon: import("@angular/core").InputSignal<boolean>;
  /** Allow editing the date by typing. `false` makes the field picker-only (read-only text). */
  readonly typableDateInput: import("@angular/core").InputSignal<boolean>;
  /** Show a clear (×) affix when a date is picked. */
  readonly clearable: import("@angular/core").InputSignal<boolean>;
  /** Earliest selectable date (inclusive). `Date` or anything `new Date()` accepts. */
  readonly min: import("@angular/core").InputSignal<string | Date | null>;
  /** Latest selectable date (inclusive). */
  readonly max: import("@angular/core").InputSignal<string | Date | null>;
  /** Render the formatted date as plain text instead of the picker. */
  readonly viewMode: import("@angular/core").InputSignal<boolean>;
  /** Custom text shown in view mode; falls back to the formatted date when omitted. */
  readonly viewValue: import("@angular/core").InputSignal<string | undefined>;
  /** Emits the picked date (local midnight) or `null` when cleared. */
  readonly change: import("@angular/core").OutputEmitterRef<Date | null>;
  /** Emits when the user flips the AD/BS toggle. */
  readonly calendarChange: import("@angular/core").OutputEmitterRef<CalendarSystem>;
  protected readonly _mode: import("@angular/core").WritableSignal<CalendarSystem>;
  protected readonly _view: import("@angular/core").WritableSignal<"date" | "year" | "month">;
  protected readonly _open: import("@angular/core").WritableSignal<boolean>;
  protected readonly _viewYear: import("@angular/core").WritableSignal<number>;
  protected readonly _viewMonth: import("@angular/core").WritableSignal<number>;
  /** Keyboard-navigation cursor — always an AD date, like the model value. */
  private readonly _activeDate;
  protected readonly _value: import("@angular/core").WritableSignal<Date | null>;
  protected readonly _disabledByForm: import("@angular/core").WritableSignal<boolean>;
  protected readonly _touched: import("@angular/core").WritableSignal<boolean>;
  /** Raw text while the user is typing; `null` means "show the formatted value". */
  protected readonly _typedText: import("@angular/core").WritableSignal<string | null>;
  private readonly _todayTime;
  protected readonly _isDisabled: import("@angular/core").Signal<boolean>;
  protected readonly _dropUp: import("@angular/core").WritableSignal<boolean>;
  protected readonly _panelLeft: import("@angular/core").WritableSignal<number>;
  protected readonly _panelTop: import("@angular/core").WritableSignal<number | null>;
  protected readonly _panelBottom: import("@angular/core").WritableSignal<number | null>;
  private readonly _host;
  private readonly _trigger;
  private readonly _field;
  private readonly _grid;
  private readonly _onViewportChange;
  /** Suppresses `openCalendarOnFocus` when we refocus the field programmatically. */
  private _skipFocusOpen;
  private _onChange;
  private _onTouched;
  constructor();
  private readonly _minTime;
  private readonly _maxTime;
  protected readonly _hasValue: import("@angular/core").Signal<boolean>;
  protected readonly _showClear: import("@angular/core").Signal<boolean>;
  protected readonly _displayValue: import("@angular/core").Signal<string>;
  protected readonly _weekdays: import("@angular/core").Signal<string[]>;
  protected readonly _headerMonthLabel: import("@angular/core").Signal<string>;
  protected readonly _headerYearLabel: import("@angular/core").Signal<string>;
  protected readonly _yearPageStart: import("@angular/core").Signal<number>;
  protected readonly _yearRangeLabel: import("@angular/core").Signal<string>;
  protected readonly _cells: import("@angular/core").Signal<DayCell[]>;
  protected readonly _monthCells: import("@angular/core").Signal<MonthCell[]>;
  protected readonly _yearCells: import("@angular/core").Signal<YearCell[]>;
  protected _onTriggerClick(): void;
  protected _onFocus(): void;
  protected _onTyped(event: Event): void;
  protected _onInputKeydown(event: KeyboardEvent): void;
  protected _onBlur(event: FocusEvent): void;
  protected _onDocumentPointerDown(event: PointerEvent): void;
  protected _clear(event: Event): void;
  protected _prev(): void;
  protected _next(): void;
  protected _superPrev(): void;
  protected _superNext(): void;
  protected _showMonthView(): void;
  protected _showYearView(): void;
  protected _selectMonth(index: number): void;
  protected _selectYear(cell: YearCell): void;
  protected _selectDay(cell: DayCell): void;
  protected _selectToday(): void;
  protected _setMode(mode: CalendarSystem): void;
  protected _onGridKeydown(event: KeyboardEvent): void;
  private _moveActive;
  private _moveActiveMonth;
  private _setActive;
  private _openPanel;
  private _close;
  /** Focus the field without re-triggering `openCalendarOnFocus`. */
  private _refocusField;
  private _reposition;
  private _commitTyped;
  private _setValue;
  /** Point the view at the month containing `date`, in the active calendar system. */
  private _syncView;
  private _shiftMonth;
  private _shiftYear;
  private _yearBounds;
  private _yearLabel;
  private _toBs;
  private _bsToJs;
  private _daysInBsMonth;
  private _boundTime;
  private _outOfRange;
  writeValue(value: Date | string | null): void;
  registerOnChange(fn: (value: Date | null) => void): void;
  registerOnTouched(fn: () => void): void;
  setDisabledState(isDisabled: boolean): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<DateInput, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<DateInput, "l-date-input", never, {
    "label": {
      "alias": "label";
      "required": false;
      "isSignal": true;
    };
    "placeholder": {
      "alias": "placeholder";
      "required": false;
      "isSignal": true;
    };
    "disabled": {
      "alias": "disabled";
      "required": false;
      "isSignal": true;
    };
    "id": {
      "alias": "id";
      "required": false;
      "isSignal": true;
    };
    "calendar": {
      "alias": "calendar";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
    "format": {
      "alias": "format";
      "required": false;
      "isSignal": true;
    };
    "showToday": {
      "alias": "showToday";
      "required": false;
      "isSignal": true;
    };
    "openCalendarOnFocus": {
      "alias": "openCalendarOnFocus";
      "required": false;
      "isSignal": true;
    };
    "showCalendarIcon": {
      "alias": "showCalendarIcon";
      "required": false;
      "isSignal": true;
    };
    "typableDateInput": {
      "alias": "typableDateInput";
      "required": false;
      "isSignal": true;
    };
    "clearable": {
      "alias": "clearable";
      "required": false;
      "isSignal": true;
    };
    "min": {
      "alias": "min";
      "required": false;
      "isSignal": true;
    };
    "max": {
      "alias": "max";
      "required": false;
      "isSignal": true;
    };
    "viewMode": {
      "alias": "viewMode";
      "required": false;
      "isSignal": true;
    };
    "viewValue": {
      "alias": "viewValue";
      "required": false;
      "isSignal": true;
    };
  }, {
    "change": "change";
    "calendarChange": "calendarChange";
  }, never, never, true, [{
    directive: typeof FormValidation;
    inputs: {
      "useValidation": "useValidation";
    };
    outputs: {};
  }]>;
}
export declare class Textarea extends BaseInput {
  protected readonly type = "text";
  /** Visible rows before the field scrolls. */
  readonly rows: import("@angular/core").InputSignal<number>;
  /** Show the drag-to-resize handle (vertical only). Off by default. */
  readonly resizable: import("@angular/core").InputSignal<boolean>;
  static ɵfac: i0.ɵɵFactoryDeclaration<Textarea, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<Textarea, "l-textarea", never, {
    "rows": {
      "alias": "rows";
      "required": false;
      "isSignal": true;
    };
    "resizable": {
      "alias": "resizable";
      "required": false;
      "isSignal": true;
    };
  }, {}, never, never, true, [{
    directive: typeof FormValidation;
    inputs: {
      "useValidation": "useValidation";
    };
    outputs: {};
  }]>;
}
export declare class Toggle extends BaseBooleanInput {
  static ɵfac: i0.ɵɵFactoryDeclaration<Toggle, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<Toggle, "l-toggle", never, {}, {}, never, never, true, [{
    directive: typeof FormValidation;
    inputs: {
      "useValidation": "useValidation";
    };
    outputs: {};
  }]>;
}
export declare class Checkbox extends BaseBooleanInput {
  static ɵfac: i0.ɵɵFactoryDeclaration<Checkbox, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<Checkbox, "l-checkbox", never, {}, {}, never, never, true, [{
    directive: typeof FormValidation;
    inputs: {
      "useValidation": "useValidation";
    };
    outputs: {};
  }]>;
}
export declare class Radio extends BaseRadioInput {
  static ɵfac: i0.ɵɵFactoryDeclaration<Radio, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<Radio, "l-radio", never, {}, {}, never, never, true, [{
    directive: typeof FormValidation;
    inputs: {
      "useValidation": "useValidation";
    };
    outputs: {};
  }]>;
}
type OtpSize = 'sm' | 'md' | 'lg';
/** `number` restricts entry to digits; `text` allows any non-space character. */
type OtpType = 'number' | 'text';
/**
 * OTP / PIN input — a row of single-character boxes for one-time codes and
 * PINs, in the spirit of Ant Design's `Input.OTP` and Mantine's `PinInput`.
 * Typing advances to the next box, Backspace walks back, arrow keys move the
 * caret, and pasting a code distributes it across the boxes. Set `mask` to hide
 * the entered characters (dots) for PIN entry. Bridges to `ControlValueAccessor`
 * so it works with `[(ngModel)]` and reactive forms.
 *
 * ```html
 * <l-otp-input [length]="6" [(ngModel)]="code" (completed)="verify($event)" />
 * <l-otp-input [length]="4" [mask]="true" type="number" />
 * ```
 */
export declare class OtpInput implements ControlValueAccessor {
  /** Number of character boxes. */
  readonly length: import("@angular/core").InputSignal<number>;
  readonly type: import("@angular/core").InputSignal<OtpType>;
  /** Hide the entered characters as dots (PIN mode). */
  readonly mask: import("@angular/core").InputSignal<boolean>;
  readonly size: import("@angular/core").InputSignal<OtpSize>;
  readonly disabled: import("@angular/core").InputSignal<boolean>;
  /** Paint the boxes in the error color. */
  readonly error: import("@angular/core").InputSignal<boolean>;
  /** Focus the first box on render. */
  readonly autoFocus: import("@angular/core").InputSignal<boolean>;
  /** A `-` between every box, e.g. `123-456`. */
  readonly separator: import("@angular/core").InputSignal<boolean>;
  readonly ariaLabel: import("@angular/core").InputSignal<string>;
  readonly name: import("@angular/core").InputSignal<string>;
  /** Emits the full value on every change. */
  readonly change: import("@angular/core").OutputEmitterRef<string>;
  /** Emits once every box is filled. */
  readonly completed: import("@angular/core").OutputEmitterRef<string>;
  protected readonly _chars: import("@angular/core").WritableSignal<string[]>;
  protected readonly _disabledByForm: import("@angular/core").WritableSignal<boolean>;
  protected readonly _isDisabled: import("@angular/core").Signal<boolean>;
  protected readonly _inputType: import("@angular/core").Signal<"text" | "password">;
  protected readonly _inputMode: import("@angular/core").Signal<"text" | "numeric">;
  protected readonly _hostClasses: import("@angular/core").Signal<string>;
  private readonly _cells;
  private _onChange;
  private _onTouched;
  constructor();
  protected _onInput(event: Event, index: number): void;
  protected _onKeydown(event: KeyboardEvent, index: number): void;
  protected _onPaste(event: ClipboardEvent, index: number): void;
  protected _onFocus(event: FocusEvent): void;
  protected _onBlur(): void;
  private _isAllowed;
  private _setChar;
  private _commit;
  private _focus;
  writeValue(value: string | null): void;
  registerOnChange(fn: (value: string) => void): void;
  registerOnTouched(fn: () => void): void;
  setDisabledState(isDisabled: boolean): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<OtpInput, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<OtpInput, "l-otp-input", never, {
    "length": {
      "alias": "length";
      "required": false;
      "isSignal": true;
    };
    "type": {
      "alias": "type";
      "required": false;
      "isSignal": true;
    };
    "mask": {
      "alias": "mask";
      "required": false;
      "isSignal": true;
    };
    "size": {
      "alias": "size";
      "required": false;
      "isSignal": true;
    };
    "disabled": {
      "alias": "disabled";
      "required": false;
      "isSignal": true;
    };
    "error": {
      "alias": "error";
      "required": false;
      "isSignal": true;
    };
    "autoFocus": {
      "alias": "autoFocus";
      "required": false;
      "isSignal": true;
    };
    "separator": {
      "alias": "separator";
      "required": false;
      "isSignal": true;
    };
    "ariaLabel": {
      "alias": "ariaLabel";
      "required": false;
      "isSignal": true;
    };
    "name": {
      "alias": "name";
      "required": false;
      "isSignal": true;
    };
  }, {
    "change": "change";
    "completed": "completed";
  }, never, never, true, never>;
}
type UploadStatus = 'pending' | 'uploading' | 'success' | 'error';
type UploadVariant = 'dropzone' | 'button';
type UploadListType = 'list' | 'grid';
type RejectReason = 'type' | 'size' | 'count';
/** A tracked file in the uploader's list. */
interface UploadFile {
  id: string;
  file: File;
  name: string;
  size: number;
  type: string;
  status: UploadStatus;
  /** 0–100. Drive this from your real upload via {@link FileUpload.patchFile}. */
  progress: number;
  /** Object URL (images) or a remote URL for the thumbnail. */
  url?: string;
  error?: string;
}
/**
 * Image / file upload with a drag-and-drop dropzone (or a compact button
 * trigger), inspired by Ant Design's `Upload`. Validates by `accept`, size and
 * count, shows image thumbnails, and renders a list (rows) or grid (cards) with
 * per-file progress and a remove control.
 *
 * The component is presentational: it manages selection, validation, previews
 * and the list. Wire your real upload by handling `(added)` and reporting
 * progress/outcome back through {@link patchFile}. Selected files are exposed as
 * a two-way `files` model.
 *
 * ```html
 * <l-file-upload accept="image/*" [multiple]="true" [maxSizeMb]="5"
 *                listType="grid" (added)="upload($event)" [(files)]="files" />
 * ```
 */
export declare class FileUpload {
  /** Native `accept` filter, e.g. `image/*` or `.pdf,.docx`. */
  readonly accept: import("@angular/core").InputSignal<string>;
  readonly multiple: import("@angular/core").InputSignal<boolean>;
  /** Reject files larger than this many megabytes (0 = no limit). */
  readonly maxSizeMb: import("@angular/core").InputSignal<number>;
  /** Cap the number of files kept (0 = no limit). */
  readonly maxCount: import("@angular/core").InputSignal<number>;
  readonly disabled: import("@angular/core").InputSignal<boolean>;
  readonly variant: import("@angular/core").InputSignal<UploadVariant>;
  readonly listType: import("@angular/core").InputSignal<UploadListType>;
  /** Primary line inside the dropzone. */
  readonly label: import("@angular/core").InputSignal<string>;
  /** Secondary hint (defaults to a summary of the accept/size limits). */
  readonly hint: import("@angular/core").InputSignal<string>;
  readonly files: import("@angular/core").ModelSignal<UploadFile[]>;
  /** Accepted files, as they are added. Kick off your upload here. */
  readonly added: import("@angular/core").OutputEmitterRef<UploadFile[]>;
  readonly removed: import("@angular/core").OutputEmitterRef<UploadFile>;
  readonly rejected: import("@angular/core").OutputEmitterRef<{
    file: File;
    reason: RejectReason;
  }>;
  private readonly _input;
  private readonly _objectUrls;
  protected readonly _dragging: import("@angular/core").WritableSignal<boolean>;
  protected readonly _hostClasses: import("@angular/core").Signal<string>;
  /** In single-file mode, hide the trigger once a file is chosen (shown again on remove). */
  protected readonly _showTrigger: import("@angular/core").Signal<boolean>;
  protected readonly _resolvedHint: import("@angular/core").Signal<string>;
  constructor();
  protected _browse(): void;
  protected _onInputChange(event: Event): void;
  protected _onDragOver(event: DragEvent): void;
  protected _onDragLeave(event: DragEvent): void;
  protected _onDrop(event: DragEvent): void;
  protected _remove(item: UploadFile, event: Event): void;
  protected _isImage(item: UploadFile): boolean;
  protected _formatSize(bytes: number): string;
  /**
   * Patch a tracked file — call this as your real upload progresses, e.g.
   * `patchFile(id, { status: 'uploading', progress: 40 })`.
   */
  patchFile(id: string, patch: Partial<Omit<UploadFile, 'id' | 'file'>>): void;
  /** Remove every file. */
  clear(): void;
  private _ingest;
  private _toUploadFile;
  private _matchesAccept;
  private _revoke;
  private _revokeAll;
  static ɵfac: i0.ɵɵFactoryDeclaration<FileUpload, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<FileUpload, "l-file-upload", never, {
    "accept": {
      "alias": "accept";
      "required": false;
      "isSignal": true;
    };
    "multiple": {
      "alias": "multiple";
      "required": false;
      "isSignal": true;
    };
    "maxSizeMb": {
      "alias": "maxSizeMb";
      "required": false;
      "isSignal": true;
    };
    "maxCount": {
      "alias": "maxCount";
      "required": false;
      "isSignal": true;
    };
    "disabled": {
      "alias": "disabled";
      "required": false;
      "isSignal": true;
    };
    "variant": {
      "alias": "variant";
      "required": false;
      "isSignal": true;
    };
    "listType": {
      "alias": "listType";
      "required": false;
      "isSignal": true;
    };
    "label": {
      "alias": "label";
      "required": false;
      "isSignal": true;
    };
    "hint": {
      "alias": "hint";
      "required": false;
      "isSignal": true;
    };
    "files": {
      "alias": "files";
      "required": false;
      "isSignal": true;
    };
  }, {
    "files": "filesChange";
    "added": "added";
    "removed": "removed";
    "rejected": "rejected";
  }, never, never, true, never>;
}
/**
 * Pure-CSS entry/leave animations supported by the modal.
 * Each value maps to a `.modal-anim-<name>` class with matching
 * `@keyframes` defined in the modal container styles.
 */
type ModalAnimation = 'slideUp' | 'slideDown' | 'slideLeft' | 'slideRight' | 'fade' | 'zoom' | 'none';
interface ModalConfig<D = any> {
  /** Arbitrary data injected into the component (via MODAL_DATA) or exposed on the template context. */
  data?: D;
  /** Panel width, e.g. '40vw', '500px'. */
  width?: string;
  /** Panel height. */
  height?: string;
  /** Panel max width (defaults to 90vw). */
  maxWidth?: string;
  /** Extra class(es) applied to the panel element. */
  panelClass?: string | string[];
  /** Render the dimmed backdrop behind the panel. Default: true. */
  backdrop?: boolean;
  /** Prevent closing on backdrop click / Escape key. Default: false. */
  disableClose?: boolean;
  /** Entry/leave animation. Default: 'slideUp'. */
  animation?: ModalAnimation;
  /** Animation duration in milliseconds. Default: 250. */
  animationDuration?: number;
}
declare const MODAL_DEFAULTS: Required<Omit<ModalConfig, 'data' | 'width' | 'height' | 'panelClass'>>;
/** Injection token used to read the data passed to a component opened in the modal (like MAT_DIALOG_DATA). */
export declare const MODAL_DATA: InjectionToken<any>;
/**
 * Handle to an opened modal, returned by `ModalService.open()`.
 * Analogous to Angular Material's `MatDialogRef`.
 */
export declare class ModalRef<T = any, R = any> {
  readonly config: ModalConfig;
  /** The instance of the component opened inside the modal (null when a TemplateRef was used). */
  componentInstance: T | null;
  /** @internal Set by ModalService — the container's ComponentRef, used for teardown. */
  _containerRef?: ComponentRef<any>;
  /** @internal Set by the container — kicks off the leave animation. */
  _startClose: () => void;
  private readonly _afterClosed;
  private _result?;
  private _closing;
  constructor(config: ModalConfig);
  /** Begin closing the modal. The result is emitted from `afterClosed()` once the leave animation finishes. */
  close(result?: R): void;
  /** @internal Called by the container once the leave animation has completed. */
  _finishClose(): void;
  /** Emits the result once and completes when the modal has fully closed. */
  afterClosed(): Observable<R | undefined>;
}
/**
 * Material-`MatDialog`-style service for opening modals.
 *
 * Supports both an `<ng-template>` (TemplateRef) and a Component class as content,
 * returns a `ModalRef` handle (close / afterClosed / componentInstance), and plays
 * pure-CSS enter/leave animations selected via `config.animation`.
 */
export declare class ModalService {
  private readonly appRef;
  private readonly injector;
  private readonly envInjector;
  private readonly openModals;
  open<T = any, D = any, R = any>(content: Type<T> | TemplateRef<any>, config?: ModalConfig<D>): ModalRef<T, R>;
  /** Close every open modal. */
  closeAll(): void;
  private dispose;
  private lockBodyScroll;
  static ɵfac: i0.ɵɵFactoryDeclaration<ModalService, never>;
  static ɵprov: i0.ɵɵInjectableDeclaration<any>;
}
interface ConfirmDialogData {
  title?: string;
  message?: string;
  confirmText?: string;
  cancelText?: string;
  /** Variant of the confirm button — `danger` for destructive actions. */
  confirmVariant?: 'primary' | 'danger';
  /**
   * Optional async action run when the user confirms. The dialog shows a
   * loading state while it runs and only closes (with `true`) when it
   * succeeds — on error the dialog stays open so the user can retry.
   * If omitted, confirming simply closes with `true`.
   */
  onConfirm?: () => Observable<unknown>;
}
/**
 * Example of opening a *component* (rather than a template) in the modal.
 * Reads its inputs from {@link MODAL_DATA} and closes itself via the injected
 * {@link ModalRef}, returning `true`/`false` through `afterClosed()`.
 */
export declare class ConfirmDialog {
  readonly ref: ModalRef<ConfirmDialog, boolean>;
  readonly data: ConfirmDialogData;
  protected readonly _loading: import("@angular/core").WritableSignal<boolean>;
  confirm(): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<ConfirmDialog, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<ConfirmDialog, "l-confirm-dialog", never, {}, {}, never, never, true, never>;
}
/**
 * Edge the drawer is anchored to. The position alone determines the
 * enter/leave animation:
 *   left   → slides in to the right  (closes by sliding left)
 *   right  → slides in to the left   (closes by sliding right)
 *   bottom → slides up               (closes by sliding down)
 */
type DrawerPosition = 'left' | 'right' | 'bottom';
interface DrawerConfig<D = any> {
  /** Arbitrary data injected into the component (via DRAWER_DATA) or exposed on the template context. */
  data?: D;
  /** Edge the panel docks to. Default: 'right'. */
  position?: DrawerPosition;
  /**
   * Size of the panel along its sliding axis — the width for left/right
   * drawers, the height for bottom drawers. E.g. '420px', '30vw', '50vh'.
   */
  size?: string;
  /** Extra class(es) applied to the panel element. */
  panelClass?: string | string[];
  /** Render the dimmed backdrop behind the panel. Default: true. */
  backdrop?: boolean;
  /** Prevent closing on backdrop click / Escape key. Default: false. */
  disableClose?: boolean;
  /** Animation duration in milliseconds. Default: 280. */
  animationDuration?: number;
}
declare const DRAWER_DEFAULTS: Required<Omit<DrawerConfig, 'data' | 'size' | 'panelClass'>>;
/** Injection token used to read the data passed to a component opened in the drawer. */
export declare const DRAWER_DATA: InjectionToken<any>;
/**
 * Handle to an opened drawer, returned by `DrawerService.open()`.
 * Mirrors {@link ModalRef} — close / afterClosed / componentInstance.
 */
export declare class DrawerRef<T = any, R = any> {
  readonly config: DrawerConfig;
  /** The instance of the component opened inside the drawer (null when a TemplateRef was used). */
  componentInstance: T | null;
  /** @internal Set by DrawerService — the container's ComponentRef, used for teardown. */
  _containerRef?: ComponentRef<any>;
  /** @internal Set by the container — kicks off the leave animation. */
  _startClose: () => void;
  private readonly _afterClosed;
  private _result?;
  private _closing;
  constructor(config: DrawerConfig);
  /** Begin closing the drawer. The result is emitted from `afterClosed()` once the leave animation finishes. */
  close(result?: R): void;
  /** @internal Called by the container once the leave animation has completed. */
  _finishClose(): void;
  /** Emits the result once and completes when the drawer has fully closed. */
  afterClosed(): Observable<R | undefined>;
}
/**
 * Service for opening edge-anchored drawers (left / right / bottom).
 *
 * Mirrors {@link ModalService}: opens an `<ng-template>` (TemplateRef) or a
 * Component class as content, returns a `DrawerRef` handle (close / afterClosed /
 * componentInstance), and plays pure-CSS slide animations chosen by `position`.
 */
export declare class DrawerService {
  private readonly appRef;
  private readonly injector;
  private readonly envInjector;
  private readonly openDrawers;
  open<T = any, D = any, R = any>(content: Type<T> | TemplateRef<any>, config?: DrawerConfig<D>): DrawerRef<T, R>;
  /** Close every open drawer. */
  closeAll(): void;
  private dispose;
  private lockBodyScroll;
  static ɵfac: i0.ɵɵFactoryDeclaration<DrawerService, never>;
  static ɵprov: i0.ɵɵInjectableDeclaration<any>;
}
/** Handle to a shown notification, returned by `NotificationService.show()`. */
export declare class NotificationRef {
  readonly id: number;
  private readonly _dismiss;
  constructor(id: number, _dismiss: () => void);
  /** Begin dismissing this notification (plays the leave animation). */
  dismiss(): void;
}
type NotificationType = 'success' | 'warn' | 'error' | 'info';
type NotificationPosition = 'top' | 'topLeft' | 'topRight' | 'bottom' | 'bottomLeft' | 'bottomRight';
/** Options accepted by `NotificationService.show()` and the type shortcuts. */
interface NotificationOptions {
  type?: NotificationType;
  title?: string;
  message?: string;
  /** Auto-dismiss delay in ms. `0` keeps it open until dismissed manually. */
  duration?: number;
  position?: NotificationPosition;
  /** Pause the dismiss timer (and progress bar) while hovered. */
  pauseOnHover?: boolean;
  /** Render the shrinking progress bar that tracks the dismiss timer. */
  showProgress?: boolean;
  /** Render the × close button. */
  showClose?: boolean;
  /** Render the leading type icon. */
  withIcon?: boolean;
}
declare const NOTIFICATION_DEFAULTS: Required<Omit<NotificationOptions, 'title' | 'message'>>;
/** Internal record for one live notification, held by the container. */
interface NotificationData extends Required<Omit<NotificationOptions, 'title' | 'message'>> {
  id: number;
  title?: string;
  message?: string;
  /** Drives the leave animation; set true to dismiss. */
  leaving: WritableSignal<boolean>;
}
/**
 * Imperative toast/notification service, in the spirit of `ModalService`.
 *
 * ```ts
 * private notify = inject(NotificationService);
 * this.notify.success('Saved', 'Your changes are live.');
 * this.notify.show({ type: 'error', title: 'Failed', position: 'bottomRight' });
 * ```
 */
export declare class NotificationService {
  private readonly _appRef;
  private readonly _envInjector;
  private _containerRef?;
  private _nextId;
  show(options: NotificationOptions): NotificationRef;
  success(title: string, message?: string, options?: NotificationOptions): NotificationRef;
  error(title: string, message?: string, options?: NotificationOptions): NotificationRef;
  warn(title: string, message?: string, options?: NotificationOptions): NotificationRef;
  info(title: string, message?: string, options?: NotificationOptions): NotificationRef;
  /** Dismiss every open notification. */
  clear(): void;
  private _showTyped;
  private _container;
  static ɵfac: i0.ɵɵFactoryDeclaration<NotificationService, never>;
  static ɵprov: i0.ɵɵInjectableDeclaration<any>;
}
/**
 * A single notification card (toast). Presentational: it renders the type icon,
 * title/message, optional close button and progress bar, and runs its own
 * dismiss timer off the progress animation (so "pause on hover" and the visible
 * bar share one clock). The owning {@link NotificationContainer} adds/removes it.
 */
export declare class Notification {
  readonly type: import("@angular/core").InputSignal<NotificationType>;
  readonly title: import("@angular/core").InputSignal<string | undefined>;
  readonly message: import("@angular/core").InputSignal<string | undefined>;
  readonly position: import("@angular/core").InputSignal<NotificationPosition>;
  readonly duration: import("@angular/core").InputSignal<number>;
  readonly pauseOnHover: import("@angular/core").InputSignal<boolean>;
  readonly showProgress: import("@angular/core").InputSignal<boolean>;
  readonly showClose: import("@angular/core").InputSignal<boolean>;
  readonly withIcon: import("@angular/core").InputSignal<boolean>;
  /** When true, the card plays its leave animation and then emits `closed`. */
  readonly leaving: import("@angular/core").InputSignal<boolean>;
  /** Requests dismissal (close clicked or timer elapsed) — the container drives the leave. */
  readonly requestDismiss: import("@angular/core").OutputEmitterRef<void>;
  /** Fired once the leave animation has finished and the card can be removed. */
  readonly closed: import("@angular/core").OutputEmitterRef<void>;
  protected readonly _hostClasses: import("@angular/core").Signal<string>;
  protected _onProgressEnd(): void;
  protected _onAnimationEnd(event: AnimationEvent): void;
  protected _onClose(): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<Notification, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<Notification, "l-notification", never, {
    "type": {
      "alias": "type";
      "required": false;
      "isSignal": true;
    };
    "title": {
      "alias": "title";
      "required": false;
      "isSignal": true;
    };
    "message": {
      "alias": "message";
      "required": false;
      "isSignal": true;
    };
    "position": {
      "alias": "position";
      "required": false;
      "isSignal": true;
    };
    "duration": {
      "alias": "duration";
      "required": false;
      "isSignal": true;
    };
    "pauseOnHover": {
      "alias": "pauseOnHover";
      "required": false;
      "isSignal": true;
    };
    "showProgress": {
      "alias": "showProgress";
      "required": false;
      "isSignal": true;
    };
    "showClose": {
      "alias": "showClose";
      "required": false;
      "isSignal": true;
    };
    "withIcon": {
      "alias": "withIcon";
      "required": false;
      "isSignal": true;
    };
    "leaving": {
      "alias": "leaving";
      "required": false;
      "isSignal": true;
    };
  }, {
    "requestDismiss": "requestDismiss";
    "closed": "closed";
  }, never, never, true, never>;
}
/** The resolved side the bubble sits on relative to its trigger. */
type TooltipSide = 'top' | 'bottom' | 'left' | 'right';
/**
 * The floating tooltip bubble. This is the presentational piece — it renders the
 * text and the arrow and fades in/out via the `visible` flag. Positioning and
 * trigger wiring live in {@link TooltipDirective}; you normally never place this
 * element yourself, you apply `[lTooltip]` to a target instead.
 */
export declare class Tooltip {
  readonly content: import("@angular/core").InputSignal<string>;
  readonly side: import("@angular/core").InputSignal<TooltipSide>;
  readonly arrow: import("@angular/core").InputSignal<boolean>;
  readonly visible: import("@angular/core").InputSignal<boolean>;
  readonly id: import("@angular/core").InputSignal<string>;
  protected readonly _showArrow: import("@angular/core").Signal<boolean>;
  static ɵfac: i0.ɵɵFactoryDeclaration<Tooltip, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<Tooltip, "l-tooltip", never, {
    "content": {
      "alias": "content";
      "required": false;
      "isSignal": true;
    };
    "side": {
      "alias": "side";
      "required": false;
      "isSignal": true;
    };
    "arrow": {
      "alias": "arrow";
      "required": false;
      "isSignal": true;
    };
    "visible": {
      "alias": "visible";
      "required": false;
      "isSignal": true;
    };
    "id": {
      "alias": "id";
      "required": false;
      "isSignal": true;
    };
  }, {}, never, never, true, never>;
}
/** Ant-style placement names: a side plus optional start/end alignment. */
type TooltipPlacement = 'top' | 'topLeft' | 'topRight' | 'bottom' | 'bottomLeft' | 'bottomRight' | 'left' | 'leftTop' | 'leftBottom' | 'right' | 'rightTop' | 'rightBottom';
type TooltipTrigger = 'hover' | 'focus' | 'click';
/**
 * Attaches an Ant-style tooltip to the host element. Shows on hover + keyboard
 * focus by default; switch with `lTooltipTrigger`. The bubble renders in a fixed
 * layer appended to `<body>`, so it escapes any ancestor `overflow` clipping,
 * flips to the opposite side when it would overflow the viewport, and stays
 * anchored while the page scrolls.
 *
 * ```html
 * <button [lTooltip]="'Delete'" lTooltipPlacement="top">🗑</button>
 * <span [lTooltip]="'Copied to clipboard'" lTooltipTrigger="click">Copy</span>
 * ```
 */
export declare class TooltipDirective {
  /** The tooltip text. An empty string disables the tooltip. */
  readonly lTooltip: import("@angular/core").InputSignal<string>;
  readonly lTooltipPlacement: import("@angular/core").InputSignal<TooltipPlacement>;
  readonly lTooltipTrigger: import("@angular/core").InputSignal<TooltipTrigger>;
  readonly lTooltipDisabled: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
  readonly lTooltipArrow: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
  /** Any CSS color/token for the bubble background (e.g. `var(--error)`). */
  readonly lTooltipColor: import("@angular/core").InputSignal<string>;
  readonly lTooltipMaxWidth: import("@angular/core").InputSignalWithTransform<number | null, unknown>;
  /** Delay before showing, in ms. */
  readonly lTooltipOpenDelay: import("@angular/core").InputSignalWithTransform<number, unknown>;
  /** Delay before hiding, in ms. */
  readonly lTooltipCloseDelay: import("@angular/core").InputSignalWithTransform<number, unknown>;
  private readonly _host;
  private readonly _vcr;
  private readonly _renderer;
  protected readonly _id: string;
  protected _visible: boolean;
  private _ref;
  private _openTimer;
  private _closeTimer;
  private readonly _onViewportChange;
  constructor();
  private get _enabled();
  protected _onEnter(): void;
  protected _onLeave(): void;
  protected _onFocus(): void;
  protected _onBlur(): void;
  protected _onClick(): void;
  protected _onEscape(): void;
  private _scheduleShow;
  private _scheduleHide;
  private _show;
  private _hide;
  private _ensure;
  private _position;
  private _clearTimer;
  private _clearTimers;
  private _unbindViewport;
  static ɵfac: i0.ɵɵFactoryDeclaration<TooltipDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<TooltipDirective, "[lTooltip]", never, {
    "lTooltip": {
      "alias": "lTooltip";
      "required": false;
      "isSignal": true;
    };
    "lTooltipPlacement": {
      "alias": "lTooltipPlacement";
      "required": false;
      "isSignal": true;
    };
    "lTooltipTrigger": {
      "alias": "lTooltipTrigger";
      "required": false;
      "isSignal": true;
    };
    "lTooltipDisabled": {
      "alias": "lTooltipDisabled";
      "required": false;
      "isSignal": true;
    };
    "lTooltipArrow": {
      "alias": "lTooltipArrow";
      "required": false;
      "isSignal": true;
    };
    "lTooltipColor": {
      "alias": "lTooltipColor";
      "required": false;
      "isSignal": true;
    };
    "lTooltipMaxWidth": {
      "alias": "lTooltipMaxWidth";
      "required": false;
      "isSignal": true;
    };
    "lTooltipOpenDelay": {
      "alias": "lTooltipOpenDelay";
      "required": false;
      "isSignal": true;
    };
    "lTooltipCloseDelay": {
      "alias": "lTooltipCloseDelay";
      "required": false;
      "isSignal": true;
    };
  }, {}, never, never, true, never>;
}
/**
 * Full-screen loading overlay driven by {@link SpinnerService}. Place one
 * instance near the app root; call `SpinnerService.show()` / `hide()` from
 * anywhere to toggle it.
 *
 * ```html
 * <l-loading-spinner />
 * ```
 */
export declare class LoadingSpinner {
  private readonly _spinner;
  protected readonly _visible: import("@angular/core").Signal<boolean>;
  static ɵfac: i0.ɵɵFactoryDeclaration<LoadingSpinner, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<LoadingSpinner, "l-loading-spinner", never, {}, {}, never, never, true, never>;
}
/**
 * Drives the global {@link LoadingSpinner} overlay. Inject it anywhere and call
 * `show()`/`hide()` around async work. Calls are reference-counted, so
 * overlapping operations keep the overlay up until the last one finishes:
 *
 * ```ts
 * this._spinner.show();
 * try {
 *   await loadData();
 * } finally {
 *   this._spinner.hide();
 * }
 * ```
 */
export declare class SpinnerService {
  private readonly _pending;
  /** True while at least one caller is showing the spinner. */
  readonly visible: import("@angular/core").Signal<boolean>;
  /** Show the overlay (increments the pending count). */
  show(): void;
  /** Hide one pending request; the overlay stays up until all are cleared. */
  hide(): void;
  /** Force the overlay off regardless of pending count. */
  reset(): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<SpinnerService, never>;
  static ɵprov: i0.ɵɵInjectableDeclaration<any>;
}
/**
 * Placeholder shown while content loads — inspired by Mantine's `Skeleton`.
 *
 * Use it standalone as a sized block (`height`/`width`/`radius`, or `circle`)
 * or wrap real content and toggle `visible`: while `visible` is true an opaque,
 * pulsing overlay covers the projected content; once false the content shows.
 *
 * ```html
 * <l-skeleton height="1rem" width="60%" />
 * <l-skeleton [circle]="true" height="48px" />
 *
 * <l-skeleton [visible]="loading()">
 *   <p>Real content, revealed when loading finishes.</p>
 * </l-skeleton>
 * ```
 */
export declare class Skeleton {
  /** Width as any CSS length, e.g. '100%', '240px'. Ignored when `circle` is set. */
  readonly width: import("@angular/core").InputSignal<string>;
  /** Height as any CSS length. Required for standalone blocks and for `circle`. */
  readonly height: import("@angular/core").InputSignal<string | undefined>;
  /** Corner radius (any CSS length). Overridden to a full circle when `circle` is set. */
  readonly radius: import("@angular/core").InputSignal<string>;
  /** Render a circle: width follows `height` and the radius becomes 50%. */
  readonly circle: import("@angular/core").InputSignal<boolean>;
  /** Play the pulsing animation. Default: true. */
  readonly animate: import("@angular/core").InputSignal<boolean>;
  /** Show the skeleton overlay (true) or reveal the projected content (false). */
  readonly visible: import("@angular/core").InputSignal<boolean>;
  protected readonly _width: import("@angular/core").Signal<string | undefined>;
  protected readonly _radius: import("@angular/core").Signal<string>;
  static ɵfac: i0.ɵɵFactoryDeclaration<Skeleton, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<Skeleton, "l-skeleton", never, {
    "width": {
      "alias": "width";
      "required": false;
      "isSignal": true;
    };
    "height": {
      "alias": "height";
      "required": false;
      "isSignal": true;
    };
    "radius": {
      "alias": "radius";
      "required": false;
      "isSignal": true;
    };
    "circle": {
      "alias": "circle";
      "required": false;
      "isSignal": true;
    };
    "animate": {
      "alias": "animate";
      "required": false;
      "isSignal": true;
    };
    "visible": {
      "alias": "visible";
      "required": false;
      "isSignal": true;
    };
  }, {}, never, ["*"], true, never>;
}
interface BreadcrumbItem {
  /** Visible crumb text. */
  label: string;
  /** Optional router link; omit for the current (last) page. */
  link?: string | unknown[];
}
/**
 * Presentational breadcrumb trail. Pass the crumbs as `items` — the last one is
 * rendered as the current page; earlier ones link via `routerLink` when they
 * carry a `link`.
 *
 * ```html
 * <l-breadcrumb
 *   title="Order #1024"
 *   [items]="[
 *     { label: 'Home', link: '/' },
 *     { label: 'Orders', link: '/orders' },
 *     { label: 'Order #1024' },
 *   ]"
 * />
 * ```
 */
export declare class Breadcrumb {
  /** Optional page title rendered above the trail. */
  readonly title: import("@angular/core").InputSignal<string>;
  /** The crumb trail, in order; the last item is treated as the current page. */
  readonly items: import("@angular/core").InputSignal<readonly BreadcrumbItem[]>;
  static ɵfac: i0.ɵɵFactoryDeclaration<Breadcrumb, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<Breadcrumb, "l-breadcrumb", never, {
    "title": {
      "alias": "title";
      "required": false;
      "isSignal": true;
    };
    "items": {
      "alias": "items";
      "required": false;
      "isSignal": true;
    };
  }, {}, never, never, true, never>;
}
/** Payload emitted whenever the page index or page size changes. */
interface PageEvent {
  pageIndex: number;
  pageSize: number;
  length: number;
}
/**
 * Page navigation with first/prev/next/last controls, a windowed page-number
 * strip, and a page-size dropdown (built on {@link Menu}).
 *
 * ```html
 * <l-pagination [length]="totalRows" [(pageIndex)]="page" (pageChange)="load($event)" />
 * ```
 */
export declare class Pagination {
  readonly pageSizeOptions: import("@angular/core").InputSignal<number[]>;
  readonly length: import("@angular/core").InputSignal<number>;
  readonly pageSize: import("@angular/core").ModelSignal<number>;
  readonly pageIndex: import("@angular/core").ModelSignal<number>;
  readonly pageChange: import("@angular/core").OutputEmitterRef<PageEvent>;
  protected readonly _totalPages: import("@angular/core").Signal<number>;
  /** Digit count of the largest page number — sizes every page button to the widest one. */
  protected readonly _pageNumChars: import("@angular/core").Signal<number>;
  /** A sliding window of up to five page numbers centered on the current page. */
  protected readonly _visiblePages: import("@angular/core").Signal<number[]>;
  protected readonly _itemsInView: import("@angular/core").Signal<number>;
  protected _onChangePageOption(size: number): void;
  protected _onPrevAndNext(direction: 'prev' | 'next'): void;
  protected _goFirstPage(): void;
  protected _goLastPage(): void;
  protected _goToPage(index: number): void;
  private _emitChange;
  static ɵfac: i0.ɵɵFactoryDeclaration<Pagination, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<Pagination, "l-pagination", never, {
    "pageSizeOptions": {
      "alias": "pageSizeOptions";
      "required": false;
      "isSignal": true;
    };
    "length": {
      "alias": "length";
      "required": false;
      "isSignal": true;
    };
    "pageSize": {
      "alias": "pageSize";
      "required": false;
      "isSignal": true;
    };
    "pageIndex": {
      "alias": "pageIndex";
      "required": false;
      "isSignal": true;
    };
  }, {
    "pageSize": "pageSizeChange";
    "pageIndex": "pageIndexChange";
    "pageChange": "pageChange";
  }, never, never, true, never>;
}
/**
 * A single tab inside {@link Tabs}. Carries the strip label (`label`/`icon`) and
 * projects its panel content via `<ng-content>`. The parent tab set owns the
 * active state; this component only shows or hides its panel accordingly.
 */
export declare class Tab implements OnInit, OnDestroy {
  /** Strip label. */
  readonly label: import("@angular/core").InputSignal<string>;
  /** Optional leading glyph/emoji. */
  readonly icon: import("@angular/core").InputSignal<string>;
  /** Explicit value bound to `l-tabs` `value`. Defaults to the tab's index. */
  readonly value: import("@angular/core").InputSignal<unknown>;
  readonly disabled: import("@angular/core").InputSignal<boolean>;
  readonly tabId: string;
  readonly panelId: string;
  private readonly _tabs;
  protected readonly _active: import("@angular/core").Signal<boolean>;
  ngOnInit(): void;
  ngOnDestroy(): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<Tab, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<Tab, "l-tab", never, {
    "label": {
      "alias": "label";
      "required": false;
      "isSignal": true;
    };
    "icon": {
      "alias": "icon";
      "required": false;
      "isSignal": true;
    };
    "value": {
      "alias": "value";
      "required": false;
      "isSignal": true;
    };
    "disabled": {
      "alias": "disabled";
      "required": false;
      "isSignal": true;
    };
  }, {}, never, ["*"], true, never>;
}
type TabsOrientation = 'horizontal' | 'vertical';
type TabsVariant = 'line' | 'pills';
type TabsSize = 'sm' | 'md' | 'lg';
/**
 * Tab set with a sliding active indicator, laid out `horizontal` (default) or
 * `vertical`. Project {@link Tab} children — the container renders the tab strip
 * from their `label`/`icon` and shows the active tab's projected panel:
 *
 * ```html
 * <l-tabs [(value)]="tab" orientation="vertical">
 *   <l-tab label="Profile" icon="👤">…</l-tab>
 *   <l-tab label="Settings" icon="⚙️">…</l-tab>
 *   <l-tab label="Archived" [disabled]="true">…</l-tab>
 * </l-tabs>
 * ```
 *
 * Active state is a two-way `value` model (a tab's `value`, falling back to its
 * index). Follows the WAI-ARIA tabs pattern with roving arrow-key navigation.
 */
export declare class Tabs {
  readonly orientation: import("@angular/core").InputSignal<TabsOrientation>;
  readonly variant: import("@angular/core").InputSignal<TabsVariant>;
  readonly size: import("@angular/core").InputSignal<TabsSize>;
  /** Stretch horizontal tabs to fill the width in equal parts. */
  readonly grow: import("@angular/core").InputSignal<boolean>;
  /** The active tab's `value` (or its index when no `value` was given). */
  readonly value: import("@angular/core").ModelSignal<unknown>;
  readonly activeChange: import("@angular/core").OutputEmitterRef<unknown>;
  private readonly _tabs;
  readonly tabs: import("@angular/core").Signal<Tab[]>;
  private readonly _buttons;
  private readonly _host;
  /** Geometry of the sliding indicator behind/under the active tab. */
  protected readonly _indicator: import("@angular/core").WritableSignal<{
    x: number;
    y: number;
    width: number;
    height: number;
    visible: boolean;
  }>;
  /** Gate the slide transition until after first paint so it never flashes from 0,0. */
  protected readonly _ready: import("@angular/core").WritableSignal<boolean>;
  protected readonly _hostClasses: import("@angular/core").Signal<string>;
  constructor();
  /** @internal Called by a tab on init (in DOM order). */
  _register(tab: Tab): void;
  /** @internal Called by a tab on destroy. */
  _unregister(tab: Tab): void;
  /** @internal A tab's value, falling back to its index when none was given. */
  _valueOf(tab: Tab): unknown;
  isActive(tab: Tab): boolean;
  protected _select(tab: Tab): void;
  protected _onKeydown(event: KeyboardEvent, index: number): void;
  private _nextEnabled;
  private _positionIndicator;
  static ɵfac: i0.ɵɵFactoryDeclaration<Tabs, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<Tabs, "l-tabs", never, {
    "orientation": {
      "alias": "orientation";
      "required": false;
      "isSignal": true;
    };
    "variant": {
      "alias": "variant";
      "required": false;
      "isSignal": true;
    };
    "size": {
      "alias": "size";
      "required": false;
      "isSignal": true;
    };
    "grow": {
      "alias": "grow";
      "required": false;
      "isSignal": true;
    };
    "value": {
      "alias": "value";
      "required": false;
      "isSignal": true;
    };
  }, {
    "value": "valueChange";
    "activeChange": "activeChange";
  }, never, ["*"], true, never>;
}
type StepperOrientation = 'horizontal' | 'vertical';
type StepStatus = 'completed' | 'active' | 'error' | 'upcoming';
/** A single step in an {@link Stepper}. */
interface Step {
  /** Primary label for the step. */
  title: string;
  /** Optional supporting line under the title. */
  description?: string;
  /**
   * Custom glyph/emoji shown in the indicator instead of the step number.
   * Ignored once the step is completed (checkmark) or in error (alert mark).
   */
  icon?: string;
  /** Mark the step invalid — indicator turns the error color with an alert mark. */
  error?: boolean;
  /** Force the step to read as completed regardless of the active index. */
  completed?: boolean;
  /** Disable this step: dimmed and never selectable. */
  disabled?: boolean;
}
/** @internal Resolved per-step view model consumed by the template. */
interface StepView extends Step {
  index: number;
  number: number;
  status: StepStatus;
  selectable: boolean;
}
/**
 * Stepper — a progress indicator for multi-step flows (wizards, checkout, form
 * sequences), styled after Mantine's stepper: the indicator sits inline with a
 * title/description body and connecting rails run between steps.
 *
 * Steps before the active index render a checkmark in the success color; the
 * active step is highlighted; any step flagged `error` (e.g. its form section is
 * invalid) shows an alert mark in the error color. A step's `icon` overrides the
 * number for steps that are neither completed nor in error, otherwise the step
 * number is shown.
 *
 * `active` is a two-way `model`, so drive it from clickable steps (`clickable`)
 * *or* from external Next/Back buttons via `[(active)]`. `allowStepSkip` gates
 * whether the user may click steps that lie ahead of the current one.
 *
 * ```html
 * <l-stepper [steps]="steps" [(active)]="current" [clickable]="true" />
 * <l-stepper [steps]="steps" orientation="vertical" [active]="2" />
 * ```
 */
export declare class Stepper {
  /** The ordered steps to render. */
  readonly steps: import("@angular/core").InputSignal<readonly Step[]>;
  /** Index of the current step. Two-way bindable for click- or button-driven control. */
  readonly active: import("@angular/core").ModelSignal<number>;
  readonly orientation: import("@angular/core").InputSignal<StepperOrientation>;
  /** Show the connecting rails between steps. Steps stay spaced either way. */
  readonly showLines: import("@angular/core").InputSignal<boolean>;
  /** Allow the user to click a step to jump to it. */
  readonly clickable: import("@angular/core").InputSignal<boolean>;
  /** When clickable, also allow selecting steps ahead of the active one (skip forward). */
  readonly allowStepSkip: import("@angular/core").InputSignal<boolean>;
  /** Emits the target index when a step is selected (only fires when it is selectable). */
  readonly stepChange: import("@angular/core").OutputEmitterRef<number>;
  protected readonly _steps: import("@angular/core").Signal<StepView[]>;
  protected readonly _hostClasses: import("@angular/core").Signal<string>;
  private _resolveStatus;
  protected _select(step: StepView): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<Stepper, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<Stepper, "l-stepper", never, {
    "steps": {
      "alias": "steps";
      "required": false;
      "isSignal": true;
    };
    "active": {
      "alias": "active";
      "required": false;
      "isSignal": true;
    };
    "orientation": {
      "alias": "orientation";
      "required": false;
      "isSignal": true;
    };
    "showLines": {
      "alias": "showLines";
      "required": false;
      "isSignal": true;
    };
    "clickable": {
      "alias": "clickable";
      "required": false;
      "isSignal": true;
    };
    "allowStepSkip": {
      "alias": "allowStepSkip";
      "required": false;
      "isSignal": true;
    };
  }, {
    "active": "activeChange";
    "stepChange": "stepChange";
  }, never, never, true, never>;
}
/** A single node in the tree data. Children make it a branch; none makes it a leaf. */
interface TreeNode {
  /** Unique key across the whole tree. */
  key: string;
  label: string;
  children?: TreeNode[];
  /** Optional glyph/emoji shown when `showIcon` is on. */
  icon?: string;
  /** Not selectable and (with `checkable`) its checkbox is skipped by cascade. */
  disabled?: boolean;
  /** Disable just this node's checkbox. */
  disableCheckbox?: boolean;
}
type CheckState = 'checked' | 'indeterminate' | 'unchecked';
/**
 * Tree view with Reddit-style connecting rails, inspired by Ant Design's `Tree`.
 * Data-driven via `nodes`; expand/collapse, selection and (optional) cascading
 * checkboxes are all owned here and read by the recursive {@link TreeItem}
 * renderer. Expanded / checked / selected state is exposed as two-way `model`s so
 * it can be driven from outside, and `expandAll()` / `collapseAll()` are callable
 * via a template ref for external buttons.
 *
 * ```html
 * <l-tree #tree [nodes]="data" [checkable]="true" [(expandedKeys)]="open" />
 * <button (click)="tree.expandAll()">Expand all</button>
 * ```
 */
export declare class Tree {
  readonly nodes: import("@angular/core").InputSignal<readonly TreeNode[]>;
  /** Show a checkbox on every node. */
  readonly checkable: import("@angular/core").InputSignal<boolean>;
  /** Draw the connecting rails between nodes. */
  readonly showLine: import("@angular/core").InputSignal<boolean>;
  /** Render each node's `icon`. */
  readonly showIcon: import("@angular/core").InputSignal<boolean>;
  /** Allow selecting (highlighting) nodes on click. */
  readonly selectable: import("@angular/core").InputSignal<boolean>;
  /** Allow more than one node to be selected. */
  readonly multiple: import("@angular/core").InputSignal<boolean>;
  /** Uncouple parent/child checkboxes (no cascade, no indeterminate). */
  readonly checkStrictly: import("@angular/core").InputSignal<boolean>;
  readonly expandedKeys: import("@angular/core").ModelSignal<string[]>;
  readonly checkedKeys: import("@angular/core").ModelSignal<string[]>;
  readonly selectedKeys: import("@angular/core").ModelSignal<string[]>;
  /** Emits the clicked node (fires even when selection is off/disabled). */
  readonly nodeClick: import("@angular/core").OutputEmitterRef<TreeNode>;
  readonly selectedChange: import("@angular/core").OutputEmitterRef<TreeNode[]>;
  readonly checkedChange: import("@angular/core").OutputEmitterRef<TreeNode[]>;
  readonly expandedChange: import("@angular/core").OutputEmitterRef<{
    node: TreeNode;
    expanded: boolean;
  }>;
  private readonly _expandedSet;
  private readonly _checkedSet;
  private readonly _selectedSet;
  /** key → node and key → parentKey lookups, rebuilt when `nodes` changes. */
  private readonly _index;
  private readonly _branchKeys;
  isExpanded(node: TreeNode): boolean;
  isSelected(node: TreeNode): boolean;
  checkState(node: TreeNode): CheckState;
  toggleExpand(node: TreeNode): void;
  onRowClick(node: TreeNode): void;
  toggleCheck(node: TreeNode): void;
  /** Expand every branch node. Call from an external control. */
  expandAll(): void;
  /** Collapse everything. */
  collapseAll(): void;
  private _hasCheckedDescendant;
  private _setSubtree;
  private _recomputeAncestors;
  static ɵfac: i0.ɵɵFactoryDeclaration<Tree, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<Tree, "l-tree", never, {
    "nodes": {
      "alias": "nodes";
      "required": false;
      "isSignal": true;
    };
    "checkable": {
      "alias": "checkable";
      "required": false;
      "isSignal": true;
    };
    "showLine": {
      "alias": "showLine";
      "required": false;
      "isSignal": true;
    };
    "showIcon": {
      "alias": "showIcon";
      "required": false;
      "isSignal": true;
    };
    "selectable": {
      "alias": "selectable";
      "required": false;
      "isSignal": true;
    };
    "multiple": {
      "alias": "multiple";
      "required": false;
      "isSignal": true;
    };
    "checkStrictly": {
      "alias": "checkStrictly";
      "required": false;
      "isSignal": true;
    };
    "expandedKeys": {
      "alias": "expandedKeys";
      "required": false;
      "isSignal": true;
    };
    "checkedKeys": {
      "alias": "checkedKeys";
      "required": false;
      "isSignal": true;
    };
    "selectedKeys": {
      "alias": "selectedKeys";
      "required": false;
      "isSignal": true;
    };
  }, {
    "expandedKeys": "expandedKeysChange";
    "checkedKeys": "checkedKeysChange";
    "selectedKeys": "selectedKeysChange";
    "nodeClick": "nodeClick";
    "selectedChange": "selectedChange";
    "checkedChange": "checkedChange";
    "expandedChange": "expandedChange";
  }, never, never, true, never>;
}
/**
 * Recursive renderer for one {@link TreeNode} and its subtree. All state lives
 * in the parent {@link Tree}; this component only reflects it and draws the
 * indentation rails. `guides` carries, per ancestor level, whether that level's
 * vertical rail continues past this node — the child rails are derived by
 * appending this node's own "has a following sibling" flag.
 *
 * @internal Consumers use `<l-tree>`, not this element directly.
 */
export declare class TreeItem {
  readonly node: import("@angular/core").InputSignal<TreeNode>;
  /** Ancestor rail-continuation flags; length equals this node's depth. */
  readonly guides: import("@angular/core").InputSignal<readonly boolean[]>;
  readonly isLast: import("@angular/core").InputSignal<boolean>;
  private readonly _tree;
  protected readonly _hasChildren: import("@angular/core").Signal<boolean>;
  protected readonly _expanded: import("@angular/core").Signal<boolean>;
  protected readonly _selected: import("@angular/core").Signal<boolean>;
  protected readonly _checkState: import("@angular/core").Signal<import("@lumen-ui/angular").CheckState>;
  protected readonly _showLine: import("@angular/core").Signal<boolean>;
  protected readonly _checkable: import("@angular/core").Signal<boolean>;
  protected readonly _showIcon: import("@angular/core").Signal<boolean>;
  protected readonly _childGuides: import("@angular/core").Signal<boolean[]>;
  private readonly _mounted;
  protected readonly _renderChildren: import("@angular/core").Signal<boolean>;
  constructor();
  protected _onRow(): void;
  protected _onToggle(event: Event): void;
  protected _onCheck(): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<TreeItem, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<TreeItem, "l-tree-item", never, {
    "node": {
      "alias": "node";
      "required": true;
      "isSignal": true;
    };
    "guides": {
      "alias": "guides";
      "required": false;
      "isSignal": true;
    };
    "isLast": {
      "alias": "isLast";
      "required": false;
      "isSignal": true;
    };
  }, {}, never, never, true, never>;
}
type SortDirection = 'asc' | 'desc';
type TableAlign = 'left' | 'center' | 'right';
interface TableSort {
  key: string;
  direction: SortDirection;
}
interface TableColumn {
  /** Property read from each row (also the sort key). */
  key: string;
  header: string;
  sortable?: boolean;
  align?: TableAlign;
  /** Any CSS width, e.g. `120px` or `20%`. */
  width?: string;
}
/**
 * Data table with column sorting, styled to match the app's `_table.scss`.
 * Feed it `columns` + `data`; cells render `row[column.key]` by default, or a
 * custom `<ng-template lTableCell="key">` when provided.
 *
 * Sorting works two ways, chosen by `serverSort`:
 * - **local** (default) — clicking a sortable header sorts `data` in place.
 * - **server** (`[serverSort]="true"`) — the table only cycles the header state
 *   and emits `(sortChange)`; you refetch and pass the sorted `data` back.
 *
 * Either way `sort` is a two-way `model`, so you can seed or read it. Header
 * clicks cycle ascending → descending → unsorted.
 *
 * ```html
 * <l-table [columns]="cols" [data]="rows" [(sort)]="sort" />
 * <l-table [columns]="cols" [data]="rows" [serverSort]="true"
 *          [loading]="loading()" (sortChange)="fetch($event)" />
 * ```
 */
export declare class Table {
  readonly columns: import("@angular/core").InputSignal<readonly TableColumn[]>;
  readonly data: import("@angular/core").InputSignal<readonly any[]>;
  /** Let the server sort: cycle the header + emit only, never reorder locally. */
  readonly serverSort: import("@angular/core").InputSignal<boolean>;
  readonly sort: import("@angular/core").ModelSignal<TableSort | null>;
  readonly loading: import("@angular/core").InputSignal<boolean>;
  readonly emptyText: import("@angular/core").InputSignal<string>;
  /** Row identity for tracking: a property name or a function. Defaults to index. */
  readonly rowKey: import("@angular/core").InputSignal<string | ((row: any) => unknown) | undefined>;
  readonly rowClick: import("@angular/core").OutputEmitterRef<any>;
  private readonly _cells;
  private readonly _cellMap;
  protected readonly _rows: import("@angular/core").Signal<readonly any[]>;
  protected _cellTemplate(key: string): TemplateRef<unknown> | undefined;
  protected _value(row: any, key: string): unknown;
  protected _sortClass(column: TableColumn): 'asc' | 'desc' | 'none';
  protected _ariaSort(column: TableColumn): 'ascending' | 'descending' | 'none' | null;
  protected _toggleSort(column: TableColumn): void;
  protected _onHeaderKeydown(event: KeyboardEvent, column: TableColumn): void;
  protected readonly _trackRow: (index: number, row: any) => unknown;
  private _compare;
  static ɵfac: i0.ɵɵFactoryDeclaration<Table, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<Table, "l-table", never, {
    "columns": {
      "alias": "columns";
      "required": false;
      "isSignal": true;
    };
    "data": {
      "alias": "data";
      "required": false;
      "isSignal": true;
    };
    "serverSort": {
      "alias": "serverSort";
      "required": false;
      "isSignal": true;
    };
    "sort": {
      "alias": "sort";
      "required": false;
      "isSignal": true;
    };
    "loading": {
      "alias": "loading";
      "required": false;
      "isSignal": true;
    };
    "emptyText": {
      "alias": "emptyText";
      "required": false;
      "isSignal": true;
    };
    "rowKey": {
      "alias": "rowKey";
      "required": false;
      "isSignal": true;
    };
  }, {
    "sort": "sortChange";
    "rowClick": "rowClick";
  }, ["_cells"], never, true, never>;
}
/**
 * Marks an `<ng-template>` as the custom cell renderer for a column. Bind the
 * column `key`; the template context exposes the row (`$implicit`), the cell
 * `value`, the `column`, and the row `index`.
 *
 * ```html
 * <l-table [columns]="cols" [data]="rows">
 *   <ng-template lTableCell="status" let-row let-value="value">
 *     <span class="status" [class]="value">…</span>
 *   </ng-template>
 * </l-table>
 * ```
 */
export declare class TableCellDirective {
  /** The column `key` this template renders. */
  readonly lTableCell: import("@angular/core").InputSignal<string>;
  readonly template: TemplateRef<any>;
  static ɵfac: i0.ɵɵFactoryDeclaration<TableCellDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<TableCellDirective, "ng-template[lTableCell]", never, {
    "lTableCell": {
      "alias": "lTableCell";
      "required": true;
      "isSignal": true;
    };
  }, {}, never, never, true, never>;
}
export type CardVariant = 'default' | 'dark';
export type CardPadding = 'none' | 'sm' | 'md' | 'lg';
export type CardShadow = 'none' | 'sm' | 'md' | 'lg';
/**
 * A surface container for grouping related content — the shared page-section
 * style as a component. Optional header (`title` input, left) with a
 * `[card-extra]` slot on its right, a `[card-footer]` slot below a divider,
 * and `padding`, `shadow`, `bordered` and `hoverable` presentation inputs.
 *
 * ```html
 * <l-card title="Project settings" shadow="sm">
 *   <l-button card-extra variant="ghost" size="sm">Edit</l-button>
 *   Body content.
 *   <span card-footer>Updated 2 days ago</span>
 * </l-card>
 * ```
 */
export declare class Card {
  /** Surface tint — `dark` uses the darker section background. */
  readonly variant: import("@angular/core").InputSignal<CardVariant>;
  /** Inner padding of each region: `none` 0, `sm` 8, `md` 12, `lg` 20 (px). */
  readonly padding: import("@angular/core").InputSignal<CardPadding>;
  /** Drop-shadow strength. */
  readonly shadow: import("@angular/core").InputSignal<CardShadow>;
  /** Show the 1px border around the card. */
  readonly bordered: import("@angular/core").InputSignal<boolean>;
  /** Lift the card and add a shadow on hover — for clickable cards. */
  readonly hoverable: import("@angular/core").InputSignal<boolean>;
  /** Header title, rendered on the left. Adding it (or `[card-extra]` content) shows the header. */
  readonly title: import("@angular/core").InputSignal<string>;
  protected readonly _hostClasses: import("@angular/core").Signal<string>;
  static ɵfac: i0.ɵɵFactoryDeclaration<Card, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<Card, "l-card", never, {
    "variant": {
      "alias": "variant";
      "required": false;
      "isSignal": true;
    };
    "padding": {
      "alias": "padding";
      "required": false;
      "isSignal": true;
    };
    "shadow": {
      "alias": "shadow";
      "required": false;
      "isSignal": true;
    };
    "bordered": {
      "alias": "bordered";
      "required": false;
      "isSignal": true;
    };
    "hoverable": {
      "alias": "hoverable";
      "required": false;
      "isSignal": true;
    };
    "title": {
      "alias": "title";
      "required": false;
      "isSignal": true;
    };
  }, {}, never, ["[card-extra]", "*", "[card-footer]"], true, never>;
}
/**
 * Compact user/entity avatar. Shows `imageUrl` when provided, otherwise falls
 * back to initials derived from `name` on a solid color chip.
 *
 * ```html
 * <l-avatar name="Ada Lovelace" size="40px" />
 * ```
 */
export declare class Avatar {
  /** Image source; when empty, the initials fallback is shown. */
  readonly imageUrl: import("@angular/core").ModelSignal<string | null>;
  /** Full name used to derive the fallback initials. */
  readonly name: import("@angular/core").InputSignal<string>;
  /** Any CSS length, applied to both width and height. */
  readonly size: import("@angular/core").InputSignal<string>;
  /** Background color of the initials chip. */
  readonly color: import("@angular/core").InputSignal<string>;
  /** Text color of the initials chip. */
  readonly textColor: import("@angular/core").InputSignal<string>;
  protected readonly _initials: import("@angular/core").Signal<string>;
  static ɵfac: i0.ɵɵFactoryDeclaration<Avatar, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<Avatar, "l-avatar", never, {
    "imageUrl": {
      "alias": "imageUrl";
      "required": false;
      "isSignal": true;
    };
    "name": {
      "alias": "name";
      "required": false;
      "isSignal": true;
    };
    "size": {
      "alias": "size";
      "required": false;
      "isSignal": true;
    };
    "color": {
      "alias": "color";
      "required": false;
      "isSignal": true;
    };
    "textColor": {
      "alias": "textColor";
      "required": false;
      "isSignal": true;
    };
  }, {
    "imageUrl": "imageUrlChange";
  }, never, never, true, never>;
}
type BadgeSize = 'sm' | 'md' | 'lg';
/**
 * The badge bubble itself — rendered and positioned by {@link BadgeDirective},
 * not used directly in templates. Shows a count (with `overflowCount` → `N+`),
 * hides at zero unless `showZero`, and pops when the count changes if `dynamic`.
 */
export declare class Badge {
  readonly count: import("@angular/core").InputSignal<number | null>;
  /** Any CSS color or token; empty falls back to the default red shade. */
  readonly color: import("@angular/core").InputSignal<string>;
  readonly size: import("@angular/core").InputSignal<BadgeSize>;
  readonly overflowCount: import("@angular/core").InputSignal<number>;
  readonly showZero: import("@angular/core").InputSignal<boolean>;
  /** Play a pop animation whenever the count changes. */
  readonly dynamic: import("@angular/core").InputSignal<boolean>;
  readonly clicked: import("@angular/core").OutputEmitterRef<MouseEvent>;
  protected readonly _pop: import("@angular/core").WritableSignal<boolean>;
  protected readonly _count: import("@angular/core").Signal<number>;
  protected readonly _visible: import("@angular/core").Signal<boolean>;
  protected readonly _display: import("@angular/core").Signal<string>;
  protected readonly _hostClasses: import("@angular/core").Signal<string>;
  constructor();
  protected _onClick(event: MouseEvent): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<Badge, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<Badge, "l-badge", never, {
    "count": {
      "alias": "count";
      "required": false;
      "isSignal": true;
    };
    "color": {
      "alias": "color";
      "required": false;
      "isSignal": true;
    };
    "size": {
      "alias": "size";
      "required": false;
      "isSignal": true;
    };
    "overflowCount": {
      "alias": "overflowCount";
      "required": false;
      "isSignal": true;
    };
    "showZero": {
      "alias": "showZero";
      "required": false;
      "isSignal": true;
    };
    "dynamic": {
      "alias": "dynamic";
      "required": false;
      "isSignal": true;
    };
  }, {
    "clicked": "clicked";
  }, never, never, true, never>;
}
/**
 * Attaches a count badge to the host element — drop it on a button, icon,
 * avatar, or any element that can contain a child and tolerate
 * `position: relative`.
 *
 * ```html
 * <button [lBadge]="unread()" lBadgeColor="var(--accent)" [lBadgeDynamic]="true">
 *   🔔
 * </button>
 * ```
 *
 * The bubble is rendered by an internal {@link Badge} component appended into
 * the host and positioned at its top-right corner. Inputs are prefixed with
 * `lBadge` to avoid clashing with native attributes (e.g. `size`, `color`).
 */
export declare class BadgeDirective {
  /** The count. Hidden at 0 unless `lBadgeShowZero` is set. */
  readonly lBadge: import("@angular/core").InputSignal<number | null>;
  /** Any CSS color or token; defaults to the badge red shade. */
  readonly lBadgeColor: import("@angular/core").InputSignal<string>;
  readonly lBadgeSize: import("@angular/core").InputSignal<BadgeSize>;
  /** Show `N+` once the count passes this. Default 99. */
  readonly lBadgeOverflowCount: import("@angular/core").InputSignalWithTransform<number, unknown>;
  readonly lBadgeShowZero: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
  /** Animate (pop) whenever the count changes. */
  readonly lBadgeDynamic: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
  /** Emits when the badge bubble is clicked (does not trigger the host's click). */
  readonly lBadgeClick: import("@angular/core").OutputEmitterRef<MouseEvent>;
  private readonly _host;
  private readonly _vcr;
  private readonly _renderer;
  private readonly _ref;
  constructor();
  static ɵfac: i0.ɵɵFactoryDeclaration<BadgeDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<BadgeDirective, "[lBadge]", never, {
    "lBadge": {
      "alias": "lBadge";
      "required": false;
      "isSignal": true;
    };
    "lBadgeColor": {
      "alias": "lBadgeColor";
      "required": false;
      "isSignal": true;
    };
    "lBadgeSize": {
      "alias": "lBadgeSize";
      "required": false;
      "isSignal": true;
    };
    "lBadgeOverflowCount": {
      "alias": "lBadgeOverflowCount";
      "required": false;
      "isSignal": true;
    };
    "lBadgeShowZero": {
      "alias": "lBadgeShowZero";
      "required": false;
      "isSignal": true;
    };
    "lBadgeDynamic": {
      "alias": "lBadgeDynamic";
      "required": false;
      "isSignal": true;
    };
  }, {
    "lBadgeClick": "lBadgeClick";
  }, never, never, true, never>;
}
type ChipVariant = 'default' | 'primary' | 'success' | 'error' | 'warn' | 'info' | 'premium';
type ChipSize = 'sm' | 'md' | 'lg';
/**
 * Pill-shaped label for statuses, tags and filters. Tinted per `variant`, with
 * an optional leading status `dot` and an optional remove button (`removable`
 * + `(removed)`) for dismissible tags.
 *
 * ```html
 * <l-chip variant="success" [dot]="true">Active</l-chip>
 * <l-chip [removable]="true" (removed)="onRemove()">Angular</l-chip>
 * ```
 */
export declare class Chip {
  readonly variant: import("@angular/core").InputSignal<ChipVariant>;
  readonly size: import("@angular/core").InputSignal<ChipSize>;
  /** Show a leading dot in the variant color. */
  readonly dot: import("@angular/core").InputSignal<boolean>;
  /** Show a remove button; pressing it emits `removed`. */
  readonly removable: import("@angular/core").InputSignal<boolean>;
  /** Accessible label for the remove button. */
  readonly removeLabel: import("@angular/core").InputSignal<string>;
  readonly removed: import("@angular/core").OutputEmitterRef<void>;
  protected readonly _hostClasses: import("@angular/core").Signal<string>;
  static ɵfac: i0.ɵɵFactoryDeclaration<Chip, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<Chip, "l-chip", never, {
    "variant": {
      "alias": "variant";
      "required": false;
      "isSignal": true;
    };
    "size": {
      "alias": "size";
      "required": false;
      "isSignal": true;
    };
    "dot": {
      "alias": "dot";
      "required": false;
      "isSignal": true;
    };
    "removable": {
      "alias": "removable";
      "required": false;
      "isSignal": true;
    };
    "removeLabel": {
      "alias": "removeLabel";
      "required": false;
      "isSignal": true;
    };
  }, {
    "removed": "removed";
  }, never, ["*"], true, never>;
}
/**
 * A single collapsible section inside an {@link Accordion}. Renders a header
 * button and a panel whose content is projected via `<ng-content>`. Open state
 * is owned by the parent accordion; this component only reflects it.
 */
export declare class AccordionItem implements OnInit, OnDestroy {
  /** Header text. For richer headers, project content into the `title` slot instead. */
  readonly title: import("@angular/core").InputSignal<string>;
  /** Disable toggling; the header is skipped by keyboard navigation. */
  readonly disabled: import("@angular/core").InputSignal<boolean>;
  /** Whether this item starts open (applied once, when it registers with the accordion). */
  readonly expanded: import("@angular/core").InputSignal<boolean>;
  readonly id: import("@angular/core").InputSignal<string>;
  /** Emits the new open state whenever this item expands or collapses. */
  readonly openedChange: import("@angular/core").OutputEmitterRef<boolean>;
  private readonly _accordion;
  private readonly _header;
  protected readonly _open: import("@angular/core").Signal<boolean>;
  protected readonly _iconPosition: import("@angular/core").Signal<"right" | "left">;
  protected readonly _hostClasses: import("@angular/core").Signal<string>;
  private _emitted;
  constructor();
  ngOnInit(): void;
  ngOnDestroy(): void;
  protected _toggle(): void;
  protected _onKeydown(event: KeyboardEvent): void;
  /** @internal Called by the parent accordion for roving focus. */
  _focusHeader(): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<AccordionItem, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<AccordionItem, "l-accordion-item", never, {
    "title": {
      "alias": "title";
      "required": false;
      "isSignal": true;
    };
    "disabled": {
      "alias": "disabled";
      "required": false;
      "isSignal": true;
    };
    "expanded": {
      "alias": "expanded";
      "required": false;
      "isSignal": true;
    };
    "id": {
      "alias": "id";
      "required": false;
      "isSignal": true;
    };
  }, {
    "openedChange": "openedChange";
  }, never, ["[slot=title]", "*"], true, never>;
}
type AccordionVariant = 'contained' | 'separated';
/**
 * Container for a stack of collapsible {@link AccordionItem}s. Owns the open
 * state — `multiple` decides whether several panels can stay open at once or
 * opening one collapses the rest — and the roving-focus keyboard navigation
 * across the item headers.
 *
 * ```html
 * <l-accordion [multiple]="true">
 *   <l-accordion-item title="Section one">…</l-accordion-item>
 *   <l-accordion-item title="Section two">…</l-accordion-item>
 * </l-accordion>
 * ```
 */
export declare class Accordion {
  /** Allow more than one panel to be open simultaneously. Default: single-open. */
  readonly multiple: import("@angular/core").InputSignal<boolean>;
  /** `contained` (one bordered list with dividers) or `separated` (spaced cards). */
  readonly variant: import("@angular/core").InputSignal<AccordionVariant>;
  /** Which side the chevron sits on. Default: 'right'. */
  readonly iconPosition: import("@angular/core").InputSignal<"right" | "left">;
  private readonly _items;
  private readonly _open;
  protected readonly _hostClasses: import("@angular/core").Signal<string>;
  /** @internal Called by an item on init (in DOM order). */
  _register(item: AccordionItem): void;
  /** @internal Called by an item on destroy. */
  _unregister(item: AccordionItem): void;
  /** @internal Reactive read used by an item to know whether it is open. */
  _isOpen(item: AccordionItem): boolean;
  /** @internal Toggle an item, honoring single/multiple mode. */
  _toggle(item: AccordionItem): void;
  /** @internal Roving focus across enabled headers (Arrow/Home/End). */
  _moveFocus(from: AccordionItem, key: string): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<Accordion, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<Accordion, "l-accordion", never, {
    "multiple": {
      "alias": "multiple";
      "required": false;
      "isSignal": true;
    };
    "variant": {
      "alias": "variant";
      "required": false;
      "isSignal": true;
    };
    "iconPosition": {
      "alias": "iconPosition";
      "required": false;
      "isSignal": true;
    };
  }, {}, never, ["*"], true, never>;
}
/** A single configurable filter field. */
interface FilterColumn {
  /** Field label shown above the control and in the active-filter chip. */
  name: string;
  /** The field key reported back in {@link FilterChange.field}. */
  formcontrolName: string;
  type: 'text' | 'select';
  /** Current value; bound two-way to the field control. */
  value?: string | number | null;
  /** Options for `select` fields (id ↔ value, name ↔ label); may carry extra keys for `groupBy`. */
  data?: readonly ({
    id: string | number;
    name: string;
  } & Record<string, unknown>)[];
  /** Optional `select` grouping key (a property on each option). */
  groupBy?: string;
}
/** One entry of the emitted, applied filter set. */
interface FilterChange {
  field: string;
  value: string;
  displayValue: string;
}
/** Internal representation of an applied filter (column or free-text search). */
interface ActiveFilter {
  filterName?: string;
  formcontrolName: string;
  displayValue: string;
  value: string | number | null | undefined;
  type?: 'search';
}
/**
 * Toolbar that combines a free-text search box with a dropdown of configurable
 * field filters (text / single-select). Applied filters surface as removable
 * chips, and the whole set is emitted via `filterChange`.
 *
 * ```html
 * <l-filter
 *   searchBy="name"
 *   [filterColumns]="columns"
 *   (filterChange)="onFilters($event)"
 * />
 * ```
 */
export declare class Filter {
  /** Fields rendered inside the filter dropdown. */
  readonly filterColumns: import("@angular/core").InputSignal<FilterColumn[]>;
  /** Field key for the free-text search box; empty hides the search box. */
  readonly searchBy: import("@angular/core").InputSignal<string>;
  /** Emits the full set of applied filters whenever it changes. */
  readonly filterChange: import("@angular/core").OutputEmitterRef<FilterChange[]>;
  private readonly _filterDropdown;
  protected readonly _filterList: import("@angular/core").WritableSignal<ActiveFilter[]>;
  protected readonly _searchText: import("@angular/core").WritableSignal<string>;
  protected _applyFilter(): void;
  protected _onSearch(): void;
  protected _removeFilter(filter: ActiveFilter): void;
  protected _removeAllFilter(): void;
  protected _closeDropdown(): void;
  private _emitFilterList;
  static ɵfac: i0.ɵɵFactoryDeclaration<Filter, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<Filter, "l-filter", never, {
    "filterColumns": {
      "alias": "filterColumns";
      "required": false;
      "isSignal": true;
    };
    "searchBy": {
      "alias": "searchBy";
      "required": false;
      "isSignal": true;
    };
  }, {
    "filterChange": "filterChange";
  }, never, never, true, never>;
}
/** Preset (`xs` 4px, `sm` 8px, `md` 16px, `lg` 24px, `xl` 32px), a pixel number, or any CSS size. */
export type BoxSpacing = 'xs' | 'sm' | 'md' | 'lg' | 'xl' | number | string;
/** A pixel number or any CSS size value (`'50%'`, `'20rem'`, …). */
export type BoxSize = number | string;
/**
 * Base building block inspired by Mantine's `Box` — a block element with style
 * props for spacing, size and color, so one-off layout tweaks don't need a
 * stylesheet. Spacing props accept the preset scale (`xs` 4px … `xl` 32px), a
 * pixel number, or any CSS value; explicit sides win over the `mx`/`my`/`px`/`py`
 * pairs, which win over `m`/`p`.
 *
 * Also usable as an attribute on any element — the LumenUI equivalent of
 * Mantine's `component` prop — so the box can render as a link, button, etc.
 *
 * ```html
 * <l-box p="md" bg="var(--accent-bg)" c="var(--accent-dark)">Highlighted</l-box>
 * <a l-box href="/docs" p="sm">Link box</a>
 * ```
 */
export declare class Box {
  /** Margin on all sides. */
  readonly m: import("@angular/core").InputSignal<BoxSpacing | undefined>;
  /** Horizontal margin (left + right). */
  readonly mx: import("@angular/core").InputSignal<BoxSpacing | undefined>;
  /** Vertical margin (top + bottom). */
  readonly my: import("@angular/core").InputSignal<BoxSpacing | undefined>;
  readonly mt: import("@angular/core").InputSignal<BoxSpacing | undefined>;
  readonly mb: import("@angular/core").InputSignal<BoxSpacing | undefined>;
  readonly ml: import("@angular/core").InputSignal<BoxSpacing | undefined>;
  readonly mr: import("@angular/core").InputSignal<BoxSpacing | undefined>;
  /** Padding on all sides. */
  readonly p: import("@angular/core").InputSignal<BoxSpacing | undefined>;
  /** Horizontal padding (left + right). */
  readonly px: import("@angular/core").InputSignal<BoxSpacing | undefined>;
  /** Vertical padding (top + bottom). */
  readonly py: import("@angular/core").InputSignal<BoxSpacing | undefined>;
  readonly pt: import("@angular/core").InputSignal<BoxSpacing | undefined>;
  readonly pb: import("@angular/core").InputSignal<BoxSpacing | undefined>;
  readonly pl: import("@angular/core").InputSignal<BoxSpacing | undefined>;
  readonly pr: import("@angular/core").InputSignal<BoxSpacing | undefined>;
  /** Width. */
  readonly w: import("@angular/core").InputSignal<BoxSize | undefined>;
  /** Min-width. */
  readonly miw: import("@angular/core").InputSignal<BoxSize | undefined>;
  /** Max-width. */
  readonly maw: import("@angular/core").InputSignal<BoxSize | undefined>;
  /** Height. */
  readonly h: import("@angular/core").InputSignal<BoxSize | undefined>;
  /** Min-height. */
  readonly mih: import("@angular/core").InputSignal<BoxSize | undefined>;
  /** Max-height. */
  readonly mah: import("@angular/core").InputSignal<BoxSize | undefined>;
  /** Background — any CSS color, including tokens like `var(--accent-bg)`. */
  readonly bg: import("@angular/core").InputSignal<string | undefined>;
  /** Text color — any CSS color, including tokens like `var(--accent-dark)`. */
  readonly c: import("@angular/core").InputSignal<string | undefined>;
  /** `<l-box>` itself renders as a block (like a div); attribute usage keeps the host's own display. */
  protected readonly _display: string | null;
  protected readonly _marginTop: import("@angular/core").Signal<string | null>;
  protected readonly _marginBottom: import("@angular/core").Signal<string | null>;
  protected readonly _marginLeft: import("@angular/core").Signal<string | null>;
  protected readonly _marginRight: import("@angular/core").Signal<string | null>;
  protected readonly _paddingTop: import("@angular/core").Signal<string | null>;
  protected readonly _paddingBottom: import("@angular/core").Signal<string | null>;
  protected readonly _paddingLeft: import("@angular/core").Signal<string | null>;
  protected readonly _paddingRight: import("@angular/core").Signal<string | null>;
  protected readonly _width: import("@angular/core").Signal<string | null>;
  protected readonly _minWidth: import("@angular/core").Signal<string | null>;
  protected readonly _maxWidth: import("@angular/core").Signal<string | null>;
  protected readonly _height: import("@angular/core").Signal<string | null>;
  protected readonly _minHeight: import("@angular/core").Signal<string | null>;
  protected readonly _maxHeight: import("@angular/core").Signal<string | null>;
  static ɵfac: i0.ɵɵFactoryDeclaration<Box, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<Box, "l-box, [l-box]", never, {
    "m": {
      "alias": "m";
      "required": false;
      "isSignal": true;
    };
    "mx": {
      "alias": "mx";
      "required": false;
      "isSignal": true;
    };
    "my": {
      "alias": "my";
      "required": false;
      "isSignal": true;
    };
    "mt": {
      "alias": "mt";
      "required": false;
      "isSignal": true;
    };
    "mb": {
      "alias": "mb";
      "required": false;
      "isSignal": true;
    };
    "ml": {
      "alias": "ml";
      "required": false;
      "isSignal": true;
    };
    "mr": {
      "alias": "mr";
      "required": false;
      "isSignal": true;
    };
    "p": {
      "alias": "p";
      "required": false;
      "isSignal": true;
    };
    "px": {
      "alias": "px";
      "required": false;
      "isSignal": true;
    };
    "py": {
      "alias": "py";
      "required": false;
      "isSignal": true;
    };
    "pt": {
      "alias": "pt";
      "required": false;
      "isSignal": true;
    };
    "pb": {
      "alias": "pb";
      "required": false;
      "isSignal": true;
    };
    "pl": {
      "alias": "pl";
      "required": false;
      "isSignal": true;
    };
    "pr": {
      "alias": "pr";
      "required": false;
      "isSignal": true;
    };
    "w": {
      "alias": "w";
      "required": false;
      "isSignal": true;
    };
    "miw": {
      "alias": "miw";
      "required": false;
      "isSignal": true;
    };
    "maw": {
      "alias": "maw";
      "required": false;
      "isSignal": true;
    };
    "h": {
      "alias": "h";
      "required": false;
      "isSignal": true;
    };
    "mih": {
      "alias": "mih";
      "required": false;
      "isSignal": true;
    };
    "mah": {
      "alias": "mah";
      "required": false;
      "isSignal": true;
    };
    "bg": {
      "alias": "bg";
      "required": false;
      "isSignal": true;
    };
    "c": {
      "alias": "c";
      "required": false;
      "isSignal": true;
    };
  }, {}, never, ["*"], true, never>;
}
export type FlexJustify = 'normal' | 'start' | 'end' | 'center' | 'space-between' | 'space-around' | 'space-evenly';
export type FlexAlign = 'normal' | 'start' | 'end' | 'center' | 'stretch' | 'baseline';
export type FlexWrap = boolean | 'nowrap' | 'wrap' | 'wrap-reverse';
/** Preset (`small` 8px, `middle` 16px, `large` 24px), a pixel number, or any CSS gap value. */
export type FlexGap = 'small' | 'middle' | 'large' | number | string;
/**
 * Flexbox container inspired by Ant Design's `Flex`. A thin, style-only wrapper —
 * all layout is applied to the host element, so children flow exactly as written.
 *
 * ```html
 * <l-flex gap="middle" justify="space-between" align="center">…</l-flex>
 * <l-flex [vertical]="true" gap="small">…</l-flex>
 * ```
 */
export declare class Flex {
  /** Lay children out as a column instead of a row. */
  readonly vertical: import("@angular/core").InputSignal<boolean>;
  readonly justify: import("@angular/core").InputSignal<FlexJustify>;
  readonly align: import("@angular/core").InputSignal<FlexAlign>;
  /** `true`/`false`, or any CSS `flex-wrap` keyword. */
  readonly wrap: import("@angular/core").InputSignal<FlexWrap>;
  readonly gap: import("@angular/core").InputSignal<FlexGap>;
  protected readonly _wrapStyle: import("@angular/core").Signal<"nowrap" | "wrap" | "wrap-reverse">;
  protected readonly _justifyStyle: import("@angular/core").Signal<string | null>;
  protected readonly _alignStyle: import("@angular/core").Signal<string | null>;
  protected readonly _gapStyle: import("@angular/core").Signal<string | null>;
  static ɵfac: i0.ɵɵFactoryDeclaration<Flex, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<Flex, "l-flex", never, {
    "vertical": {
      "alias": "vertical";
      "required": false;
      "isSignal": true;
    };
    "justify": {
      "alias": "justify";
      "required": false;
      "isSignal": true;
    };
    "align": {
      "alias": "align";
      "required": false;
      "isSignal": true;
    };
    "wrap": {
      "alias": "wrap";
      "required": false;
      "isSignal": true;
    };
    "gap": {
      "alias": "gap";
      "required": false;
      "isSignal": true;
    };
  }, {}, never, ["*"], true, never>;
}
export type GridBreakpoint = 'xs' | 'sm' | 'md' | 'lg' | 'xl' | 'xxl';
/** Per-breakpoint column settings; a bare number is shorthand for `{ span }`. */
export interface ColSize {
  span?: number;
  offset?: number;
  order?: number;
}
export type ColResponsive = number | ColSize;
export type RowJustify = 'start' | 'end' | 'center' | 'space-between' | 'space-around' | 'space-evenly';
export type RowAlign = 'top' | 'middle' | 'bottom' | 'stretch';
/**
 * Tracks the viewport width as a signal so `l-col` responsive props re-evaluate
 * on resize. Root-scoped — the listener lives for the app's lifetime.
 */
export declare class GridBreakpoints {
  private readonly _width;
  /** Active breakpoints, smallest first — later entries override earlier ones (mobile-first). */
  readonly active: import("@angular/core").Signal<GridBreakpoint[]>;
  constructor();
  static ɵfac: i0.ɵɵFactoryDeclaration<GridBreakpoints, never>;
  static ɵprov: i0.ɵɵInjectableDeclaration<any>;
}
/**
 * 12-column grid row, Bootstrap-style. Hosts `l-col` children and hands them
 * the horizontal `gutter` (cols pad themselves; the row cancels the outer
 * padding with negative margins). A `[h, v]` gutter adds vertical space
 * between wrapped lines via `row-gap`.
 *
 * ```html
 * <l-row [gutter]="[16, 16]" justify="center" align="middle">
 *   <l-col [span]="6" [md]="4">…</l-col>
 * </l-row>
 * ```
 */
export declare class Row {
  /** Spacing between columns (px). A `[horizontal, vertical]` pair also spaces wrapped lines. */
  readonly gutter: import("@angular/core").InputSignal<number | [number, number]>;
  readonly justify: import("@angular/core").InputSignal<RowJustify>;
  readonly align: import("@angular/core").InputSignal<RowAlign>;
  readonly wrap: import("@angular/core").InputSignal<boolean>;
  /** Horizontal gutter — read by child `l-col`s to pad themselves. */
  readonly gutterX: import("@angular/core").Signal<number>;
  readonly gutterY: import("@angular/core").Signal<number>;
  protected readonly _justifyStyle: import("@angular/core").Signal<string>;
  protected readonly _alignStyle: import("@angular/core").Signal<string>;
  protected readonly _gutterMargin: import("@angular/core").Signal<number | null>;
  static ɵfac: i0.ɵɵFactoryDeclaration<Row, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<Row, "l-row", never, {
    "gutter": {
      "alias": "gutter";
      "required": false;
      "isSignal": true;
    };
    "justify": {
      "alias": "justify";
      "required": false;
      "isSignal": true;
    };
    "align": {
      "alias": "align";
      "required": false;
      "isSignal": true;
    };
    "wrap": {
      "alias": "wrap";
      "required": false;
      "isSignal": true;
    };
  }, {}, never, ["*"], true, never>;
}
/**
 * Grid column for `l-row`, on a 12-column track. `span`/`offset`/`order` are the
 * base values; the `xs`…`xxl` inputs override them per breakpoint, mobile-first
 * (the largest matching breakpoint wins). `span: 0` hides the column. `flex`
 * takes precedence over `span` for fill/fixed-width columns.
 */
export declare class Col {
  /** Columns to span out of 12. `0` hides the column. Unset → sized by content (or `flex`). */
  readonly span: import("@angular/core").InputSignal<number | null>;
  /** Columns to skip on the left, out of 12. */
  readonly offset: import("@angular/core").InputSignal<number>;
  readonly order: import("@angular/core").InputSignal<number | null>;
  /** CSS `flex` shorthand — `'auto'` (fill), a grow number, or e.g. `'0 0 200px'`. */
  readonly flex: import("@angular/core").InputSignal<string | number | null>;
  readonly xs: import("@angular/core").InputSignal<ColResponsive | null>;
  readonly sm: import("@angular/core").InputSignal<ColResponsive | null>;
  readonly md: import("@angular/core").InputSignal<ColResponsive | null>;
  readonly lg: import("@angular/core").InputSignal<ColResponsive | null>;
  readonly xl: import("@angular/core").InputSignal<ColResponsive | null>;
  readonly xxl: import("@angular/core").InputSignal<ColResponsive | null>;
  private readonly _row;
  private readonly _breakpoints;
  private readonly _byBreakpoint;
  /** Base size merged with every active breakpoint override, smallest first. */
  private readonly _size;
  protected readonly _hidden: import("@angular/core").Signal<boolean>;
  protected readonly _flexStyle: import("@angular/core").Signal<string | null>;
  protected readonly _maxWidthStyle: import("@angular/core").Signal<string | null>;
  protected readonly _offsetStyle: import("@angular/core").Signal<string | null>;
  protected readonly _orderStyle: import("@angular/core").Signal<number | null>;
  protected readonly _gutterPad: import("@angular/core").Signal<number | null>;
  static ɵfac: i0.ɵɵFactoryDeclaration<Col, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<Col, "l-col", never, {
    "span": {
      "alias": "span";
      "required": false;
      "isSignal": true;
    };
    "offset": {
      "alias": "offset";
      "required": false;
      "isSignal": true;
    };
    "order": {
      "alias": "order";
      "required": false;
      "isSignal": true;
    };
    "flex": {
      "alias": "flex";
      "required": false;
      "isSignal": true;
    };
    "xs": {
      "alias": "xs";
      "required": false;
      "isSignal": true;
    };
    "sm": {
      "alias": "sm";
      "required": false;
      "isSignal": true;
    };
    "md": {
      "alias": "md";
      "required": false;
      "isSignal": true;
    };
    "lg": {
      "alias": "lg";
      "required": false;
      "isSignal": true;
    };
    "xl": {
      "alias": "xl";
      "required": false;
      "isSignal": true;
    };
    "xxl": {
      "alias": "xxl";
      "required": false;
      "isSignal": true;
    };
  }, {}, never, ["*"], true, never>;
}
/** Preset (`xs` 4px, `sm` 8px, `md` 16px, `lg` 24px, `xl` 32px), a pixel number, or any CSS size. */
export type SpacerSize = 'xs' | 'sm' | 'md' | 'lg' | 'xl' | number | string;
/**
 * Empty block that adds fixed space between elements — inspired by Mantine's
 * `Space`. Use `h` for vertical gaps in a stack and `w` for horizontal gaps in
 * a row; it never shrinks, so the space holds inside flex layouts.
 *
 * ```html
 * <p>First</p>
 * <l-spacer h="md" />
 * <p>Second</p>
 *
 * <l-flex align="center">
 *   <l-button>Save</l-button>
 *   <l-spacer [w]="24" />
 *   <l-button>Cancel</l-button>
 * </l-flex>
 * ```
 */
export declare class Spacer {
  /** Vertical space — sets the height. */
  readonly h: import("@angular/core").InputSignal<SpacerSize | undefined>;
  /** Horizontal space — sets the width. */
  readonly w: import("@angular/core").InputSignal<SpacerSize | undefined>;
  protected readonly _height: import("@angular/core").Signal<string | null>;
  protected readonly _width: import("@angular/core").Signal<string | null>;
  static ɵfac: i0.ɵɵFactoryDeclaration<Spacer, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<Spacer, "l-spacer", never, {
    "h": {
      "alias": "h";
      "required": false;
      "isSignal": true;
    };
    "w": {
      "alias": "w";
      "required": false;
      "isSignal": true;
    };
  }, {}, never, never, true, never>;
}
export type { AccordionVariant, BadgeSize, BreadcrumbItem, CheckState, ChipSize, ChipVariant, ConfirmDialogData, DrawerConfig, DrawerPosition, FilterChange, FilterColumn, MenuMode, ModalAnimation, ModalConfig, NotificationOptions, NotificationPosition, NotificationType, OtpSize, OtpType, PageEvent, RejectReason, SegmentedOption, SegmentedOrientation, SegmentedSize, SortDirection, Step, StepStatus, StepperOrientation, TableAlign, TableColumn, TableSort, TabsOrientation, TabsSize, TabsVariant, TooltipPlacement, TooltipSide, TooltipTrigger, TreeNode, UploadFile, UploadListType, UploadStatus, UploadVariant };